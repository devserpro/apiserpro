# Página Web da Documentação das APIs SERPRO

## Endereço para acesso padrao as páginas da API:

https://devserpro.github.io/apis/

## Para mostrar link apenas para determinada API (ex: API CPF)

https://devserpro.github.io/apis/?api=cpf

## Para mostrar link para determinada API, com informações do cliente (para teste em Produção)

https://devserpro.github.io/apis/?api=cpf&bearer=123456789&amb=https://apigateway.serpro.gov.br
