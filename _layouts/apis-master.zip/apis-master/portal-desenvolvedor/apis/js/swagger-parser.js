/*!
 * Swagger Parser v6.0.3 (January 10th 2019)
 * 
 * https://apidevtools.org/swagger-parser/
 * 
 * @author  James Messinger (https://jamesmessinger.com)
 * @license MIT
 */
(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.SwaggerParser = f()}})(function(){var define,module,exports;return (function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
  "use strict";
  
  var validateSchema = require("./validators/schema"),
      validateSpec = require("./validators/spec"),
      normalizeArgs = require("json-schema-ref-parser/lib/normalize-args"),
      util = require("./util"),
      Options = require("./options"),
      maybe = require("call-me-maybe"),
      ono = require("ono"),
      $RefParser = require("json-schema-ref-parser"),
      dereference = require("json-schema-ref-parser/lib/dereference");
  
  module.exports = SwaggerParser;
  
  /**
   * This class parses a Swagger 2.0 or 3.0 API, resolves its JSON references and their resolved values,
   * and provides methods for traversing, dereferencing, and validating the API.
   *
   * @constructor
   * @extends $RefParser
   */
  function SwaggerParser () {
    $RefParser.apply(this, arguments);
  }
  
  util.inherits(SwaggerParser, $RefParser);
  SwaggerParser.YAML = $RefParser.YAML;
  SwaggerParser.parse = $RefParser.parse;
  SwaggerParser.resolve = $RefParser.resolve;
  SwaggerParser.bundle = $RefParser.bundle;
  SwaggerParser.dereference = $RefParser.dereference;
  
  /**
   * Alias {@link $RefParser#schema} as {@link SwaggerParser#api}
   */
  Object.defineProperty(SwaggerParser.prototype, "api", {
    configurable: true,
    enumerable: true,
    get: function () {
      return this.schema;
    }
  });
  
  /**
   * Parses the given Swagger API.
   * This method does not resolve any JSON references.
   * It just reads a single file in JSON or YAML format, and parse it as a JavaScript object.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [api] - The Swagger API object. This object will be used instead of reading from `path`.
   * @param {ParserOptions} [options] - Options that determine how the API is parsed
   * @param {function} [callback] - An error-first callback. The second parameter is the parsed API object.
   * @returns {Promise} - The returned promise resolves with the parsed API object.
   */
  SwaggerParser.prototype.parse = function (path, api, options, callback) {
    var args = normalizeArgs(arguments);
    args.options = new Options(args.options);
  
    return $RefParser.prototype.parse.call(this, args.path, args.schema, args.options)
      .then(function (schema) {
        if (schema.swagger) {
          // Verify that the parsed object is a Swagger API
          if (schema.swagger === undefined || schema.info === undefined || schema.paths === undefined) {
            throw ono.syntax("%s is not a valid Swagger API definition", args.path || args.schema);
          }
          else if (typeof schema.swagger === "number") {
            // This is a very common mistake, so give a helpful error message
            throw ono.syntax('Swagger version number must be a string (e.g. "2.0") not a number.');
          }
          else if (typeof schema.info.version === "number") {
            // This is a very common mistake, so give a helpful error message
            throw ono.syntax('API version number must be a string (e.g. "1.0.0") not a number.');
          }
          else if (schema.swagger !== "2.0") {
            throw ono.syntax("Unrecognized Swagger version: %d. Expected 2.0", schema.swagger);
          }
        }
        else {
          var supportedVersions = ["3.0.0", "3.0.1", "3.0.2"];
  
          // Verify that the parsed object is a Openapi API
          if (schema.openapi === undefined || schema.info === undefined || schema.paths === undefined) {
            throw ono.syntax("%s is not a valid Openapi API definition", args.path || args.schema);
          }
          else if (typeof schema.openapi === "number") {
            // This is a very common mistake, so give a helpful error message
            throw ono.syntax('Openapi version number must be a string (e.g. "3.0.0") not a number.');
          }
          else if (typeof schema.info.version === "number") {
            // This is a very common mistake, so give a helpful error message
            throw ono.syntax('API version number must be a string (e.g. "1.0.0") not a number.');
          }
          else if (supportedVersions.indexOf(schema.openapi) === -1) {
            throw ono.syntax(
              "Unsupported OpenAPI version: %d. Swagger Parser only supports versions %s",
              schema.openapi, supportedVersions.join(", "));
          }
        }
  
        // Looks good!
        return maybe(args.callback, Promise.resolve(schema));
      })
      .catch(function (err) {
        return maybe(args.callback, Promise.reject(err));
      });
  };
  
  /**
   * Parses, dereferences, and validates the given Swagger API.
   * Depending on the options, validation can include JSON Schema validation and/or Swagger Spec validation.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [api] - The Swagger API object. This object will be used instead of reading from `path`.
   * @param {ParserOptions} [options] - Options that determine how the API is parsed, dereferenced, and validated
   * @param {function} [callback] - An error-first callback. The second parameter is the parsed API object.
   * @returns {Promise} - The returned promise resolves with the parsed API object.
   */
  SwaggerParser.validate = function (path, api, options, callback) {
    var Class = this; // eslint-disable-line consistent-this
    var instance = new Class();
    return instance.validate.apply(instance, arguments);
  };
  
  /**
   * Parses, dereferences, and validates the given Swagger API.
   * Depending on the options, validation can include JSON Schema validation and/or Swagger Spec validation.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [api] - The Swagger API object. This object will be used instead of reading from `path`.
   * @param {ParserOptions} [options] - Options that determine how the API is parsed, dereferenced, and validated
   * @param {function} [callback] - An error-first callback. The second parameter is the parsed API object.
   * @returns {Promise} - The returned promise resolves with the parsed API object.
   */
  SwaggerParser.prototype.validate = function (path, api, options, callback) {
    var me = this;
    var args = normalizeArgs(arguments);
    args.options = new Options(args.options);
  
    // ZSchema doesn't support circular objects, so don't dereference circular $refs yet
    // (see https://github.com/zaggino/z-schema/issues/137)
    var circular$RefOption = args.options.dereference.circular;
    args.options.validate.schema && (args.options.dereference.circular = "ignore");
  
    return this.dereference(args.path, args.schema, args.options)
      .then(function () {
        // Restore the original options, now that we're done dereferencing
        args.options.dereference.circular = circular$RefOption;
  
        if (args.options.validate.schema) {
          // Validate the API against the Swagger schema
          // NOTE: This is safe to do, because we haven't dereferenced circular $refs yet
          validateSchema(me.api);
  
          if (me.$refs.circular) {
            if (circular$RefOption === true) {
              // The API has circular references,
              // so we need to do a second-pass to fully-dereference it
              dereference(me, args.options);
            }
            else if (circular$RefOption === false) {
              // The API has circular references, and they're not allowed, so throw an error
              throw ono.reference("The API contains circular references");
            }
          }
        }
  
        if (args.options.validate.spec) {
          // Validate the API against the Swagger spec
          validateSpec(me.api);
        }
  
        return maybe(args.callback, Promise.resolve(me.schema));
      })
      .catch(function (err) {
        return maybe(args.callback, Promise.reject(err));
      });
  };
  
  /**
   * The Swagger object
   * https://github.com/swagger-api/swagger-spec/blob/master/versions/2.0.md#swagger-object
   *
   * @typedef {{swagger: string, info: {}, paths: {}}} SwaggerObject
   */
  
  },{"./options":2,"./util":3,"./validators/schema":4,"./validators/spec":5,"call-me-maybe":11,"json-schema-ref-parser":73,"json-schema-ref-parser/lib/dereference":72,"json-schema-ref-parser/lib/normalize-args":74,"ono":122}],2:[function(require,module,exports){
  "use strict";
  
  var $RefParserOptions = require("json-schema-ref-parser/lib/options"),
      schemaValidator = require("./validators/schema"),
      specValidator = require("./validators/spec"),
      util = require("util");
  
  module.exports = ParserOptions;
  
  /**
   * Options that determine how Swagger APIs are parsed, resolved, dereferenced, and validated.
   *
   * @param {object|ParserOptions} [options] - Overridden options
   * @constructor
   * @extends $RefParserOptions
   */
  function ParserOptions (options) {
    $RefParserOptions.call(this, ParserOptions.defaults);
    $RefParserOptions.apply(this, arguments);
  }
  
  ParserOptions.defaults = {
    /**
     * Determines how the API definition will be validated.
     *
     * You can add additional validators of your own, replace an existing one with
     * your own implemenation, or disable any validator by setting it to false.
     */
    validate: {
      schema: schemaValidator,
      spec: specValidator,
    },
  };
  
  util.inherits(ParserOptions, $RefParserOptions);
  
  },{"./validators/schema":4,"./validators/spec":5,"json-schema-ref-parser/lib/options":75,"util":152}],3:[function(require,module,exports){
  "use strict";
  
  var util = require("util");
  
  exports.format = util.format;
  exports.inherits = util.inherits;
  
  /**
   * Regular Expression that matches Swagger path params.
   */
  exports.swaggerParamRegExp = /\{([^/}]+)}/g;
  
  },{"util":152}],4:[function(require,module,exports){
  "use strict";
  
  var util = require("../util"),
      ono = require("ono"),
      ZSchema = require("z-schema");
  
  module.exports = validateSchema;
  
  initializeZSchema();
  
  /**
   * Validates the given Swagger API against the Swagger 2.0 or 3.0 schema.
   *
   * @param {SwaggerObject} api
   */
  function validateSchema (api) {
    // Choose the appropriate schema (Swagger or OpenAPI)
    var schema = api.swagger
      ? require("swagger-schema-official/schema.json")
      : require("openapi-schema-validation/schema/openapi-3.0.json");
  
    var isValid = ZSchema.validate(api, schema);
  
    if (!isValid) {
      var err = ZSchema.getLastError();
      var message = "Swagger schema validation failed. \n" + formatZSchemaError(err.details);
      throw ono.syntax(err, { details: err.details }, message);
    }
  }
  
  /**
   * Performs one-time initialization logic to prepare for Swagger Schema validation.
   */
  function initializeZSchema () {
    ZSchema = new ZSchema({
      breakOnFirstError: true,
      noExtraKeywords: true,
      ignoreUnknownFormats: false,
      reportPathAsArray: true
    });
  }
  
  /**
   * Z-Schema validation errors are a nested tree structure.
   * This function crawls that tree and builds an error message string.
   *
   * @param {object[]}  errors     - The Z-Schema error details
   * @param {string}    [indent]   - The whitespace used to indent the error message
   * @returns {string}
   */
  function formatZSchemaError (errors, indent) {
    indent = indent || "  ";
    var message = "";
    errors.forEach(function (error, index) {
      message += util.format("%s%s at #/%s\n", indent, error.message, error.path.join("/"));
      if (error.inner) {
        message += formatZSchemaError(error.inner, indent + "  ");
      }
    });
    return message;
  }
  
  },{"../util":3,"ono":122,"openapi-schema-validation/schema/openapi-3.0.json":123,"swagger-schema-official/schema.json":145,"z-schema":241}],5:[function(require,module,exports){
  "use strict";
  
  var util = require("../util"),
      ono = require("ono"),
      swaggerMethods = require("swagger-methods"),
      primitiveTypes = ["array", "boolean", "integer", "number", "string"],
      schemaTypes = ["array", "boolean", "integer", "number", "string", "object", "null", undefined];
  
  module.exports = validateSpec;
  
  /**
   * Validates parts of the Swagger 2.0 spec that aren't covered by the Swagger 2.0 JSON Schema.
   *
   * @param {SwaggerObject} api
   */
  function validateSpec (api) {
    if (api.openapi) {
      // We don't (yet) support validating against the OpenAPI spec
      return;
    }
  
    var paths = Object.keys(api.paths || {});
    var operationIds = [];
    paths.forEach(function (pathName) {
      var path = api.paths[pathName];
      var pathId = "/paths" + pathName;
  
      if (path && pathName.indexOf("/") === 0) {
        validatePath(api, path, pathId, operationIds);
      }
    });
    var definitions = Object.keys(api.definitions || {});
    definitions.forEach(function (definitionName) {
      var definition = api.definitions[definitionName];
      var definitionId = "/definitions/" + definitionName;
      validateRequiredPropertiesExist(definition, definitionId);
    });
  }
  
  /**
   * Validates the given path.
   *
   * @param {SwaggerObject} api           - The entire Swagger API object
   * @param {object}        path          - A Path object, from the Swagger API
   * @param {string}        pathId        - A value that uniquely identifies the path
   * @param {string}        operationIds  - An array of collected operationIds found in other paths
   */
  function validatePath (api, path, pathId, operationIds) {
    swaggerMethods.forEach(function (operationName) {
      var operation = path[operationName];
      var operationId = pathId + "/" + operationName;
  
      if (operation) {
        var declaredOperationId = operation.operationId;
        if (declaredOperationId) {
          if (operationIds.indexOf(declaredOperationId) === -1) {
            operationIds.push(declaredOperationId);
          }
          else {
            throw ono.syntax("Validation failed. Duplicate operation id '%s'", declaredOperationId);
          }
        }
        validateParameters(api, path, pathId, operation, operationId);
  
        var responses = Object.keys(operation.responses || {});
        responses.forEach(function (responseName) {
          var response = operation.responses[responseName];
          var responseId = operationId + "/responses/" + responseName;
          validateResponse(responseName, (response || {}), responseId);
        });
      }
    });
  }
  
  /**
   * Validates the parameters for the given operation.
   *
   * @param {SwaggerObject} api           - The entire Swagger API object
   * @param {object}        path          - A Path object, from the Swagger API
   * @param {string}        pathId        - A value that uniquely identifies the path
   * @param {object}        operation     - An Operation object, from the Swagger API
   * @param {string}        operationId   - A value that uniquely identifies the operation
   */
  function validateParameters (api, path, pathId, operation, operationId) {
    var pathParams = path.parameters || [];
    var operationParams = operation.parameters || [];
  
    // Check for duplicate path parameters
    try {
      checkForDuplicates(pathParams);
    }
    catch (e) {
      throw ono.syntax(e, "Validation failed. %s has duplicate parameters", pathId);
    }
  
    // Check for duplicate operation parameters
    try {
      checkForDuplicates(operationParams);
    }
    catch (e) {
      throw ono.syntax(e, "Validation failed. %s has duplicate parameters", operationId);
    }
  
    // Combine the path and operation parameters,
    // with the operation params taking precedence over the path params
    var params = pathParams.reduce(function (combinedParams, value) {
      var duplicate = combinedParams.some(function (param) {
        return param.in === value.in && param.name === value.name;
      });
      if (!duplicate) {
        combinedParams.push(value);
      }
      return combinedParams;
    }, operationParams.slice());
  
    validateBodyParameters(params, operationId);
    validatePathParameters(params, pathId, operationId);
    validateParameterTypes(params, api, operation, operationId);
  }
  
  /**
   * Validates body and formData parameters for the given operation.
   *
   * @param   {object[]}  params       -  An array of Parameter objects
   * @param   {string}    operationId  -  A value that uniquely identifies the operation
   */
  function validateBodyParameters (params, operationId) {
    var bodyParams = params.filter(function (param) { return param.in === "body"; });
    var formParams = params.filter(function (param) { return param.in === "formData"; });
  
    // There can only be one "body" parameter
    if (bodyParams.length > 1) {
      throw ono.syntax(
        "Validation failed. %s has %d body parameters. Only one is allowed.",
        operationId, bodyParams.length
      );
    }
    else if (bodyParams.length > 0 && formParams.length > 0) {
      // "body" params and "formData" params are mutually exclusive
      throw ono.syntax(
        "Validation failed. %s has body parameters and formData parameters. Only one or the other is allowed.",
        operationId
      );
    }
  }
  
  /**
   * Validates path parameters for the given path.
   *
   * @param   {object[]}  params        - An array of Parameter objects
   * @param   {string}    pathId        - A value that uniquely identifies the path
   * @param   {string}    operationId   - A value that uniquely identifies the operation
   */
  function validatePathParameters (params, pathId, operationId) {
    // Find all {placeholders} in the path string
    var placeholders = pathId.match(util.swaggerParamRegExp) || [];
  
    // Check for duplicates
    for (var i = 0; i < placeholders.length; i++) {
      for (var j = i + 1; j < placeholders.length; j++) {
        if (placeholders[i] === placeholders[j]) {
          throw ono.syntax(
            "Validation failed. %s has multiple path placeholders named %s", operationId, placeholders[i]);
        }
      }
    }
  
    params
      .filter(function (param) { return param.in === "path"; })
      .forEach(function (param) {
        if (param.required !== true) {
          throw ono.syntax(
            'Validation failed. Path parameters cannot be optional. Set required=true for the "%s" parameter at %s',
            param.name,
            operationId
          );
        }
        var match = placeholders.indexOf("{" + param.name + "}");
        if (match === -1) {
          throw ono.syntax(
            'Validation failed. %s has a path parameter named "%s", ' +
            "but there is no corresponding {%s} in the path string",
            operationId,
            param.name,
            param.name
          );
        }
        placeholders.splice(match, 1);
      });
  
    if (placeholders.length > 0) {
      throw ono.syntax("Validation failed. %s is missing path parameter(s) for %s", operationId, placeholders);
    }
  }
  
  /**
   * Validates data types of parameters for the given operation.
   *
   * @param   {object[]}  params       -  An array of Parameter objects
   * @param   {object}    api          -  The entire Swagger API object
   * @param   {object}    operation    -  An Operation object, from the Swagger API
   * @param   {string}    operationId  -  A value that uniquely identifies the operation
   */
  function validateParameterTypes (params, api, operation, operationId) {
    params.forEach(function (param) {
      var parameterId = operationId + "/parameters/" + param.name;
      var schema, validTypes;
  
      switch (param.in) {
        case "body":
          schema = param.schema;
          validTypes = schemaTypes;
          break;
        case "formData":
          schema = param;
          validTypes = primitiveTypes.concat("file");
          break;
        default:
          schema = param;
          validTypes = primitiveTypes;
      }
  
      validateSchema(schema, parameterId, validTypes);
      validateRequiredPropertiesExist(schema, parameterId);
  
      if (schema.type === "file") {
        // "file" params must consume at least one of these MIME types
        var formData = /multipart\/(.*\+)?form-data/;
        var urlEncoded = /application\/(.*\+)?x-www-form-urlencoded/;
  
        var consumes = operation.consumes || api.consumes || [];
  
        var hasValidMimeType = consumes.some(function (consume) {
          return formData.test(consume) || urlEncoded.test(consume);
        });
  
        if (!hasValidMimeType) {
          throw ono.syntax(
            "Validation failed. %s has a file parameter, so it must consume multipart/form-data " +
            "or application/x-www-form-urlencoded",
            operationId
          );
        }
      }
    });
  }
  
  /**
   * Checks the given parameter list for duplicates, and throws an error if found.
   *
   * @param   {object[]}  params  - An array of Parameter objects
   */
  function checkForDuplicates (params) {
    for (var i = 0; i < params.length - 1; i++) {
      var outer = params[i];
      for (var j = i + 1; j < params.length; j++) {
        var inner = params[j];
        if (outer.name === inner.name && outer.in === inner.in) {
          throw ono.syntax('Validation failed. Found multiple %s parameters named "%s"', outer.in, outer.name);
        }
      }
    }
  }
  
  /**
   * Validates the given response object.
   *
   * @param   {string}    code        -  The HTTP response code (or "default")
   * @param   {object}    response    -  A Response object, from the Swagger API
   * @param   {string}    responseId  -  A value that uniquely identifies the response
   */
  function validateResponse (code, response, responseId) {
    if (code !== "default" && (code < 100 || code > 599)) {
      throw ono.syntax("Validation failed. %s has an invalid response code (%s)", responseId, code);
    }
  
    var headers = Object.keys(response.headers || {});
    headers.forEach(function (headerName) {
      var header = response.headers[headerName];
      var headerId = responseId + "/headers/" + headerName;
      validateSchema(header, headerId, primitiveTypes);
    });
  
    if (response.schema) {
      var validTypes = schemaTypes.concat("file");
      if (validTypes.indexOf(response.schema.type) === -1) {
        throw ono.syntax(
          "Validation failed. %s has an invalid response schema type (%s)", responseId, response.schema.type);
      }
      else {
        validateSchema(response.schema, responseId + "/schema", validTypes);
      }
    }
  }
  
  /**
   * Validates the given Swagger schema object.
   *
   * @param {object}    schema      - A Schema object, from the Swagger API
   * @param {string}    schemaId    - A value that uniquely identifies the schema object
   * @param {string[]}  validTypes  - An array of the allowed schema types
   */
  function validateSchema (schema, schemaId, validTypes) {
    if (validTypes.indexOf(schema.type) === -1) {
      throw ono.syntax(
        "Validation failed. %s has an invalid type (%s)", schemaId, schema.type);
    }
  
    if (schema.type === "array" && !schema.items) {
      throw ono.syntax('Validation failed. %s is an array, so it must include an "items" schema', schemaId);
    }
  }
  
  /**
   * Validates that the declared properties of the given Swagger schema object actually exist.
   *
   * @param {object}    schema      - A Schema object, from the Swagger API
   * @param {string}    schemaId    - A value that uniquely identifies the schema object
   */
  function validateRequiredPropertiesExist (schema, schemaId) {
    /**
     * Recursively collects all properties of the schema and its ancestors. They are added to the props object.
     */
    function collectProperties (schemaObj, props) {
      if (schemaObj.properties) {
        for (var property in schemaObj.properties) {
          if (schemaObj.properties.hasOwnProperty(property)) {
            props[property] = schemaObj.properties[property];
          }
        }
      }
      if (schemaObj.allOf) {
        schemaObj.allOf.forEach(function (parent) {
          collectProperties(parent, props);
        });
      }
    }
  
    if (schema.required && Array.isArray(schema.required)) {
      var props = {};
      collectProperties(schema, props);
      schema.required.forEach(function (requiredProperty) {
        if (!props[requiredProperty]) {
          throw ono.syntax("Validation failed. Property '%s' listed as required but does not exist in '%s'",
            requiredProperty, schemaId);
        }
      });
    }
  }
  
  },{"../util":3,"ono":122,"swagger-methods":144}],6:[function(require,module,exports){
  'use strict'
  
  exports.byteLength = byteLength
  exports.toByteArray = toByteArray
  exports.fromByteArray = fromByteArray
  
  var lookup = []
  var revLookup = []
  var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array
  
  var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
  for (var i = 0, len = code.length; i < len; ++i) {
    lookup[i] = code[i]
    revLookup[code.charCodeAt(i)] = i
  }
  
  // Support decoding URL-safe base64 strings, as Node.js does.
  // See: https://en.wikipedia.org/wiki/Base64#URL_applications
  revLookup['-'.charCodeAt(0)] = 62
  revLookup['_'.charCodeAt(0)] = 63
  
  function getLens (b64) {
    var len = b64.length
  
    if (len % 4 > 0) {
      throw new Error('Invalid string. Length must be a multiple of 4')
    }
  
    // Trim off extra bytes after placeholder bytes are found
    // See: https://github.com/beatgammit/base64-js/issues/42
    var validLen = b64.indexOf('=')
    if (validLen === -1) validLen = len
  
    var placeHoldersLen = validLen === len
      ? 0
      : 4 - (validLen % 4)
  
    return [validLen, placeHoldersLen]
  }
  
  // base64 is 4/3 + up to two characters of the original data
  function byteLength (b64) {
    var lens = getLens(b64)
    var validLen = lens[0]
    var placeHoldersLen = lens[1]
    return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
  }
  
  function _byteLength (b64, validLen, placeHoldersLen) {
    return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
  }
  
  function toByteArray (b64) {
    var tmp
    var lens = getLens(b64)
    var validLen = lens[0]
    var placeHoldersLen = lens[1]
  
    var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen))
  
    var curByte = 0
  
    // if there are placeholders, only get up to the last complete 4 chars
    var len = placeHoldersLen > 0
      ? validLen - 4
      : validLen
  
    for (var i = 0; i < len; i += 4) {
      tmp =
        (revLookup[b64.charCodeAt(i)] << 18) |
        (revLookup[b64.charCodeAt(i + 1)] << 12) |
        (revLookup[b64.charCodeAt(i + 2)] << 6) |
        revLookup[b64.charCodeAt(i + 3)]
      arr[curByte++] = (tmp >> 16) & 0xFF
      arr[curByte++] = (tmp >> 8) & 0xFF
      arr[curByte++] = tmp & 0xFF
    }
  
    if (placeHoldersLen === 2) {
      tmp =
        (revLookup[b64.charCodeAt(i)] << 2) |
        (revLookup[b64.charCodeAt(i + 1)] >> 4)
      arr[curByte++] = tmp & 0xFF
    }
  
    if (placeHoldersLen === 1) {
      tmp =
        (revLookup[b64.charCodeAt(i)] << 10) |
        (revLookup[b64.charCodeAt(i + 1)] << 4) |
        (revLookup[b64.charCodeAt(i + 2)] >> 2)
      arr[curByte++] = (tmp >> 8) & 0xFF
      arr[curByte++] = tmp & 0xFF
    }
  
    return arr
  }
  
  function tripletToBase64 (num) {
    return lookup[num >> 18 & 0x3F] +
      lookup[num >> 12 & 0x3F] +
      lookup[num >> 6 & 0x3F] +
      lookup[num & 0x3F]
  }
  
  function encodeChunk (uint8, start, end) {
    var tmp
    var output = []
    for (var i = start; i < end; i += 3) {
      tmp =
        ((uint8[i] << 16) & 0xFF0000) +
        ((uint8[i + 1] << 8) & 0xFF00) +
        (uint8[i + 2] & 0xFF)
      output.push(tripletToBase64(tmp))
    }
    return output.join('')
  }
  
  function fromByteArray (uint8) {
    var tmp
    var len = uint8.length
    var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
    var parts = []
    var maxChunkLength = 16383 // must be multiple of 3
  
    // go through the array every three bytes, we'll deal with trailing stuff later
    for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
      parts.push(encodeChunk(
        uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)
      ))
    }
  
    // pad the end with zeros, but make sure to not forget the extra bytes
    if (extraBytes === 1) {
      tmp = uint8[len - 1]
      parts.push(
        lookup[tmp >> 2] +
        lookup[(tmp << 4) & 0x3F] +
        '=='
      )
    } else if (extraBytes === 2) {
      tmp = (uint8[len - 2] << 8) + uint8[len - 1]
      parts.push(
        lookup[tmp >> 10] +
        lookup[(tmp >> 4) & 0x3F] +
        lookup[(tmp << 2) & 0x3F] +
        '='
      )
    }
  
    return parts.join('')
  }
  
  },{}],7:[function(require,module,exports){
  
  },{}],8:[function(require,module,exports){
  (function (global){
  /*! https://mths.be/punycode v1.4.1 by @mathias */
  ;(function(root) {
  
    /** Detect free variables */
    var freeExports = typeof exports == 'object' && exports &&
      !exports.nodeType && exports;
    var freeModule = typeof module == 'object' && module &&
      !module.nodeType && module;
    var freeGlobal = typeof global == 'object' && global;
    if (
      freeGlobal.global === freeGlobal ||
      freeGlobal.window === freeGlobal ||
      freeGlobal.self === freeGlobal
    ) {
      root = freeGlobal;
    }
  
    /**
     * The `punycode` object.
     * @name punycode
     * @type Object
     */
    var punycode,
  
    /** Highest positive signed 32-bit float value */
    maxInt = 2147483647, // aka. 0x7FFFFFFF or 2^31-1
  
    /** Bootstring parameters */
    base = 36,
    tMin = 1,
    tMax = 26,
    skew = 38,
    damp = 700,
    initialBias = 72,
    initialN = 128, // 0x80
    delimiter = '-', // '\x2D'
  
    /** Regular expressions */
    regexPunycode = /^xn--/,
    regexNonASCII = /[^\x20-\x7E]/, // unprintable ASCII chars + non-ASCII chars
    regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g, // RFC 3490 separators
  
    /** Error messages */
    errors = {
      'overflow': 'Overflow: input needs wider integers to process',
      'not-basic': 'Illegal input >= 0x80 (not a basic code point)',
      'invalid-input': 'Invalid input'
    },
  
    /** Convenience shortcuts */
    baseMinusTMin = base - tMin,
    floor = Math.floor,
    stringFromCharCode = String.fromCharCode,
  
    /** Temporary variable */
    key;
  
    /*--------------------------------------------------------------------------*/
  
    /**
     * A generic error utility function.
     * @private
     * @param {String} type The error type.
     * @returns {Error} Throws a `RangeError` with the applicable error message.
     */
    function error(type) {
      throw new RangeError(errors[type]);
    }
  
    /**
     * A generic `Array#map` utility function.
     * @private
     * @param {Array} array The array to iterate over.
     * @param {Function} callback The function that gets called for every array
     * item.
     * @returns {Array} A new array of values returned by the callback function.
     */
    function map(array, fn) {
      var length = array.length;
      var result = [];
      while (length--) {
        result[length] = fn(array[length]);
      }
      return result;
    }
  
    /**
     * A simple `Array#map`-like wrapper to work with domain name strings or email
     * addresses.
     * @private
     * @param {String} domain The domain name or email address.
     * @param {Function} callback The function that gets called for every
     * character.
     * @returns {Array} A new string of characters returned by the callback
     * function.
     */
    function mapDomain(string, fn) {
      var parts = string.split('@');
      var result = '';
      if (parts.length > 1) {
        // In email addresses, only the domain name should be punycoded. Leave
        // the local part (i.e. everything up to `@`) intact.
        result = parts[0] + '@';
        string = parts[1];
      }
      // Avoid `split(regex)` for IE8 compatibility. See #17.
      string = string.replace(regexSeparators, '\x2E');
      var labels = string.split('.');
      var encoded = map(labels, fn).join('.');
      return result + encoded;
    }
  
    /**
     * Creates an array containing the numeric code points of each Unicode
     * character in the string. While JavaScript uses UCS-2 internally,
     * this function will convert a pair of surrogate halves (each of which
     * UCS-2 exposes as separate characters) into a single code point,
     * matching UTF-16.
     * @see `punycode.ucs2.encode`
     * @see <https://mathiasbynens.be/notes/javascript-encoding>
     * @memberOf punycode.ucs2
     * @name decode
     * @param {String} string The Unicode input string (UCS-2).
     * @returns {Array} The new array of code points.
     */
    function ucs2decode(string) {
      var output = [],
          counter = 0,
          length = string.length,
          value,
          extra;
      while (counter < length) {
        value = string.charCodeAt(counter++);
        if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
          // high surrogate, and there is a next character
          extra = string.charCodeAt(counter++);
          if ((extra & 0xFC00) == 0xDC00) { // low surrogate
            output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
          } else {
            // unmatched surrogate; only append this code unit, in case the next
            // code unit is the high surrogate of a surrogate pair
            output.push(value);
            counter--;
          }
        } else {
          output.push(value);
        }
      }
      return output;
    }
  
    /**
     * Creates a string based on an array of numeric code points.
     * @see `punycode.ucs2.decode`
     * @memberOf punycode.ucs2
     * @name encode
     * @param {Array} codePoints The array of numeric code points.
     * @returns {String} The new Unicode string (UCS-2).
     */
    function ucs2encode(array) {
      return map(array, function(value) {
        var output = '';
        if (value > 0xFFFF) {
          value -= 0x10000;
          output += stringFromCharCode(value >>> 10 & 0x3FF | 0xD800);
          value = 0xDC00 | value & 0x3FF;
        }
        output += stringFromCharCode(value);
        return output;
      }).join('');
    }
  
    /**
     * Converts a basic code point into a digit/integer.
     * @see `digitToBasic()`
     * @private
     * @param {Number} codePoint The basic numeric code point value.
     * @returns {Number} The numeric value of a basic code point (for use in
     * representing integers) in the range `0` to `base - 1`, or `base` if
     * the code point does not represent a value.
     */
    function basicToDigit(codePoint) {
      if (codePoint - 48 < 10) {
        return codePoint - 22;
      }
      if (codePoint - 65 < 26) {
        return codePoint - 65;
      }
      if (codePoint - 97 < 26) {
        return codePoint - 97;
      }
      return base;
    }
  
    /**
     * Converts a digit/integer into a basic code point.
     * @see `basicToDigit()`
     * @private
     * @param {Number} digit The numeric value of a basic code point.
     * @returns {Number} The basic code point whose value (when used for
     * representing integers) is `digit`, which needs to be in the range
     * `0` to `base - 1`. If `flag` is non-zero, the uppercase form is
     * used; else, the lowercase form is used. The behavior is undefined
     * if `flag` is non-zero and `digit` has no uppercase form.
     */
    function digitToBasic(digit, flag) {
      //  0..25 map to ASCII a..z or A..Z
      // 26..35 map to ASCII 0..9
      return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
    }
  
    /**
     * Bias adaptation function as per section 3.4 of RFC 3492.
     * https://tools.ietf.org/html/rfc3492#section-3.4
     * @private
     */
    function adapt(delta, numPoints, firstTime) {
      var k = 0;
      delta = firstTime ? floor(delta / damp) : delta >> 1;
      delta += floor(delta / numPoints);
      for (/* no initialization */; delta > baseMinusTMin * tMax >> 1; k += base) {
        delta = floor(delta / baseMinusTMin);
      }
      return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
    }
  
    /**
     * Converts a Punycode string of ASCII-only symbols to a string of Unicode
     * symbols.
     * @memberOf punycode
     * @param {String} input The Punycode string of ASCII-only symbols.
     * @returns {String} The resulting string of Unicode symbols.
     */
    function decode(input) {
      // Don't use UCS-2
      var output = [],
          inputLength = input.length,
          out,
          i = 0,
          n = initialN,
          bias = initialBias,
          basic,
          j,
          index,
          oldi,
          w,
          k,
          digit,
          t,
          /** Cached calculation results */
          baseMinusT;
  
      // Handle the basic code points: let `basic` be the number of input code
      // points before the last delimiter, or `0` if there is none, then copy
      // the first basic code points to the output.
  
      basic = input.lastIndexOf(delimiter);
      if (basic < 0) {
        basic = 0;
      }
  
      for (j = 0; j < basic; ++j) {
        // if it's not a basic code point
        if (input.charCodeAt(j) >= 0x80) {
          error('not-basic');
        }
        output.push(input.charCodeAt(j));
      }
  
      // Main decoding loop: start just after the last delimiter if any basic code
      // points were copied; start at the beginning otherwise.
  
      for (index = basic > 0 ? basic + 1 : 0; index < inputLength; /* no final expression */) {
  
        // `index` is the index of the next character to be consumed.
        // Decode a generalized variable-length integer into `delta`,
        // which gets added to `i`. The overflow checking is easier
        // if we increase `i` as we go, then subtract off its starting
        // value at the end to obtain `delta`.
        for (oldi = i, w = 1, k = base; /* no condition */; k += base) {
  
          if (index >= inputLength) {
            error('invalid-input');
          }
  
          digit = basicToDigit(input.charCodeAt(index++));
  
          if (digit >= base || digit > floor((maxInt - i) / w)) {
            error('overflow');
          }
  
          i += digit * w;
          t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
  
          if (digit < t) {
            break;
          }
  
          baseMinusT = base - t;
          if (w > floor(maxInt / baseMinusT)) {
            error('overflow');
          }
  
          w *= baseMinusT;
  
        }
  
        out = output.length + 1;
        bias = adapt(i - oldi, out, oldi == 0);
  
        // `i` was supposed to wrap around from `out` to `0`,
        // incrementing `n` each time, so we'll fix that now:
        if (floor(i / out) > maxInt - n) {
          error('overflow');
        }
  
        n += floor(i / out);
        i %= out;
  
        // Insert `n` at position `i` of the output
        output.splice(i++, 0, n);
  
      }
  
      return ucs2encode(output);
    }
  
    /**
     * Converts a string of Unicode symbols (e.g. a domain name label) to a
     * Punycode string of ASCII-only symbols.
     * @memberOf punycode
     * @param {String} input The string of Unicode symbols.
     * @returns {String} The resulting Punycode string of ASCII-only symbols.
     */
    function encode(input) {
      var n,
          delta,
          handledCPCount,
          basicLength,
          bias,
          j,
          m,
          q,
          k,
          t,
          currentValue,
          output = [],
          /** `inputLength` will hold the number of code points in `input`. */
          inputLength,
          /** Cached calculation results */
          handledCPCountPlusOne,
          baseMinusT,
          qMinusT;
  
      // Convert the input in UCS-2 to Unicode
      input = ucs2decode(input);
  
      // Cache the length
      inputLength = input.length;
  
      // Initialize the state
      n = initialN;
      delta = 0;
      bias = initialBias;
  
      // Handle the basic code points
      for (j = 0; j < inputLength; ++j) {
        currentValue = input[j];
        if (currentValue < 0x80) {
          output.push(stringFromCharCode(currentValue));
        }
      }
  
      handledCPCount = basicLength = output.length;
  
      // `handledCPCount` is the number of code points that have been handled;
      // `basicLength` is the number of basic code points.
  
      // Finish the basic string - if it is not empty - with a delimiter
      if (basicLength) {
        output.push(delimiter);
      }
  
      // Main encoding loop:
      while (handledCPCount < inputLength) {
  
        // All non-basic code points < n have been handled already. Find the next
        // larger one:
        for (m = maxInt, j = 0; j < inputLength; ++j) {
          currentValue = input[j];
          if (currentValue >= n && currentValue < m) {
            m = currentValue;
          }
        }
  
        // Increase `delta` enough to advance the decoder's <n,i> state to <m,0>,
        // but guard against overflow
        handledCPCountPlusOne = handledCPCount + 1;
        if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
          error('overflow');
        }
  
        delta += (m - n) * handledCPCountPlusOne;
        n = m;
  
        for (j = 0; j < inputLength; ++j) {
          currentValue = input[j];
  
          if (currentValue < n && ++delta > maxInt) {
            error('overflow');
          }
  
          if (currentValue == n) {
            // Represent delta as a generalized variable-length integer
            for (q = delta, k = base; /* no condition */; k += base) {
              t = k <= bias ? tMin : (k >= bias + tMax ? tMax : k - bias);
              if (q < t) {
                break;
              }
              qMinusT = q - t;
              baseMinusT = base - t;
              output.push(
                stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0))
              );
              q = floor(qMinusT / baseMinusT);
            }
  
            output.push(stringFromCharCode(digitToBasic(q, 0)));
            bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
            delta = 0;
            ++handledCPCount;
          }
        }
  
        ++delta;
        ++n;
  
      }
      return output.join('');
    }
  
    /**
     * Converts a Punycode string representing a domain name or an email address
     * to Unicode. Only the Punycoded parts of the input will be converted, i.e.
     * it doesn't matter if you call it on a string that has already been
     * converted to Unicode.
     * @memberOf punycode
     * @param {String} input The Punycoded domain name or email address to
     * convert to Unicode.
     * @returns {String} The Unicode representation of the given Punycode
     * string.
     */
    function toUnicode(input) {
      return mapDomain(input, function(string) {
        return regexPunycode.test(string)
          ? decode(string.slice(4).toLowerCase())
          : string;
      });
    }
  
    /**
     * Converts a Unicode string representing a domain name or an email address to
     * Punycode. Only the non-ASCII parts of the domain name will be converted,
     * i.e. it doesn't matter if you call it with a domain that's already in
     * ASCII.
     * @memberOf punycode
     * @param {String} input The domain name or email address to convert, as a
     * Unicode string.
     * @returns {String} The Punycode representation of the given domain name or
     * email address.
     */
    function toASCII(input) {
      return mapDomain(input, function(string) {
        return regexNonASCII.test(string)
          ? 'xn--' + encode(string)
          : string;
      });
    }
  
    /*--------------------------------------------------------------------------*/
  
    /** Define the public API */
    punycode = {
      /**
       * A string representing the current Punycode.js version number.
       * @memberOf punycode
       * @type String
       */
      'version': '1.4.1',
      /**
       * An object of methods to convert from JavaScript's internal character
       * representation (UCS-2) to Unicode code points, and back.
       * @see <https://mathiasbynens.be/notes/javascript-encoding>
       * @memberOf punycode
       * @type Object
       */
      'ucs2': {
        'decode': ucs2decode,
        'encode': ucs2encode
      },
      'decode': decode,
      'encode': encode,
      'toASCII': toASCII,
      'toUnicode': toUnicode
    };
  
    /** Expose `punycode` */
    // Some AMD build optimizers, like r.js, check for specific condition patterns
    // like the following:
    if (
      typeof define == 'function' &&
      typeof define.amd == 'object' &&
      define.amd
    ) {
      define('punycode', function() {
        return punycode;
      });
    } else if (freeExports && freeModule) {
      if (module.exports == freeExports) {
        // in Node.js, io.js, or RingoJS v0.8.0+
        freeModule.exports = punycode;
      } else {
        // in Narwhal or RingoJS v0.7.0-
        for (key in punycode) {
          punycode.hasOwnProperty(key) && (freeExports[key] = punycode[key]);
        }
      }
    } else {
      // in Rhino or a web browser
      root.punycode = punycode;
    }
  
  }(this));
  
  }).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{}],9:[function(require,module,exports){
  /*!
   * The buffer module from node.js, for the browser.
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   */
  /* eslint-disable no-proto */
  
  'use strict'
  
  var base64 = require('base64-js')
  var ieee754 = require('ieee754')
  
  exports.Buffer = Buffer
  exports.SlowBuffer = SlowBuffer
  exports.INSPECT_MAX_BYTES = 50
  
  var K_MAX_LENGTH = 0x7fffffff
  exports.kMaxLength = K_MAX_LENGTH
  
  /**
   * If `Buffer.TYPED_ARRAY_SUPPORT`:
   *   === true    Use Uint8Array implementation (fastest)
   *   === false   Print warning and recommend using `buffer` v4.x which has an Object
   *               implementation (most compatible, even IE6)
   *
   * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
   * Opera 11.6+, iOS 4.2+.
   *
   * We report that the browser does not support typed arrays if the are not subclassable
   * using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
   * (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
   * for __proto__ and has a buggy typed array implementation.
   */
  Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport()
  
  if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== 'undefined' &&
      typeof console.error === 'function') {
    console.error(
      'This browser lacks typed array (Uint8Array) support which is required by ' +
      '`buffer` v5.x. Use `buffer` v4.x if you require old browser support.'
    )
  }
  
  function typedArraySupport () {
    // Can typed array instances can be augmented?
    try {
      var arr = new Uint8Array(1)
      arr.__proto__ = { __proto__: Uint8Array.prototype, foo: function () { return 42 } }
      return arr.foo() === 42
    } catch (e) {
      return false
    }
  }
  
  Object.defineProperty(Buffer.prototype, 'parent', {
    enumerable: true,
    get: function () {
      if (!Buffer.isBuffer(this)) return undefined
      return this.buffer
    }
  })
  
  Object.defineProperty(Buffer.prototype, 'offset', {
    enumerable: true,
    get: function () {
      if (!Buffer.isBuffer(this)) return undefined
      return this.byteOffset
    }
  })
  
  function createBuffer (length) {
    if (length > K_MAX_LENGTH) {
      throw new RangeError('The value "' + length + '" is invalid for option "size"')
    }
    // Return an augmented `Uint8Array` instance
    var buf = new Uint8Array(length)
    buf.__proto__ = Buffer.prototype
    return buf
  }
  
  /**
   * The Buffer constructor returns instances of `Uint8Array` that have their
   * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
   * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
   * and the `Uint8Array` methods. Square bracket notation works as expected -- it
   * returns a single octet.
   *
   * The `Uint8Array` prototype remains unmodified.
   */
  
  function Buffer (arg, encodingOrOffset, length) {
    // Common case.
    if (typeof arg === 'number') {
      if (typeof encodingOrOffset === 'string') {
        throw new TypeError(
          'The "string" argument must be of type string. Received type number'
        )
      }
      return allocUnsafe(arg)
    }
    return from(arg, encodingOrOffset, length)
  }
  
  // Fix subarray() in ES2016. See: https://github.com/feross/buffer/pull/97
  if (typeof Symbol !== 'undefined' && Symbol.species != null &&
      Buffer[Symbol.species] === Buffer) {
    Object.defineProperty(Buffer, Symbol.species, {
      value: null,
      configurable: true,
      enumerable: false,
      writable: false
    })
  }
  
  Buffer.poolSize = 8192 // not used by this implementation
  
  function from (value, encodingOrOffset, length) {
    if (typeof value === 'string') {
      return fromString(value, encodingOrOffset)
    }
  
    if (ArrayBuffer.isView(value)) {
      return fromArrayLike(value)
    }
  
    if (value == null) {
      throw TypeError(
        'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
        'or Array-like Object. Received type ' + (typeof value)
      )
    }
  
    if (isInstance(value, ArrayBuffer) ||
        (value && isInstance(value.buffer, ArrayBuffer))) {
      return fromArrayBuffer(value, encodingOrOffset, length)
    }
  
    if (typeof value === 'number') {
      throw new TypeError(
        'The "value" argument must not be of type number. Received type number'
      )
    }
  
    var valueOf = value.valueOf && value.valueOf()
    if (valueOf != null && valueOf !== value) {
      return Buffer.from(valueOf, encodingOrOffset, length)
    }
  
    var b = fromObject(value)
    if (b) return b
  
    if (typeof Symbol !== 'undefined' && Symbol.toPrimitive != null &&
        typeof value[Symbol.toPrimitive] === 'function') {
      return Buffer.from(
        value[Symbol.toPrimitive]('string'), encodingOrOffset, length
      )
    }
  
    throw new TypeError(
      'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
      'or Array-like Object. Received type ' + (typeof value)
    )
  }
  
  /**
   * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
   * if value is a number.
   * Buffer.from(str[, encoding])
   * Buffer.from(array)
   * Buffer.from(buffer)
   * Buffer.from(arrayBuffer[, byteOffset[, length]])
   **/
  Buffer.from = function (value, encodingOrOffset, length) {
    return from(value, encodingOrOffset, length)
  }
  
  // Note: Change prototype *after* Buffer.from is defined to workaround Chrome bug:
  // https://github.com/feross/buffer/pull/148
  Buffer.prototype.__proto__ = Uint8Array.prototype
  Buffer.__proto__ = Uint8Array
  
  function assertSize (size) {
    if (typeof size !== 'number') {
      throw new TypeError('"size" argument must be of type number')
    } else if (size < 0) {
      throw new RangeError('The value "' + size + '" is invalid for option "size"')
    }
  }
  
  function alloc (size, fill, encoding) {
    assertSize(size)
    if (size <= 0) {
      return createBuffer(size)
    }
    if (fill !== undefined) {
      // Only pay attention to encoding if it's a string. This
      // prevents accidentally sending in a number that would
      // be interpretted as a start offset.
      return typeof encoding === 'string'
        ? createBuffer(size).fill(fill, encoding)
        : createBuffer(size).fill(fill)
    }
    return createBuffer(size)
  }
  
  /**
   * Creates a new filled Buffer instance.
   * alloc(size[, fill[, encoding]])
   **/
  Buffer.alloc = function (size, fill, encoding) {
    return alloc(size, fill, encoding)
  }
  
  function allocUnsafe (size) {
    assertSize(size)
    return createBuffer(size < 0 ? 0 : checked(size) | 0)
  }
  
  /**
   * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
   * */
  Buffer.allocUnsafe = function (size) {
    return allocUnsafe(size)
  }
  /**
   * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
   */
  Buffer.allocUnsafeSlow = function (size) {
    return allocUnsafe(size)
  }
  
  function fromString (string, encoding) {
    if (typeof encoding !== 'string' || encoding === '') {
      encoding = 'utf8'
    }
  
    if (!Buffer.isEncoding(encoding)) {
      throw new TypeError('Unknown encoding: ' + encoding)
    }
  
    var length = byteLength(string, encoding) | 0
    var buf = createBuffer(length)
  
    var actual = buf.write(string, encoding)
  
    if (actual !== length) {
      // Writing a hex string, for example, that contains invalid characters will
      // cause everything after the first invalid character to be ignored. (e.g.
      // 'abxxcd' will be treated as 'ab')
      buf = buf.slice(0, actual)
    }
  
    return buf
  }
  
  function fromArrayLike (array) {
    var length = array.length < 0 ? 0 : checked(array.length) | 0
    var buf = createBuffer(length)
    for (var i = 0; i < length; i += 1) {
      buf[i] = array[i] & 255
    }
    return buf
  }
  
  function fromArrayBuffer (array, byteOffset, length) {
    if (byteOffset < 0 || array.byteLength < byteOffset) {
      throw new RangeError('"offset" is outside of buffer bounds')
    }
  
    if (array.byteLength < byteOffset + (length || 0)) {
      throw new RangeError('"length" is outside of buffer bounds')
    }
  
    var buf
    if (byteOffset === undefined && length === undefined) {
      buf = new Uint8Array(array)
    } else if (length === undefined) {
      buf = new Uint8Array(array, byteOffset)
    } else {
      buf = new Uint8Array(array, byteOffset, length)
    }
  
    // Return an augmented `Uint8Array` instance
    buf.__proto__ = Buffer.prototype
    return buf
  }
  
  function fromObject (obj) {
    if (Buffer.isBuffer(obj)) {
      var len = checked(obj.length) | 0
      var buf = createBuffer(len)
  
      if (buf.length === 0) {
        return buf
      }
  
      obj.copy(buf, 0, 0, len)
      return buf
    }
  
    if (obj.length !== undefined) {
      if (typeof obj.length !== 'number' || numberIsNaN(obj.length)) {
        return createBuffer(0)
      }
      return fromArrayLike(obj)
    }
  
    if (obj.type === 'Buffer' && Array.isArray(obj.data)) {
      return fromArrayLike(obj.data)
    }
  }
  
  function checked (length) {
    // Note: cannot use `length < K_MAX_LENGTH` here because that fails when
    // length is NaN (which is otherwise coerced to zero.)
    if (length >= K_MAX_LENGTH) {
      throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
                           'size: 0x' + K_MAX_LENGTH.toString(16) + ' bytes')
    }
    return length | 0
  }
  
  function SlowBuffer (length) {
    if (+length != length) { // eslint-disable-line eqeqeq
      length = 0
    }
    return Buffer.alloc(+length)
  }
  
  Buffer.isBuffer = function isBuffer (b) {
    return b != null && b._isBuffer === true &&
      b !== Buffer.prototype // so Buffer.isBuffer(Buffer.prototype) will be false
  }
  
  Buffer.compare = function compare (a, b) {
    if (isInstance(a, Uint8Array)) a = Buffer.from(a, a.offset, a.byteLength)
    if (isInstance(b, Uint8Array)) b = Buffer.from(b, b.offset, b.byteLength)
    if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
      throw new TypeError(
        'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
      )
    }
  
    if (a === b) return 0
  
    var x = a.length
    var y = b.length
  
    for (var i = 0, len = Math.min(x, y); i < len; ++i) {
      if (a[i] !== b[i]) {
        x = a[i]
        y = b[i]
        break
      }
    }
  
    if (x < y) return -1
    if (y < x) return 1
    return 0
  }
  
  Buffer.isEncoding = function isEncoding (encoding) {
    switch (String(encoding).toLowerCase()) {
      case 'hex':
      case 'utf8':
      case 'utf-8':
      case 'ascii':
      case 'latin1':
      case 'binary':
      case 'base64':
      case 'ucs2':
      case 'ucs-2':
      case 'utf16le':
      case 'utf-16le':
        return true
      default:
        return false
    }
  }
  
  Buffer.concat = function concat (list, length) {
    if (!Array.isArray(list)) {
      throw new TypeError('"list" argument must be an Array of Buffers')
    }
  
    if (list.length === 0) {
      return Buffer.alloc(0)
    }
  
    var i
    if (length === undefined) {
      length = 0
      for (i = 0; i < list.length; ++i) {
        length += list[i].length
      }
    }
  
    var buffer = Buffer.allocUnsafe(length)
    var pos = 0
    for (i = 0; i < list.length; ++i) {
      var buf = list[i]
      if (isInstance(buf, Uint8Array)) {
        buf = Buffer.from(buf)
      }
      if (!Buffer.isBuffer(buf)) {
        throw new TypeError('"list" argument must be an Array of Buffers')
      }
      buf.copy(buffer, pos)
      pos += buf.length
    }
    return buffer
  }
  
  function byteLength (string, encoding) {
    if (Buffer.isBuffer(string)) {
      return string.length
    }
    if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) {
      return string.byteLength
    }
    if (typeof string !== 'string') {
      throw new TypeError(
        'The "string" argument must be one of type string, Buffer, or ArrayBuffer. ' +
        'Received type ' + typeof string
      )
    }
  
    var len = string.length
    var mustMatch = (arguments.length > 2 && arguments[2] === true)
    if (!mustMatch && len === 0) return 0
  
    // Use a for loop to avoid recursion
    var loweredCase = false
    for (;;) {
      switch (encoding) {
        case 'ascii':
        case 'latin1':
        case 'binary':
          return len
        case 'utf8':
        case 'utf-8':
          return utf8ToBytes(string).length
        case 'ucs2':
        case 'ucs-2':
        case 'utf16le':
        case 'utf-16le':
          return len * 2
        case 'hex':
          return len >>> 1
        case 'base64':
          return base64ToBytes(string).length
        default:
          if (loweredCase) {
            return mustMatch ? -1 : utf8ToBytes(string).length // assume utf8
          }
          encoding = ('' + encoding).toLowerCase()
          loweredCase = true
      }
    }
  }
  Buffer.byteLength = byteLength
  
  function slowToString (encoding, start, end) {
    var loweredCase = false
  
    // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
    // property of a typed array.
  
    // This behaves neither like String nor Uint8Array in that we set start/end
    // to their upper/lower bounds if the value passed is out of range.
    // undefined is handled specially as per ECMA-262 6th Edition,
    // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
    if (start === undefined || start < 0) {
      start = 0
    }
    // Return early if start > this.length. Done here to prevent potential uint32
    // coercion fail below.
    if (start > this.length) {
      return ''
    }
  
    if (end === undefined || end > this.length) {
      end = this.length
    }
  
    if (end <= 0) {
      return ''
    }
  
    // Force coersion to uint32. This will also coerce falsey/NaN values to 0.
    end >>>= 0
    start >>>= 0
  
    if (end <= start) {
      return ''
    }
  
    if (!encoding) encoding = 'utf8'
  
    while (true) {
      switch (encoding) {
        case 'hex':
          return hexSlice(this, start, end)
  
        case 'utf8':
        case 'utf-8':
          return utf8Slice(this, start, end)
  
        case 'ascii':
          return asciiSlice(this, start, end)
  
        case 'latin1':
        case 'binary':
          return latin1Slice(this, start, end)
  
        case 'base64':
          return base64Slice(this, start, end)
  
        case 'ucs2':
        case 'ucs-2':
        case 'utf16le':
        case 'utf-16le':
          return utf16leSlice(this, start, end)
  
        default:
          if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
          encoding = (encoding + '').toLowerCase()
          loweredCase = true
      }
    }
  }
  
  // This property is used by `Buffer.isBuffer` (and the `is-buffer` npm package)
  // to detect a Buffer instance. It's not possible to use `instanceof Buffer`
  // reliably in a browserify context because there could be multiple different
  // copies of the 'buffer' package in use. This method works even for Buffer
  // instances that were created from another copy of the `buffer` package.
  // See: https://github.com/feross/buffer/issues/154
  Buffer.prototype._isBuffer = true
  
  function swap (b, n, m) {
    var i = b[n]
    b[n] = b[m]
    b[m] = i
  }
  
  Buffer.prototype.swap16 = function swap16 () {
    var len = this.length
    if (len % 2 !== 0) {
      throw new RangeError('Buffer size must be a multiple of 16-bits')
    }
    for (var i = 0; i < len; i += 2) {
      swap(this, i, i + 1)
    }
    return this
  }
  
  Buffer.prototype.swap32 = function swap32 () {
    var len = this.length
    if (len % 4 !== 0) {
      throw new RangeError('Buffer size must be a multiple of 32-bits')
    }
    for (var i = 0; i < len; i += 4) {
      swap(this, i, i + 3)
      swap(this, i + 1, i + 2)
    }
    return this
  }
  
  Buffer.prototype.swap64 = function swap64 () {
    var len = this.length
    if (len % 8 !== 0) {
      throw new RangeError('Buffer size must be a multiple of 64-bits')
    }
    for (var i = 0; i < len; i += 8) {
      swap(this, i, i + 7)
      swap(this, i + 1, i + 6)
      swap(this, i + 2, i + 5)
      swap(this, i + 3, i + 4)
    }
    return this
  }
  
  Buffer.prototype.toString = function toString () {
    var length = this.length
    if (length === 0) return ''
    if (arguments.length === 0) return utf8Slice(this, 0, length)
    return slowToString.apply(this, arguments)
  }
  
  Buffer.prototype.toLocaleString = Buffer.prototype.toString
  
  Buffer.prototype.equals = function equals (b) {
    if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
    if (this === b) return true
    return Buffer.compare(this, b) === 0
  }
  
  Buffer.prototype.inspect = function inspect () {
    var str = ''
    var max = exports.INSPECT_MAX_BYTES
    str = this.toString('hex', 0, max).replace(/(.{2})/g, '$1 ').trim()
    if (this.length > max) str += ' ... '
    return '<Buffer ' + str + '>'
  }
  
  Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
    if (isInstance(target, Uint8Array)) {
      target = Buffer.from(target, target.offset, target.byteLength)
    }
    if (!Buffer.isBuffer(target)) {
      throw new TypeError(
        'The "target" argument must be one of type Buffer or Uint8Array. ' +
        'Received type ' + (typeof target)
      )
    }
  
    if (start === undefined) {
      start = 0
    }
    if (end === undefined) {
      end = target ? target.length : 0
    }
    if (thisStart === undefined) {
      thisStart = 0
    }
    if (thisEnd === undefined) {
      thisEnd = this.length
    }
  
    if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
      throw new RangeError('out of range index')
    }
  
    if (thisStart >= thisEnd && start >= end) {
      return 0
    }
    if (thisStart >= thisEnd) {
      return -1
    }
    if (start >= end) {
      return 1
    }
  
    start >>>= 0
    end >>>= 0
    thisStart >>>= 0
    thisEnd >>>= 0
  
    if (this === target) return 0
  
    var x = thisEnd - thisStart
    var y = end - start
    var len = Math.min(x, y)
  
    var thisCopy = this.slice(thisStart, thisEnd)
    var targetCopy = target.slice(start, end)
  
    for (var i = 0; i < len; ++i) {
      if (thisCopy[i] !== targetCopy[i]) {
        x = thisCopy[i]
        y = targetCopy[i]
        break
      }
    }
  
    if (x < y) return -1
    if (y < x) return 1
    return 0
  }
  
  // Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
  // OR the last index of `val` in `buffer` at offset <= `byteOffset`.
  //
  // Arguments:
  // - buffer - a Buffer to search
  // - val - a string, Buffer, or number
  // - byteOffset - an index into `buffer`; will be clamped to an int32
  // - encoding - an optional encoding, relevant is val is a string
  // - dir - true for indexOf, false for lastIndexOf
  function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
    // Empty buffer means no match
    if (buffer.length === 0) return -1
  
    // Normalize byteOffset
    if (typeof byteOffset === 'string') {
      encoding = byteOffset
      byteOffset = 0
    } else if (byteOffset > 0x7fffffff) {
      byteOffset = 0x7fffffff
    } else if (byteOffset < -0x80000000) {
      byteOffset = -0x80000000
    }
    byteOffset = +byteOffset // Coerce to Number.
    if (numberIsNaN(byteOffset)) {
      // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
      byteOffset = dir ? 0 : (buffer.length - 1)
    }
  
    // Normalize byteOffset: negative offsets start from the end of the buffer
    if (byteOffset < 0) byteOffset = buffer.length + byteOffset
    if (byteOffset >= buffer.length) {
      if (dir) return -1
      else byteOffset = buffer.length - 1
    } else if (byteOffset < 0) {
      if (dir) byteOffset = 0
      else return -1
    }
  
    // Normalize val
    if (typeof val === 'string') {
      val = Buffer.from(val, encoding)
    }
  
    // Finally, search either indexOf (if dir is true) or lastIndexOf
    if (Buffer.isBuffer(val)) {
      // Special case: looking for empty string/buffer always fails
      if (val.length === 0) {
        return -1
      }
      return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
    } else if (typeof val === 'number') {
      val = val & 0xFF // Search for a byte value [0-255]
      if (typeof Uint8Array.prototype.indexOf === 'function') {
        if (dir) {
          return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset)
        } else {
          return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
        }
      }
      return arrayIndexOf(buffer, [ val ], byteOffset, encoding, dir)
    }
  
    throw new TypeError('val must be string, number or Buffer')
  }
  
  function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
    var indexSize = 1
    var arrLength = arr.length
    var valLength = val.length
  
    if (encoding !== undefined) {
      encoding = String(encoding).toLowerCase()
      if (encoding === 'ucs2' || encoding === 'ucs-2' ||
          encoding === 'utf16le' || encoding === 'utf-16le') {
        if (arr.length < 2 || val.length < 2) {
          return -1
        }
        indexSize = 2
        arrLength /= 2
        valLength /= 2
        byteOffset /= 2
      }
    }
  
    function read (buf, i) {
      if (indexSize === 1) {
        return buf[i]
      } else {
        return buf.readUInt16BE(i * indexSize)
      }
    }
  
    var i
    if (dir) {
      var foundIndex = -1
      for (i = byteOffset; i < arrLength; i++) {
        if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
          if (foundIndex === -1) foundIndex = i
          if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
        } else {
          if (foundIndex !== -1) i -= i - foundIndex
          foundIndex = -1
        }
      }
    } else {
      if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength
      for (i = byteOffset; i >= 0; i--) {
        var found = true
        for (var j = 0; j < valLength; j++) {
          if (read(arr, i + j) !== read(val, j)) {
            found = false
            break
          }
        }
        if (found) return i
      }
    }
  
    return -1
  }
  
  Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
    return this.indexOf(val, byteOffset, encoding) !== -1
  }
  
  Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
    return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
  }
  
  Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
    return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
  }
  
  function hexWrite (buf, string, offset, length) {
    offset = Number(offset) || 0
    var remaining = buf.length - offset
    if (!length) {
      length = remaining
    } else {
      length = Number(length)
      if (length > remaining) {
        length = remaining
      }
    }
  
    var strLen = string.length
  
    if (length > strLen / 2) {
      length = strLen / 2
    }
    for (var i = 0; i < length; ++i) {
      var parsed = parseInt(string.substr(i * 2, 2), 16)
      if (numberIsNaN(parsed)) return i
      buf[offset + i] = parsed
    }
    return i
  }
  
  function utf8Write (buf, string, offset, length) {
    return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
  }
  
  function asciiWrite (buf, string, offset, length) {
    return blitBuffer(asciiToBytes(string), buf, offset, length)
  }
  
  function latin1Write (buf, string, offset, length) {
    return asciiWrite(buf, string, offset, length)
  }
  
  function base64Write (buf, string, offset, length) {
    return blitBuffer(base64ToBytes(string), buf, offset, length)
  }
  
  function ucs2Write (buf, string, offset, length) {
    return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
  }
  
  Buffer.prototype.write = function write (string, offset, length, encoding) {
    // Buffer#write(string)
    if (offset === undefined) {
      encoding = 'utf8'
      length = this.length
      offset = 0
    // Buffer#write(string, encoding)
    } else if (length === undefined && typeof offset === 'string') {
      encoding = offset
      length = this.length
      offset = 0
    // Buffer#write(string, offset[, length][, encoding])
    } else if (isFinite(offset)) {
      offset = offset >>> 0
      if (isFinite(length)) {
        length = length >>> 0
        if (encoding === undefined) encoding = 'utf8'
      } else {
        encoding = length
        length = undefined
      }
    } else {
      throw new Error(
        'Buffer.write(string, encoding, offset[, length]) is no longer supported'
      )
    }
  
    var remaining = this.length - offset
    if (length === undefined || length > remaining) length = remaining
  
    if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
      throw new RangeError('Attempt to write outside buffer bounds')
    }
  
    if (!encoding) encoding = 'utf8'
  
    var loweredCase = false
    for (;;) {
      switch (encoding) {
        case 'hex':
          return hexWrite(this, string, offset, length)
  
        case 'utf8':
        case 'utf-8':
          return utf8Write(this, string, offset, length)
  
        case 'ascii':
          return asciiWrite(this, string, offset, length)
  
        case 'latin1':
        case 'binary':
          return latin1Write(this, string, offset, length)
  
        case 'base64':
          // Warning: maxLength not taken into account in base64Write
          return base64Write(this, string, offset, length)
  
        case 'ucs2':
        case 'ucs-2':
        case 'utf16le':
        case 'utf-16le':
          return ucs2Write(this, string, offset, length)
  
        default:
          if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
          encoding = ('' + encoding).toLowerCase()
          loweredCase = true
      }
    }
  }
  
  Buffer.prototype.toJSON = function toJSON () {
    return {
      type: 'Buffer',
      data: Array.prototype.slice.call(this._arr || this, 0)
    }
  }
  
  function base64Slice (buf, start, end) {
    if (start === 0 && end === buf.length) {
      return base64.fromByteArray(buf)
    } else {
      return base64.fromByteArray(buf.slice(start, end))
    }
  }
  
  function utf8Slice (buf, start, end) {
    end = Math.min(buf.length, end)
    var res = []
  
    var i = start
    while (i < end) {
      var firstByte = buf[i]
      var codePoint = null
      var bytesPerSequence = (firstByte > 0xEF) ? 4
        : (firstByte > 0xDF) ? 3
          : (firstByte > 0xBF) ? 2
            : 1
  
      if (i + bytesPerSequence <= end) {
        var secondByte, thirdByte, fourthByte, tempCodePoint
  
        switch (bytesPerSequence) {
          case 1:
            if (firstByte < 0x80) {
              codePoint = firstByte
            }
            break
          case 2:
            secondByte = buf[i + 1]
            if ((secondByte & 0xC0) === 0x80) {
              tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
              if (tempCodePoint > 0x7F) {
                codePoint = tempCodePoint
              }
            }
            break
          case 3:
            secondByte = buf[i + 1]
            thirdByte = buf[i + 2]
            if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
              tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
              if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
                codePoint = tempCodePoint
              }
            }
            break
          case 4:
            secondByte = buf[i + 1]
            thirdByte = buf[i + 2]
            fourthByte = buf[i + 3]
            if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
              tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
              if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
                codePoint = tempCodePoint
              }
            }
        }
      }
  
      if (codePoint === null) {
        // we did not generate a valid codePoint so insert a
        // replacement char (U+FFFD) and advance only 1 byte
        codePoint = 0xFFFD
        bytesPerSequence = 1
      } else if (codePoint > 0xFFFF) {
        // encode to utf16 (surrogate pair dance)
        codePoint -= 0x10000
        res.push(codePoint >>> 10 & 0x3FF | 0xD800)
        codePoint = 0xDC00 | codePoint & 0x3FF
      }
  
      res.push(codePoint)
      i += bytesPerSequence
    }
  
    return decodeCodePointsArray(res)
  }
  
  // Based on http://stackoverflow.com/a/22747272/680742, the browser with
  // the lowest limit is Chrome, with 0x10000 args.
  // We go 1 magnitude less, for safety
  var MAX_ARGUMENTS_LENGTH = 0x1000
  
  function decodeCodePointsArray (codePoints) {
    var len = codePoints.length
    if (len <= MAX_ARGUMENTS_LENGTH) {
      return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
    }
  
    // Decode in chunks to avoid "call stack size exceeded".
    var res = ''
    var i = 0
    while (i < len) {
      res += String.fromCharCode.apply(
        String,
        codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
      )
    }
    return res
  }
  
  function asciiSlice (buf, start, end) {
    var ret = ''
    end = Math.min(buf.length, end)
  
    for (var i = start; i < end; ++i) {
      ret += String.fromCharCode(buf[i] & 0x7F)
    }
    return ret
  }
  
  function latin1Slice (buf, start, end) {
    var ret = ''
    end = Math.min(buf.length, end)
  
    for (var i = start; i < end; ++i) {
      ret += String.fromCharCode(buf[i])
    }
    return ret
  }
  
  function hexSlice (buf, start, end) {
    var len = buf.length
  
    if (!start || start < 0) start = 0
    if (!end || end < 0 || end > len) end = len
  
    var out = ''
    for (var i = start; i < end; ++i) {
      out += toHex(buf[i])
    }
    return out
  }
  
  function utf16leSlice (buf, start, end) {
    var bytes = buf.slice(start, end)
    var res = ''
    for (var i = 0; i < bytes.length; i += 2) {
      res += String.fromCharCode(bytes[i] + (bytes[i + 1] * 256))
    }
    return res
  }
  
  Buffer.prototype.slice = function slice (start, end) {
    var len = this.length
    start = ~~start
    end = end === undefined ? len : ~~end
  
    if (start < 0) {
      start += len
      if (start < 0) start = 0
    } else if (start > len) {
      start = len
    }
  
    if (end < 0) {
      end += len
      if (end < 0) end = 0
    } else if (end > len) {
      end = len
    }
  
    if (end < start) end = start
  
    var newBuf = this.subarray(start, end)
    // Return an augmented `Uint8Array` instance
    newBuf.__proto__ = Buffer.prototype
    return newBuf
  }
  
  /*
   * Need to make sure that buffer isn't trying to write out of bounds.
   */
  function checkOffset (offset, ext, length) {
    if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
    if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
  }
  
  Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
    offset = offset >>> 0
    byteLength = byteLength >>> 0
    if (!noAssert) checkOffset(offset, byteLength, this.length)
  
    var val = this[offset]
    var mul = 1
    var i = 0
    while (++i < byteLength && (mul *= 0x100)) {
      val += this[offset + i] * mul
    }
  
    return val
  }
  
  Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
    offset = offset >>> 0
    byteLength = byteLength >>> 0
    if (!noAssert) {
      checkOffset(offset, byteLength, this.length)
    }
  
    var val = this[offset + --byteLength]
    var mul = 1
    while (byteLength > 0 && (mul *= 0x100)) {
      val += this[offset + --byteLength] * mul
    }
  
    return val
  }
  
  Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 1, this.length)
    return this[offset]
  }
  
  Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 2, this.length)
    return this[offset] | (this[offset + 1] << 8)
  }
  
  Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 2, this.length)
    return (this[offset] << 8) | this[offset + 1]
  }
  
  Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 4, this.length)
  
    return ((this[offset]) |
        (this[offset + 1] << 8) |
        (this[offset + 2] << 16)) +
        (this[offset + 3] * 0x1000000)
  }
  
  Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 4, this.length)
  
    return (this[offset] * 0x1000000) +
      ((this[offset + 1] << 16) |
      (this[offset + 2] << 8) |
      this[offset + 3])
  }
  
  Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
    offset = offset >>> 0
    byteLength = byteLength >>> 0
    if (!noAssert) checkOffset(offset, byteLength, this.length)
  
    var val = this[offset]
    var mul = 1
    var i = 0
    while (++i < byteLength && (mul *= 0x100)) {
      val += this[offset + i] * mul
    }
    mul *= 0x80
  
    if (val >= mul) val -= Math.pow(2, 8 * byteLength)
  
    return val
  }
  
  Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
    offset = offset >>> 0
    byteLength = byteLength >>> 0
    if (!noAssert) checkOffset(offset, byteLength, this.length)
  
    var i = byteLength
    var mul = 1
    var val = this[offset + --i]
    while (i > 0 && (mul *= 0x100)) {
      val += this[offset + --i] * mul
    }
    mul *= 0x80
  
    if (val >= mul) val -= Math.pow(2, 8 * byteLength)
  
    return val
  }
  
  Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 1, this.length)
    if (!(this[offset] & 0x80)) return (this[offset])
    return ((0xff - this[offset] + 1) * -1)
  }
  
  Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 2, this.length)
    var val = this[offset] | (this[offset + 1] << 8)
    return (val & 0x8000) ? val | 0xFFFF0000 : val
  }
  
  Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 2, this.length)
    var val = this[offset + 1] | (this[offset] << 8)
    return (val & 0x8000) ? val | 0xFFFF0000 : val
  }
  
  Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 4, this.length)
  
    return (this[offset]) |
      (this[offset + 1] << 8) |
      (this[offset + 2] << 16) |
      (this[offset + 3] << 24)
  }
  
  Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 4, this.length)
  
    return (this[offset] << 24) |
      (this[offset + 1] << 16) |
      (this[offset + 2] << 8) |
      (this[offset + 3])
  }
  
  Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 4, this.length)
    return ieee754.read(this, offset, true, 23, 4)
  }
  
  Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 4, this.length)
    return ieee754.read(this, offset, false, 23, 4)
  }
  
  Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 8, this.length)
    return ieee754.read(this, offset, true, 52, 8)
  }
  
  Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
    offset = offset >>> 0
    if (!noAssert) checkOffset(offset, 8, this.length)
    return ieee754.read(this, offset, false, 52, 8)
  }
  
  function checkInt (buf, value, offset, ext, max, min) {
    if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
    if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
    if (offset + ext > buf.length) throw new RangeError('Index out of range')
  }
  
  Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
    value = +value
    offset = offset >>> 0
    byteLength = byteLength >>> 0
    if (!noAssert) {
      var maxBytes = Math.pow(2, 8 * byteLength) - 1
      checkInt(this, value, offset, byteLength, maxBytes, 0)
    }
  
    var mul = 1
    var i = 0
    this[offset] = value & 0xFF
    while (++i < byteLength && (mul *= 0x100)) {
      this[offset + i] = (value / mul) & 0xFF
    }
  
    return offset + byteLength
  }
  
  Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
    value = +value
    offset = offset >>> 0
    byteLength = byteLength >>> 0
    if (!noAssert) {
      var maxBytes = Math.pow(2, 8 * byteLength) - 1
      checkInt(this, value, offset, byteLength, maxBytes, 0)
    }
  
    var i = byteLength - 1
    var mul = 1
    this[offset + i] = value & 0xFF
    while (--i >= 0 && (mul *= 0x100)) {
      this[offset + i] = (value / mul) & 0xFF
    }
  
    return offset + byteLength
  }
  
  Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
    this[offset] = (value & 0xff)
    return offset + 1
  }
  
  Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
    return offset + 2
  }
  
  Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
    this[offset] = (value >>> 8)
    this[offset + 1] = (value & 0xff)
    return offset + 2
  }
  
  Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
    this[offset + 3] = (value >>> 24)
    this[offset + 2] = (value >>> 16)
    this[offset + 1] = (value >>> 8)
    this[offset] = (value & 0xff)
    return offset + 4
  }
  
  Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
    this[offset] = (value >>> 24)
    this[offset + 1] = (value >>> 16)
    this[offset + 2] = (value >>> 8)
    this[offset + 3] = (value & 0xff)
    return offset + 4
  }
  
  Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) {
      var limit = Math.pow(2, (8 * byteLength) - 1)
  
      checkInt(this, value, offset, byteLength, limit - 1, -limit)
    }
  
    var i = 0
    var mul = 1
    var sub = 0
    this[offset] = value & 0xFF
    while (++i < byteLength && (mul *= 0x100)) {
      if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
        sub = 1
      }
      this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
    }
  
    return offset + byteLength
  }
  
  Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) {
      var limit = Math.pow(2, (8 * byteLength) - 1)
  
      checkInt(this, value, offset, byteLength, limit - 1, -limit)
    }
  
    var i = byteLength - 1
    var mul = 1
    var sub = 0
    this[offset + i] = value & 0xFF
    while (--i >= 0 && (mul *= 0x100)) {
      if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
        sub = 1
      }
      this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
    }
  
    return offset + byteLength
  }
  
  Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
    if (value < 0) value = 0xff + value + 1
    this[offset] = (value & 0xff)
    return offset + 1
  }
  
  Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
    return offset + 2
  }
  
  Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
    this[offset] = (value >>> 8)
    this[offset + 1] = (value & 0xff)
    return offset + 2
  }
  
  Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
    this[offset] = (value & 0xff)
    this[offset + 1] = (value >>> 8)
    this[offset + 2] = (value >>> 16)
    this[offset + 3] = (value >>> 24)
    return offset + 4
  }
  
  Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
    if (value < 0) value = 0xffffffff + value + 1
    this[offset] = (value >>> 24)
    this[offset + 1] = (value >>> 16)
    this[offset + 2] = (value >>> 8)
    this[offset + 3] = (value & 0xff)
    return offset + 4
  }
  
  function checkIEEE754 (buf, value, offset, ext, max, min) {
    if (offset + ext > buf.length) throw new RangeError('Index out of range')
    if (offset < 0) throw new RangeError('Index out of range')
  }
  
  function writeFloat (buf, value, offset, littleEndian, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) {
      checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
    }
    ieee754.write(buf, value, offset, littleEndian, 23, 4)
    return offset + 4
  }
  
  Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
    return writeFloat(this, value, offset, true, noAssert)
  }
  
  Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
    return writeFloat(this, value, offset, false, noAssert)
  }
  
  function writeDouble (buf, value, offset, littleEndian, noAssert) {
    value = +value
    offset = offset >>> 0
    if (!noAssert) {
      checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
    }
    ieee754.write(buf, value, offset, littleEndian, 52, 8)
    return offset + 8
  }
  
  Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
    return writeDouble(this, value, offset, true, noAssert)
  }
  
  Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
    return writeDouble(this, value, offset, false, noAssert)
  }
  
  // copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
  Buffer.prototype.copy = function copy (target, targetStart, start, end) {
    if (!Buffer.isBuffer(target)) throw new TypeError('argument should be a Buffer')
    if (!start) start = 0
    if (!end && end !== 0) end = this.length
    if (targetStart >= target.length) targetStart = target.length
    if (!targetStart) targetStart = 0
    if (end > 0 && end < start) end = start
  
    // Copy 0 bytes; we're done
    if (end === start) return 0
    if (target.length === 0 || this.length === 0) return 0
  
    // Fatal error conditions
    if (targetStart < 0) {
      throw new RangeError('targetStart out of bounds')
    }
    if (start < 0 || start >= this.length) throw new RangeError('Index out of range')
    if (end < 0) throw new RangeError('sourceEnd out of bounds')
  
    // Are we oob?
    if (end > this.length) end = this.length
    if (target.length - targetStart < end - start) {
      end = target.length - targetStart + start
    }
  
    var len = end - start
  
    if (this === target && typeof Uint8Array.prototype.copyWithin === 'function') {
      // Use built-in when available, missing from IE11
      this.copyWithin(targetStart, start, end)
    } else if (this === target && start < targetStart && targetStart < end) {
      // descending copy from end
      for (var i = len - 1; i >= 0; --i) {
        target[i + targetStart] = this[i + start]
      }
    } else {
      Uint8Array.prototype.set.call(
        target,
        this.subarray(start, end),
        targetStart
      )
    }
  
    return len
  }
  
  // Usage:
  //    buffer.fill(number[, offset[, end]])
  //    buffer.fill(buffer[, offset[, end]])
  //    buffer.fill(string[, offset[, end]][, encoding])
  Buffer.prototype.fill = function fill (val, start, end, encoding) {
    // Handle string cases:
    if (typeof val === 'string') {
      if (typeof start === 'string') {
        encoding = start
        start = 0
        end = this.length
      } else if (typeof end === 'string') {
        encoding = end
        end = this.length
      }
      if (encoding !== undefined && typeof encoding !== 'string') {
        throw new TypeError('encoding must be a string')
      }
      if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
        throw new TypeError('Unknown encoding: ' + encoding)
      }
      if (val.length === 1) {
        var code = val.charCodeAt(0)
        if ((encoding === 'utf8' && code < 128) ||
            encoding === 'latin1') {
          // Fast path: If `val` fits into a single byte, use that numeric value.
          val = code
        }
      }
    } else if (typeof val === 'number') {
      val = val & 255
    }
  
    // Invalid ranges are not set to a default, so can range check early.
    if (start < 0 || this.length < start || this.length < end) {
      throw new RangeError('Out of range index')
    }
  
    if (end <= start) {
      return this
    }
  
    start = start >>> 0
    end = end === undefined ? this.length : end >>> 0
  
    if (!val) val = 0
  
    var i
    if (typeof val === 'number') {
      for (i = start; i < end; ++i) {
        this[i] = val
      }
    } else {
      var bytes = Buffer.isBuffer(val)
        ? val
        : Buffer.from(val, encoding)
      var len = bytes.length
      if (len === 0) {
        throw new TypeError('The value "' + val +
          '" is invalid for argument "value"')
      }
      for (i = 0; i < end - start; ++i) {
        this[i + start] = bytes[i % len]
      }
    }
  
    return this
  }
  
  // HELPER FUNCTIONS
  // ================
  
  var INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g
  
  function base64clean (str) {
    // Node takes equal signs as end of the Base64 encoding
    str = str.split('=')[0]
    // Node strips out invalid characters like \n and \t from the string, base64-js does not
    str = str.trim().replace(INVALID_BASE64_RE, '')
    // Node converts strings with length < 2 to ''
    if (str.length < 2) return ''
    // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
    while (str.length % 4 !== 0) {
      str = str + '='
    }
    return str
  }
  
  function toHex (n) {
    if (n < 16) return '0' + n.toString(16)
    return n.toString(16)
  }
  
  function utf8ToBytes (string, units) {
    units = units || Infinity
    var codePoint
    var length = string.length
    var leadSurrogate = null
    var bytes = []
  
    for (var i = 0; i < length; ++i) {
      codePoint = string.charCodeAt(i)
  
      // is surrogate component
      if (codePoint > 0xD7FF && codePoint < 0xE000) {
        // last char was a lead
        if (!leadSurrogate) {
          // no lead yet
          if (codePoint > 0xDBFF) {
            // unexpected trail
            if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
            continue
          } else if (i + 1 === length) {
            // unpaired lead
            if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
            continue
          }
  
          // valid lead
          leadSurrogate = codePoint
  
          continue
        }
  
        // 2 leads in a row
        if (codePoint < 0xDC00) {
          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
          leadSurrogate = codePoint
          continue
        }
  
        // valid surrogate pair
        codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
      } else if (leadSurrogate) {
        // valid bmp char, but last char was a lead
        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
      }
  
      leadSurrogate = null
  
      // encode utf8
      if (codePoint < 0x80) {
        if ((units -= 1) < 0) break
        bytes.push(codePoint)
      } else if (codePoint < 0x800) {
        if ((units -= 2) < 0) break
        bytes.push(
          codePoint >> 0x6 | 0xC0,
          codePoint & 0x3F | 0x80
        )
      } else if (codePoint < 0x10000) {
        if ((units -= 3) < 0) break
        bytes.push(
          codePoint >> 0xC | 0xE0,
          codePoint >> 0x6 & 0x3F | 0x80,
          codePoint & 0x3F | 0x80
        )
      } else if (codePoint < 0x110000) {
        if ((units -= 4) < 0) break
        bytes.push(
          codePoint >> 0x12 | 0xF0,
          codePoint >> 0xC & 0x3F | 0x80,
          codePoint >> 0x6 & 0x3F | 0x80,
          codePoint & 0x3F | 0x80
        )
      } else {
        throw new Error('Invalid code point')
      }
    }
  
    return bytes
  }
  
  function asciiToBytes (str) {
    var byteArray = []
    for (var i = 0; i < str.length; ++i) {
      // Node's code seems to be doing this and not & 0x7F..
      byteArray.push(str.charCodeAt(i) & 0xFF)
    }
    return byteArray
  }
  
  function utf16leToBytes (str, units) {
    var c, hi, lo
    var byteArray = []
    for (var i = 0; i < str.length; ++i) {
      if ((units -= 2) < 0) break
  
      c = str.charCodeAt(i)
      hi = c >> 8
      lo = c % 256
      byteArray.push(lo)
      byteArray.push(hi)
    }
  
    return byteArray
  }
  
  function base64ToBytes (str) {
    return base64.toByteArray(base64clean(str))
  }
  
  function blitBuffer (src, dst, offset, length) {
    for (var i = 0; i < length; ++i) {
      if ((i + offset >= dst.length) || (i >= src.length)) break
      dst[i + offset] = src[i]
    }
    return i
  }
  
  // ArrayBuffer or Uint8Array objects from other contexts (i.e. iframes) do not pass
  // the `instanceof` check but they should be treated as of that type.
  // See: https://github.com/feross/buffer/issues/166
  function isInstance (obj, type) {
    return obj instanceof type ||
      (obj != null && obj.constructor != null && obj.constructor.name != null &&
        obj.constructor.name === type.name)
  }
  function numberIsNaN (obj) {
    // For IE11 support
    return obj !== obj // eslint-disable-line no-self-compare
  }
  
  },{"base64-js":6,"ieee754":67}],10:[function(require,module,exports){
  module.exports = {
    "100": "Continue",
    "101": "Switching Protocols",
    "102": "Processing",
    "200": "OK",
    "201": "Created",
    "202": "Accepted",
    "203": "Non-Authoritative Information",
    "204": "No Content",
    "205": "Reset Content",
    "206": "Partial Content",
    "207": "Multi-Status",
    "208": "Already Reported",
    "226": "IM Used",
    "300": "Multiple Choices",
    "301": "Moved Permanently",
    "302": "Found",
    "303": "See Other",
    "304": "Not Modified",
    "305": "Use Proxy",
    "307": "Temporary Redirect",
    "308": "Permanent Redirect",
    "400": "Bad Request",
    "401": "Unauthorized",
    "402": "Payment Required",
    "403": "Forbidden",
    "404": "Not Found",
    "405": "Method Not Allowed",
    "406": "Not Acceptable",
    "407": "Proxy Authentication Required",
    "408": "Request Timeout",
    "409": "Conflict",
    "410": "Gone",
    "411": "Length Required",
    "412": "Precondition Failed",
    "413": "Payload Too Large",
    "414": "URI Too Long",
    "415": "Unsupported Media Type",
    "416": "Range Not Satisfiable",
    "417": "Expectation Failed",
    "418": "I'm a teapot",
    "421": "Misdirected Request",
    "422": "Unprocessable Entity",
    "423": "Locked",
    "424": "Failed Dependency",
    "425": "Unordered Collection",
    "426": "Upgrade Required",
    "428": "Precondition Required",
    "429": "Too Many Requests",
    "431": "Request Header Fields Too Large",
    "451": "Unavailable For Legal Reasons",
    "500": "Internal Server Error",
    "501": "Not Implemented",
    "502": "Bad Gateway",
    "503": "Service Unavailable",
    "504": "Gateway Timeout",
    "505": "HTTP Version Not Supported",
    "506": "Variant Also Negotiates",
    "507": "Insufficient Storage",
    "508": "Loop Detected",
    "509": "Bandwidth Limit Exceeded",
    "510": "Not Extended",
    "511": "Network Authentication Required"
  }
  
  },{}],11:[function(require,module,exports){
  (function (process,global){
  "use strict"
  
  var next = (global.process && process.nextTick) || global.setImmediate || function (f) {
    setTimeout(f, 0)
  }
  
  module.exports = function maybe (cb, promise) {
    if (cb) {
      promise
        .then(function (result) {
          next(function () { cb(null, result) })
        }, function (err) {
          next(function () { cb(err) })
        })
      return undefined
    }
    else {
      return promise
    }
  }
  
  }).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{"_process":125}],12:[function(require,module,exports){
  require('../modules/es6.symbol');
  require('../modules/es6.object.to-string');
  module.exports = require('../modules/_core').Symbol;
  
  },{"../modules/_core":18,"../modules/es6.object.to-string":61,"../modules/es6.symbol":62}],13:[function(require,module,exports){
  module.exports = function (it) {
    if (typeof it != 'function') throw TypeError(it + ' is not a function!');
    return it;
  };
  
  },{}],14:[function(require,module,exports){
  var isObject = require('./_is-object');
  module.exports = function (it) {
    if (!isObject(it)) throw TypeError(it + ' is not an object!');
    return it;
  };
  
  },{"./_is-object":34}],15:[function(require,module,exports){
  // false -> Array#indexOf
  // true  -> Array#includes
  var toIObject = require('./_to-iobject');
  var toLength = require('./_to-length');
  var toAbsoluteIndex = require('./_to-absolute-index');
  module.exports = function (IS_INCLUDES) {
    return function ($this, el, fromIndex) {
      var O = toIObject($this);
      var length = toLength(O.length);
      var index = toAbsoluteIndex(fromIndex, length);
      var value;
      // Array#includes uses SameValueZero equality algorithm
      // eslint-disable-next-line no-self-compare
      if (IS_INCLUDES && el != el) while (length > index) {
        value = O[index++];
        // eslint-disable-next-line no-self-compare
        if (value != value) return true;
      // Array#indexOf ignores holes, Array#includes - not
      } else for (;length > index; index++) if (IS_INCLUDES || index in O) {
        if (O[index] === el) return IS_INCLUDES || index || 0;
      } return !IS_INCLUDES && -1;
    };
  };
  
  },{"./_to-absolute-index":52,"./_to-iobject":54,"./_to-length":55}],16:[function(require,module,exports){
  // getting tag from 19.1.3.6 Object.prototype.toString()
  var cof = require('./_cof');
  var TAG = require('./_wks')('toStringTag');
  // ES3 wrong here
  var ARG = cof(function () { return arguments; }()) == 'Arguments';
  
  // fallback for IE11 Script Access Denied error
  var tryGet = function (it, key) {
    try {
      return it[key];
    } catch (e) { /* empty */ }
  };
  
  module.exports = function (it) {
    var O, T, B;
    return it === undefined ? 'Undefined' : it === null ? 'Null'
      // @@toStringTag case
      : typeof (T = tryGet(O = Object(it), TAG)) == 'string' ? T
      // builtinTag case
      : ARG ? cof(O)
      // ES3 arguments fallback
      : (B = cof(O)) == 'Object' && typeof O.callee == 'function' ? 'Arguments' : B;
  };
  
  },{"./_cof":17,"./_wks":60}],17:[function(require,module,exports){
  var toString = {}.toString;
  
  module.exports = function (it) {
    return toString.call(it).slice(8, -1);
  };
  
  },{}],18:[function(require,module,exports){
  var core = module.exports = { version: '2.5.7' };
  if (typeof __e == 'number') __e = core; // eslint-disable-line no-undef
  
  },{}],19:[function(require,module,exports){
  // optional / simple context binding
  var aFunction = require('./_a-function');
  module.exports = function (fn, that, length) {
    aFunction(fn);
    if (that === undefined) return fn;
    switch (length) {
      case 1: return function (a) {
        return fn.call(that, a);
      };
      case 2: return function (a, b) {
        return fn.call(that, a, b);
      };
      case 3: return function (a, b, c) {
        return fn.call(that, a, b, c);
      };
    }
    return function (/* ...args */) {
      return fn.apply(that, arguments);
    };
  };
  
  },{"./_a-function":13}],20:[function(require,module,exports){
  // 7.2.1 RequireObjectCoercible(argument)
  module.exports = function (it) {
    if (it == undefined) throw TypeError("Can't call method on  " + it);
    return it;
  };
  
  },{}],21:[function(require,module,exports){
  // Thank's IE8 for his funny defineProperty
  module.exports = !require('./_fails')(function () {
    return Object.defineProperty({}, 'a', { get: function () { return 7; } }).a != 7;
  });
  
  },{"./_fails":26}],22:[function(require,module,exports){
  var isObject = require('./_is-object');
  var document = require('./_global').document;
  // typeof document.createElement is 'object' in old IE
  var is = isObject(document) && isObject(document.createElement);
  module.exports = function (it) {
    return is ? document.createElement(it) : {};
  };
  
  },{"./_global":27,"./_is-object":34}],23:[function(require,module,exports){
  // IE 8- don't enum bug keys
  module.exports = (
    'constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf'
  ).split(',');
  
  },{}],24:[function(require,module,exports){
  // all enumerable object keys, includes symbols
  var getKeys = require('./_object-keys');
  var gOPS = require('./_object-gops');
  var pIE = require('./_object-pie');
  module.exports = function (it) {
    var result = getKeys(it);
    var getSymbols = gOPS.f;
    if (getSymbols) {
      var symbols = getSymbols(it);
      var isEnum = pIE.f;
      var i = 0;
      var key;
      while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
    } return result;
  };
  
  },{"./_object-gops":43,"./_object-keys":45,"./_object-pie":46}],25:[function(require,module,exports){
  var global = require('./_global');
  var core = require('./_core');
  var hide = require('./_hide');
  var redefine = require('./_redefine');
  var ctx = require('./_ctx');
  var PROTOTYPE = 'prototype';
  
  var $export = function (type, name, source) {
    var IS_FORCED = type & $export.F;
    var IS_GLOBAL = type & $export.G;
    var IS_STATIC = type & $export.S;
    var IS_PROTO = type & $export.P;
    var IS_BIND = type & $export.B;
    var target = IS_GLOBAL ? global : IS_STATIC ? global[name] || (global[name] = {}) : (global[name] || {})[PROTOTYPE];
    var exports = IS_GLOBAL ? core : core[name] || (core[name] = {});
    var expProto = exports[PROTOTYPE] || (exports[PROTOTYPE] = {});
    var key, own, out, exp;
    if (IS_GLOBAL) source = name;
    for (key in source) {
      // contains in native
      own = !IS_FORCED && target && target[key] !== undefined;
      // export native or passed
      out = (own ? target : source)[key];
      // bind timers to global for call from export context
      exp = IS_BIND && own ? ctx(out, global) : IS_PROTO && typeof out == 'function' ? ctx(Function.call, out) : out;
      // extend global
      if (target) redefine(target, key, out, type & $export.U);
      // export
      if (exports[key] != out) hide(exports, key, exp);
      if (IS_PROTO && expProto[key] != out) expProto[key] = out;
    }
  };
  global.core = core;
  // type bitmap
  $export.F = 1;   // forced
  $export.G = 2;   // global
  $export.S = 4;   // static
  $export.P = 8;   // proto
  $export.B = 16;  // bind
  $export.W = 32;  // wrap
  $export.U = 64;  // safe
  $export.R = 128; // real proto method for `library`
  module.exports = $export;
  
  },{"./_core":18,"./_ctx":19,"./_global":27,"./_hide":29,"./_redefine":48}],26:[function(require,module,exports){
  module.exports = function (exec) {
    try {
      return !!exec();
    } catch (e) {
      return true;
    }
  };
  
  },{}],27:[function(require,module,exports){
  // https://github.com/zloirock/core-js/issues/86#issuecomment-115759028
  var global = module.exports = typeof window != 'undefined' && window.Math == Math
    ? window : typeof self != 'undefined' && self.Math == Math ? self
    // eslint-disable-next-line no-new-func
    : Function('return this')();
  if (typeof __g == 'number') __g = global; // eslint-disable-line no-undef
  
  },{}],28:[function(require,module,exports){
  var hasOwnProperty = {}.hasOwnProperty;
  module.exports = function (it, key) {
    return hasOwnProperty.call(it, key);
  };
  
  },{}],29:[function(require,module,exports){
  var dP = require('./_object-dp');
  var createDesc = require('./_property-desc');
  module.exports = require('./_descriptors') ? function (object, key, value) {
    return dP.f(object, key, createDesc(1, value));
  } : function (object, key, value) {
    object[key] = value;
    return object;
  };
  
  },{"./_descriptors":21,"./_object-dp":38,"./_property-desc":47}],30:[function(require,module,exports){
  var document = require('./_global').document;
  module.exports = document && document.documentElement;
  
  },{"./_global":27}],31:[function(require,module,exports){
  module.exports = !require('./_descriptors') && !require('./_fails')(function () {
    return Object.defineProperty(require('./_dom-create')('div'), 'a', { get: function () { return 7; } }).a != 7;
  });
  
  },{"./_descriptors":21,"./_dom-create":22,"./_fails":26}],32:[function(require,module,exports){
  // fallback for non-array-like ES3 and non-enumerable old V8 strings
  var cof = require('./_cof');
  // eslint-disable-next-line no-prototype-builtins
  module.exports = Object('z').propertyIsEnumerable(0) ? Object : function (it) {
    return cof(it) == 'String' ? it.split('') : Object(it);
  };
  
  },{"./_cof":17}],33:[function(require,module,exports){
  // 7.2.2 IsArray(argument)
  var cof = require('./_cof');
  module.exports = Array.isArray || function isArray(arg) {
    return cof(arg) == 'Array';
  };
  
  },{"./_cof":17}],34:[function(require,module,exports){
  module.exports = function (it) {
    return typeof it === 'object' ? it !== null : typeof it === 'function';
  };
  
  },{}],35:[function(require,module,exports){
  module.exports = false;
  
  },{}],36:[function(require,module,exports){
  var META = require('./_uid')('meta');
  var isObject = require('./_is-object');
  var has = require('./_has');
  var setDesc = require('./_object-dp').f;
  var id = 0;
  var isExtensible = Object.isExtensible || function () {
    return true;
  };
  var FREEZE = !require('./_fails')(function () {
    return isExtensible(Object.preventExtensions({}));
  });
  var setMeta = function (it) {
    setDesc(it, META, { value: {
      i: 'O' + ++id, // object ID
      w: {}          // weak collections IDs
    } });
  };
  var fastKey = function (it, create) {
    // return primitive with prefix
    if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
    if (!has(it, META)) {
      // can't set metadata to uncaught frozen object
      if (!isExtensible(it)) return 'F';
      // not necessary to add metadata
      if (!create) return 'E';
      // add missing metadata
      setMeta(it);
    // return object ID
    } return it[META].i;
  };
  var getWeak = function (it, create) {
    if (!has(it, META)) {
      // can't set metadata to uncaught frozen object
      if (!isExtensible(it)) return true;
      // not necessary to add metadata
      if (!create) return false;
      // add missing metadata
      setMeta(it);
    // return hash weak collections IDs
    } return it[META].w;
  };
  // add metadata on freeze-family methods calling
  var onFreeze = function (it) {
    if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
    return it;
  };
  var meta = module.exports = {
    KEY: META,
    NEED: false,
    fastKey: fastKey,
    getWeak: getWeak,
    onFreeze: onFreeze
  };
  
  },{"./_fails":26,"./_has":28,"./_is-object":34,"./_object-dp":38,"./_uid":57}],37:[function(require,module,exports){
  // 19.1.2.2 / 15.2.3.5 Object.create(O [, Properties])
  var anObject = require('./_an-object');
  var dPs = require('./_object-dps');
  var enumBugKeys = require('./_enum-bug-keys');
  var IE_PROTO = require('./_shared-key')('IE_PROTO');
  var Empty = function () { /* empty */ };
  var PROTOTYPE = 'prototype';
  
  // Create object with fake `null` prototype: use iframe Object with cleared prototype
  var createDict = function () {
    // Thrash, waste and sodomy: IE GC bug
    var iframe = require('./_dom-create')('iframe');
    var i = enumBugKeys.length;
    var lt = '<';
    var gt = '>';
    var iframeDocument;
    iframe.style.display = 'none';
    require('./_html').appendChild(iframe);
    iframe.src = 'javascript:'; // eslint-disable-line no-script-url
    // createDict = iframe.contentWindow.Object;
    // html.removeChild(iframe);
    iframeDocument = iframe.contentWindow.document;
    iframeDocument.open();
    iframeDocument.write(lt + 'script' + gt + 'document.F=Object' + lt + '/script' + gt);
    iframeDocument.close();
    createDict = iframeDocument.F;
    while (i--) delete createDict[PROTOTYPE][enumBugKeys[i]];
    return createDict();
  };
  
  module.exports = Object.create || function create(O, Properties) {
    var result;
    if (O !== null) {
      Empty[PROTOTYPE] = anObject(O);
      result = new Empty();
      Empty[PROTOTYPE] = null;
      // add "__proto__" for Object.getPrototypeOf polyfill
      result[IE_PROTO] = O;
    } else result = createDict();
    return Properties === undefined ? result : dPs(result, Properties);
  };
  
  },{"./_an-object":14,"./_dom-create":22,"./_enum-bug-keys":23,"./_html":30,"./_object-dps":39,"./_shared-key":50}],38:[function(require,module,exports){
  var anObject = require('./_an-object');
  var IE8_DOM_DEFINE = require('./_ie8-dom-define');
  var toPrimitive = require('./_to-primitive');
  var dP = Object.defineProperty;
  
  exports.f = require('./_descriptors') ? Object.defineProperty : function defineProperty(O, P, Attributes) {
    anObject(O);
    P = toPrimitive(P, true);
    anObject(Attributes);
    if (IE8_DOM_DEFINE) try {
      return dP(O, P, Attributes);
    } catch (e) { /* empty */ }
    if ('get' in Attributes || 'set' in Attributes) throw TypeError('Accessors not supported!');
    if ('value' in Attributes) O[P] = Attributes.value;
    return O;
  };
  
  },{"./_an-object":14,"./_descriptors":21,"./_ie8-dom-define":31,"./_to-primitive":56}],39:[function(require,module,exports){
  var dP = require('./_object-dp');
  var anObject = require('./_an-object');
  var getKeys = require('./_object-keys');
  
  module.exports = require('./_descriptors') ? Object.defineProperties : function defineProperties(O, Properties) {
    anObject(O);
    var keys = getKeys(Properties);
    var length = keys.length;
    var i = 0;
    var P;
    while (length > i) dP.f(O, P = keys[i++], Properties[P]);
    return O;
  };
  
  },{"./_an-object":14,"./_descriptors":21,"./_object-dp":38,"./_object-keys":45}],40:[function(require,module,exports){
  var pIE = require('./_object-pie');
  var createDesc = require('./_property-desc');
  var toIObject = require('./_to-iobject');
  var toPrimitive = require('./_to-primitive');
  var has = require('./_has');
  var IE8_DOM_DEFINE = require('./_ie8-dom-define');
  var gOPD = Object.getOwnPropertyDescriptor;
  
  exports.f = require('./_descriptors') ? gOPD : function getOwnPropertyDescriptor(O, P) {
    O = toIObject(O);
    P = toPrimitive(P, true);
    if (IE8_DOM_DEFINE) try {
      return gOPD(O, P);
    } catch (e) { /* empty */ }
    if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
  };
  
  },{"./_descriptors":21,"./_has":28,"./_ie8-dom-define":31,"./_object-pie":46,"./_property-desc":47,"./_to-iobject":54,"./_to-primitive":56}],41:[function(require,module,exports){
  // fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
  var toIObject = require('./_to-iobject');
  var gOPN = require('./_object-gopn').f;
  var toString = {}.toString;
  
  var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
    ? Object.getOwnPropertyNames(window) : [];
  
  var getWindowNames = function (it) {
    try {
      return gOPN(it);
    } catch (e) {
      return windowNames.slice();
    }
  };
  
  module.exports.f = function getOwnPropertyNames(it) {
    return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
  };
  
  },{"./_object-gopn":42,"./_to-iobject":54}],42:[function(require,module,exports){
  // 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
  var $keys = require('./_object-keys-internal');
  var hiddenKeys = require('./_enum-bug-keys').concat('length', 'prototype');
  
  exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
    return $keys(O, hiddenKeys);
  };
  
  },{"./_enum-bug-keys":23,"./_object-keys-internal":44}],43:[function(require,module,exports){
  exports.f = Object.getOwnPropertySymbols;
  
  },{}],44:[function(require,module,exports){
  var has = require('./_has');
  var toIObject = require('./_to-iobject');
  var arrayIndexOf = require('./_array-includes')(false);
  var IE_PROTO = require('./_shared-key')('IE_PROTO');
  
  module.exports = function (object, names) {
    var O = toIObject(object);
    var i = 0;
    var result = [];
    var key;
    for (key in O) if (key != IE_PROTO) has(O, key) && result.push(key);
    // Don't enum bug & hidden keys
    while (names.length > i) if (has(O, key = names[i++])) {
      ~arrayIndexOf(result, key) || result.push(key);
    }
    return result;
  };
  
  },{"./_array-includes":15,"./_has":28,"./_shared-key":50,"./_to-iobject":54}],45:[function(require,module,exports){
  // 19.1.2.14 / 15.2.3.14 Object.keys(O)
  var $keys = require('./_object-keys-internal');
  var enumBugKeys = require('./_enum-bug-keys');
  
  module.exports = Object.keys || function keys(O) {
    return $keys(O, enumBugKeys);
  };
  
  },{"./_enum-bug-keys":23,"./_object-keys-internal":44}],46:[function(require,module,exports){
  exports.f = {}.propertyIsEnumerable;
  
  },{}],47:[function(require,module,exports){
  module.exports = function (bitmap, value) {
    return {
      enumerable: !(bitmap & 1),
      configurable: !(bitmap & 2),
      writable: !(bitmap & 4),
      value: value
    };
  };
  
  },{}],48:[function(require,module,exports){
  var global = require('./_global');
  var hide = require('./_hide');
  var has = require('./_has');
  var SRC = require('./_uid')('src');
  var TO_STRING = 'toString';
  var $toString = Function[TO_STRING];
  var TPL = ('' + $toString).split(TO_STRING);
  
  require('./_core').inspectSource = function (it) {
    return $toString.call(it);
  };
  
  (module.exports = function (O, key, val, safe) {
    var isFunction = typeof val == 'function';
    if (isFunction) has(val, 'name') || hide(val, 'name', key);
    if (O[key] === val) return;
    if (isFunction) has(val, SRC) || hide(val, SRC, O[key] ? '' + O[key] : TPL.join(String(key)));
    if (O === global) {
      O[key] = val;
    } else if (!safe) {
      delete O[key];
      hide(O, key, val);
    } else if (O[key]) {
      O[key] = val;
    } else {
      hide(O, key, val);
    }
  // add fake Function#toString for correct work wrapped methods / constructors with methods like LoDash isNative
  })(Function.prototype, TO_STRING, function toString() {
    return typeof this == 'function' && this[SRC] || $toString.call(this);
  });
  
  },{"./_core":18,"./_global":27,"./_has":28,"./_hide":29,"./_uid":57}],49:[function(require,module,exports){
  var def = require('./_object-dp').f;
  var has = require('./_has');
  var TAG = require('./_wks')('toStringTag');
  
  module.exports = function (it, tag, stat) {
    if (it && !has(it = stat ? it : it.prototype, TAG)) def(it, TAG, { configurable: true, value: tag });
  };
  
  },{"./_has":28,"./_object-dp":38,"./_wks":60}],50:[function(require,module,exports){
  var shared = require('./_shared')('keys');
  var uid = require('./_uid');
  module.exports = function (key) {
    return shared[key] || (shared[key] = uid(key));
  };
  
  },{"./_shared":51,"./_uid":57}],51:[function(require,module,exports){
  var core = require('./_core');
  var global = require('./_global');
  var SHARED = '__core-js_shared__';
  var store = global[SHARED] || (global[SHARED] = {});
  
  (module.exports = function (key, value) {
    return store[key] || (store[key] = value !== undefined ? value : {});
  })('versions', []).push({
    version: core.version,
    mode: require('./_library') ? 'pure' : 'global',
    copyright: '© 2018 Denis Pushkarev (zloirock.ru)'
  });
  
  },{"./_core":18,"./_global":27,"./_library":35}],52:[function(require,module,exports){
  var toInteger = require('./_to-integer');
  var max = Math.max;
  var min = Math.min;
  module.exports = function (index, length) {
    index = toInteger(index);
    return index < 0 ? max(index + length, 0) : min(index, length);
  };
  
  },{"./_to-integer":53}],53:[function(require,module,exports){
  // 7.1.4 ToInteger
  var ceil = Math.ceil;
  var floor = Math.floor;
  module.exports = function (it) {
    return isNaN(it = +it) ? 0 : (it > 0 ? floor : ceil)(it);
  };
  
  },{}],54:[function(require,module,exports){
  // to indexed object, toObject with fallback for non-array-like ES3 strings
  var IObject = require('./_iobject');
  var defined = require('./_defined');
  module.exports = function (it) {
    return IObject(defined(it));
  };
  
  },{"./_defined":20,"./_iobject":32}],55:[function(require,module,exports){
  // 7.1.15 ToLength
  var toInteger = require('./_to-integer');
  var min = Math.min;
  module.exports = function (it) {
    return it > 0 ? min(toInteger(it), 0x1fffffffffffff) : 0; // pow(2, 53) - 1 == 9007199254740991
  };
  
  },{"./_to-integer":53}],56:[function(require,module,exports){
  // 7.1.1 ToPrimitive(input [, PreferredType])
  var isObject = require('./_is-object');
  // instead of the ES6 spec version, we didn't implement @@toPrimitive case
  // and the second argument - flag - preferred type is a string
  module.exports = function (it, S) {
    if (!isObject(it)) return it;
    var fn, val;
    if (S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
    if (typeof (fn = it.valueOf) == 'function' && !isObject(val = fn.call(it))) return val;
    if (!S && typeof (fn = it.toString) == 'function' && !isObject(val = fn.call(it))) return val;
    throw TypeError("Can't convert object to primitive value");
  };
  
  },{"./_is-object":34}],57:[function(require,module,exports){
  var id = 0;
  var px = Math.random();
  module.exports = function (key) {
    return 'Symbol('.concat(key === undefined ? '' : key, ')_', (++id + px).toString(36));
  };
  
  },{}],58:[function(require,module,exports){
  var global = require('./_global');
  var core = require('./_core');
  var LIBRARY = require('./_library');
  var wksExt = require('./_wks-ext');
  var defineProperty = require('./_object-dp').f;
  module.exports = function (name) {
    var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
    if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
  };
  
  },{"./_core":18,"./_global":27,"./_library":35,"./_object-dp":38,"./_wks-ext":59}],59:[function(require,module,exports){
  exports.f = require('./_wks');
  
  },{"./_wks":60}],60:[function(require,module,exports){
  var store = require('./_shared')('wks');
  var uid = require('./_uid');
  var Symbol = require('./_global').Symbol;
  var USE_SYMBOL = typeof Symbol == 'function';
  
  var $exports = module.exports = function (name) {
    return store[name] || (store[name] =
      USE_SYMBOL && Symbol[name] || (USE_SYMBOL ? Symbol : uid)('Symbol.' + name));
  };
  
  $exports.store = store;
  
  },{"./_global":27,"./_shared":51,"./_uid":57}],61:[function(require,module,exports){
  'use strict';
  // 19.1.3.6 Object.prototype.toString()
  var classof = require('./_classof');
  var test = {};
  test[require('./_wks')('toStringTag')] = 'z';
  if (test + '' != '[object z]') {
    require('./_redefine')(Object.prototype, 'toString', function toString() {
      return '[object ' + classof(this) + ']';
    }, true);
  }
  
  },{"./_classof":16,"./_redefine":48,"./_wks":60}],62:[function(require,module,exports){
  'use strict';
  // ECMAScript 6 symbols shim
  var global = require('./_global');
  var has = require('./_has');
  var DESCRIPTORS = require('./_descriptors');
  var $export = require('./_export');
  var redefine = require('./_redefine');
  var META = require('./_meta').KEY;
  var $fails = require('./_fails');
  var shared = require('./_shared');
  var setToStringTag = require('./_set-to-string-tag');
  var uid = require('./_uid');
  var wks = require('./_wks');
  var wksExt = require('./_wks-ext');
  var wksDefine = require('./_wks-define');
  var enumKeys = require('./_enum-keys');
  var isArray = require('./_is-array');
  var anObject = require('./_an-object');
  var isObject = require('./_is-object');
  var toIObject = require('./_to-iobject');
  var toPrimitive = require('./_to-primitive');
  var createDesc = require('./_property-desc');
  var _create = require('./_object-create');
  var gOPNExt = require('./_object-gopn-ext');
  var $GOPD = require('./_object-gopd');
  var $DP = require('./_object-dp');
  var $keys = require('./_object-keys');
  var gOPD = $GOPD.f;
  var dP = $DP.f;
  var gOPN = gOPNExt.f;
  var $Symbol = global.Symbol;
  var $JSON = global.JSON;
  var _stringify = $JSON && $JSON.stringify;
  var PROTOTYPE = 'prototype';
  var HIDDEN = wks('_hidden');
  var TO_PRIMITIVE = wks('toPrimitive');
  var isEnum = {}.propertyIsEnumerable;
  var SymbolRegistry = shared('symbol-registry');
  var AllSymbols = shared('symbols');
  var OPSymbols = shared('op-symbols');
  var ObjectProto = Object[PROTOTYPE];
  var USE_NATIVE = typeof $Symbol == 'function';
  var QObject = global.QObject;
  // Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
  var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;
  
  // fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
  var setSymbolDesc = DESCRIPTORS && $fails(function () {
    return _create(dP({}, 'a', {
      get: function () { return dP(this, 'a', { value: 7 }).a; }
    })).a != 7;
  }) ? function (it, key, D) {
    var protoDesc = gOPD(ObjectProto, key);
    if (protoDesc) delete ObjectProto[key];
    dP(it, key, D);
    if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
  } : dP;
  
  var wrap = function (tag) {
    var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
    sym._k = tag;
    return sym;
  };
  
  var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
    return typeof it == 'symbol';
  } : function (it) {
    return it instanceof $Symbol;
  };
  
  var $defineProperty = function defineProperty(it, key, D) {
    if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
    anObject(it);
    key = toPrimitive(key, true);
    anObject(D);
    if (has(AllSymbols, key)) {
      if (!D.enumerable) {
        if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
        it[HIDDEN][key] = true;
      } else {
        if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
        D = _create(D, { enumerable: createDesc(0, false) });
      } return setSymbolDesc(it, key, D);
    } return dP(it, key, D);
  };
  var $defineProperties = function defineProperties(it, P) {
    anObject(it);
    var keys = enumKeys(P = toIObject(P));
    var i = 0;
    var l = keys.length;
    var key;
    while (l > i) $defineProperty(it, key = keys[i++], P[key]);
    return it;
  };
  var $create = function create(it, P) {
    return P === undefined ? _create(it) : $defineProperties(_create(it), P);
  };
  var $propertyIsEnumerable = function propertyIsEnumerable(key) {
    var E = isEnum.call(this, key = toPrimitive(key, true));
    if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
    return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
  };
  var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
    it = toIObject(it);
    key = toPrimitive(key, true);
    if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
    var D = gOPD(it, key);
    if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
    return D;
  };
  var $getOwnPropertyNames = function getOwnPropertyNames(it) {
    var names = gOPN(toIObject(it));
    var result = [];
    var i = 0;
    var key;
    while (names.length > i) {
      if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
    } return result;
  };
  var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
    var IS_OP = it === ObjectProto;
    var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
    var result = [];
    var i = 0;
    var key;
    while (names.length > i) {
      if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
    } return result;
  };
  
  // 19.4.1.1 Symbol([description])
  if (!USE_NATIVE) {
    $Symbol = function Symbol() {
      if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
      var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
      var $set = function (value) {
        if (this === ObjectProto) $set.call(OPSymbols, value);
        if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
        setSymbolDesc(this, tag, createDesc(1, value));
      };
      if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
      return wrap(tag);
    };
    redefine($Symbol[PROTOTYPE], 'toString', function toString() {
      return this._k;
    });
  
    $GOPD.f = $getOwnPropertyDescriptor;
    $DP.f = $defineProperty;
    require('./_object-gopn').f = gOPNExt.f = $getOwnPropertyNames;
    require('./_object-pie').f = $propertyIsEnumerable;
    require('./_object-gops').f = $getOwnPropertySymbols;
  
    if (DESCRIPTORS && !require('./_library')) {
      redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
    }
  
    wksExt.f = function (name) {
      return wrap(wks(name));
    };
  }
  
  $export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });
  
  for (var es6Symbols = (
    // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
    'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
  ).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);
  
  for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);
  
  $export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
    // 19.4.2.1 Symbol.for(key)
    'for': function (key) {
      return has(SymbolRegistry, key += '')
        ? SymbolRegistry[key]
        : SymbolRegistry[key] = $Symbol(key);
    },
    // 19.4.2.5 Symbol.keyFor(sym)
    keyFor: function keyFor(sym) {
      if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
      for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
    },
    useSetter: function () { setter = true; },
    useSimple: function () { setter = false; }
  });
  
  $export($export.S + $export.F * !USE_NATIVE, 'Object', {
    // 19.1.2.2 Object.create(O [, Properties])
    create: $create,
    // 19.1.2.4 Object.defineProperty(O, P, Attributes)
    defineProperty: $defineProperty,
    // 19.1.2.3 Object.defineProperties(O, Properties)
    defineProperties: $defineProperties,
    // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
    getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
    // 19.1.2.7 Object.getOwnPropertyNames(O)
    getOwnPropertyNames: $getOwnPropertyNames,
    // 19.1.2.8 Object.getOwnPropertySymbols(O)
    getOwnPropertySymbols: $getOwnPropertySymbols
  });
  
  // 24.3.2 JSON.stringify(value [, replacer [, space]])
  $JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
    var S = $Symbol();
    // MS Edge converts symbol values to JSON as {}
    // WebKit converts symbol values to JSON as null
    // V8 throws on boxed symbols
    return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
  })), 'JSON', {
    stringify: function stringify(it) {
      var args = [it];
      var i = 1;
      var replacer, $replacer;
      while (arguments.length > i) args.push(arguments[i++]);
      $replacer = replacer = args[1];
      if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
      if (!isArray(replacer)) replacer = function (key, value) {
        if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
        if (!isSymbol(value)) return value;
      };
      args[1] = replacer;
      return _stringify.apply($JSON, args);
    }
  });
  
  // 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
  $Symbol[PROTOTYPE][TO_PRIMITIVE] || require('./_hide')($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
  // 19.4.3.5 Symbol.prototype[@@toStringTag]
  setToStringTag($Symbol, 'Symbol');
  // 20.2.1.9 Math[@@toStringTag]
  setToStringTag(Math, 'Math', true);
  // 24.3.3 JSON[@@toStringTag]
  setToStringTag(global.JSON, 'JSON', true);
  
  },{"./_an-object":14,"./_descriptors":21,"./_enum-keys":24,"./_export":25,"./_fails":26,"./_global":27,"./_has":28,"./_hide":29,"./_is-array":33,"./_is-object":34,"./_library":35,"./_meta":36,"./_object-create":37,"./_object-dp":38,"./_object-gopd":40,"./_object-gopn":42,"./_object-gopn-ext":41,"./_object-gops":43,"./_object-keys":45,"./_object-pie":46,"./_property-desc":47,"./_redefine":48,"./_set-to-string-tag":49,"./_shared":51,"./_to-iobject":54,"./_to-primitive":56,"./_uid":57,"./_wks":60,"./_wks-define":58,"./_wks-ext":59}],63:[function(require,module,exports){
  (function (Buffer){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  // NOTE: These type checking functions intentionally don't use `instanceof`
  // because it is fragile and can be easily faked with `Object.create()`.
  
  function isArray(arg) {
    if (Array.isArray) {
      return Array.isArray(arg);
    }
    return objectToString(arg) === '[object Array]';
  }
  exports.isArray = isArray;
  
  function isBoolean(arg) {
    return typeof arg === 'boolean';
  }
  exports.isBoolean = isBoolean;
  
  function isNull(arg) {
    return arg === null;
  }
  exports.isNull = isNull;
  
  function isNullOrUndefined(arg) {
    return arg == null;
  }
  exports.isNullOrUndefined = isNullOrUndefined;
  
  function isNumber(arg) {
    return typeof arg === 'number';
  }
  exports.isNumber = isNumber;
  
  function isString(arg) {
    return typeof arg === 'string';
  }
  exports.isString = isString;
  
  function isSymbol(arg) {
    return typeof arg === 'symbol';
  }
  exports.isSymbol = isSymbol;
  
  function isUndefined(arg) {
    return arg === void 0;
  }
  exports.isUndefined = isUndefined;
  
  function isRegExp(re) {
    return objectToString(re) === '[object RegExp]';
  }
  exports.isRegExp = isRegExp;
  
  function isObject(arg) {
    return typeof arg === 'object' && arg !== null;
  }
  exports.isObject = isObject;
  
  function isDate(d) {
    return objectToString(d) === '[object Date]';
  }
  exports.isDate = isDate;
  
  function isError(e) {
    return (objectToString(e) === '[object Error]' || e instanceof Error);
  }
  exports.isError = isError;
  
  function isFunction(arg) {
    return typeof arg === 'function';
  }
  exports.isFunction = isFunction;
  
  function isPrimitive(arg) {
    return arg === null ||
           typeof arg === 'boolean' ||
           typeof arg === 'number' ||
           typeof arg === 'string' ||
           typeof arg === 'symbol' ||  // ES6 symbol
           typeof arg === 'undefined';
  }
  exports.isPrimitive = isPrimitive;
  
  exports.isBuffer = Buffer.isBuffer;
  
  function objectToString(o) {
    return Object.prototype.toString.call(o);
  }
  
  }).call(this,{"isBuffer":require("../../is-buffer/index.js")})
  
  },{"../../is-buffer/index.js":69}],64:[function(require,module,exports){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  var objectCreate = Object.create || objectCreatePolyfill
  var objectKeys = Object.keys || objectKeysPolyfill
  var bind = Function.prototype.bind || functionBindPolyfill
  
  function EventEmitter() {
    if (!this._events || !Object.prototype.hasOwnProperty.call(this, '_events')) {
      this._events = objectCreate(null);
      this._eventsCount = 0;
    }
  
    this._maxListeners = this._maxListeners || undefined;
  }
  module.exports = EventEmitter;
  
  // Backwards-compat with node 0.10.x
  EventEmitter.EventEmitter = EventEmitter;
  
  EventEmitter.prototype._events = undefined;
  EventEmitter.prototype._maxListeners = undefined;
  
  // By default EventEmitters will print a warning if more than 10 listeners are
  // added to it. This is a useful default which helps finding memory leaks.
  var defaultMaxListeners = 10;
  
  var hasDefineProperty;
  try {
    var o = {};
    if (Object.defineProperty) Object.defineProperty(o, 'x', { value: 0 });
    hasDefineProperty = o.x === 0;
  } catch (err) { hasDefineProperty = false }
  if (hasDefineProperty) {
    Object.defineProperty(EventEmitter, 'defaultMaxListeners', {
      enumerable: true,
      get: function() {
        return defaultMaxListeners;
      },
      set: function(arg) {
        // check whether the input is a positive number (whose value is zero or
        // greater and not a NaN).
        if (typeof arg !== 'number' || arg < 0 || arg !== arg)
          throw new TypeError('"defaultMaxListeners" must be a positive number');
        defaultMaxListeners = arg;
      }
    });
  } else {
    EventEmitter.defaultMaxListeners = defaultMaxListeners;
  }
  
  // Obviously not all Emitters should be limited to 10. This function allows
  // that to be increased. Set to zero for unlimited.
  EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
    if (typeof n !== 'number' || n < 0 || isNaN(n))
      throw new TypeError('"n" argument must be a positive number');
    this._maxListeners = n;
    return this;
  };
  
  function $getMaxListeners(that) {
    if (that._maxListeners === undefined)
      return EventEmitter.defaultMaxListeners;
    return that._maxListeners;
  }
  
  EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
    return $getMaxListeners(this);
  };
  
  // These standalone emit* functions are used to optimize calling of event
  // handlers for fast cases because emit() itself often has a variable number of
  // arguments and can be deoptimized because of that. These functions always have
  // the same number of arguments and thus do not get deoptimized, so the code
  // inside them can execute faster.
  function emitNone(handler, isFn, self) {
    if (isFn)
      handler.call(self);
    else {
      var len = handler.length;
      var listeners = arrayClone(handler, len);
      for (var i = 0; i < len; ++i)
        listeners[i].call(self);
    }
  }
  function emitOne(handler, isFn, self, arg1) {
    if (isFn)
      handler.call(self, arg1);
    else {
      var len = handler.length;
      var listeners = arrayClone(handler, len);
      for (var i = 0; i < len; ++i)
        listeners[i].call(self, arg1);
    }
  }
  function emitTwo(handler, isFn, self, arg1, arg2) {
    if (isFn)
      handler.call(self, arg1, arg2);
    else {
      var len = handler.length;
      var listeners = arrayClone(handler, len);
      for (var i = 0; i < len; ++i)
        listeners[i].call(self, arg1, arg2);
    }
  }
  function emitThree(handler, isFn, self, arg1, arg2, arg3) {
    if (isFn)
      handler.call(self, arg1, arg2, arg3);
    else {
      var len = handler.length;
      var listeners = arrayClone(handler, len);
      for (var i = 0; i < len; ++i)
        listeners[i].call(self, arg1, arg2, arg3);
    }
  }
  
  function emitMany(handler, isFn, self, args) {
    if (isFn)
      handler.apply(self, args);
    else {
      var len = handler.length;
      var listeners = arrayClone(handler, len);
      for (var i = 0; i < len; ++i)
        listeners[i].apply(self, args);
    }
  }
  
  EventEmitter.prototype.emit = function emit(type) {
    var er, handler, len, args, i, events;
    var doError = (type === 'error');
  
    events = this._events;
    if (events)
      doError = (doError && events.error == null);
    else if (!doError)
      return false;
  
    // If there is no 'error' event listener then throw.
    if (doError) {
      if (arguments.length > 1)
        er = arguments[1];
      if (er instanceof Error) {
        throw er; // Unhandled 'error' event
      } else {
        // At least give some kind of context to the user
        var err = new Error('Unhandled "error" event. (' + er + ')');
        err.context = er;
        throw err;
      }
      return false;
    }
  
    handler = events[type];
  
    if (!handler)
      return false;
  
    var isFn = typeof handler === 'function';
    len = arguments.length;
    switch (len) {
        // fast cases
      case 1:
        emitNone(handler, isFn, this);
        break;
      case 2:
        emitOne(handler, isFn, this, arguments[1]);
        break;
      case 3:
        emitTwo(handler, isFn, this, arguments[1], arguments[2]);
        break;
      case 4:
        emitThree(handler, isFn, this, arguments[1], arguments[2], arguments[3]);
        break;
        // slower
      default:
        args = new Array(len - 1);
        for (i = 1; i < len; i++)
          args[i - 1] = arguments[i];
        emitMany(handler, isFn, this, args);
    }
  
    return true;
  };
  
  function _addListener(target, type, listener, prepend) {
    var m;
    var events;
    var existing;
  
    if (typeof listener !== 'function')
      throw new TypeError('"listener" argument must be a function');
  
    events = target._events;
    if (!events) {
      events = target._events = objectCreate(null);
      target._eventsCount = 0;
    } else {
      // To avoid recursion in the case that type === "newListener"! Before
      // adding it to the listeners, first emit "newListener".
      if (events.newListener) {
        target.emit('newListener', type,
            listener.listener ? listener.listener : listener);
  
        // Re-assign `events` because a newListener handler could have caused the
        // this._events to be assigned to a new object
        events = target._events;
      }
      existing = events[type];
    }
  
    if (!existing) {
      // Optimize the case of one listener. Don't need the extra array object.
      existing = events[type] = listener;
      ++target._eventsCount;
    } else {
      if (typeof existing === 'function') {
        // Adding the second element, need to change to array.
        existing = events[type] =
            prepend ? [listener, existing] : [existing, listener];
      } else {
        // If we've already got an array, just append.
        if (prepend) {
          existing.unshift(listener);
        } else {
          existing.push(listener);
        }
      }
  
      // Check for listener leak
      if (!existing.warned) {
        m = $getMaxListeners(target);
        if (m && m > 0 && existing.length > m) {
          existing.warned = true;
          var w = new Error('Possible EventEmitter memory leak detected. ' +
              existing.length + ' "' + String(type) + '" listeners ' +
              'added. Use emitter.setMaxListeners() to ' +
              'increase limit.');
          w.name = 'MaxListenersExceededWarning';
          w.emitter = target;
          w.type = type;
          w.count = existing.length;
          if (typeof console === 'object' && console.warn) {
            console.warn('%s: %s', w.name, w.message);
          }
        }
      }
    }
  
    return target;
  }
  
  EventEmitter.prototype.addListener = function addListener(type, listener) {
    return _addListener(this, type, listener, false);
  };
  
  EventEmitter.prototype.on = EventEmitter.prototype.addListener;
  
  EventEmitter.prototype.prependListener =
      function prependListener(type, listener) {
        return _addListener(this, type, listener, true);
      };
  
  function onceWrapper() {
    if (!this.fired) {
      this.target.removeListener(this.type, this.wrapFn);
      this.fired = true;
      switch (arguments.length) {
        case 0:
          return this.listener.call(this.target);
        case 1:
          return this.listener.call(this.target, arguments[0]);
        case 2:
          return this.listener.call(this.target, arguments[0], arguments[1]);
        case 3:
          return this.listener.call(this.target, arguments[0], arguments[1],
              arguments[2]);
        default:
          var args = new Array(arguments.length);
          for (var i = 0; i < args.length; ++i)
            args[i] = arguments[i];
          this.listener.apply(this.target, args);
      }
    }
  }
  
  function _onceWrap(target, type, listener) {
    var state = { fired: false, wrapFn: undefined, target: target, type: type, listener: listener };
    var wrapped = bind.call(onceWrapper, state);
    wrapped.listener = listener;
    state.wrapFn = wrapped;
    return wrapped;
  }
  
  EventEmitter.prototype.once = function once(type, listener) {
    if (typeof listener !== 'function')
      throw new TypeError('"listener" argument must be a function');
    this.on(type, _onceWrap(this, type, listener));
    return this;
  };
  
  EventEmitter.prototype.prependOnceListener =
      function prependOnceListener(type, listener) {
        if (typeof listener !== 'function')
          throw new TypeError('"listener" argument must be a function');
        this.prependListener(type, _onceWrap(this, type, listener));
        return this;
      };
  
  // Emits a 'removeListener' event if and only if the listener was removed.
  EventEmitter.prototype.removeListener =
      function removeListener(type, listener) {
        var list, events, position, i, originalListener;
  
        if (typeof listener !== 'function')
          throw new TypeError('"listener" argument must be a function');
  
        events = this._events;
        if (!events)
          return this;
  
        list = events[type];
        if (!list)
          return this;
  
        if (list === listener || list.listener === listener) {
          if (--this._eventsCount === 0)
            this._events = objectCreate(null);
          else {
            delete events[type];
            if (events.removeListener)
              this.emit('removeListener', type, list.listener || listener);
          }
        } else if (typeof list !== 'function') {
          position = -1;
  
          for (i = list.length - 1; i >= 0; i--) {
            if (list[i] === listener || list[i].listener === listener) {
              originalListener = list[i].listener;
              position = i;
              break;
            }
          }
  
          if (position < 0)
            return this;
  
          if (position === 0)
            list.shift();
          else
            spliceOne(list, position);
  
          if (list.length === 1)
            events[type] = list[0];
  
          if (events.removeListener)
            this.emit('removeListener', type, originalListener || listener);
        }
  
        return this;
      };
  
  EventEmitter.prototype.removeAllListeners =
      function removeAllListeners(type) {
        var listeners, events, i;
  
        events = this._events;
        if (!events)
          return this;
  
        // not listening for removeListener, no need to emit
        if (!events.removeListener) {
          if (arguments.length === 0) {
            this._events = objectCreate(null);
            this._eventsCount = 0;
          } else if (events[type]) {
            if (--this._eventsCount === 0)
              this._events = objectCreate(null);
            else
              delete events[type];
          }
          return this;
        }
  
        // emit removeListener for all listeners on all events
        if (arguments.length === 0) {
          var keys = objectKeys(events);
          var key;
          for (i = 0; i < keys.length; ++i) {
            key = keys[i];
            if (key === 'removeListener') continue;
            this.removeAllListeners(key);
          }
          this.removeAllListeners('removeListener');
          this._events = objectCreate(null);
          this._eventsCount = 0;
          return this;
        }
  
        listeners = events[type];
  
        if (typeof listeners === 'function') {
          this.removeListener(type, listeners);
        } else if (listeners) {
          // LIFO order
          for (i = listeners.length - 1; i >= 0; i--) {
            this.removeListener(type, listeners[i]);
          }
        }
  
        return this;
      };
  
  function _listeners(target, type, unwrap) {
    var events = target._events;
  
    if (!events)
      return [];
  
    var evlistener = events[type];
    if (!evlistener)
      return [];
  
    if (typeof evlistener === 'function')
      return unwrap ? [evlistener.listener || evlistener] : [evlistener];
  
    return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
  }
  
  EventEmitter.prototype.listeners = function listeners(type) {
    return _listeners(this, type, true);
  };
  
  EventEmitter.prototype.rawListeners = function rawListeners(type) {
    return _listeners(this, type, false);
  };
  
  EventEmitter.listenerCount = function(emitter, type) {
    if (typeof emitter.listenerCount === 'function') {
      return emitter.listenerCount(type);
    } else {
      return listenerCount.call(emitter, type);
    }
  };
  
  EventEmitter.prototype.listenerCount = listenerCount;
  function listenerCount(type) {
    var events = this._events;
  
    if (events) {
      var evlistener = events[type];
  
      if (typeof evlistener === 'function') {
        return 1;
      } else if (evlistener) {
        return evlistener.length;
      }
    }
  
    return 0;
  }
  
  EventEmitter.prototype.eventNames = function eventNames() {
    return this._eventsCount > 0 ? Reflect.ownKeys(this._events) : [];
  };
  
  // About 1.5x faster than the two-arg version of Array#splice().
  function spliceOne(list, index) {
    for (var i = index, k = i + 1, n = list.length; k < n; i += 1, k += 1)
      list[i] = list[k];
    list.pop();
  }
  
  function arrayClone(arr, n) {
    var copy = new Array(n);
    for (var i = 0; i < n; ++i)
      copy[i] = arr[i];
    return copy;
  }
  
  function unwrapListeners(arr) {
    var ret = new Array(arr.length);
    for (var i = 0; i < ret.length; ++i) {
      ret[i] = arr[i].listener || arr[i];
    }
    return ret;
  }
  
  function objectCreatePolyfill(proto) {
    var F = function() {};
    F.prototype = proto;
    return new F;
  }
  function objectKeysPolyfill(obj) {
    var keys = [];
    for (var k in obj) if (Object.prototype.hasOwnProperty.call(obj, k)) {
      keys.push(k);
    }
    return k;
  }
  function functionBindPolyfill(context) {
    var fn = this;
    return function () {
      return fn.apply(context, arguments);
    };
  }
  
  },{}],65:[function(require,module,exports){
  function format(fmt) {
    var re = /(%?)(%([jds]))/g
      , args = Array.prototype.slice.call(arguments, 1);
    if(args.length) {
      fmt = fmt.replace(re, function(match, escaped, ptn, flag) {
        var arg = args.shift();
        switch(flag) {
          case 's':
            arg = '' + arg;
            break;
          case 'd':
            arg = Number(arg);
            break;
          case 'j':
            arg = JSON.stringify(arg);
            break;
        }
        if(!escaped) {
          return arg; 
        }
        args.unshift(arg);
        return match;
      })
    }
  
    // arguments remain after formatting
    if(args.length) {
      fmt += ' ' + args.join(' ');
    }
  
    // update escaped %% values
    fmt = fmt.replace(/%{2,2}/g, '%');
  
    return '' + fmt;
  }
  
  module.exports = format;
  
  },{}],66:[function(require,module,exports){
  var http = require('http')
  var url = require('url')
  
  var https = module.exports
  
  for (var key in http) {
    if (http.hasOwnProperty(key)) https[key] = http[key]
  }
  
  https.request = function (params, cb) {
    params = validateParams(params)
    return http.request.call(this, params, cb)
  }
  
  https.get = function (params, cb) {
    params = validateParams(params)
    return http.get.call(this, params, cb)
  }
  
  function validateParams (params) {
    if (typeof params === 'string') {
      params = url.parse(params)
    }
    if (!params.protocol) {
      params.protocol = 'https:'
    }
    if (params.protocol !== 'https:') {
      throw new Error('Protocol "' + params.protocol + '" not supported. Expected "https:"')
    }
    return params
  }
  
  },{"http":139,"url":148}],67:[function(require,module,exports){
  exports.read = function (buffer, offset, isLE, mLen, nBytes) {
    var e, m
    var eLen = (nBytes * 8) - mLen - 1
    var eMax = (1 << eLen) - 1
    var eBias = eMax >> 1
    var nBits = -7
    var i = isLE ? (nBytes - 1) : 0
    var d = isLE ? -1 : 1
    var s = buffer[offset + i]
  
    i += d
  
    e = s & ((1 << (-nBits)) - 1)
    s >>= (-nBits)
    nBits += eLen
    for (; nBits > 0; e = (e * 256) + buffer[offset + i], i += d, nBits -= 8) {}
  
    m = e & ((1 << (-nBits)) - 1)
    e >>= (-nBits)
    nBits += mLen
    for (; nBits > 0; m = (m * 256) + buffer[offset + i], i += d, nBits -= 8) {}
  
    if (e === 0) {
      e = 1 - eBias
    } else if (e === eMax) {
      return m ? NaN : ((s ? -1 : 1) * Infinity)
    } else {
      m = m + Math.pow(2, mLen)
      e = e - eBias
    }
    return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
  }
  
  exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
    var e, m, c
    var eLen = (nBytes * 8) - mLen - 1
    var eMax = (1 << eLen) - 1
    var eBias = eMax >> 1
    var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
    var i = isLE ? 0 : (nBytes - 1)
    var d = isLE ? 1 : -1
    var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0
  
    value = Math.abs(value)
  
    if (isNaN(value) || value === Infinity) {
      m = isNaN(value) ? 1 : 0
      e = eMax
    } else {
      e = Math.floor(Math.log(value) / Math.LN2)
      if (value * (c = Math.pow(2, -e)) < 1) {
        e--
        c *= 2
      }
      if (e + eBias >= 1) {
        value += rt / c
      } else {
        value += rt * Math.pow(2, 1 - eBias)
      }
      if (value * c >= 2) {
        e++
        c /= 2
      }
  
      if (e + eBias >= eMax) {
        m = 0
        e = eMax
      } else if (e + eBias >= 1) {
        m = ((value * c) - 1) * Math.pow(2, mLen)
        e = e + eBias
      } else {
        m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
        e = 0
      }
    }
  
    for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}
  
    e = (e << mLen) | m
    eLen += mLen
    for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}
  
    buffer[offset + i - d] |= s * 128
  }
  
  },{}],68:[function(require,module,exports){
  if (typeof Object.create === 'function') {
    // implementation from standard node.js 'util' module
    module.exports = function inherits(ctor, superCtor) {
      ctor.super_ = superCtor
      ctor.prototype = Object.create(superCtor.prototype, {
        constructor: {
          value: ctor,
          enumerable: false,
          writable: true,
          configurable: true
        }
      });
    };
  } else {
    // old school shim for old browsers
    module.exports = function inherits(ctor, superCtor) {
      ctor.super_ = superCtor
      var TempCtor = function () {}
      TempCtor.prototype = superCtor.prototype
      ctor.prototype = new TempCtor()
      ctor.prototype.constructor = ctor
    }
  }
  
  },{}],69:[function(require,module,exports){
  /*!
   * Determine if an object is a Buffer
   *
   * @author   Feross Aboukhadijeh <https://feross.org>
   * @license  MIT
   */
  
  // The _isBuffer check is for Safari 5-7 support, because it's missing
  // Object.prototype.constructor. Remove this eventually
  module.exports = function (obj) {
    return obj != null && (isBuffer(obj) || isSlowBuffer(obj) || !!obj._isBuffer)
  }
  
  function isBuffer (obj) {
    return !!obj.constructor && typeof obj.constructor.isBuffer === 'function' && obj.constructor.isBuffer(obj)
  }
  
  // For Node v0.10 support. Remove this eventually.
  function isSlowBuffer (obj) {
    return typeof obj.readFloatLE === 'function' && typeof obj.slice === 'function' && isBuffer(obj.slice(0, 0))
  }
  
  },{}],70:[function(require,module,exports){
  var toString = {}.toString;
  
  module.exports = Array.isArray || function (arr) {
    return toString.call(arr) == '[object Array]';
  };
  
  },{}],71:[function(require,module,exports){
  "use strict";
  
  var $Ref = require("./ref"),
      Pointer = require("./pointer"),
      url = require("./util/url");
  
  module.exports = bundle;
  
  /**
   * Bundles all external JSON references into the main JSON schema, thus resulting in a schema that
   * only has *internal* references, not any *external* references.
   * This method mutates the JSON schema object, adding new references and re-mapping existing ones.
   *
   * @param {$RefParser} parser
   * @param {$RefParserOptions} options
   */
  function bundle (parser, options) {
    // console.log('Bundling $ref pointers in %s', parser.$refs._root$Ref.path);
  
    // Build an inventory of all $ref pointers in the JSON Schema
    var inventory = [];
    crawl(parser, "schema", parser.$refs._root$Ref.path + "#", "#", 0, inventory, parser.$refs, options);
  
    // Remap all $ref pointers
    remap(inventory);
  }
  
  /**
   * Recursively crawls the given value, and inventories all JSON references.
   *
   * @param {object} parent - The object containing the value to crawl. If the value is not an object or array, it will be ignored.
   * @param {string} key - The property key of `parent` to be crawled
   * @param {string} path - The full path of the property being crawled, possibly with a JSON Pointer in the hash
   * @param {string} pathFromRoot - The path of the property being crawled, from the schema root
   * @param {object[]} inventory - An array of already-inventoried $ref pointers
   * @param {$Refs} $refs
   * @param {$RefParserOptions} options
   */
  function crawl (parent, key, path, pathFromRoot, indirections, inventory, $refs, options) {
    var obj = key === null ? parent : parent[key];
  
    if (obj && typeof obj === "object") {
      if ($Ref.isAllowed$Ref(obj)) {
        inventory$Ref(parent, key, path, pathFromRoot, indirections, inventory, $refs, options);
      }
      else {
        // Crawl the object in a specific order that's optimized for bundling.
        // This is important because it determines how `pathFromRoot` gets built,
        // which later determines which keys get dereferenced and which ones get remapped
        var keys = Object.keys(obj)
          .sort(function (a, b) {
            // Most people will expect references to be bundled into the the "definitions" property,
            // so we always crawl that property first, if it exists.
            if (a === "definitions") {
              return -1;
            }
            else if (b === "definitions") {
              return 1;
            }
            else {
              // Otherwise, crawl the keys based on their length.
              // This produces the shortest possible bundled references
              return a.length - b.length;
            }
          });
  
        keys.forEach(function (key) {
          var keyPath = Pointer.join(path, key);
          var keyPathFromRoot = Pointer.join(pathFromRoot, key);
          var value = obj[key];
  
          if ($Ref.isAllowed$Ref(value)) {
            inventory$Ref(obj, key, path, keyPathFromRoot, indirections, inventory, $refs, options);
          }
          else {
            crawl(obj, key, keyPath, keyPathFromRoot, indirections, inventory, $refs, options);
          }
        });
      }
    }
  }
  
  /**
   * Inventories the given JSON Reference (i.e. records detailed information about it so we can
   * optimize all $refs in the schema), and then crawls the resolved value.
   *
   * @param {object} $refParent - The object that contains a JSON Reference as one of its keys
   * @param {string} $refKey - The key in `$refParent` that is a JSON Reference
   * @param {string} path - The full path of the JSON Reference at `$refKey`, possibly with a JSON Pointer in the hash
   * @param {string} pathFromRoot - The path of the JSON Reference at `$refKey`, from the schema root
   * @param {object[]} inventory - An array of already-inventoried $ref pointers
   * @param {$Refs} $refs
   * @param {$RefParserOptions} options
   */
  function inventory$Ref ($refParent, $refKey, path, pathFromRoot, indirections, inventory, $refs, options) {
    var $ref = $refKey === null ? $refParent : $refParent[$refKey];
    var $refPath = url.resolve(path, $ref.$ref);
    var pointer = $refs._resolve($refPath, options);
    var depth = Pointer.parse(pathFromRoot).length;
    var file = url.stripHash(pointer.path);
    var hash = url.getHash(pointer.path);
    var external = file !== $refs._root$Ref.path;
    var extended = $Ref.isExtended$Ref($ref);
    indirections += pointer.indirections;
  
    var existingEntry = findInInventory(inventory, $refParent, $refKey);
    if (existingEntry) {
      // This $Ref has already been inventoried, so we don't need to process it again
      if (depth < existingEntry.depth || indirections < existingEntry.indirections) {
        removeFromInventory(inventory, existingEntry);
      }
      else {
        return;
      }
    }
  
    inventory.push({
      $ref: $ref,                   // The JSON Reference (e.g. {$ref: string})
      parent: $refParent,           // The object that contains this $ref pointer
      key: $refKey,                 // The key in `parent` that is the $ref pointer
      pathFromRoot: pathFromRoot,   // The path to the $ref pointer, from the JSON Schema root
      depth: depth,                 // How far from the JSON Schema root is this $ref pointer?
      file: file,                   // The file that the $ref pointer resolves to
      hash: hash,                   // The hash within `file` that the $ref pointer resolves to
      value: pointer.value,         // The resolved value of the $ref pointer
      circular: pointer.circular,   // Is this $ref pointer DIRECTLY circular? (i.e. it references itself)
      extended: extended,           // Does this $ref extend its resolved value? (i.e. it has extra properties, in addition to "$ref")
      external: external,           // Does this $ref pointer point to a file other than the main JSON Schema file?
      indirections: indirections,   // The number of indirect references that were traversed to resolve the value
    });
  
    // Recursively crawl the resolved value
    crawl(pointer.value, null, pointer.path, pathFromRoot, indirections + 1, inventory, $refs, options);
  }
  
  /**
   * Re-maps every $ref pointer, so that they're all relative to the root of the JSON Schema.
   * Each referenced value is dereferenced EXACTLY ONCE.  All subsequent references to the same
   * value are re-mapped to point to the first reference.
   *
   * @example:
   *  {
   *    first: { $ref: somefile.json#/some/part },
   *    second: { $ref: somefile.json#/another/part },
   *    third: { $ref: somefile.json },
   *    fourth: { $ref: somefile.json#/some/part/sub/part }
   *  }
   *
   * In this example, there are four references to the same file, but since the third reference points
   * to the ENTIRE file, that's the only one we need to dereference.  The other three can just be
   * remapped to point inside the third one.
   *
   * On the other hand, if the third reference DIDN'T exist, then the first and second would both need
   * to be dereferenced, since they point to different parts of the file. The fourth reference does NOT
   * need to be dereferenced, because it can be remapped to point inside the first one.
   *
   * @param {object[]} inventory
   */
  function remap (inventory) {
    // Group & sort all the $ref pointers, so they're in the order that we need to dereference/remap them
    inventory.sort(function (a, b) {
      if (a.file !== b.file) {
        // Group all the $refs that point to the same file
        return a.file < b.file ? -1 : +1;
      }
      else if (a.hash !== b.hash) {
        // Group all the $refs that point to the same part of the file
        return a.hash < b.hash ? -1 : +1;
      }
      else if (a.circular !== b.circular) {
        // If the $ref points to itself, then sort it higher than other $refs that point to this $ref
        return a.circular ? -1 : +1;
      }
      else if (a.extended !== b.extended) {
        // If the $ref extends the resolved value, then sort it lower than other $refs that don't extend the value
        return a.extended ? +1 : -1;
      }
      else if (a.indirections !== b.indirections) {
        // Sort direct references higher than indirect references
        return a.indirections - b.indirections;
      }
      else if (a.depth !== b.depth) {
        // Sort $refs by how close they are to the JSON Schema root
        return a.depth - b.depth;
      }
      else {
        // Determine how far each $ref is from the "definitions" property.
        // Most people will expect references to be bundled into the the "definitions" property if possible.
        var aDefinitionsIndex = a.pathFromRoot.lastIndexOf("/definitions");
        var bDefinitionsIndex = b.pathFromRoot.lastIndexOf("/definitions");
  
        if (aDefinitionsIndex !== bDefinitionsIndex) {
          // Give higher priority to the $ref that's closer to the "definitions" property
          return bDefinitionsIndex - aDefinitionsIndex;
        }
        else {
          // All else is equal, so use the shorter path, which will produce the shortest possible reference
          return a.pathFromRoot.length - b.pathFromRoot.length;
        }
      }
    });
  
    var file, hash, pathFromRoot;
    inventory.forEach(function (entry) {
      // console.log('Re-mapping $ref pointer "%s" at %s', entry.$ref.$ref, entry.pathFromRoot);
  
      if (!entry.external) {
        // This $ref already resolves to the main JSON Schema file
        entry.$ref.$ref = entry.hash;
      }
      else if (entry.file === file && entry.hash === hash) {
        // This $ref points to the same value as the prevous $ref, so remap it to the same path
        entry.$ref.$ref = pathFromRoot;
      }
      else if (entry.file === file && entry.hash.indexOf(hash + "/") === 0) {
        // This $ref points to a sub-value of the prevous $ref, so remap it beneath that path
        entry.$ref.$ref = Pointer.join(pathFromRoot, Pointer.parse(entry.hash.replace(hash, "#")));
      }
      else {
        // We've moved to a new file or new hash
        file = entry.file;
        hash = entry.hash;
        pathFromRoot = entry.pathFromRoot;
  
        // This is the first $ref to point to this value, so dereference the value.
        // Any other $refs that point to the same value will point to this $ref instead
        entry.$ref = entry.parent[entry.key] = $Ref.dereference(entry.$ref, entry.value);
  
        if (entry.circular) {
          // This $ref points to itself
          entry.$ref.$ref = entry.pathFromRoot;
        }
      }
  
      // console.log('    new value: %s', (entry.$ref && entry.$ref.$ref) ? entry.$ref.$ref : '[object Object]');
    });
  }
  
  /**
   * TODO
   */
  function findInInventory (inventory, $refParent, $refKey) {
    for (var i = 0; i < inventory.length; i++) {
      var existingEntry = inventory[i];
      if (existingEntry.parent === $refParent && existingEntry.key === $refKey) {
        return existingEntry;
      }
    }
  }
  
  function removeFromInventory (inventory, entry) {
    var index = inventory.indexOf(entry);
    inventory.splice(index, 1);
  }
  
  },{"./pointer":81,"./ref":82,"./util/url":88}],72:[function(require,module,exports){
  "use strict";
  
  var $Ref = require("./ref"),
      Pointer = require("./pointer"),
      ono = require("ono"),
      url = require("./util/url");
  
  module.exports = dereference;
  
  /**
   * Crawls the JSON schema, finds all JSON references, and dereferences them.
   * This method mutates the JSON schema object, replacing JSON references with their resolved value.
   *
   * @param {$RefParser} parser
   * @param {$RefParserOptions} options
   */
  function dereference (parser, options) {
    // console.log('Dereferencing $ref pointers in %s', parser.$refs._root$Ref.path);
    var dereferenced = crawl(parser.schema, parser.$refs._root$Ref.path, "#", [], parser.$refs, options);
    parser.$refs.circular = dereferenced.circular;
    parser.schema = dereferenced.value;
  }
  
  /**
   * Recursively crawls the given value, and dereferences any JSON references.
   *
   * @param {*} obj - The value to crawl. If it's not an object or array, it will be ignored.
   * @param {string} path - The full path of `obj`, possibly with a JSON Pointer in the hash
   * @param {string} pathFromRoot - The path of `obj` from the schema root
   * @param {object[]} parents - An array of the parent objects that have already been dereferenced
   * @param {$Refs} $refs
   * @param {$RefParserOptions} options
   * @returns {{value: object, circular: boolean}}
   */
  function crawl (obj, path, pathFromRoot, parents, $refs, options) {
    var dereferenced;
    var result = {
      value: obj,
      circular: false
    };
  
    if (obj && typeof obj === "object") {
      parents.push(obj);
  
      if ($Ref.isAllowed$Ref(obj, options)) {
        dereferenced = dereference$Ref(obj, path, pathFromRoot, parents, $refs, options);
        result.circular = dereferenced.circular;
        result.value = dereferenced.value;
      }
      else {
        Object.keys(obj).forEach(function (key) {
          var keyPath = Pointer.join(path, key);
          var keyPathFromRoot = Pointer.join(pathFromRoot, key);
          var value = obj[key];
          var circular = false;
  
          if ($Ref.isAllowed$Ref(value, options)) {
            dereferenced = dereference$Ref(value, keyPath, keyPathFromRoot, parents, $refs, options);
            circular = dereferenced.circular;
            obj[key] = dereferenced.value;
          }
          else {
            if (parents.indexOf(value) === -1) {
              dereferenced = crawl(value, keyPath, keyPathFromRoot, parents, $refs, options);
              circular = dereferenced.circular;
              obj[key] = dereferenced.value;
            }
            else {
              circular = foundCircularReference(keyPath, $refs, options);
            }
          }
  
          // Set the "isCircular" flag if this or any other property is circular
          result.circular = result.circular || circular;
        });
      }
  
      parents.pop();
    }
  
    return result;
  }
  
  /**
   * Dereferences the given JSON Reference, and then crawls the resulting value.
   *
   * @param {{$ref: string}} $ref - The JSON Reference to resolve
   * @param {string} path - The full path of `$ref`, possibly with a JSON Pointer in the hash
   * @param {string} pathFromRoot - The path of `$ref` from the schema root
   * @param {object[]} parents - An array of the parent objects that have already been dereferenced
   * @param {$Refs} $refs
   * @param {$RefParserOptions} options
   * @returns {{value: object, circular: boolean}}
   */
  function dereference$Ref ($ref, path, pathFromRoot, parents, $refs, options) {
    // console.log('Dereferencing $ref pointer "%s" at %s', $ref.$ref, path);
  
    var $refPath = url.resolve(path, $ref.$ref);
    var pointer = $refs._resolve($refPath, options);
  
    // Check for circular references
    var directCircular = pointer.circular;
    var circular = directCircular || parents.indexOf(pointer.value) !== -1;
    circular && foundCircularReference(path, $refs, options);
  
    // Dereference the JSON reference
    var dereferencedValue = $Ref.dereference($ref, pointer.value);
  
    // Crawl the dereferenced value (unless it's circular)
    if (!circular) {
      // Determine if the dereferenced value is circular
      var dereferenced = crawl(dereferencedValue, pointer.path, pathFromRoot, parents, $refs, options);
      circular = dereferenced.circular;
      dereferencedValue = dereferenced.value;
    }
  
    if (circular && !directCircular && options.dereference.circular === "ignore") {
      // The user has chosen to "ignore" circular references, so don't change the value
      dereferencedValue = $ref;
    }
  
    if (directCircular) {
      // The pointer is a DIRECT circular reference (i.e. it references itself).
      // So replace the $ref path with the absolute path from the JSON Schema root
      dereferencedValue.$ref = pathFromRoot;
    }
  
    return {
      circular: circular,
      value: dereferencedValue
    };
  }
  
  /**
   * Called when a circular reference is found.
   * It sets the {@link $Refs#circular} flag, and throws an error if options.dereference.circular is false.
   *
   * @param {string} keyPath - The JSON Reference path of the circular reference
   * @param {$Refs} $refs
   * @param {$RefParserOptions} options
   * @returns {boolean} - always returns true, to indicate that a circular reference was found
   */
  function foundCircularReference (keyPath, $refs, options) {
    $refs.circular = true;
    if (!options.dereference.circular) {
      throw ono.reference("Circular $ref pointer found at %s", keyPath);
    }
    return true;
  }
  
  },{"./pointer":81,"./ref":82,"./util/url":88,"ono":122}],73:[function(require,module,exports){
  (function (Buffer){
  "use strict";
  
  var Options = require("./options"),
      $Refs = require("./refs"),
      parse = require("./parse"),
      normalizeArgs = require("./normalize-args"),
      resolveExternal = require("./resolve-external"),
      bundle = require("./bundle"),
      dereference = require("./dereference"),
      url = require("./util/url"),
      maybe = require("call-me-maybe"),
      ono = require("ono");
  
  module.exports = $RefParser;
  module.exports.YAML = require("./util/yaml");
  
  /**
   * This class parses a JSON schema, builds a map of its JSON references and their resolved values,
   * and provides methods for traversing, manipulating, and dereferencing those references.
   *
   * @constructor
   */
  function $RefParser () {
    /**
     * The parsed (and possibly dereferenced) JSON schema object
     *
     * @type {object}
     * @readonly
     */
    this.schema = null;
  
    /**
     * The resolved JSON references
     *
     * @type {$Refs}
     * @readonly
     */
    this.$refs = new $Refs();
  }
  
  /**
   * Parses the given JSON schema.
   * This method does not resolve any JSON references.
   * It just reads a single file in JSON or YAML format, and parse it as a JavaScript object.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [schema] - A JSON schema object. This object will be used instead of reading from `path`.
   * @param {$RefParserOptions} [options] - Options that determine how the schema is parsed
   * @param {function} [callback] - An error-first callback. The second parameter is the parsed JSON schema object.
   * @returns {Promise} - The returned promise resolves with the parsed JSON schema object.
   */
  $RefParser.parse = function (path, schema, options, callback) {
    var Class = this; // eslint-disable-line consistent-this
    var instance = new Class();
    return instance.parse.apply(instance, arguments);
  };
  
  /**
   * Parses the given JSON schema.
   * This method does not resolve any JSON references.
   * It just reads a single file in JSON or YAML format, and parse it as a JavaScript object.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [schema] - A JSON schema object. This object will be used instead of reading from `path`.
   * @param {$RefParserOptions} [options] - Options that determine how the schema is parsed
   * @param {function} [callback] - An error-first callback. The second parameter is the parsed JSON schema object.
   * @returns {Promise} - The returned promise resolves with the parsed JSON schema object.
   */
  $RefParser.prototype.parse = function (path, schema, options, callback) {
    var args = normalizeArgs(arguments);
    var promise;
  
    if (!args.path && !args.schema) {
      var err = ono("Expected a file path, URL, or object. Got %s", args.path || args.schema);
      return maybe(args.callback, Promise.reject(err));
    }
  
    // Reset everything
    this.schema = null;
    this.$refs = new $Refs();
  
    // If the path is a filesystem path, then convert it to a URL.
    // NOTE: According to the JSON Reference spec, these should already be URLs,
    // but, in practice, many people use local filesystem paths instead.
    // So we're being generous here and doing the conversion automatically.
    // This is not intended to be a 100% bulletproof solution.
    // If it doesn't work for your use-case, then use a URL instead.
    var pathType = "http";
    if (url.isFileSystemPath(args.path)) {
      args.path = url.fromFileSystemPath(args.path);
      pathType = "file";
    }
  
    // Resolve the absolute path of the schema
    args.path = url.resolve(url.cwd(), args.path);
  
    if (args.schema && typeof args.schema === "object") {
      // A schema object was passed-in.
      // So immediately add a new $Ref with the schema object as its value
      var $ref = this.$refs._add(args.path);
      $ref.value = args.schema;
      $ref.pathType = pathType;
      promise = Promise.resolve(args.schema);
    }
    else {
      // Parse the schema file/url
      promise = parse(args.path, this.$refs, args.options);
    }
  
    var me = this;
    return promise
      .then(function (result) {
        if (!result || typeof result !== "object" || Buffer.isBuffer(result)) {
          throw ono.syntax('"%s" is not a valid JSON Schema', me.$refs._root$Ref.path || result);
        }
        else {
          me.schema = result;
          return maybe(args.callback, Promise.resolve(me.schema));
        }
      })
      .catch(function (e) {
        return maybe(args.callback, Promise.reject(e));
      });
  };
  
  /**
   * Parses the given JSON schema and resolves any JSON references, including references in
   * externally-referenced files.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [schema] - A JSON schema object. This object will be used instead of reading from `path`.
   * @param {$RefParserOptions} [options] - Options that determine how the schema is parsed and resolved
   * @param {function} [callback]
   * - An error-first callback. The second parameter is a {@link $Refs} object containing the resolved JSON references
   *
   * @returns {Promise}
   * The returned promise resolves with a {@link $Refs} object containing the resolved JSON references
   */
  $RefParser.resolve = function (path, schema, options, callback) {
    var Class = this; // eslint-disable-line consistent-this
    var instance = new Class();
    return instance.resolve.apply(instance, arguments);
  };
  
  /**
   * Parses the given JSON schema and resolves any JSON references, including references in
   * externally-referenced files.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [schema] - A JSON schema object. This object will be used instead of reading from `path`.
   * @param {$RefParserOptions} [options] - Options that determine how the schema is parsed and resolved
   * @param {function} [callback]
   * - An error-first callback. The second parameter is a {@link $Refs} object containing the resolved JSON references
   *
   * @returns {Promise}
   * The returned promise resolves with a {@link $Refs} object containing the resolved JSON references
   */
  $RefParser.prototype.resolve = function (path, schema, options, callback) {
    var me = this;
    var args = normalizeArgs(arguments);
  
    return this.parse(args.path, args.schema, args.options)
      .then(function () {
        return resolveExternal(me, args.options);
      })
      .then(function () {
        return maybe(args.callback, Promise.resolve(me.$refs));
      })
      .catch(function (err) {
        return maybe(args.callback, Promise.reject(err));
      });
  };
  
  /**
   * Parses the given JSON schema, resolves any JSON references, and bundles all external references
   * into the main JSON schema. This produces a JSON schema that only has *internal* references,
   * not any *external* references.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [schema] - A JSON schema object. This object will be used instead of reading from `path`.
   * @param {$RefParserOptions} [options] - Options that determine how the schema is parsed, resolved, and dereferenced
   * @param {function} [callback] - An error-first callback. The second parameter is the bundled JSON schema object
   * @returns {Promise} - The returned promise resolves with the bundled JSON schema object.
   */
  $RefParser.bundle = function (path, schema, options, callback) {
    var Class = this; // eslint-disable-line consistent-this
    var instance = new Class();
    return instance.bundle.apply(instance, arguments);
  };
  
  /**
   * Parses the given JSON schema, resolves any JSON references, and bundles all external references
   * into the main JSON schema. This produces a JSON schema that only has *internal* references,
   * not any *external* references.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [schema] - A JSON schema object. This object will be used instead of reading from `path`.
   * @param {$RefParserOptions} [options] - Options that determine how the schema is parsed, resolved, and dereferenced
   * @param {function} [callback] - An error-first callback. The second parameter is the bundled JSON schema object
   * @returns {Promise} - The returned promise resolves with the bundled JSON schema object.
   */
  $RefParser.prototype.bundle = function (path, schema, options, callback) {
    var me = this;
    var args = normalizeArgs(arguments);
  
    return this.resolve(args.path, args.schema, args.options)
      .then(function () {
        bundle(me, args.options);
        return maybe(args.callback, Promise.resolve(me.schema));
      })
      .catch(function (err) {
        return maybe(args.callback, Promise.reject(err));
      });
  };
  
  /**
   * Parses the given JSON schema, resolves any JSON references, and dereferences the JSON schema.
   * That is, all JSON references are replaced with their resolved values.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [schema] - A JSON schema object. This object will be used instead of reading from `path`.
   * @param {$RefParserOptions} [options] - Options that determine how the schema is parsed, resolved, and dereferenced
   * @param {function} [callback] - An error-first callback. The second parameter is the dereferenced JSON schema object
   * @returns {Promise} - The returned promise resolves with the dereferenced JSON schema object.
   */
  $RefParser.dereference = function (path, schema, options, callback) {
    var Class = this; // eslint-disable-line consistent-this
    var instance = new Class();
    return instance.dereference.apply(instance, arguments);
  };
  
  /**
   * Parses the given JSON schema, resolves any JSON references, and dereferences the JSON schema.
   * That is, all JSON references are replaced with their resolved values.
   *
   * @param {string} [path] - The file path or URL of the JSON schema
   * @param {object} [schema] - A JSON schema object. This object will be used instead of reading from `path`.
   * @param {$RefParserOptions} [options] - Options that determine how the schema is parsed, resolved, and dereferenced
   * @param {function} [callback] - An error-first callback. The second parameter is the dereferenced JSON schema object
   * @returns {Promise} - The returned promise resolves with the dereferenced JSON schema object.
   */
  $RefParser.prototype.dereference = function (path, schema, options, callback) {
    var me = this;
    var args = normalizeArgs(arguments);
  
    return this.resolve(args.path, args.schema, args.options)
      .then(function () {
        dereference(me, args.options);
        return maybe(args.callback, Promise.resolve(me.schema));
      })
      .catch(function (err) {
        return maybe(args.callback, Promise.reject(err));
      });
  };
  
  }).call(this,{"isBuffer":require("../../is-buffer/index.js")})
  
  },{"../../is-buffer/index.js":69,"./bundle":71,"./dereference":72,"./normalize-args":74,"./options":75,"./parse":76,"./refs":83,"./resolve-external":84,"./util/url":88,"./util/yaml":89,"call-me-maybe":11,"ono":122}],74:[function(require,module,exports){
  "use strict";
  
  var Options = require("./options");
  
  module.exports = normalizeArgs;
  
  /**
   * Normalizes the given arguments, accounting for optional args.
   *
   * @param {Arguments} args
   * @returns {object}
   */
  function normalizeArgs (args) {
    var path, schema, options, callback;
    args = Array.prototype.slice.call(args);
  
    if (typeof args[args.length - 1] === "function") {
      // The last parameter is a callback function
      callback = args.pop();
    }
  
    if (typeof args[0] === "string") {
      // The first parameter is the path
      path = args[0];
      if (typeof args[2] === "object") {
        // The second parameter is the schema, and the third parameter is the options
        schema = args[1];
        options = args[2];
      }
      else {
        // The second parameter is the options
        schema = undefined;
        options = args[1];
      }
    }
    else {
      // The first parameter is the schema
      path = "";
      schema = args[0];
      options = args[1];
    }
  
    if (!(options instanceof Options)) {
      options = new Options(options);
    }
  
    return {
      path: path,
      schema: schema,
      options: options,
      callback: callback
    };
  }
  
  },{"./options":75}],75:[function(require,module,exports){
  /* eslint lines-around-comment: [2, {beforeBlockComment: false}] */
  "use strict";
  
  var jsonParser = require("./parsers/json"),
      yamlParser = require("./parsers/yaml"),
      textParser = require("./parsers/text"),
      binaryParser = require("./parsers/binary"),
      fileResolver = require("./resolvers/file"),
      httpResolver = require("./resolvers/http");
  
  module.exports = $RefParserOptions;
  
  /**
   * Options that determine how JSON schemas are parsed, resolved, and dereferenced.
   *
   * @param {object|$RefParserOptions} [options] - Overridden options
   * @constructor
   */
  function $RefParserOptions (options) {
    merge(this, $RefParserOptions.defaults);
    merge(this, options);
  }
  
  $RefParserOptions.defaults = {
    /**
     * Determines how different types of files will be parsed.
     *
     * You can add additional parsers of your own, replace an existing one with
     * your own implemenation, or disable any parser by setting it to false.
     */
    parse: {
      json: jsonParser,
      yaml: yamlParser,
      text: textParser,
      binary: binaryParser,
    },
  
    /**
     * Determines how JSON References will be resolved.
     *
     * You can add additional resolvers of your own, replace an existing one with
     * your own implemenation, or disable any resolver by setting it to false.
     */
    resolve: {
      file: fileResolver,
      http: httpResolver,
  
      /**
       * Determines whether external $ref pointers will be resolved.
       * If this option is disabled, then none of above resolvers will be called.
       * Instead, external $ref pointers will simply be ignored.
       *
       * @type {boolean}
       */
      external: true,
    },
  
    /**
     * Determines the types of JSON references that are allowed.
     */
    dereference: {
      /**
       * Dereference circular (recursive) JSON references?
       * If false, then a {@link ReferenceError} will be thrown if a circular reference is found.
       * If "ignore", then circular references will not be dereferenced.
       *
       * @type {boolean|string}
       */
      circular: true
    },
  };
  
  /**
   * Merges the properties of the source object into the target object.
   *
   * @param {object} target - The object that we're populating
   * @param {?object} source - The options that are being merged
   * @returns {object}
   */
  function merge (target, source) {
    if (isMergeable(source)) {
      var keys = Object.keys(source);
      for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        var sourceSetting = source[key];
        var targetSetting = target[key];
  
        if (isMergeable(sourceSetting)) {
          // It's a nested object, so merge it recursively
          target[key] = merge(targetSetting || {}, sourceSetting);
        }
        else if (sourceSetting !== undefined) {
          // It's a scalar value, function, or array. No merging necessary. Just overwrite the target value.
          target[key] = sourceSetting;
        }
      }
    }
    return target;
  }
  
  /**
   * Determines whether the given value can be merged,
   * or if it is a scalar value that should just override the target value.
   *
   * @param   {*}  val
   * @returns {Boolean}
   */
  function isMergeable (val) {
    return val &&
      (typeof val === "object") &&
      !Array.isArray(val) &&
      !(val instanceof RegExp) &&
      !(val instanceof Date);
  }
  
  },{"./parsers/binary":77,"./parsers/json":78,"./parsers/text":79,"./parsers/yaml":80,"./resolvers/file":85,"./resolvers/http":86}],76:[function(require,module,exports){
  (function (Buffer){
  "use strict";
  
  var ono = require("ono"),
      url = require("./util/url"),
      plugins = require("./util/plugins");
  
  module.exports = parse;
  
  /**
   * Reads and parses the specified file path or URL.
   *
   * @param {string} path - This path MUST already be resolved, since `read` doesn't know the resolution context
   * @param {$Refs} $refs
   * @param {$RefParserOptions} options
   *
   * @returns {Promise}
   * The promise resolves with the parsed file contents, NOT the raw (Buffer) contents.
   */
  function parse (path, $refs, options) {
    try {
      // Remove the URL fragment, if any
      path = url.stripHash(path);
  
      // Add a new $Ref for this file, even though we don't have the value yet.
      // This ensures that we don't simultaneously read & parse the same file multiple times
      var $ref = $refs._add(path);
  
      // This "file object" will be passed to all resolvers and parsers.
      var file = {
        url: path,
        extension: url.getExtension(path),
      };
  
      // Read the file and then parse the data
      return readFile(file, options)
        .then(function (resolver) {
          $ref.pathType = resolver.plugin.name;
          file.data = resolver.result;
          return parseFile(file, options);
        })
        .then(function (parser) {
          $ref.value = parser.result;
          return parser.result;
        });
    }
    catch (e) {
      return Promise.reject(e);
    }
  }
  
  /**
   * Reads the given file, using the configured resolver plugins
   *
   * @param {object} file           - An object containing information about the referenced file
   * @param {string} file.url       - The full URL of the referenced file
   * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
   * @param {$RefParserOptions} options
   *
   * @returns {Promise}
   * The promise resolves with the raw file contents and the resolver that was used.
   */
  function readFile (file, options) {
    return new Promise(function (resolve, reject) {
      // console.log('Reading %s', file.url);
  
      // Find the resolvers that can read this file
      var resolvers = plugins.all(options.resolve);
      resolvers = plugins.filter(resolvers, "canRead", file);
  
      // Run the resolvers, in order, until one of them succeeds
      plugins.sort(resolvers);
      plugins.run(resolvers, "read", file)
        .then(resolve, onError);
  
      function onError (err) {
        // Throw the original error, if it's one of our own (user-friendly) errors.
        // Otherwise, throw a generic, friendly error.
        if (err && !(err instanceof SyntaxError)) {
          reject(err);
        }
        else {
          reject(ono.syntax('Unable to resolve $ref pointer "%s"', file.url));
        }
      }
    });
  }
  
  /**
   * Parses the given file's contents, using the configured parser plugins.
   *
   * @param {object} file           - An object containing information about the referenced file
   * @param {string} file.url       - The full URL of the referenced file
   * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
   * @param {*}      file.data      - The file contents. This will be whatever data type was returned by the resolver
   * @param {$RefParserOptions} options
   *
   * @returns {Promise}
   * The promise resolves with the parsed file contents and the parser that was used.
   */
  function parseFile (file, options) {
    return new Promise(function (resolve, reject) {
      // console.log('Parsing %s', file.url);
  
      // Find the parsers that can read this file type.
      // If none of the parsers are an exact match for this file, then we'll try ALL of them.
      // This handles situations where the file IS a supported type, just with an unknown extension.
      var allParsers = plugins.all(options.parse);
      var filteredParsers = plugins.filter(allParsers, "canParse", file);
      var parsers = filteredParsers.length > 0 ? filteredParsers : allParsers;
  
      // Run the parsers, in order, until one of them succeeds
      plugins.sort(parsers);
      plugins.run(parsers, "parse", file)
        .then(onParsed, onError);
  
      function onParsed (parser) {
        if (!parser.plugin.allowEmpty && isEmpty(parser.result)) {
          reject(ono.syntax('Error parsing "%s" as %s. \nParsed value is empty', file.url, parser.plugin.name));
        }
        else {
          resolve(parser);
        }
      }
  
      function onError (err) {
        if (err) {
          err = err instanceof Error ? err : new Error(err);
          reject(ono.syntax(err, "Error parsing %s", file.url));
        }
        else {
          reject(ono.syntax("Unable to parse %s", file.url));
        }
      }
    });
  }
  
  /**
   * Determines whether the parsed value is "empty".
   *
   * @param {*} value
   * @returns {boolean}
   */
  function isEmpty (value) {
    return value === undefined ||
      (typeof value === "object" && Object.keys(value).length === 0) ||
      (typeof value === "string" && value.trim().length === 0) ||
      (Buffer.isBuffer(value) && value.length === 0);
  }
  
  }).call(this,{"isBuffer":require("../../is-buffer/index.js")})
  
  },{"../../is-buffer/index.js":69,"./util/plugins":87,"./util/url":88,"ono":122}],77:[function(require,module,exports){
  (function (Buffer){
  "use strict";
  
  var BINARY_REGEXP = /\.(jpeg|jpg|gif|png|bmp|ico)$/i;
  
  module.exports = {
    /**
     * The order that this parser will run, in relation to other parsers.
     *
     * @type {number}
     */
    order: 400,
  
    /**
     * Whether to allow "empty" files (zero bytes).
     *
     * @type {boolean}
     */
    allowEmpty: true,
  
    /**
     * Determines whether this parser can parse a given file reference.
     * Parsers that return true will be tried, in order, until one successfully parses the file.
     * Parsers that return false will be skipped, UNLESS all parsers returned false, in which case
     * every parser will be tried.
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @param {*}      file.data      - The file contents. This will be whatever data type was returned by the resolver
     * @returns {boolean}
     */
    canParse: function isBinary (file) {
      // Use this parser if the file is a Buffer, and has a known binary extension
      return Buffer.isBuffer(file.data) && BINARY_REGEXP.test(file.url);
    },
  
    /**
     * Parses the given data as a Buffer (byte array).
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @param {*}      file.data      - The file contents. This will be whatever data type was returned by the resolver
     * @returns {Promise<Buffer>}
     */
    parse: function parseBinary (file) {
      if (Buffer.isBuffer(file.data)) {
        return file.data;
      }
      else {
        // This will reject if data is anything other than a string or typed array
        return new Buffer(file.data);
      }
    }
  };
  
  }).call(this,require("buffer").Buffer)
  
  },{"buffer":9}],78:[function(require,module,exports){
  (function (Buffer){
  "use strict";
  
  module.exports = {
    /**
     * The order that this parser will run, in relation to other parsers.
     *
     * @type {number}
     */
    order: 100,
  
    /**
     * Whether to allow "empty" files. This includes zero-byte files, as well as empty JSON objects.
     *
     * @type {boolean}
     */
    allowEmpty: true,
  
    /**
     * Determines whether this parser can parse a given file reference.
     * Parsers that match will be tried, in order, until one successfully parses the file.
     * Parsers that don't match will be skipped, UNLESS none of the parsers match, in which case
     * every parser will be tried.
     *
     * @type {RegExp|string[]|function}
     */
    canParse: ".json",
  
    /**
     * Parses the given file as JSON
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @param {*}      file.data      - The file contents. This will be whatever data type was returned by the resolver
     * @returns {Promise}
     */
    parse: function parseJSON (file) {
      return new Promise(function (resolve, reject) {
        var data = file.data;
        if (Buffer.isBuffer(data)) {
          data = data.toString();
        }
  
        if (typeof data === "string") {
          if (data.trim().length === 0) {
            resolve(undefined);  // This mirrors the YAML behavior
          }
          else {
            resolve(JSON.parse(data));
          }
        }
        else {
          // data is already a JavaScript value (object, array, number, null, NaN, etc.)
          resolve(data);
        }
      });
    }
  };
  
  }).call(this,{"isBuffer":require("../../../is-buffer/index.js")})
  
  },{"../../../is-buffer/index.js":69}],79:[function(require,module,exports){
  (function (Buffer){
  "use strict";
  
  var TEXT_REGEXP = /\.(txt|htm|html|md|xml|js|min|map|css|scss|less|svg)$/i;
  
  module.exports = {
    /**
     * The order that this parser will run, in relation to other parsers.
     *
     * @type {number}
     */
    order: 300,
  
    /**
     * Whether to allow "empty" files (zero bytes).
     *
     * @type {boolean}
     */
    allowEmpty: true,
  
    /**
     * The encoding that the text is expected to be in.
     *
     * @type {string}
     */
    encoding: "utf8",
  
    /**
     * Determines whether this parser can parse a given file reference.
     * Parsers that return true will be tried, in order, until one successfully parses the file.
     * Parsers that return false will be skipped, UNLESS all parsers returned false, in which case
     * every parser will be tried.
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @param {*}      file.data      - The file contents. This will be whatever data type was returned by the resolver
     * @returns {boolean}
     */
    canParse: function isText (file) {
      // Use this parser if the file is a string or Buffer, and has a known text-based extension
      return (typeof file.data === "string" || Buffer.isBuffer(file.data)) && TEXT_REGEXP.test(file.url);
    },
  
    /**
     * Parses the given file as text
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @param {*}      file.data      - The file contents. This will be whatever data type was returned by the resolver
     * @returns {Promise<string>}
     */
    parse: function parseText (file) {
      if (typeof file.data === "string") {
        return file.data;
      }
      else if (Buffer.isBuffer(file.data)) {
        return file.data.toString(this.encoding);
      }
      else {
        throw new Error("data is not text");
      }
    }
  };
  
  }).call(this,{"isBuffer":require("../../../is-buffer/index.js")})
  
  },{"../../../is-buffer/index.js":69}],80:[function(require,module,exports){
  (function (Buffer){
  "use strict";
  
  var YAML = require("../util/yaml");
  
  module.exports = {
    /**
     * The order that this parser will run, in relation to other parsers.
     *
     * @type {number}
     */
    order: 200,
  
    /**
     * Whether to allow "empty" files. This includes zero-byte files, as well as empty JSON objects.
     *
     * @type {boolean}
     */
    allowEmpty: true,
  
    /**
     * Determines whether this parser can parse a given file reference.
     * Parsers that match will be tried, in order, until one successfully parses the file.
     * Parsers that don't match will be skipped, UNLESS none of the parsers match, in which case
     * every parser will be tried.
     *
     * @type {RegExp|string[]|function}
     */
    canParse: [".yaml", ".yml", ".json"],  // JSON is valid YAML
  
    /**
     * Parses the given file as YAML
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @param {*}      file.data      - The file contents. This will be whatever data type was returned by the resolver
     * @returns {Promise}
     */
    parse: function parseYAML (file) {
      return new Promise(function (resolve, reject) {
        var data = file.data;
        if (Buffer.isBuffer(data)) {
          data = data.toString();
        }
  
        if (typeof data === "string") {
          resolve(YAML.parse(data));
        }
        else {
          // data is already a JavaScript value (object, array, number, null, NaN, etc.)
          resolve(data);
        }
      });
    }
  };
  
  }).call(this,{"isBuffer":require("../../../is-buffer/index.js")})
  
  },{"../../../is-buffer/index.js":69,"../util/yaml":89}],81:[function(require,module,exports){
  "use strict";
  
  module.exports = Pointer;
  
  var $Ref = require("./ref"),
      url = require("./util/url"),
      ono = require("ono"),
      slashes = /\//g,
      tildes = /~/g,
      escapedSlash = /~1/g,
      escapedTilde = /~0/g;
  
  /**
   * This class represents a single JSON pointer and its resolved value.
   *
   * @param {$Ref} $ref
   * @param {string} path
   * @param {string} [friendlyPath] - The original user-specified path (used for error messages)
   * @constructor
   */
  function Pointer ($ref, path, friendlyPath) {
    /**
     * The {@link $Ref} object that contains this {@link Pointer} object.
     * @type {$Ref}
     */
    this.$ref = $ref;
  
    /**
     * The file path or URL, containing the JSON pointer in the hash.
     * This path is relative to the path of the main JSON schema file.
     * @type {string}
     */
    this.path = path;
  
    /**
     * The original path or URL, used for error messages.
     * @type {string}
     */
    this.originalPath = friendlyPath || path;
  
    /**
     * The value of the JSON pointer.
     * Can be any JSON type, not just objects. Unknown file types are represented as Buffers (byte arrays).
     * @type {?*}
     */
    this.value = undefined;
  
    /**
     * Indicates whether the pointer references itself.
     * @type {boolean}
     */
    this.circular = false;
  
    /**
     * The number of indirect references that were traversed to resolve the value.
     * Resolving a single pointer may require resolving multiple $Refs.
     * @type {number}
     */
    this.indirections = 0;
  }
  
  /**
   * Resolves the value of a nested property within the given object.
   *
   * @param {*} obj - The object that will be crawled
   * @param {$RefParserOptions} options
   *
   * @returns {Pointer}
   * Returns a JSON pointer whose {@link Pointer#value} is the resolved value.
   * If resolving this value required resolving other JSON references, then
   * the {@link Pointer#$ref} and {@link Pointer#path} will reflect the resolution path
   * of the resolved value.
   */
  Pointer.prototype.resolve = function (obj, options) {
    var tokens = Pointer.parse(this.path);
  
    // Crawl the object, one token at a time
    this.value = obj;
    for (var i = 0; i < tokens.length; i++) {
      if (resolveIf$Ref(this, options)) {
        // The $ref path has changed, so append the remaining tokens to the path
        this.path = Pointer.join(this.path, tokens.slice(i));
      }
  
      var token = tokens[i];
      if (this.value[token] === undefined) {
        throw ono.syntax('Error resolving $ref pointer "%s". \nToken "%s" does not exist.', this.originalPath, token);
      }
      else {
        this.value = this.value[token];
      }
    }
  
    // Resolve the final value
    resolveIf$Ref(this, options);
    return this;
  };
  
  /**
   * Sets the value of a nested property within the given object.
   *
   * @param {*} obj - The object that will be crawled
   * @param {*} value - the value to assign
   * @param {$RefParserOptions} options
   *
   * @returns {*}
   * Returns the modified object, or an entirely new object if the entire object is overwritten.
   */
  Pointer.prototype.set = function (obj, value, options) {
    var tokens = Pointer.parse(this.path);
    var token;
  
    if (tokens.length === 0) {
      // There are no tokens, replace the entire object with the new value
      this.value = value;
      return value;
    }
  
    // Crawl the object, one token at a time
    this.value = obj;
    for (var i = 0; i < tokens.length - 1; i++) {
      resolveIf$Ref(this, options);
  
      token = tokens[i];
      if (this.value && this.value[token] !== undefined) {
        // The token exists
        this.value = this.value[token];
      }
      else {
        // The token doesn't exist, so create it
        this.value = setValue(this, token, {});
      }
    }
  
    // Set the value of the final token
    resolveIf$Ref(this, options);
    token = tokens[tokens.length - 1];
    setValue(this, token, value);
  
    // Return the updated object
    return obj;
  };
  
  /**
   * Parses a JSON pointer (or a path containing a JSON pointer in the hash)
   * and returns an array of the pointer's tokens.
   * (e.g. "schema.json#/definitions/person/name" => ["definitions", "person", "name"])
   *
   * The pointer is parsed according to RFC 6901
   * {@link https://tools.ietf.org/html/rfc6901#section-3}
   *
   * @param {string} path
   * @returns {string[]}
   */
  Pointer.parse = function (path) {
    // Get the JSON pointer from the path's hash
    var pointer = url.getHash(path).substr(1);
  
    // If there's no pointer, then there are no tokens,
    // so return an empty array
    if (!pointer) {
      return [];
    }
  
    // Split into an array
    pointer = pointer.split("/");
  
    // Decode each part, according to RFC 6901
    for (var i = 0; i < pointer.length; i++) {
      pointer[i] = decodeURIComponent(pointer[i].replace(escapedSlash, "/").replace(escapedTilde, "~"));
    }
  
    if (pointer[0] !== "") {
      throw ono.syntax('Invalid $ref pointer "%s". Pointers must begin with "#/"', pointer);
    }
  
    return pointer.slice(1);
  };
  
  /**
   * Creates a JSON pointer path, by joining one or more tokens to a base path.
   *
   * @param {string} base - The base path (e.g. "schema.json#/definitions/person")
   * @param {string|string[]} tokens - The token(s) to append (e.g. ["name", "first"])
   * @returns {string}
   */
  Pointer.join = function (base, tokens) {
    // Ensure that the base path contains a hash
    if (base.indexOf("#") === -1) {
      base += "#";
    }
  
    // Append each token to the base path
    tokens = Array.isArray(tokens) ? tokens : [tokens];
    for (var i = 0; i < tokens.length; i++) {
      var token = tokens[i];
      // Encode the token, according to RFC 6901
      base += "/" + encodeURIComponent(token.replace(tildes, "~0").replace(slashes, "~1"));
    }
  
    return base;
  };
  
  /**
   * If the given pointer's {@link Pointer#value} is a JSON reference,
   * then the reference is resolved and {@link Pointer#value} is replaced with the resolved value.
   * In addition, {@link Pointer#path} and {@link Pointer#$ref} are updated to reflect the
   * resolution path of the new value.
   *
   * @param {Pointer} pointer
   * @param {$RefParserOptions} options
   * @returns {boolean} - Returns `true` if the resolution path changed
   */
  function resolveIf$Ref (pointer, options) {
    // Is the value a JSON reference? (and allowed?)
  
    if ($Ref.isAllowed$Ref(pointer.value, options)) {
      var $refPath = url.resolve(pointer.path, pointer.value.$ref);
  
      if ($refPath === pointer.path) {
        // The value is a reference to itself, so there's nothing to do.
        pointer.circular = true;
      }
      else {
        var resolved = pointer.$ref.$refs._resolve($refPath, options);
        pointer.indirections += resolved.indirections + 1;
  
        if ($Ref.isExtended$Ref(pointer.value)) {
          // This JSON reference "extends" the resolved value, rather than simply pointing to it.
          // So the resolved path does NOT change.  Just the value does.
          pointer.value = $Ref.dereference(pointer.value, resolved.value);
          return false;
        }
        else {
          // Resolve the reference
          pointer.$ref = resolved.$ref;
          pointer.path = resolved.path;
          pointer.value = resolved.value;
        }
  
        return true;
      }
    }
  }
  
  /**
   * Sets the specified token value of the {@link Pointer#value}.
   *
   * The token is evaluated according to RFC 6901.
   * {@link https://tools.ietf.org/html/rfc6901#section-4}
   *
   * @param {Pointer} pointer - The JSON Pointer whose value will be modified
   * @param {string} token - A JSON Pointer token that indicates how to modify `obj`
   * @param {*} value - The value to assign
   * @returns {*} - Returns the assigned value
   */
  function setValue (pointer, token, value) {
    if (pointer.value && typeof pointer.value === "object") {
      if (token === "-" && Array.isArray(pointer.value)) {
        pointer.value.push(value);
      }
      else {
        pointer.value[token] = value;
      }
    }
    else {
      throw ono.syntax('Error assigning $ref pointer "%s". \nCannot set "%s" of a non-object.', pointer.path, token);
    }
    return value;
  }
  
  },{"./ref":82,"./util/url":88,"ono":122}],82:[function(require,module,exports){
  "use strict";
  
  module.exports = $Ref;
  
  var Pointer = require("./pointer");
  
  /**
   * This class represents a single JSON reference and its resolved value.
   *
   * @constructor
   */
  function $Ref () {
    /**
     * The file path or URL of the referenced file.
     * This path is relative to the path of the main JSON schema file.
     *
     * This path does NOT contain document fragments (JSON pointers). It always references an ENTIRE file.
     * Use methods such as {@link $Ref#get}, {@link $Ref#resolve}, and {@link $Ref#exists} to get
     * specific JSON pointers within the file.
     *
     * @type {string}
     */
    this.path = undefined;
  
    /**
     * The resolved value of the JSON reference.
     * Can be any JSON type, not just objects. Unknown file types are represented as Buffers (byte arrays).
     * @type {?*}
     */
    this.value = undefined;
  
    /**
     * The {@link $Refs} object that contains this {@link $Ref} object.
     * @type {$Refs}
     */
    this.$refs = undefined;
  
    /**
     * Indicates the type of {@link $Ref#path} (e.g. "file", "http", etc.)
     * @type {?string}
     */
    this.pathType = undefined;
  }
  
  /**
   * Determines whether the given JSON reference exists within this {@link $Ref#value}.
   *
   * @param {string} path - The full path being resolved, optionally with a JSON pointer in the hash
   * @param {$RefParserOptions} options
   * @returns {boolean}
   */
  $Ref.prototype.exists = function (path, options) {
    try {
      this.resolve(path, options);
      return true;
    }
    catch (e) {
      return false;
    }
  };
  
  /**
   * Resolves the given JSON reference within this {@link $Ref#value} and returns the resolved value.
   *
   * @param {string} path - The full path being resolved, optionally with a JSON pointer in the hash
   * @param {$RefParserOptions} options
   * @returns {*} - Returns the resolved value
   */
  $Ref.prototype.get = function (path, options) {
    return this.resolve(path, options).value;
  };
  
  /**
   * Resolves the given JSON reference within this {@link $Ref#value}.
   *
   * @param {string} path - The full path being resolved, optionally with a JSON pointer in the hash
   * @param {$RefParserOptions} options
   * @param {string} [friendlyPath] - The original user-specified path (used for error messages)
   * @returns {Pointer}
   */
  $Ref.prototype.resolve = function (path, options, friendlyPath) {
    var pointer = new Pointer(this, path, friendlyPath);
    return pointer.resolve(this.value, options);
  };
  
  /**
   * Sets the value of a nested property within this {@link $Ref#value}.
   * If the property, or any of its parents don't exist, they will be created.
   *
   * @param {string} path - The full path of the property to set, optionally with a JSON pointer in the hash
   * @param {*} value - The value to assign
   */
  $Ref.prototype.set = function (path, value) {
    var pointer = new Pointer(this, path);
    this.value = pointer.set(this.value, value);
  };
  
  /**
   * Determines whether the given value is a JSON reference.
   *
   * @param {*} value - The value to inspect
   * @returns {boolean}
   */
  $Ref.is$Ref = function (value) {
    return value && typeof value === "object" && typeof value.$ref === "string" && value.$ref.length > 0;
  };
  
  /**
   * Determines whether the given value is an external JSON reference.
   *
   * @param {*} value - The value to inspect
   * @returns {boolean}
   */
  $Ref.isExternal$Ref = function (value) {
    return $Ref.is$Ref(value) && value.$ref[0] !== "#";
  };
  
  /**
   * Determines whether the given value is a JSON reference, and whether it is allowed by the options.
   * For example, if it references an external file, then options.resolve.external must be true.
   *
   * @param {*} value - The value to inspect
   * @param {$RefParserOptions} options
   * @returns {boolean}
   */
  $Ref.isAllowed$Ref = function (value, options) {
    if ($Ref.is$Ref(value)) {
      if (value.$ref.substr(0, 2) === "#/" || value.$ref === "#") {
        // It's a JSON Pointer reference, which is always allowed
        return true;
      }
      else if (value.$ref[0] !== "#" && (!options || options.resolve.external)) {
        // It's an external reference, which is allowed by the options
        return true;
      }
    }
  };
  
  /**
   * Determines whether the given value is a JSON reference that "extends" its resolved value.
   * That is, it has extra properties (in addition to "$ref"), so rather than simply pointing to
   * an existing value, this $ref actually creates a NEW value that is a shallow copy of the resolved
   * value, plus the extra properties.
   *
   * @example:
   *  {
   *    person: {
   *      properties: {
   *        firstName: { type: string }
   *        lastName: { type: string }
   *      }
   *    }
   *    employee: {
   *      properties: {
   *        $ref: #/person/properties
   *        salary: { type: number }
   *      }
   *    }
   *  }
   *
   *  In this example, "employee" is an extended $ref, since it extends "person" with an additional
   *  property (salary).  The result is a NEW value that looks like this:
   *
   *  {
   *    properties: {
   *      firstName: { type: string }
   *      lastName: { type: string }
   *      salary: { type: number }
   *    }
   *  }
   *
   * @param {*} value - The value to inspect
   * @returns {boolean}
   */
  $Ref.isExtended$Ref = function (value) {
    return $Ref.is$Ref(value) && Object.keys(value).length > 1;
  };
  
  /**
   * Returns the resolved value of a JSON Reference.
   * If necessary, the resolved value is merged with the JSON Reference to create a new object
   *
   * @example:
   *  {
   *    person: {
   *      properties: {
   *        firstName: { type: string }
   *        lastName: { type: string }
   *      }
   *    }
   *    employee: {
   *      properties: {
   *        $ref: #/person/properties
   *        salary: { type: number }
   *      }
   *    }
   *  }
   *
   *  When "person" and "employee" are merged, you end up with the following object:
   *
   *  {
   *    properties: {
   *      firstName: { type: string }
   *      lastName: { type: string }
   *      salary: { type: number }
   *    }
   *  }
   *
   * @param {object} $ref - The JSON reference object (the one with the "$ref" property)
   * @param {*} resolvedValue - The resolved value, which can be any type
   * @returns {*} - Returns the dereferenced value
   */
  $Ref.dereference = function ($ref, resolvedValue) {
    if (resolvedValue && typeof resolvedValue === "object" && $Ref.isExtended$Ref($ref)) {
      var merged = {};
      Object.keys($ref).forEach(function (key) {
        if (key !== "$ref") {
          merged[key] = $ref[key];
        }
      });
      Object.keys(resolvedValue).forEach(function (key) {
        if (!(key in merged)) {
          merged[key] = resolvedValue[key];
        }
      });
      return merged;
    }
    else {
      // Completely replace the original reference with the resolved value
      return resolvedValue;
    }
  };
  
  },{"./pointer":81}],83:[function(require,module,exports){
  "use strict";
  
  var ono = require("ono"),
      $Ref = require("./ref"),
      url = require("./util/url");
  
  module.exports = $Refs;
  
  /**
   * This class is a map of JSON references and their resolved values.
   */
  function $Refs () {
    /**
     * Indicates whether the schema contains any circular references.
     *
     * @type {boolean}
     */
    this.circular = false;
  
    /**
     * A map of paths/urls to {@link $Ref} objects
     *
     * @type {object}
     * @protected
     */
    this._$refs = {};
  
    /**
     * The {@link $Ref} object that is the root of the JSON schema.
     *
     * @type {$Ref}
     * @protected
     */
    this._root$Ref = null;
  }
  
  /**
   * Returns the paths of all the files/URLs that are referenced by the JSON schema,
   * including the schema itself.
   *
   * @param {...string|string[]} [types] - Only return paths of the given types ("file", "http", etc.)
   * @returns {string[]}
   */
  $Refs.prototype.paths = function (types) {
    var paths = getPaths(this._$refs, arguments);
    return paths.map(function (path) {
      return path.decoded;
    });
  };
  
  /**
   * Returns the map of JSON references and their resolved values.
   *
   * @param {...string|string[]} [types] - Only return references of the given types ("file", "http", etc.)
   * @returns {object}
   */
  $Refs.prototype.values = function (types) {
    var $refs = this._$refs;
    var paths = getPaths($refs, arguments);
    return paths.reduce(function (obj, path) {
      obj[path.decoded] = $refs[path.encoded].value;
      return obj;
    }, {});
  };
  
  /**
   * Returns a POJO (plain old JavaScript object) for serialization as JSON.
   *
   * @returns {object}
   */
  $Refs.prototype.toJSON = $Refs.prototype.values;
  
  /**
   * Determines whether the given JSON reference exists.
   *
   * @param {string} path - The path being resolved, optionally with a JSON pointer in the hash
   * @param {$RefParserOptions} [options]
   * @returns {boolean}
   */
  $Refs.prototype.exists = function (path, options) {
    try {
      this._resolve(path, options);
      return true;
    }
    catch (e) {
      return false;
    }
  };
  
  /**
   * Resolves the given JSON reference and returns the resolved value.
   *
   * @param {string} path - The path being resolved, with a JSON pointer in the hash
   * @param {$RefParserOptions} [options]
   * @returns {*} - Returns the resolved value
   */
  $Refs.prototype.get = function (path, options) {
    return this._resolve(path, options).value;
  };
  
  /**
   * Sets the value of a nested property within this {@link $Ref#value}.
   * If the property, or any of its parents don't exist, they will be created.
   *
   * @param {string} path - The path of the property to set, optionally with a JSON pointer in the hash
   * @param {*} value - The value to assign
   */
  $Refs.prototype.set = function (path, value) {
    var absPath = url.resolve(this._root$Ref.path, path);
    var withoutHash = url.stripHash(absPath);
    var $ref = this._$refs[withoutHash];
  
    if (!$ref) {
      throw ono('Error resolving $ref pointer "%s". \n"%s" not found.', path, withoutHash);
    }
  
    $ref.set(absPath, value);
  };
  
  /**
   * Creates a new {@link $Ref} object and adds it to this {@link $Refs} object.
   *
   * @param {string} path  - The file path or URL of the referenced file
   */
  $Refs.prototype._add = function (path) {
    var withoutHash = url.stripHash(path);
  
    var $ref = new $Ref();
    $ref.path = withoutHash;
    $ref.$refs = this;
  
    this._$refs[withoutHash] = $ref;
    this._root$Ref = this._root$Ref || $ref;
  
    return $ref;
  };
  
  /**
   * Resolves the given JSON reference.
   *
   * @param {string} path - The path being resolved, optionally with a JSON pointer in the hash
   * @param {$RefParserOptions} [options]
   * @returns {Pointer}
   * @protected
   */
  $Refs.prototype._resolve = function (path, options) {
    var absPath = url.resolve(this._root$Ref.path, path);
    var withoutHash = url.stripHash(absPath);
    var $ref = this._$refs[withoutHash];
  
    if (!$ref) {
      throw ono('Error resolving $ref pointer "%s". \n"%s" not found.', path, withoutHash);
    }
  
    return $ref.resolve(absPath, options, path);
  };
  
  /**
   * Returns the specified {@link $Ref} object, or undefined.
   *
   * @param {string} path - The path being resolved, optionally with a JSON pointer in the hash
   * @returns {$Ref|undefined}
   * @protected
   */
  $Refs.prototype._get$Ref = function (path) {
    path = url.resolve(this._root$Ref.path, path);
    var withoutHash = url.stripHash(path);
    return this._$refs[withoutHash];
  };
  
  /**
   * Returns the encoded and decoded paths keys of the given object.
   *
   * @param {object} $refs - The object whose keys are URL-encoded paths
   * @param {...string|string[]} [types] - Only return paths of the given types ("file", "http", etc.)
   * @returns {object[]}
   */
  function getPaths ($refs, types) {
    var paths = Object.keys($refs);
  
    // Filter the paths by type
    types = Array.isArray(types[0]) ? types[0] : Array.prototype.slice.call(types);
    if (types.length > 0 && types[0]) {
      paths = paths.filter(function (key) {
        return types.indexOf($refs[key].pathType) !== -1;
      });
    }
  
    // Decode local filesystem paths
    return paths.map(function (path) {
      return {
        encoded: path,
        decoded: $refs[path].pathType === "file" ? url.toFileSystemPath(path, true) : path
      };
    });
  }
  
  },{"./ref":82,"./util/url":88,"ono":122}],84:[function(require,module,exports){
  "use strict";
  
  var $Ref = require("./ref"),
      Pointer = require("./pointer"),
      parse = require("./parse"),
      url = require("./util/url");
  
  module.exports = resolveExternal;
  
  /**
   * Crawls the JSON schema, finds all external JSON references, and resolves their values.
   * This method does not mutate the JSON schema. The resolved values are added to {@link $RefParser#$refs}.
   *
   * NOTE: We only care about EXTERNAL references here. INTERNAL references are only relevant when dereferencing.
   *
   * @param {$RefParser} parser
   * @param {$RefParserOptions} options
   *
   * @returns {Promise}
   * The promise resolves once all JSON references in the schema have been resolved,
   * including nested references that are contained in externally-referenced files.
   */
  function resolveExternal (parser, options) {
    if (!options.resolve.external) {
      // Nothing to resolve, so exit early
      return Promise.resolve();
    }
  
    try {
      // console.log('Resolving $ref pointers in %s', parser.$refs._root$Ref.path);
      var promises = crawl(parser.schema, parser.$refs._root$Ref.path + "#", parser.$refs, options);
      return Promise.all(promises);
    }
    catch (e) {
      return Promise.reject(e);
    }
  }
  
  /**
   * Recursively crawls the given value, and resolves any external JSON references.
   *
   * @param {*} obj - The value to crawl. If it's not an object or array, it will be ignored.
   * @param {string} path - The full path of `obj`, possibly with a JSON Pointer in the hash
   * @param {$Refs} $refs
   * @param {$RefParserOptions} options
   *
   * @returns {Promise[]}
   * Returns an array of promises. There will be one promise for each JSON reference in `obj`.
   * If `obj` does not contain any JSON references, then the array will be empty.
   * If any of the JSON references point to files that contain additional JSON references,
   * then the corresponding promise will internally reference an array of promises.
   */
  function crawl (obj, path, $refs, options) {
    var promises = [];
  
    if (obj && typeof obj === "object") {
      if ($Ref.isExternal$Ref(obj)) {
        promises.push(resolve$Ref(obj, path, $refs, options));
      }
      else {
        Object.keys(obj).forEach(function (key) {
          var keyPath = Pointer.join(path, key);
          var value = obj[key];
  
          if ($Ref.isExternal$Ref(value)) {
            promises.push(resolve$Ref(value, keyPath, $refs, options));
          }
          else {
            promises = promises.concat(crawl(value, keyPath, $refs, options));
          }
        });
      }
    }
  
    return promises;
  }
  
  /**
   * Resolves the given JSON Reference, and then crawls the resulting value.
   *
   * @param {{$ref: string}} $ref - The JSON Reference to resolve
   * @param {string} path - The full path of `$ref`, possibly with a JSON Pointer in the hash
   * @param {$Refs} $refs
   * @param {$RefParserOptions} options
   *
   * @returns {Promise}
   * The promise resolves once all JSON references in the object have been resolved,
   * including nested references that are contained in externally-referenced files.
   */
  function resolve$Ref ($ref, path, $refs, options) {
    // console.log('Resolving $ref pointer "%s" at %s', $ref.$ref, path);
  
    var resolvedPath = url.resolve(path, $ref.$ref);
    var withoutHash = url.stripHash(resolvedPath);
  
    // Do we already have this $ref?
    $ref = $refs._$refs[withoutHash];
    if ($ref) {
      // We've already parsed this $ref, so use the existing value
      return Promise.resolve($ref.value);
    }
  
    // Parse the $referenced file/url
    return parse(resolvedPath, $refs, options)
      .then(function (result) {
        // Crawl the parsed value
        // console.log('Resolving $ref pointers in %s', withoutHash);
        var promises = crawl(result, withoutHash + "#", $refs, options);
        return Promise.all(promises);
      });
  }
  
  },{"./parse":76,"./pointer":81,"./ref":82,"./util/url":88}],85:[function(require,module,exports){
  "use strict";
  var fs = require("fs"),
      ono = require("ono"),
      url = require("../util/url");
  
  module.exports = {
    /**
     * The order that this resolver will run, in relation to other resolvers.
     *
     * @type {number}
     */
    order: 100,
  
    /**
     * Determines whether this resolver can read a given file reference.
     * Resolvers that return true will be tried, in order, until one successfully resolves the file.
     * Resolvers that return false will not be given a chance to resolve the file.
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @returns {boolean}
     */
    canRead: function isFile (file) {
      return url.isFileSystemPath(file.url);
    },
  
    /**
     * Reads the given file and returns its raw contents as a Buffer.
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @returns {Promise<Buffer>}
     */
    read: function readFile (file) {
      return new Promise(function (resolve, reject) {
        var path;
        try {
          path = url.toFileSystemPath(file.url);
        }
        catch (err) {
          reject(ono.uri(err, "Malformed URI: %s", file.url));
        }
  
        // console.log('Opening file: %s', path);
  
        try {
          fs.readFile(path, function (err, data) {
            if (err) {
              reject(ono(err, 'Error opening file "%s"', path));
            }
            else {
              resolve(data);
            }
          });
        }
        catch (err) {
          reject(ono(err, 'Error opening file "%s"', path));
        }
      });
    }
  };
  
  },{"../util/url":88,"fs":7,"ono":122}],86:[function(require,module,exports){
  (function (process,Buffer){
  "use strict";
  
  var http = require("http"),
      https = require("https"),
      ono = require("ono"),
      url = require("../util/url");
  
  module.exports = {
    /**
     * The order that this resolver will run, in relation to other resolvers.
     *
     * @type {number}
     */
    order: 200,
  
    /**
     * HTTP headers to send when downloading files.
     *
     * @example:
     * {
     *   "User-Agent": "JSON Schema $Ref Parser",
     *   Accept: "application/json"
     * }
     *
     * @type {object}
     */
    headers: null,
  
    /**
     * HTTP request timeout (in milliseconds).
     *
     * @type {number}
     */
    timeout: 5000, // 5 seconds
  
    /**
     * The maximum number of HTTP redirects to follow.
     * To disable automatic following of redirects, set this to zero.
     *
     * @type {number}
     */
    redirects: 5,
  
    /**
     * The `withCredentials` option of XMLHttpRequest.
     * Set this to `true` if you're downloading files from a CORS-enabled server that requires authentication
     *
     * @type {boolean}
     */
    withCredentials: false,
  
    /**
     * Determines whether this resolver can read a given file reference.
     * Resolvers that return true will be tried in order, until one successfully resolves the file.
     * Resolvers that return false will not be given a chance to resolve the file.
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @returns {boolean}
     */
    canRead: function isHttp (file) {
      return url.isHttp(file.url);
    },
  
    /**
     * Reads the given URL and returns its raw contents as a Buffer.
     *
     * @param {object} file           - An object containing information about the referenced file
     * @param {string} file.url       - The full URL of the referenced file
     * @param {string} file.extension - The lowercased file extension (e.g. ".txt", ".html", etc.)
     * @returns {Promise<Buffer>}
     */
    read: function readHttp (file) {
      var u = url.parse(file.url);
  
      if (process.browser && !u.protocol) {
        // Use the protocol of the current page
        u.protocol = url.parse(location.href).protocol;
      }
  
      return download(u, this);
    }
  };
  
  /**
   * Downloads the given file.
   *
   * @param {Url|string} u        - The url to download (can be a parsed {@link Url} object)
   * @param {object} httpOptions  - The `options.resolve.http` object
   * @param {number} [redirects]  - The redirect URLs that have already been followed
   *
   * @returns {Promise<Buffer>}
   * The promise resolves with the raw downloaded data, or rejects if there is an HTTP error.
   */
  function download (u, httpOptions, redirects) {
    return new Promise(function (resolve, reject) {
      u = url.parse(u);
      redirects = redirects || [];
      redirects.push(u.href);
  
      get(u, httpOptions)
        .then(function (res) {
          if (res.statusCode >= 400) {
            throw ono({ status: res.statusCode }, "HTTP ERROR %d", res.statusCode);
          }
          else if (res.statusCode >= 300) {
            if (redirects.length > httpOptions.redirects) {
              reject(ono({ status: res.statusCode }, "Error downloading %s. \nToo many redirects: \n  %s",
                redirects[0], redirects.join(" \n  ")));
            }
            else if (!res.headers.location) {
              throw ono({ status: res.statusCode }, "HTTP %d redirect with no location header", res.statusCode);
            }
            else {
              // console.log('HTTP %d redirect %s -> %s', res.statusCode, u.href, res.headers.location);
              var redirectTo = url.resolve(u, res.headers.location);
              download(redirectTo, httpOptions, redirects).then(resolve, reject);
            }
          }
          else {
            resolve(res.body || new Buffer(0));
          }
        })
        .catch(function (err) {
          reject(ono(err, "Error downloading", u.href));
        });
    });
  }
  
  /**
   * Sends an HTTP GET request.
   *
   * @param {Url} u - A parsed {@link Url} object
   * @param {object} httpOptions - The `options.resolve.http` object
   *
   * @returns {Promise<Response>}
   * The promise resolves with the HTTP Response object.
   */
  function get (u, httpOptions) {
    return new Promise(function (resolve, reject) {
      // console.log('GET', u.href);
  
      var protocol = u.protocol === "https:" ? https : http;
      var req = protocol.get({
        hostname: u.hostname,
        port: u.port,
        path: u.path,
        auth: u.auth,
        protocol: u.protocol,
        headers: httpOptions.headers || {},
        withCredentials: httpOptions.withCredentials
      });
  
      if (typeof req.setTimeout === "function") {
        req.setTimeout(httpOptions.timeout);
      }
  
      req.on("timeout", function () {
        req.abort();
      });
  
      req.on("error", reject);
  
      req.once("response", function (res) {
        res.body = new Buffer(0);
  
        res.on("data", function (data) {
          res.body = Buffer.concat([res.body, new Buffer(data)]);
        });
  
        res.on("error", reject);
  
        res.on("end", function () {
          resolve(res);
        });
      });
    });
  }
  
  }).call(this,require('_process'),require("buffer").Buffer)
  
  },{"../util/url":88,"_process":125,"buffer":9,"http":139,"https":66,"ono":122}],87:[function(require,module,exports){
  "use strict";
  
  /**
   * Returns the given plugins as an array, rather than an object map.
   * All other methods in this module expect an array of plugins rather than an object map.
   *
   * @param  {object} plugins - A map of plugin objects
   * @return {object[]}
   */
  exports.all = function (plugins) {
    return Object.keys(plugins)
      .filter(function (key) {
        return typeof plugins[key] === "object";
      })
      .map(function (key) {
        plugins[key].name = key;
        return plugins[key];
      });
  };
  
  /**
   * Filters the given plugins, returning only the ones return `true` for the given method.
   *
   * @param  {object[]} plugins - An array of plugin objects
   * @param  {string}   method  - The name of the filter method to invoke for each plugin
   * @param  {object}   file    - A file info object, which will be passed to each method
   * @return {object[]}
   */
  exports.filter = function (plugins, method, file) {
    return plugins
      .filter(function (plugin) {
        return !!getResult(plugin, method, file);
      });
  };
  
  /**
   * Sorts the given plugins, in place, by their `order` property.
   *
   * @param {object[]} plugins - An array of plugin objects
   * @returns {object[]}
   */
  exports.sort = function (plugins) {
    plugins.forEach(function (plugin) {
      plugin.order = plugin.order || Number.MAX_SAFE_INTEGER;
    });
  
    return plugins.sort(function (a, b) { return a.order - b.order; });
  };
  
  /**
   * Runs the specified method of the given plugins, in order, until one of them returns a successful result.
   * Each method can return a synchronous value, a Promise, or call an error-first callback.
   * If the promise resolves successfully, or the callback is called without an error, then the result
   * is immediately returned and no further plugins are called.
   * If the promise rejects, or the callback is called with an error, then the next plugin is called.
   * If ALL plugins fail, then the last error is thrown.
   *
   * @param {object[]}  plugins - An array of plugin objects
   * @param {string}    method  - The name of the method to invoke for each plugin
   * @param {object}    file    - A file info object, which will be passed to each method
   * @returns {Promise}
   */
  exports.run = function (plugins, method, file) {
    var plugin, lastError, index = 0;
  
    return new Promise(function (resolve, reject) {
      runNextPlugin();
  
      function runNextPlugin () {
        plugin = plugins[index++];
        if (!plugin) {
          // There are no more functions, so re-throw the last error
          return reject(lastError);
        }
  
        try {
          // console.log('  %s', plugin.name);
          var result = getResult(plugin, method, file, callback);
          if (result && typeof result.then === "function") {
            // A promise was returned
            result.then(onSuccess, onError);
          }
          else if (result !== undefined) {
            // A synchronous result was returned
            onSuccess(result);
          }
          // else { the callback will be called }
        }
        catch (e) {
          onError(e);
        }
      }
  
      function callback (err, result) {
        if (err) {
          onError(err);
        }
        else {
          onSuccess(result);
        }
      }
  
      function onSuccess (result) {
        // console.log('    success');
        resolve({
          plugin: plugin,
          result: result
        });
      }
  
      function onError (err) {
        // console.log('    %s', err.message || err);
        lastError = err;
        runNextPlugin();
      }
    });
  };
  
  /**
   * Returns the value of the given property.
   * If the property is a function, then the result of the function is returned.
   * If the value is a RegExp, then it will be tested against the file URL.
   * If the value is an aray, then it will be compared against the file extension.
   *
   * @param   {object}   obj        - The object whose property/method is called
   * @param   {string}   prop       - The name of the property/method to invoke
   * @param   {object}   file       - A file info object, which will be passed to the method
   * @param   {function} [callback] - A callback function, which will be passed to the method
   * @returns {*}
   */
  function getResult (obj, prop, file, callback) {
    var value = obj[prop];
  
    if (typeof value === "function") {
      return value.apply(obj, [file, callback]);
    }
  
    if (!callback) {
      // The synchronous plugin functions (canParse and canRead)
      // allow a "shorthand" syntax, where the user can match
      // files by RegExp or by file extension.
      if (value instanceof RegExp) {
        return value.test(file.url);
      }
      else if (typeof value === "string") {
        return value === file.extension;
      }
      else if (Array.isArray(value)) {
        return value.indexOf(file.extension) !== -1;
      }
    }
  
    return value;
  }
  
  },{}],88:[function(require,module,exports){
  (function (process){
  "use strict";
  
  var isWindows = /^win/.test(process.platform),
      forwardSlashPattern = /\//g,
      protocolPattern = /^(\w{2,}):\/\//i,
      url = module.exports;
  
  // RegExp patterns to URL-encode special characters in local filesystem paths
  var urlEncodePatterns = [
    /\?/g, "%3F",
    /\#/g, "%23",
  ];
  
  // RegExp patterns to URL-decode special characters for local filesystem paths
  var urlDecodePatterns = [
    /\%23/g, "#",
    /\%24/g, "$",
    /\%26/g, "&",
    /\%2C/g, ",",
    /\%40/g, "@"
  ];
  
  exports.parse = require("url").parse;
  exports.resolve = require("url").resolve;
  
  /**
   * Returns the current working directory (in Node) or the current page URL (in browsers).
   *
   * @returns {string}
   */
  exports.cwd = function cwd () {
    return process.browser ? location.href : process.cwd() + "/";
  };
  
  /**
   * Returns the protocol of the given URL, or `undefined` if it has no protocol.
   *
   * @param   {string} path
   * @returns {?string}
   */
  exports.getProtocol = function getProtocol (path) {
    var match = protocolPattern.exec(path);
    if (match) {
      return match[1].toLowerCase();
    }
  };
  
  /**
   * Returns the lowercased file extension of the given URL,
   * or an empty string if it has no extension.
   *
   * @param   {string} path
   * @returns {string}
   */
  exports.getExtension = function getExtension (path) {
    var lastDot = path.lastIndexOf(".");
    if (lastDot >= 0) {
      return path.substr(lastDot).toLowerCase();
    }
    return "";
  };
  
  /**
   * Returns the hash (URL fragment), of the given path.
   * If there is no hash, then the root hash ("#") is returned.
   *
   * @param   {string} path
   * @returns {string}
   */
  exports.getHash = function getHash (path) {
    var hashIndex = path.indexOf("#");
    if (hashIndex >= 0) {
      return path.substr(hashIndex);
    }
    return "#";
  };
  
  /**
   * Removes the hash (URL fragment), if any, from the given path.
   *
   * @param   {string} path
   * @returns {string}
   */
  exports.stripHash = function stripHash (path) {
    var hashIndex = path.indexOf("#");
    if (hashIndex >= 0) {
      path = path.substr(0, hashIndex);
    }
    return path;
  };
  
  /**
   * Determines whether the given path is an HTTP(S) URL.
   *
   * @param   {string} path
   * @returns {boolean}
   */
  exports.isHttp = function isHttp (path) {
    var protocol = url.getProtocol(path);
    if (protocol === "http" || protocol === "https") {
      return true;
    }
    else if (protocol === undefined) {
      // There is no protocol.  If we're running in a browser, then assume it's HTTP.
      return process.browser;
    }
    else {
      // It's some other protocol, such as "ftp://", "mongodb://", etc.
      return false;
    }
  };
  
  /**
   * Determines whether the given path is a filesystem path.
   * This includes "file://" URLs.
   *
   * @param   {string} path
   * @returns {boolean}
   */
  exports.isFileSystemPath = function isFileSystemPath (path) {
    if (process.browser) {
      // We're running in a browser, so assume that all paths are URLs.
      // This way, even relative paths will be treated as URLs rather than as filesystem paths
      return false;
    }
  
    var protocol = url.getProtocol(path);
    return protocol === undefined || protocol === "file";
  };
  
  /**
   * Converts a filesystem path to a properly-encoded URL.
   *
   * This is intended to handle situations where JSON Schema $Ref Parser is called
   * with a filesystem path that contains characters which are not allowed in URLs.
   *
   * @example
   * The following filesystem paths would be converted to the following URLs:
   *
   *    <"!@#$%^&*+=?'>.json              ==>   %3C%22!@%23$%25%5E&*+=%3F\'%3E.json
   *    C:\\My Documents\\File (1).json   ==>   C:/My%20Documents/File%20(1).json
   *    file://Project #42/file.json      ==>   file://Project%20%2342/file.json
   *
   * @param {string} path
   * @returns {string}
   */
  exports.fromFileSystemPath = function fromFileSystemPath (path) {
    // Step 1: On Windows, replace backslashes with forward slashes,
    // rather than encoding them as "%5C"
    if (isWindows) {
      path = path.replace(/\\/g, "/");
    }
  
    // Step 2: `encodeURI` will take care of MOST characters
    path = encodeURI(path);
  
    // Step 3: Manually encode characters that are not encoded by `encodeURI`.
    // This includes characters such as "#" and "?", which have special meaning in URLs,
    // but are just normal characters in a filesystem path.
    for (var i = 0; i < urlEncodePatterns.length; i += 2) {
      path = path.replace(urlEncodePatterns[i], urlEncodePatterns[i + 1]);
    }
  
    return path;
  };
  
  /**
   * Converts a URL to a local filesystem path.
   *
   * @param {string}  path
   * @param {boolean} [keepFileProtocol] - If true, then "file://" will NOT be stripped
   * @returns {string}
   */
  exports.toFileSystemPath = function toFileSystemPath (path, keepFileProtocol) {
    // Step 1: `decodeURI` will decode characters such as Cyrillic characters, spaces, etc.
    path = decodeURI(path);
  
    // Step 2: Manually decode characters that are not decoded by `decodeURI`.
    // This includes characters such as "#" and "?", which have special meaning in URLs,
    // but are just normal characters in a filesystem path.
    for (var i = 0; i < urlDecodePatterns.length; i += 2) {
      path = path.replace(urlDecodePatterns[i], urlDecodePatterns[i + 1]);
    }
  
    // Step 3: If it's a "file://" URL, then format it consistently
    // or convert it to a local filesystem path
    var isFileUrl = path.substr(0, 7).toLowerCase() === "file://";
    if (isFileUrl) {
      // Strip-off the protocol, and the initial "/", if there is one
      path = path[7] === "/" ? path.substr(8) : path.substr(7);
  
      // insert a colon (":") after the drive letter on Windows
      if (isWindows && path[1] === "/") {
        path = path[0] + ":" + path.substr(1);
      }
  
      if (keepFileProtocol) {
        // Return the consistently-formatted "file://" URL
        path = "file:///" + path;
      }
      else {
        // Convert the "file://" URL to a local filesystem path.
        // On Windows, it will start with something like "C:/".
        // On Posix, it will start with "/"
        isFileUrl = false;
        path = isWindows ? path : "/" + path;
      }
    }
  
    // Step 4: Normalize Windows paths (unless it's a "file://" URL)
    if (isWindows && !isFileUrl) {
      // Replace forward slashes with backslashes
      path = path.replace(forwardSlashPattern, "\\");
  
      // Capitalize the drive letter
      if (path.substr(1, 2) === ":\\") {
        path = path[0].toUpperCase() + path.substr(1);
      }
    }
  
    return path;
  };
  
  }).call(this,require('_process'))
  
  },{"_process":125,"url":148}],89:[function(require,module,exports){
  /* eslint lines-around-comment: [2, {beforeBlockComment: false}] */
  "use strict";
  
  var yaml = require("js-yaml"),
      ono = require("ono");
  
  /**
   * Simple YAML parsing functions, similar to {@link JSON.parse} and {@link JSON.stringify}
   */
  module.exports = {
    /**
     * Parses a YAML string and returns the value.
     *
     * @param {string} text - The YAML string to be parsed
     * @param {function} [reviver] - Not currently supported. Provided for consistency with {@link JSON.parse}
     * @returns {*}
     */
    parse: function yamlParse (text, reviver) {
      try {
        return yaml.safeLoad(text);
      }
      catch (e) {
        if (e instanceof Error) {
          throw e;
        }
        else {
          // https://github.com/nodeca/js-yaml/issues/153
          throw ono(e, e.message);
        }
      }
    },
  
    /**
     * Converts a JavaScript value to a YAML string.
     *
     * @param   {*} value - The value to convert to YAML
     * @param   {function|array} replacer - Not currently supported. Provided for consistency with {@link JSON.stringify}
     * @param   {string|number} space - The number of spaces to use for indentation, or a string containing the number of spaces.
     * @returns {string}
     */
    stringify: function yamlStringify (value, replacer, space) {
      try {
        var indent = (typeof space === "string" ? space.length : space) || 2;
        return yaml.safeDump(value, { indent: indent });
      }
      catch (e) {
        if (e instanceof Error) {
          throw e;
        }
        else {
          // https://github.com/nodeca/js-yaml/issues/153
          throw ono(e, e.message);
        }
      }
    }
  };
  
  },{"js-yaml":90,"ono":122}],90:[function(require,module,exports){
  'use strict';
  
  
  var yaml = require('./lib/js-yaml.js');
  
  
  module.exports = yaml;
  
  },{"./lib/js-yaml.js":91}],91:[function(require,module,exports){
  'use strict';
  
  
  var loader = require('./js-yaml/loader');
  var dumper = require('./js-yaml/dumper');
  
  
  function deprecated(name) {
    return function () {
      throw new Error('Function ' + name + ' is deprecated and cannot be used.');
    };
  }
  
  
  module.exports.Type                = require('./js-yaml/type');
  module.exports.Schema              = require('./js-yaml/schema');
  module.exports.FAILSAFE_SCHEMA     = require('./js-yaml/schema/failsafe');
  module.exports.JSON_SCHEMA         = require('./js-yaml/schema/json');
  module.exports.CORE_SCHEMA         = require('./js-yaml/schema/core');
  module.exports.DEFAULT_SAFE_SCHEMA = require('./js-yaml/schema/default_safe');
  module.exports.DEFAULT_FULL_SCHEMA = require('./js-yaml/schema/default_full');
  module.exports.load                = loader.load;
  module.exports.loadAll             = loader.loadAll;
  module.exports.safeLoad            = loader.safeLoad;
  module.exports.safeLoadAll         = loader.safeLoadAll;
  module.exports.dump                = dumper.dump;
  module.exports.safeDump            = dumper.safeDump;
  module.exports.YAMLException       = require('./js-yaml/exception');
  
  // Deprecated schema names from JS-YAML 2.0.x
  module.exports.MINIMAL_SCHEMA = require('./js-yaml/schema/failsafe');
  module.exports.SAFE_SCHEMA    = require('./js-yaml/schema/default_safe');
  module.exports.DEFAULT_SCHEMA = require('./js-yaml/schema/default_full');
  
  // Deprecated functions from JS-YAML 1.x.x
  module.exports.scan           = deprecated('scan');
  module.exports.parse          = deprecated('parse');
  module.exports.compose        = deprecated('compose');
  module.exports.addConstructor = deprecated('addConstructor');
  
  },{"./js-yaml/dumper":93,"./js-yaml/exception":94,"./js-yaml/loader":95,"./js-yaml/schema":97,"./js-yaml/schema/core":98,"./js-yaml/schema/default_full":99,"./js-yaml/schema/default_safe":100,"./js-yaml/schema/failsafe":101,"./js-yaml/schema/json":102,"./js-yaml/type":103}],92:[function(require,module,exports){
  'use strict';
  
  
  function isNothing(subject) {
    return (typeof subject === 'undefined') || (subject === null);
  }
  
  
  function isObject(subject) {
    return (typeof subject === 'object') && (subject !== null);
  }
  
  
  function toArray(sequence) {
    if (Array.isArray(sequence)) return sequence;
    else if (isNothing(sequence)) return [];
  
    return [ sequence ];
  }
  
  
  function extend(target, source) {
    var index, length, key, sourceKeys;
  
    if (source) {
      sourceKeys = Object.keys(source);
  
      for (index = 0, length = sourceKeys.length; index < length; index += 1) {
        key = sourceKeys[index];
        target[key] = source[key];
      }
    }
  
    return target;
  }
  
  
  function repeat(string, count) {
    var result = '', cycle;
  
    for (cycle = 0; cycle < count; cycle += 1) {
      result += string;
    }
  
    return result;
  }
  
  
  function isNegativeZero(number) {
    return (number === 0) && (Number.NEGATIVE_INFINITY === 1 / number);
  }
  
  
  module.exports.isNothing      = isNothing;
  module.exports.isObject       = isObject;
  module.exports.toArray        = toArray;
  module.exports.repeat         = repeat;
  module.exports.isNegativeZero = isNegativeZero;
  module.exports.extend         = extend;
  
  },{}],93:[function(require,module,exports){
  'use strict';
  
  /*eslint-disable no-use-before-define*/
  
  var common              = require('./common');
  var YAMLException       = require('./exception');
  var DEFAULT_FULL_SCHEMA = require('./schema/default_full');
  var DEFAULT_SAFE_SCHEMA = require('./schema/default_safe');
  
  var _toString       = Object.prototype.toString;
  var _hasOwnProperty = Object.prototype.hasOwnProperty;
  
  var CHAR_TAB                  = 0x09; /* Tab */
  var CHAR_LINE_FEED            = 0x0A; /* LF */
  var CHAR_SPACE                = 0x20; /* Space */
  var CHAR_EXCLAMATION          = 0x21; /* ! */
  var CHAR_DOUBLE_QUOTE         = 0x22; /* " */
  var CHAR_SHARP                = 0x23; /* # */
  var CHAR_PERCENT              = 0x25; /* % */
  var CHAR_AMPERSAND            = 0x26; /* & */
  var CHAR_SINGLE_QUOTE         = 0x27; /* ' */
  var CHAR_ASTERISK             = 0x2A; /* * */
  var CHAR_COMMA                = 0x2C; /* , */
  var CHAR_MINUS                = 0x2D; /* - */
  var CHAR_COLON                = 0x3A; /* : */
  var CHAR_GREATER_THAN         = 0x3E; /* > */
  var CHAR_QUESTION             = 0x3F; /* ? */
  var CHAR_COMMERCIAL_AT        = 0x40; /* @ */
  var CHAR_LEFT_SQUARE_BRACKET  = 0x5B; /* [ */
  var CHAR_RIGHT_SQUARE_BRACKET = 0x5D; /* ] */
  var CHAR_GRAVE_ACCENT         = 0x60; /* ` */
  var CHAR_LEFT_CURLY_BRACKET   = 0x7B; /* { */
  var CHAR_VERTICAL_LINE        = 0x7C; /* | */
  var CHAR_RIGHT_CURLY_BRACKET  = 0x7D; /* } */
  
  var ESCAPE_SEQUENCES = {};
  
  ESCAPE_SEQUENCES[0x00]   = '\\0';
  ESCAPE_SEQUENCES[0x07]   = '\\a';
  ESCAPE_SEQUENCES[0x08]   = '\\b';
  ESCAPE_SEQUENCES[0x09]   = '\\t';
  ESCAPE_SEQUENCES[0x0A]   = '\\n';
  ESCAPE_SEQUENCES[0x0B]   = '\\v';
  ESCAPE_SEQUENCES[0x0C]   = '\\f';
  ESCAPE_SEQUENCES[0x0D]   = '\\r';
  ESCAPE_SEQUENCES[0x1B]   = '\\e';
  ESCAPE_SEQUENCES[0x22]   = '\\"';
  ESCAPE_SEQUENCES[0x5C]   = '\\\\';
  ESCAPE_SEQUENCES[0x85]   = '\\N';
  ESCAPE_SEQUENCES[0xA0]   = '\\_';
  ESCAPE_SEQUENCES[0x2028] = '\\L';
  ESCAPE_SEQUENCES[0x2029] = '\\P';
  
  var DEPRECATED_BOOLEANS_SYNTAX = [
    'y', 'Y', 'yes', 'Yes', 'YES', 'on', 'On', 'ON',
    'n', 'N', 'no', 'No', 'NO', 'off', 'Off', 'OFF'
  ];
  
  function compileStyleMap(schema, map) {
    var result, keys, index, length, tag, style, type;
  
    if (map === null) return {};
  
    result = {};
    keys = Object.keys(map);
  
    for (index = 0, length = keys.length; index < length; index += 1) {
      tag = keys[index];
      style = String(map[tag]);
  
      if (tag.slice(0, 2) === '!!') {
        tag = 'tag:yaml.org,2002:' + tag.slice(2);
      }
      type = schema.compiledTypeMap['fallback'][tag];
  
      if (type && _hasOwnProperty.call(type.styleAliases, style)) {
        style = type.styleAliases[style];
      }
  
      result[tag] = style;
    }
  
    return result;
  }
  
  function encodeHex(character) {
    var string, handle, length;
  
    string = character.toString(16).toUpperCase();
  
    if (character <= 0xFF) {
      handle = 'x';
      length = 2;
    } else if (character <= 0xFFFF) {
      handle = 'u';
      length = 4;
    } else if (character <= 0xFFFFFFFF) {
      handle = 'U';
      length = 8;
    } else {
      throw new YAMLException('code point within a string may not be greater than 0xFFFFFFFF');
    }
  
    return '\\' + handle + common.repeat('0', length - string.length) + string;
  }
  
  function State(options) {
    this.schema        = options['schema'] || DEFAULT_FULL_SCHEMA;
    this.indent        = Math.max(1, (options['indent'] || 2));
    this.noArrayIndent = options['noArrayIndent'] || false;
    this.skipInvalid   = options['skipInvalid'] || false;
    this.flowLevel     = (common.isNothing(options['flowLevel']) ? -1 : options['flowLevel']);
    this.styleMap      = compileStyleMap(this.schema, options['styles'] || null);
    this.sortKeys      = options['sortKeys'] || false;
    this.lineWidth     = options['lineWidth'] || 80;
    this.noRefs        = options['noRefs'] || false;
    this.noCompatMode  = options['noCompatMode'] || false;
    this.condenseFlow  = options['condenseFlow'] || false;
  
    this.implicitTypes = this.schema.compiledImplicit;
    this.explicitTypes = this.schema.compiledExplicit;
  
    this.tag = null;
    this.result = '';
  
    this.duplicates = [];
    this.usedDuplicates = null;
  }
  
  // Indents every line in a string. Empty lines (\n only) are not indented.
  function indentString(string, spaces) {
    var ind = common.repeat(' ', spaces),
        position = 0,
        next = -1,
        result = '',
        line,
        length = string.length;
  
    while (position < length) {
      next = string.indexOf('\n', position);
      if (next === -1) {
        line = string.slice(position);
        position = length;
      } else {
        line = string.slice(position, next + 1);
        position = next + 1;
      }
  
      if (line.length && line !== '\n') result += ind;
  
      result += line;
    }
  
    return result;
  }
  
  function generateNextLine(state, level) {
    return '\n' + common.repeat(' ', state.indent * level);
  }
  
  function testImplicitResolving(state, str) {
    var index, length, type;
  
    for (index = 0, length = state.implicitTypes.length; index < length; index += 1) {
      type = state.implicitTypes[index];
  
      if (type.resolve(str)) {
        return true;
      }
    }
  
    return false;
  }
  
  // [33] s-white ::= s-space | s-tab
  function isWhitespace(c) {
    return c === CHAR_SPACE || c === CHAR_TAB;
  }
  
  // Returns true if the character can be printed without escaping.
  // From YAML 1.2: "any allowed characters known to be non-printable
  // should also be escaped. [However,] This isn’t mandatory"
  // Derived from nb-char - \t - #x85 - #xA0 - #x2028 - #x2029.
  function isPrintable(c) {
    return  (0x00020 <= c && c <= 0x00007E)
        || ((0x000A1 <= c && c <= 0x00D7FF) && c !== 0x2028 && c !== 0x2029)
        || ((0x0E000 <= c && c <= 0x00FFFD) && c !== 0xFEFF /* BOM */)
        ||  (0x10000 <= c && c <= 0x10FFFF);
  }
  
  // Simplified test for values allowed after the first character in plain style.
  function isPlainSafe(c) {
    // Uses a subset of nb-char - c-flow-indicator - ":" - "#"
    // where nb-char ::= c-printable - b-char - c-byte-order-mark.
    return isPrintable(c) && c !== 0xFEFF
      // - c-flow-indicator
      && c !== CHAR_COMMA
      && c !== CHAR_LEFT_SQUARE_BRACKET
      && c !== CHAR_RIGHT_SQUARE_BRACKET
      && c !== CHAR_LEFT_CURLY_BRACKET
      && c !== CHAR_RIGHT_CURLY_BRACKET
      // - ":" - "#"
      && c !== CHAR_COLON
      && c !== CHAR_SHARP;
  }
  
  // Simplified test for values allowed as the first character in plain style.
  function isPlainSafeFirst(c) {
    // Uses a subset of ns-char - c-indicator
    // where ns-char = nb-char - s-white.
    return isPrintable(c) && c !== 0xFEFF
      && !isWhitespace(c) // - s-white
      // - (c-indicator ::=
      // “-” | “?” | “:” | “,” | “[” | “]” | “{” | “}”
      && c !== CHAR_MINUS
      && c !== CHAR_QUESTION
      && c !== CHAR_COLON
      && c !== CHAR_COMMA
      && c !== CHAR_LEFT_SQUARE_BRACKET
      && c !== CHAR_RIGHT_SQUARE_BRACKET
      && c !== CHAR_LEFT_CURLY_BRACKET
      && c !== CHAR_RIGHT_CURLY_BRACKET
      // | “#” | “&” | “*” | “!” | “|” | “>” | “'” | “"”
      && c !== CHAR_SHARP
      && c !== CHAR_AMPERSAND
      && c !== CHAR_ASTERISK
      && c !== CHAR_EXCLAMATION
      && c !== CHAR_VERTICAL_LINE
      && c !== CHAR_GREATER_THAN
      && c !== CHAR_SINGLE_QUOTE
      && c !== CHAR_DOUBLE_QUOTE
      // | “%” | “@” | “`”)
      && c !== CHAR_PERCENT
      && c !== CHAR_COMMERCIAL_AT
      && c !== CHAR_GRAVE_ACCENT;
  }
  
  // Determines whether block indentation indicator is required.
  function needIndentIndicator(string) {
    var leadingSpaceRe = /^\n* /;
    return leadingSpaceRe.test(string);
  }
  
  var STYLE_PLAIN   = 1,
      STYLE_SINGLE  = 2,
      STYLE_LITERAL = 3,
      STYLE_FOLDED  = 4,
      STYLE_DOUBLE  = 5;
  
  // Determines which scalar styles are possible and returns the preferred style.
  // lineWidth = -1 => no limit.
  // Pre-conditions: str.length > 0.
  // Post-conditions:
  //    STYLE_PLAIN or STYLE_SINGLE => no \n are in the string.
  //    STYLE_LITERAL => no lines are suitable for folding (or lineWidth is -1).
  //    STYLE_FOLDED => a line > lineWidth and can be folded (and lineWidth != -1).
  function chooseScalarStyle(string, singleLineOnly, indentPerLevel, lineWidth, testAmbiguousType) {
    var i;
    var char;
    var hasLineBreak = false;
    var hasFoldableLine = false; // only checked if shouldTrackWidth
    var shouldTrackWidth = lineWidth !== -1;
    var previousLineBreak = -1; // count the first line correctly
    var plain = isPlainSafeFirst(string.charCodeAt(0))
            && !isWhitespace(string.charCodeAt(string.length - 1));
  
    if (singleLineOnly) {
      // Case: no block styles.
      // Check for disallowed characters to rule out plain and single.
      for (i = 0; i < string.length; i++) {
        char = string.charCodeAt(i);
        if (!isPrintable(char)) {
          return STYLE_DOUBLE;
        }
        plain = plain && isPlainSafe(char);
      }
    } else {
      // Case: block styles permitted.
      for (i = 0; i < string.length; i++) {
        char = string.charCodeAt(i);
        if (char === CHAR_LINE_FEED) {
          hasLineBreak = true;
          // Check if any line can be folded.
          if (shouldTrackWidth) {
            hasFoldableLine = hasFoldableLine ||
              // Foldable line = too long, and not more-indented.
              (i - previousLineBreak - 1 > lineWidth &&
               string[previousLineBreak + 1] !== ' ');
            previousLineBreak = i;
          }
        } else if (!isPrintable(char)) {
          return STYLE_DOUBLE;
        }
        plain = plain && isPlainSafe(char);
      }
      // in case the end is missing a \n
      hasFoldableLine = hasFoldableLine || (shouldTrackWidth &&
        (i - previousLineBreak - 1 > lineWidth &&
         string[previousLineBreak + 1] !== ' '));
    }
    // Although every style can represent \n without escaping, prefer block styles
    // for multiline, since they're more readable and they don't add empty lines.
    // Also prefer folding a super-long line.
    if (!hasLineBreak && !hasFoldableLine) {
      // Strings interpretable as another type have to be quoted;
      // e.g. the string 'true' vs. the boolean true.
      return plain && !testAmbiguousType(string)
        ? STYLE_PLAIN : STYLE_SINGLE;
    }
    // Edge case: block indentation indicator can only have one digit.
    if (indentPerLevel > 9 && needIndentIndicator(string)) {
      return STYLE_DOUBLE;
    }
    // At this point we know block styles are valid.
    // Prefer literal style unless we want to fold.
    return hasFoldableLine ? STYLE_FOLDED : STYLE_LITERAL;
  }
  
  // Note: line breaking/folding is implemented for only the folded style.
  // NB. We drop the last trailing newline (if any) of a returned block scalar
  //  since the dumper adds its own newline. This always works:
  //    • No ending newline => unaffected; already using strip "-" chomping.
  //    • Ending newline    => removed then restored.
  //  Importantly, this keeps the "+" chomp indicator from gaining an extra line.
  function writeScalar(state, string, level, iskey) {
    state.dump = (function () {
      if (string.length === 0) {
        return "''";
      }
      if (!state.noCompatMode &&
          DEPRECATED_BOOLEANS_SYNTAX.indexOf(string) !== -1) {
        return "'" + string + "'";
      }
  
      var indent = state.indent * Math.max(1, level); // no 0-indent scalars
      // As indentation gets deeper, let the width decrease monotonically
      // to the lower bound min(state.lineWidth, 40).
      // Note that this implies
      //  state.lineWidth ≤ 40 + state.indent: width is fixed at the lower bound.
      //  state.lineWidth > 40 + state.indent: width decreases until the lower bound.
      // This behaves better than a constant minimum width which disallows narrower options,
      // or an indent threshold which causes the width to suddenly increase.
      var lineWidth = state.lineWidth === -1
        ? -1 : Math.max(Math.min(state.lineWidth, 40), state.lineWidth - indent);
  
      // Without knowing if keys are implicit/explicit, assume implicit for safety.
      var singleLineOnly = iskey
        // No block styles in flow mode.
        || (state.flowLevel > -1 && level >= state.flowLevel);
      function testAmbiguity(string) {
        return testImplicitResolving(state, string);
      }
  
      switch (chooseScalarStyle(string, singleLineOnly, state.indent, lineWidth, testAmbiguity)) {
        case STYLE_PLAIN:
          return string;
        case STYLE_SINGLE:
          return "'" + string.replace(/'/g, "''") + "'";
        case STYLE_LITERAL:
          return '|' + blockHeader(string, state.indent)
            + dropEndingNewline(indentString(string, indent));
        case STYLE_FOLDED:
          return '>' + blockHeader(string, state.indent)
            + dropEndingNewline(indentString(foldString(string, lineWidth), indent));
        case STYLE_DOUBLE:
          return '"' + escapeString(string, lineWidth) + '"';
        default:
          throw new YAMLException('impossible error: invalid scalar style');
      }
    }());
  }
  
  // Pre-conditions: string is valid for a block scalar, 1 <= indentPerLevel <= 9.
  function blockHeader(string, indentPerLevel) {
    var indentIndicator = needIndentIndicator(string) ? String(indentPerLevel) : '';
  
    // note the special case: the string '\n' counts as a "trailing" empty line.
    var clip =          string[string.length - 1] === '\n';
    var keep = clip && (string[string.length - 2] === '\n' || string === '\n');
    var chomp = keep ? '+' : (clip ? '' : '-');
  
    return indentIndicator + chomp + '\n';
  }
  
  // (See the note for writeScalar.)
  function dropEndingNewline(string) {
    return string[string.length - 1] === '\n' ? string.slice(0, -1) : string;
  }
  
  // Note: a long line without a suitable break point will exceed the width limit.
  // Pre-conditions: every char in str isPrintable, str.length > 0, width > 0.
  function foldString(string, width) {
    // In folded style, $k$ consecutive newlines output as $k+1$ newlines—
    // unless they're before or after a more-indented line, or at the very
    // beginning or end, in which case $k$ maps to $k$.
    // Therefore, parse each chunk as newline(s) followed by a content line.
    var lineRe = /(\n+)([^\n]*)/g;
  
    // first line (possibly an empty line)
    var result = (function () {
      var nextLF = string.indexOf('\n');
      nextLF = nextLF !== -1 ? nextLF : string.length;
      lineRe.lastIndex = nextLF;
      return foldLine(string.slice(0, nextLF), width);
    }());
    // If we haven't reached the first content line yet, don't add an extra \n.
    var prevMoreIndented = string[0] === '\n' || string[0] === ' ';
    var moreIndented;
  
    // rest of the lines
    var match;
    while ((match = lineRe.exec(string))) {
      var prefix = match[1], line = match[2];
      moreIndented = (line[0] === ' ');
      result += prefix
        + (!prevMoreIndented && !moreIndented && line !== ''
          ? '\n' : '')
        + foldLine(line, width);
      prevMoreIndented = moreIndented;
    }
  
    return result;
  }
  
  // Greedy line breaking.
  // Picks the longest line under the limit each time,
  // otherwise settles for the shortest line over the limit.
  // NB. More-indented lines *cannot* be folded, as that would add an extra \n.
  function foldLine(line, width) {
    if (line === '' || line[0] === ' ') return line;
  
    // Since a more-indented line adds a \n, breaks can't be followed by a space.
    var breakRe = / [^ ]/g; // note: the match index will always be <= length-2.
    var match;
    // start is an inclusive index. end, curr, and next are exclusive.
    var start = 0, end, curr = 0, next = 0;
    var result = '';
  
    // Invariants: 0 <= start <= length-1.
    //   0 <= curr <= next <= max(0, length-2). curr - start <= width.
    // Inside the loop:
    //   A match implies length >= 2, so curr and next are <= length-2.
    while ((match = breakRe.exec(line))) {
      next = match.index;
      // maintain invariant: curr - start <= width
      if (next - start > width) {
        end = (curr > start) ? curr : next; // derive end <= length-2
        result += '\n' + line.slice(start, end);
        // skip the space that was output as \n
        start = end + 1;                    // derive start <= length-1
      }
      curr = next;
    }
  
    // By the invariants, start <= length-1, so there is something left over.
    // It is either the whole string or a part starting from non-whitespace.
    result += '\n';
    // Insert a break if the remainder is too long and there is a break available.
    if (line.length - start > width && curr > start) {
      result += line.slice(start, curr) + '\n' + line.slice(curr + 1);
    } else {
      result += line.slice(start);
    }
  
    return result.slice(1); // drop extra \n joiner
  }
  
  // Escapes a double-quoted string.
  function escapeString(string) {
    var result = '';
    var char, nextChar;
    var escapeSeq;
  
    for (var i = 0; i < string.length; i++) {
      char = string.charCodeAt(i);
      // Check for surrogate pairs (reference Unicode 3.0 section "3.7 Surrogates").
      if (char >= 0xD800 && char <= 0xDBFF/* high surrogate */) {
        nextChar = string.charCodeAt(i + 1);
        if (nextChar >= 0xDC00 && nextChar <= 0xDFFF/* low surrogate */) {
          // Combine the surrogate pair and store it escaped.
          result += encodeHex((char - 0xD800) * 0x400 + nextChar - 0xDC00 + 0x10000);
          // Advance index one extra since we already used that char here.
          i++; continue;
        }
      }
      escapeSeq = ESCAPE_SEQUENCES[char];
      result += !escapeSeq && isPrintable(char)
        ? string[i]
        : escapeSeq || encodeHex(char);
    }
  
    return result;
  }
  
  function writeFlowSequence(state, level, object) {
    var _result = '',
        _tag    = state.tag,
        index,
        length;
  
    for (index = 0, length = object.length; index < length; index += 1) {
      // Write only valid elements.
      if (writeNode(state, level, object[index], false, false)) {
        if (index !== 0) _result += ',' + (!state.condenseFlow ? ' ' : '');
        _result += state.dump;
      }
    }
  
    state.tag = _tag;
    state.dump = '[' + _result + ']';
  }
  
  function writeBlockSequence(state, level, object, compact) {
    var _result = '',
        _tag    = state.tag,
        index,
        length;
  
    for (index = 0, length = object.length; index < length; index += 1) {
      // Write only valid elements.
      if (writeNode(state, level + 1, object[index], true, true)) {
        if (!compact || index !== 0) {
          _result += generateNextLine(state, level);
        }
  
        if (state.dump && CHAR_LINE_FEED === state.dump.charCodeAt(0)) {
          _result += '-';
        } else {
          _result += '- ';
        }
  
        _result += state.dump;
      }
    }
  
    state.tag = _tag;
    state.dump = _result || '[]'; // Empty sequence if no valid values.
  }
  
  function writeFlowMapping(state, level, object) {
    var _result       = '',
        _tag          = state.tag,
        objectKeyList = Object.keys(object),
        index,
        length,
        objectKey,
        objectValue,
        pairBuffer;
  
    for (index = 0, length = objectKeyList.length; index < length; index += 1) {
      pairBuffer = state.condenseFlow ? '"' : '';
  
      if (index !== 0) pairBuffer += ', ';
  
      objectKey = objectKeyList[index];
      objectValue = object[objectKey];
  
      if (!writeNode(state, level, objectKey, false, false)) {
        continue; // Skip this pair because of invalid key;
      }
  
      if (state.dump.length > 1024) pairBuffer += '? ';
  
      pairBuffer += state.dump + (state.condenseFlow ? '"' : '') + ':' + (state.condenseFlow ? '' : ' ');
  
      if (!writeNode(state, level, objectValue, false, false)) {
        continue; // Skip this pair because of invalid value.
      }
  
      pairBuffer += state.dump;
  
      // Both key and value are valid.
      _result += pairBuffer;
    }
  
    state.tag = _tag;
    state.dump = '{' + _result + '}';
  }
  
  function writeBlockMapping(state, level, object, compact) {
    var _result       = '',
        _tag          = state.tag,
        objectKeyList = Object.keys(object),
        index,
        length,
        objectKey,
        objectValue,
        explicitPair,
        pairBuffer;
  
    // Allow sorting keys so that the output file is deterministic
    if (state.sortKeys === true) {
      // Default sorting
      objectKeyList.sort();
    } else if (typeof state.sortKeys === 'function') {
      // Custom sort function
      objectKeyList.sort(state.sortKeys);
    } else if (state.sortKeys) {
      // Something is wrong
      throw new YAMLException('sortKeys must be a boolean or a function');
    }
  
    for (index = 0, length = objectKeyList.length; index < length; index += 1) {
      pairBuffer = '';
  
      if (!compact || index !== 0) {
        pairBuffer += generateNextLine(state, level);
      }
  
      objectKey = objectKeyList[index];
      objectValue = object[objectKey];
  
      if (!writeNode(state, level + 1, objectKey, true, true, true)) {
        continue; // Skip this pair because of invalid key.
      }
  
      explicitPair = (state.tag !== null && state.tag !== '?') ||
                     (state.dump && state.dump.length > 1024);
  
      if (explicitPair) {
        if (state.dump && CHAR_LINE_FEED === state.dump.charCodeAt(0)) {
          pairBuffer += '?';
        } else {
          pairBuffer += '? ';
        }
      }
  
      pairBuffer += state.dump;
  
      if (explicitPair) {
        pairBuffer += generateNextLine(state, level);
      }
  
      if (!writeNode(state, level + 1, objectValue, true, explicitPair)) {
        continue; // Skip this pair because of invalid value.
      }
  
      if (state.dump && CHAR_LINE_FEED === state.dump.charCodeAt(0)) {
        pairBuffer += ':';
      } else {
        pairBuffer += ': ';
      }
  
      pairBuffer += state.dump;
  
      // Both key and value are valid.
      _result += pairBuffer;
    }
  
    state.tag = _tag;
    state.dump = _result || '{}'; // Empty mapping if no valid pairs.
  }
  
  function detectType(state, object, explicit) {
    var _result, typeList, index, length, type, style;
  
    typeList = explicit ? state.explicitTypes : state.implicitTypes;
  
    for (index = 0, length = typeList.length; index < length; index += 1) {
      type = typeList[index];
  
      if ((type.instanceOf  || type.predicate) &&
          (!type.instanceOf || ((typeof object === 'object') && (object instanceof type.instanceOf))) &&
          (!type.predicate  || type.predicate(object))) {
  
        state.tag = explicit ? type.tag : '?';
  
        if (type.represent) {
          style = state.styleMap[type.tag] || type.defaultStyle;
  
          if (_toString.call(type.represent) === '[object Function]') {
            _result = type.represent(object, style);
          } else if (_hasOwnProperty.call(type.represent, style)) {
            _result = type.represent[style](object, style);
          } else {
            throw new YAMLException('!<' + type.tag + '> tag resolver accepts not "' + style + '" style');
          }
  
          state.dump = _result;
        }
  
        return true;
      }
    }
  
    return false;
  }
  
  // Serializes `object` and writes it to global `result`.
  // Returns true on success, or false on invalid object.
  //
  function writeNode(state, level, object, block, compact, iskey) {
    state.tag = null;
    state.dump = object;
  
    if (!detectType(state, object, false)) {
      detectType(state, object, true);
    }
  
    var type = _toString.call(state.dump);
  
    if (block) {
      block = (state.flowLevel < 0 || state.flowLevel > level);
    }
  
    var objectOrArray = type === '[object Object]' || type === '[object Array]',
        duplicateIndex,
        duplicate;
  
    if (objectOrArray) {
      duplicateIndex = state.duplicates.indexOf(object);
      duplicate = duplicateIndex !== -1;
    }
  
    if ((state.tag !== null && state.tag !== '?') || duplicate || (state.indent !== 2 && level > 0)) {
      compact = false;
    }
  
    if (duplicate && state.usedDuplicates[duplicateIndex]) {
      state.dump = '*ref_' + duplicateIndex;
    } else {
      if (objectOrArray && duplicate && !state.usedDuplicates[duplicateIndex]) {
        state.usedDuplicates[duplicateIndex] = true;
      }
      if (type === '[object Object]') {
        if (block && (Object.keys(state.dump).length !== 0)) {
          writeBlockMapping(state, level, state.dump, compact);
          if (duplicate) {
            state.dump = '&ref_' + duplicateIndex + state.dump;
          }
        } else {
          writeFlowMapping(state, level, state.dump);
          if (duplicate) {
            state.dump = '&ref_' + duplicateIndex + ' ' + state.dump;
          }
        }
      } else if (type === '[object Array]') {
        var arrayLevel = (state.noArrayIndent) ? level - 1 : level;
        if (block && (state.dump.length !== 0)) {
          writeBlockSequence(state, arrayLevel, state.dump, compact);
          if (duplicate) {
            state.dump = '&ref_' + duplicateIndex + state.dump;
          }
        } else {
          writeFlowSequence(state, arrayLevel, state.dump);
          if (duplicate) {
            state.dump = '&ref_' + duplicateIndex + ' ' + state.dump;
          }
        }
      } else if (type === '[object String]') {
        if (state.tag !== '?') {
          writeScalar(state, state.dump, level, iskey);
        }
      } else {
        if (state.skipInvalid) return false;
        throw new YAMLException('unacceptable kind of an object to dump ' + type);
      }
  
      if (state.tag !== null && state.tag !== '?') {
        state.dump = '!<' + state.tag + '> ' + state.dump;
      }
    }
  
    return true;
  }
  
  function getDuplicateReferences(object, state) {
    var objects = [],
        duplicatesIndexes = [],
        index,
        length;
  
    inspectNode(object, objects, duplicatesIndexes);
  
    for (index = 0, length = duplicatesIndexes.length; index < length; index += 1) {
      state.duplicates.push(objects[duplicatesIndexes[index]]);
    }
    state.usedDuplicates = new Array(length);
  }
  
  function inspectNode(object, objects, duplicatesIndexes) {
    var objectKeyList,
        index,
        length;
  
    if (object !== null && typeof object === 'object') {
      index = objects.indexOf(object);
      if (index !== -1) {
        if (duplicatesIndexes.indexOf(index) === -1) {
          duplicatesIndexes.push(index);
        }
      } else {
        objects.push(object);
  
        if (Array.isArray(object)) {
          for (index = 0, length = object.length; index < length; index += 1) {
            inspectNode(object[index], objects, duplicatesIndexes);
          }
        } else {
          objectKeyList = Object.keys(object);
  
          for (index = 0, length = objectKeyList.length; index < length; index += 1) {
            inspectNode(object[objectKeyList[index]], objects, duplicatesIndexes);
          }
        }
      }
    }
  }
  
  function dump(input, options) {
    options = options || {};
  
    var state = new State(options);
  
    if (!state.noRefs) getDuplicateReferences(input, state);
  
    if (writeNode(state, 0, input, true, true)) return state.dump + '\n';
  
    return '';
  }
  
  function safeDump(input, options) {
    return dump(input, common.extend({ schema: DEFAULT_SAFE_SCHEMA }, options));
  }
  
  module.exports.dump     = dump;
  module.exports.safeDump = safeDump;
  
  },{"./common":92,"./exception":94,"./schema/default_full":99,"./schema/default_safe":100}],94:[function(require,module,exports){
  // YAML error class. http://stackoverflow.com/questions/8458984
  //
  'use strict';
  
  function YAMLException(reason, mark) {
    // Super constructor
    Error.call(this);
  
    this.name = 'YAMLException';
    this.reason = reason;
    this.mark = mark;
    this.message = (this.reason || '(unknown reason)') + (this.mark ? ' ' + this.mark.toString() : '');
  
    // Include stack trace in error object
    if (Error.captureStackTrace) {
      // Chrome and NodeJS
      Error.captureStackTrace(this, this.constructor);
    } else {
      // FF, IE 10+ and Safari 6+. Fallback for others
      this.stack = (new Error()).stack || '';
    }
  }
  
  
  // Inherit from Error
  YAMLException.prototype = Object.create(Error.prototype);
  YAMLException.prototype.constructor = YAMLException;
  
  
  YAMLException.prototype.toString = function toString(compact) {
    var result = this.name + ': ';
  
    result += this.reason || '(unknown reason)';
  
    if (!compact && this.mark) {
      result += ' ' + this.mark.toString();
    }
  
    return result;
  };
  
  
  module.exports = YAMLException;
  
  },{}],95:[function(require,module,exports){
  'use strict';
  
  /*eslint-disable max-len,no-use-before-define*/
  
  var common              = require('./common');
  var YAMLException       = require('./exception');
  var Mark                = require('./mark');
  var DEFAULT_SAFE_SCHEMA = require('./schema/default_safe');
  var DEFAULT_FULL_SCHEMA = require('./schema/default_full');
  
  
  var _hasOwnProperty = Object.prototype.hasOwnProperty;
  
  
  var CONTEXT_FLOW_IN   = 1;
  var CONTEXT_FLOW_OUT  = 2;
  var CONTEXT_BLOCK_IN  = 3;
  var CONTEXT_BLOCK_OUT = 4;
  
  
  var CHOMPING_CLIP  = 1;
  var CHOMPING_STRIP = 2;
  var CHOMPING_KEEP  = 3;
  
  
  var PATTERN_NON_PRINTABLE         = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/;
  var PATTERN_NON_ASCII_LINE_BREAKS = /[\x85\u2028\u2029]/;
  var PATTERN_FLOW_INDICATORS       = /[,\[\]\{\}]/;
  var PATTERN_TAG_HANDLE            = /^(?:!|!!|![a-z\-]+!)$/i;
  var PATTERN_TAG_URI               = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
  
  
  function is_EOL(c) {
    return (c === 0x0A/* LF */) || (c === 0x0D/* CR */);
  }
  
  function is_WHITE_SPACE(c) {
    return (c === 0x09/* Tab */) || (c === 0x20/* Space */);
  }
  
  function is_WS_OR_EOL(c) {
    return (c === 0x09/* Tab */) ||
           (c === 0x20/* Space */) ||
           (c === 0x0A/* LF */) ||
           (c === 0x0D/* CR */);
  }
  
  function is_FLOW_INDICATOR(c) {
    return c === 0x2C/* , */ ||
           c === 0x5B/* [ */ ||
           c === 0x5D/* ] */ ||
           c === 0x7B/* { */ ||
           c === 0x7D/* } */;
  }
  
  function fromHexCode(c) {
    var lc;
  
    if ((0x30/* 0 */ <= c) && (c <= 0x39/* 9 */)) {
      return c - 0x30;
    }
  
    /*eslint-disable no-bitwise*/
    lc = c | 0x20;
  
    if ((0x61/* a */ <= lc) && (lc <= 0x66/* f */)) {
      return lc - 0x61 + 10;
    }
  
    return -1;
  }
  
  function escapedHexLen(c) {
    if (c === 0x78/* x */) { return 2; }
    if (c === 0x75/* u */) { return 4; }
    if (c === 0x55/* U */) { return 8; }
    return 0;
  }
  
  function fromDecimalCode(c) {
    if ((0x30/* 0 */ <= c) && (c <= 0x39/* 9 */)) {
      return c - 0x30;
    }
  
    return -1;
  }
  
  function simpleEscapeSequence(c) {
    /* eslint-disable indent */
    return (c === 0x30/* 0 */) ? '\x00' :
          (c === 0x61/* a */) ? '\x07' :
          (c === 0x62/* b */) ? '\x08' :
          (c === 0x74/* t */) ? '\x09' :
          (c === 0x09/* Tab */) ? '\x09' :
          (c === 0x6E/* n */) ? '\x0A' :
          (c === 0x76/* v */) ? '\x0B' :
          (c === 0x66/* f */) ? '\x0C' :
          (c === 0x72/* r */) ? '\x0D' :
          (c === 0x65/* e */) ? '\x1B' :
          (c === 0x20/* Space */) ? ' ' :
          (c === 0x22/* " */) ? '\x22' :
          (c === 0x2F/* / */) ? '/' :
          (c === 0x5C/* \ */) ? '\x5C' :
          (c === 0x4E/* N */) ? '\x85' :
          (c === 0x5F/* _ */) ? '\xA0' :
          (c === 0x4C/* L */) ? '\u2028' :
          (c === 0x50/* P */) ? '\u2029' : '';
  }
  
  function charFromCodepoint(c) {
    if (c <= 0xFFFF) {
      return String.fromCharCode(c);
    }
    // Encode UTF-16 surrogate pair
    // https://en.wikipedia.org/wiki/UTF-16#Code_points_U.2B010000_to_U.2B10FFFF
    return String.fromCharCode(
      ((c - 0x010000) >> 10) + 0xD800,
      ((c - 0x010000) & 0x03FF) + 0xDC00
    );
  }
  
  var simpleEscapeCheck = new Array(256); // integer, for fast access
  var simpleEscapeMap = new Array(256);
  for (var i = 0; i < 256; i++) {
    simpleEscapeCheck[i] = simpleEscapeSequence(i) ? 1 : 0;
    simpleEscapeMap[i] = simpleEscapeSequence(i);
  }
  
  
  function State(input, options) {
    this.input = input;
  
    this.filename  = options['filename']  || null;
    this.schema    = options['schema']    || DEFAULT_FULL_SCHEMA;
    this.onWarning = options['onWarning'] || null;
    this.legacy    = options['legacy']    || false;
    this.json      = options['json']      || false;
    this.listener  = options['listener']  || null;
  
    this.implicitTypes = this.schema.compiledImplicit;
    this.typeMap       = this.schema.compiledTypeMap;
  
    this.length     = input.length;
    this.position   = 0;
    this.line       = 0;
    this.lineStart  = 0;
    this.lineIndent = 0;
  
    this.documents = [];
  
    /*
    this.version;
    this.checkLineBreaks;
    this.tagMap;
    this.anchorMap;
    this.tag;
    this.anchor;
    this.kind;
    this.result;*/
  
  }
  
  
  function generateError(state, message) {
    return new YAMLException(
      message,
      new Mark(state.filename, state.input, state.position, state.line, (state.position - state.lineStart)));
  }
  
  function throwError(state, message) {
    throw generateError(state, message);
  }
  
  function throwWarning(state, message) {
    if (state.onWarning) {
      state.onWarning.call(null, generateError(state, message));
    }
  }
  
  
  var directiveHandlers = {
  
    YAML: function handleYamlDirective(state, name, args) {
  
      var match, major, minor;
  
      if (state.version !== null) {
        throwError(state, 'duplication of %YAML directive');
      }
  
      if (args.length !== 1) {
        throwError(state, 'YAML directive accepts exactly one argument');
      }
  
      match = /^([0-9]+)\.([0-9]+)$/.exec(args[0]);
  
      if (match === null) {
        throwError(state, 'ill-formed argument of the YAML directive');
      }
  
      major = parseInt(match[1], 10);
      minor = parseInt(match[2], 10);
  
      if (major !== 1) {
        throwError(state, 'unacceptable YAML version of the document');
      }
  
      state.version = args[0];
      state.checkLineBreaks = (minor < 2);
  
      if (minor !== 1 && minor !== 2) {
        throwWarning(state, 'unsupported YAML version of the document');
      }
    },
  
    TAG: function handleTagDirective(state, name, args) {
  
      var handle, prefix;
  
      if (args.length !== 2) {
        throwError(state, 'TAG directive accepts exactly two arguments');
      }
  
      handle = args[0];
      prefix = args[1];
  
      if (!PATTERN_TAG_HANDLE.test(handle)) {
        throwError(state, 'ill-formed tag handle (first argument) of the TAG directive');
      }
  
      if (_hasOwnProperty.call(state.tagMap, handle)) {
        throwError(state, 'there is a previously declared suffix for "' + handle + '" tag handle');
      }
  
      if (!PATTERN_TAG_URI.test(prefix)) {
        throwError(state, 'ill-formed tag prefix (second argument) of the TAG directive');
      }
  
      state.tagMap[handle] = prefix;
    }
  };
  
  
  function captureSegment(state, start, end, checkJson) {
    var _position, _length, _character, _result;
  
    if (start < end) {
      _result = state.input.slice(start, end);
  
      if (checkJson) {
        for (_position = 0, _length = _result.length; _position < _length; _position += 1) {
          _character = _result.charCodeAt(_position);
          if (!(_character === 0x09 ||
                (0x20 <= _character && _character <= 0x10FFFF))) {
            throwError(state, 'expected valid JSON character');
          }
        }
      } else if (PATTERN_NON_PRINTABLE.test(_result)) {
        throwError(state, 'the stream contains non-printable characters');
      }
  
      state.result += _result;
    }
  }
  
  function mergeMappings(state, destination, source, overridableKeys) {
    var sourceKeys, key, index, quantity;
  
    if (!common.isObject(source)) {
      throwError(state, 'cannot merge mappings; the provided source object is unacceptable');
    }
  
    sourceKeys = Object.keys(source);
  
    for (index = 0, quantity = sourceKeys.length; index < quantity; index += 1) {
      key = sourceKeys[index];
  
      if (!_hasOwnProperty.call(destination, key)) {
        destination[key] = source[key];
        overridableKeys[key] = true;
      }
    }
  }
  
  function storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, valueNode, startLine, startPos) {
    var index, quantity;
  
    keyNode = String(keyNode);
  
    if (_result === null) {
      _result = {};
    }
  
    if (keyTag === 'tag:yaml.org,2002:merge') {
      if (Array.isArray(valueNode)) {
        for (index = 0, quantity = valueNode.length; index < quantity; index += 1) {
          mergeMappings(state, _result, valueNode[index], overridableKeys);
        }
      } else {
        mergeMappings(state, _result, valueNode, overridableKeys);
      }
    } else {
      if (!state.json &&
          !_hasOwnProperty.call(overridableKeys, keyNode) &&
          _hasOwnProperty.call(_result, keyNode)) {
        state.line = startLine || state.line;
        state.position = startPos || state.position;
        throwError(state, 'duplicated mapping key');
      }
      _result[keyNode] = valueNode;
      delete overridableKeys[keyNode];
    }
  
    return _result;
  }
  
  function readLineBreak(state) {
    var ch;
  
    ch = state.input.charCodeAt(state.position);
  
    if (ch === 0x0A/* LF */) {
      state.position++;
    } else if (ch === 0x0D/* CR */) {
      state.position++;
      if (state.input.charCodeAt(state.position) === 0x0A/* LF */) {
        state.position++;
      }
    } else {
      throwError(state, 'a line break is expected');
    }
  
    state.line += 1;
    state.lineStart = state.position;
  }
  
  function skipSeparationSpace(state, allowComments, checkIndent) {
    var lineBreaks = 0,
        ch = state.input.charCodeAt(state.position);
  
    while (ch !== 0) {
      while (is_WHITE_SPACE(ch)) {
        ch = state.input.charCodeAt(++state.position);
      }
  
      if (allowComments && ch === 0x23/* # */) {
        do {
          ch = state.input.charCodeAt(++state.position);
        } while (ch !== 0x0A/* LF */ && ch !== 0x0D/* CR */ && ch !== 0);
      }
  
      if (is_EOL(ch)) {
        readLineBreak(state);
  
        ch = state.input.charCodeAt(state.position);
        lineBreaks++;
        state.lineIndent = 0;
  
        while (ch === 0x20/* Space */) {
          state.lineIndent++;
          ch = state.input.charCodeAt(++state.position);
        }
      } else {
        break;
      }
    }
  
    if (checkIndent !== -1 && lineBreaks !== 0 && state.lineIndent < checkIndent) {
      throwWarning(state, 'deficient indentation');
    }
  
    return lineBreaks;
  }
  
  function testDocumentSeparator(state) {
    var _position = state.position,
        ch;
  
    ch = state.input.charCodeAt(_position);
  
    // Condition state.position === state.lineStart is tested
    // in parent on each call, for efficiency. No needs to test here again.
    if ((ch === 0x2D/* - */ || ch === 0x2E/* . */) &&
        ch === state.input.charCodeAt(_position + 1) &&
        ch === state.input.charCodeAt(_position + 2)) {
  
      _position += 3;
  
      ch = state.input.charCodeAt(_position);
  
      if (ch === 0 || is_WS_OR_EOL(ch)) {
        return true;
      }
    }
  
    return false;
  }
  
  function writeFoldedLines(state, count) {
    if (count === 1) {
      state.result += ' ';
    } else if (count > 1) {
      state.result += common.repeat('\n', count - 1);
    }
  }
  
  
  function readPlainScalar(state, nodeIndent, withinFlowCollection) {
    var preceding,
        following,
        captureStart,
        captureEnd,
        hasPendingContent,
        _line,
        _lineStart,
        _lineIndent,
        _kind = state.kind,
        _result = state.result,
        ch;
  
    ch = state.input.charCodeAt(state.position);
  
    if (is_WS_OR_EOL(ch)      ||
        is_FLOW_INDICATOR(ch) ||
        ch === 0x23/* # */    ||
        ch === 0x26/* & */    ||
        ch === 0x2A/* * */    ||
        ch === 0x21/* ! */    ||
        ch === 0x7C/* | */    ||
        ch === 0x3E/* > */    ||
        ch === 0x27/* ' */    ||
        ch === 0x22/* " */    ||
        ch === 0x25/* % */    ||
        ch === 0x40/* @ */    ||
        ch === 0x60/* ` */) {
      return false;
    }
  
    if (ch === 0x3F/* ? */ || ch === 0x2D/* - */) {
      following = state.input.charCodeAt(state.position + 1);
  
      if (is_WS_OR_EOL(following) ||
          withinFlowCollection && is_FLOW_INDICATOR(following)) {
        return false;
      }
    }
  
    state.kind = 'scalar';
    state.result = '';
    captureStart = captureEnd = state.position;
    hasPendingContent = false;
  
    while (ch !== 0) {
      if (ch === 0x3A/* : */) {
        following = state.input.charCodeAt(state.position + 1);
  
        if (is_WS_OR_EOL(following) ||
            withinFlowCollection && is_FLOW_INDICATOR(following)) {
          break;
        }
  
      } else if (ch === 0x23/* # */) {
        preceding = state.input.charCodeAt(state.position - 1);
  
        if (is_WS_OR_EOL(preceding)) {
          break;
        }
  
      } else if ((state.position === state.lineStart && testDocumentSeparator(state)) ||
                 withinFlowCollection && is_FLOW_INDICATOR(ch)) {
        break;
  
      } else if (is_EOL(ch)) {
        _line = state.line;
        _lineStart = state.lineStart;
        _lineIndent = state.lineIndent;
        skipSeparationSpace(state, false, -1);
  
        if (state.lineIndent >= nodeIndent) {
          hasPendingContent = true;
          ch = state.input.charCodeAt(state.position);
          continue;
        } else {
          state.position = captureEnd;
          state.line = _line;
          state.lineStart = _lineStart;
          state.lineIndent = _lineIndent;
          break;
        }
      }
  
      if (hasPendingContent) {
        captureSegment(state, captureStart, captureEnd, false);
        writeFoldedLines(state, state.line - _line);
        captureStart = captureEnd = state.position;
        hasPendingContent = false;
      }
  
      if (!is_WHITE_SPACE(ch)) {
        captureEnd = state.position + 1;
      }
  
      ch = state.input.charCodeAt(++state.position);
    }
  
    captureSegment(state, captureStart, captureEnd, false);
  
    if (state.result) {
      return true;
    }
  
    state.kind = _kind;
    state.result = _result;
    return false;
  }
  
  function readSingleQuotedScalar(state, nodeIndent) {
    var ch,
        captureStart, captureEnd;
  
    ch = state.input.charCodeAt(state.position);
  
    if (ch !== 0x27/* ' */) {
      return false;
    }
  
    state.kind = 'scalar';
    state.result = '';
    state.position++;
    captureStart = captureEnd = state.position;
  
    while ((ch = state.input.charCodeAt(state.position)) !== 0) {
      if (ch === 0x27/* ' */) {
        captureSegment(state, captureStart, state.position, true);
        ch = state.input.charCodeAt(++state.position);
  
        if (ch === 0x27/* ' */) {
          captureStart = state.position;
          state.position++;
          captureEnd = state.position;
        } else {
          return true;
        }
  
      } else if (is_EOL(ch)) {
        captureSegment(state, captureStart, captureEnd, true);
        writeFoldedLines(state, skipSeparationSpace(state, false, nodeIndent));
        captureStart = captureEnd = state.position;
  
      } else if (state.position === state.lineStart && testDocumentSeparator(state)) {
        throwError(state, 'unexpected end of the document within a single quoted scalar');
  
      } else {
        state.position++;
        captureEnd = state.position;
      }
    }
  
    throwError(state, 'unexpected end of the stream within a single quoted scalar');
  }
  
  function readDoubleQuotedScalar(state, nodeIndent) {
    var captureStart,
        captureEnd,
        hexLength,
        hexResult,
        tmp,
        ch;
  
    ch = state.input.charCodeAt(state.position);
  
    if (ch !== 0x22/* " */) {
      return false;
    }
  
    state.kind = 'scalar';
    state.result = '';
    state.position++;
    captureStart = captureEnd = state.position;
  
    while ((ch = state.input.charCodeAt(state.position)) !== 0) {
      if (ch === 0x22/* " */) {
        captureSegment(state, captureStart, state.position, true);
        state.position++;
        return true;
  
      } else if (ch === 0x5C/* \ */) {
        captureSegment(state, captureStart, state.position, true);
        ch = state.input.charCodeAt(++state.position);
  
        if (is_EOL(ch)) {
          skipSeparationSpace(state, false, nodeIndent);
  
          // TODO: rework to inline fn with no type cast?
        } else if (ch < 256 && simpleEscapeCheck[ch]) {
          state.result += simpleEscapeMap[ch];
          state.position++;
  
        } else if ((tmp = escapedHexLen(ch)) > 0) {
          hexLength = tmp;
          hexResult = 0;
  
          for (; hexLength > 0; hexLength--) {
            ch = state.input.charCodeAt(++state.position);
  
            if ((tmp = fromHexCode(ch)) >= 0) {
              hexResult = (hexResult << 4) + tmp;
  
            } else {
              throwError(state, 'expected hexadecimal character');
            }
          }
  
          state.result += charFromCodepoint(hexResult);
  
          state.position++;
  
        } else {
          throwError(state, 'unknown escape sequence');
        }
  
        captureStart = captureEnd = state.position;
  
      } else if (is_EOL(ch)) {
        captureSegment(state, captureStart, captureEnd, true);
        writeFoldedLines(state, skipSeparationSpace(state, false, nodeIndent));
        captureStart = captureEnd = state.position;
  
      } else if (state.position === state.lineStart && testDocumentSeparator(state)) {
        throwError(state, 'unexpected end of the document within a double quoted scalar');
  
      } else {
        state.position++;
        captureEnd = state.position;
      }
    }
  
    throwError(state, 'unexpected end of the stream within a double quoted scalar');
  }
  
  function readFlowCollection(state, nodeIndent) {
    var readNext = true,
        _line,
        _tag     = state.tag,
        _result,
        _anchor  = state.anchor,
        following,
        terminator,
        isPair,
        isExplicitPair,
        isMapping,
        overridableKeys = {},
        keyNode,
        keyTag,
        valueNode,
        ch;
  
    ch = state.input.charCodeAt(state.position);
  
    if (ch === 0x5B/* [ */) {
      terminator = 0x5D;/* ] */
      isMapping = false;
      _result = [];
    } else if (ch === 0x7B/* { */) {
      terminator = 0x7D;/* } */
      isMapping = true;
      _result = {};
    } else {
      return false;
    }
  
    if (state.anchor !== null) {
      state.anchorMap[state.anchor] = _result;
    }
  
    ch = state.input.charCodeAt(++state.position);
  
    while (ch !== 0) {
      skipSeparationSpace(state, true, nodeIndent);
  
      ch = state.input.charCodeAt(state.position);
  
      if (ch === terminator) {
        state.position++;
        state.tag = _tag;
        state.anchor = _anchor;
        state.kind = isMapping ? 'mapping' : 'sequence';
        state.result = _result;
        return true;
      } else if (!readNext) {
        throwError(state, 'missed comma between flow collection entries');
      }
  
      keyTag = keyNode = valueNode = null;
      isPair = isExplicitPair = false;
  
      if (ch === 0x3F/* ? */) {
        following = state.input.charCodeAt(state.position + 1);
  
        if (is_WS_OR_EOL(following)) {
          isPair = isExplicitPair = true;
          state.position++;
          skipSeparationSpace(state, true, nodeIndent);
        }
      }
  
      _line = state.line;
      composeNode(state, nodeIndent, CONTEXT_FLOW_IN, false, true);
      keyTag = state.tag;
      keyNode = state.result;
      skipSeparationSpace(state, true, nodeIndent);
  
      ch = state.input.charCodeAt(state.position);
  
      if ((isExplicitPair || state.line === _line) && ch === 0x3A/* : */) {
        isPair = true;
        ch = state.input.charCodeAt(++state.position);
        skipSeparationSpace(state, true, nodeIndent);
        composeNode(state, nodeIndent, CONTEXT_FLOW_IN, false, true);
        valueNode = state.result;
      }
  
      if (isMapping) {
        storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, valueNode);
      } else if (isPair) {
        _result.push(storeMappingPair(state, null, overridableKeys, keyTag, keyNode, valueNode));
      } else {
        _result.push(keyNode);
      }
  
      skipSeparationSpace(state, true, nodeIndent);
  
      ch = state.input.charCodeAt(state.position);
  
      if (ch === 0x2C/* , */) {
        readNext = true;
        ch = state.input.charCodeAt(++state.position);
      } else {
        readNext = false;
      }
    }
  
    throwError(state, 'unexpected end of the stream within a flow collection');
  }
  
  function readBlockScalar(state, nodeIndent) {
    var captureStart,
        folding,
        chomping       = CHOMPING_CLIP,
        didReadContent = false,
        detectedIndent = false,
        textIndent     = nodeIndent,
        emptyLines     = 0,
        atMoreIndented = false,
        tmp,
        ch;
  
    ch = state.input.charCodeAt(state.position);
  
    if (ch === 0x7C/* | */) {
      folding = false;
    } else if (ch === 0x3E/* > */) {
      folding = true;
    } else {
      return false;
    }
  
    state.kind = 'scalar';
    state.result = '';
  
    while (ch !== 0) {
      ch = state.input.charCodeAt(++state.position);
  
      if (ch === 0x2B/* + */ || ch === 0x2D/* - */) {
        if (CHOMPING_CLIP === chomping) {
          chomping = (ch === 0x2B/* + */) ? CHOMPING_KEEP : CHOMPING_STRIP;
        } else {
          throwError(state, 'repeat of a chomping mode identifier');
        }
  
      } else if ((tmp = fromDecimalCode(ch)) >= 0) {
        if (tmp === 0) {
          throwError(state, 'bad explicit indentation width of a block scalar; it cannot be less than one');
        } else if (!detectedIndent) {
          textIndent = nodeIndent + tmp - 1;
          detectedIndent = true;
        } else {
          throwError(state, 'repeat of an indentation width identifier');
        }
  
      } else {
        break;
      }
    }
  
    if (is_WHITE_SPACE(ch)) {
      do { ch = state.input.charCodeAt(++state.position); }
      while (is_WHITE_SPACE(ch));
  
      if (ch === 0x23/* # */) {
        do { ch = state.input.charCodeAt(++state.position); }
        while (!is_EOL(ch) && (ch !== 0));
      }
    }
  
    while (ch !== 0) {
      readLineBreak(state);
      state.lineIndent = 0;
  
      ch = state.input.charCodeAt(state.position);
  
      while ((!detectedIndent || state.lineIndent < textIndent) &&
             (ch === 0x20/* Space */)) {
        state.lineIndent++;
        ch = state.input.charCodeAt(++state.position);
      }
  
      if (!detectedIndent && state.lineIndent > textIndent) {
        textIndent = state.lineIndent;
      }
  
      if (is_EOL(ch)) {
        emptyLines++;
        continue;
      }
  
      // End of the scalar.
      if (state.lineIndent < textIndent) {
  
        // Perform the chomping.
        if (chomping === CHOMPING_KEEP) {
          state.result += common.repeat('\n', didReadContent ? 1 + emptyLines : emptyLines);
        } else if (chomping === CHOMPING_CLIP) {
          if (didReadContent) { // i.e. only if the scalar is not empty.
            state.result += '\n';
          }
        }
  
        // Break this `while` cycle and go to the funciton's epilogue.
        break;
      }
  
      // Folded style: use fancy rules to handle line breaks.
      if (folding) {
  
        // Lines starting with white space characters (more-indented lines) are not folded.
        if (is_WHITE_SPACE(ch)) {
          atMoreIndented = true;
          // except for the first content line (cf. Example 8.1)
          state.result += common.repeat('\n', didReadContent ? 1 + emptyLines : emptyLines);
  
        // End of more-indented block.
        } else if (atMoreIndented) {
          atMoreIndented = false;
          state.result += common.repeat('\n', emptyLines + 1);
  
        // Just one line break - perceive as the same line.
        } else if (emptyLines === 0) {
          if (didReadContent) { // i.e. only if we have already read some scalar content.
            state.result += ' ';
          }
  
        // Several line breaks - perceive as different lines.
        } else {
          state.result += common.repeat('\n', emptyLines);
        }
  
      // Literal style: just add exact number of line breaks between content lines.
      } else {
        // Keep all line breaks except the header line break.
        state.result += common.repeat('\n', didReadContent ? 1 + emptyLines : emptyLines);
      }
  
      didReadContent = true;
      detectedIndent = true;
      emptyLines = 0;
      captureStart = state.position;
  
      while (!is_EOL(ch) && (ch !== 0)) {
        ch = state.input.charCodeAt(++state.position);
      }
  
      captureSegment(state, captureStart, state.position, false);
    }
  
    return true;
  }
  
  function readBlockSequence(state, nodeIndent) {
    var _line,
        _tag      = state.tag,
        _anchor   = state.anchor,
        _result   = [],
        following,
        detected  = false,
        ch;
  
    if (state.anchor !== null) {
      state.anchorMap[state.anchor] = _result;
    }
  
    ch = state.input.charCodeAt(state.position);
  
    while (ch !== 0) {
  
      if (ch !== 0x2D/* - */) {
        break;
      }
  
      following = state.input.charCodeAt(state.position + 1);
  
      if (!is_WS_OR_EOL(following)) {
        break;
      }
  
      detected = true;
      state.position++;
  
      if (skipSeparationSpace(state, true, -1)) {
        if (state.lineIndent <= nodeIndent) {
          _result.push(null);
          ch = state.input.charCodeAt(state.position);
          continue;
        }
      }
  
      _line = state.line;
      composeNode(state, nodeIndent, CONTEXT_BLOCK_IN, false, true);
      _result.push(state.result);
      skipSeparationSpace(state, true, -1);
  
      ch = state.input.charCodeAt(state.position);
  
      if ((state.line === _line || state.lineIndent > nodeIndent) && (ch !== 0)) {
        throwError(state, 'bad indentation of a sequence entry');
      } else if (state.lineIndent < nodeIndent) {
        break;
      }
    }
  
    if (detected) {
      state.tag = _tag;
      state.anchor = _anchor;
      state.kind = 'sequence';
      state.result = _result;
      return true;
    }
    return false;
  }
  
  function readBlockMapping(state, nodeIndent, flowIndent) {
    var following,
        allowCompact,
        _line,
        _pos,
        _tag          = state.tag,
        _anchor       = state.anchor,
        _result       = {},
        overridableKeys = {},
        keyTag        = null,
        keyNode       = null,
        valueNode     = null,
        atExplicitKey = false,
        detected      = false,
        ch;
  
    if (state.anchor !== null) {
      state.anchorMap[state.anchor] = _result;
    }
  
    ch = state.input.charCodeAt(state.position);
  
    while (ch !== 0) {
      following = state.input.charCodeAt(state.position + 1);
      _line = state.line; // Save the current line.
      _pos = state.position;
  
      //
      // Explicit notation case. There are two separate blocks:
      // first for the key (denoted by "?") and second for the value (denoted by ":")
      //
      if ((ch === 0x3F/* ? */ || ch === 0x3A/* : */) && is_WS_OR_EOL(following)) {
  
        if (ch === 0x3F/* ? */) {
          if (atExplicitKey) {
            storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, null);
            keyTag = keyNode = valueNode = null;
          }
  
          detected = true;
          atExplicitKey = true;
          allowCompact = true;
  
        } else if (atExplicitKey) {
          // i.e. 0x3A/* : */ === character after the explicit key.
          atExplicitKey = false;
          allowCompact = true;
  
        } else {
          throwError(state, 'incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line');
        }
  
        state.position += 1;
        ch = following;
  
      //
      // Implicit notation case. Flow-style node as the key first, then ":", and the value.
      //
      } else if (composeNode(state, flowIndent, CONTEXT_FLOW_OUT, false, true)) {
  
        if (state.line === _line) {
          ch = state.input.charCodeAt(state.position);
  
          while (is_WHITE_SPACE(ch)) {
            ch = state.input.charCodeAt(++state.position);
          }
  
          if (ch === 0x3A/* : */) {
            ch = state.input.charCodeAt(++state.position);
  
            if (!is_WS_OR_EOL(ch)) {
              throwError(state, 'a whitespace character is expected after the key-value separator within a block mapping');
            }
  
            if (atExplicitKey) {
              storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, null);
              keyTag = keyNode = valueNode = null;
            }
  
            detected = true;
            atExplicitKey = false;
            allowCompact = false;
            keyTag = state.tag;
            keyNode = state.result;
  
          } else if (detected) {
            throwError(state, 'can not read an implicit mapping pair; a colon is missed');
  
          } else {
            state.tag = _tag;
            state.anchor = _anchor;
            return true; // Keep the result of `composeNode`.
          }
  
        } else if (detected) {
          throwError(state, 'can not read a block mapping entry; a multiline key may not be an implicit key');
  
        } else {
          state.tag = _tag;
          state.anchor = _anchor;
          return true; // Keep the result of `composeNode`.
        }
  
      } else {
        break; // Reading is done. Go to the epilogue.
      }
  
      //
      // Common reading code for both explicit and implicit notations.
      //
      if (state.line === _line || state.lineIndent > nodeIndent) {
        if (composeNode(state, nodeIndent, CONTEXT_BLOCK_OUT, true, allowCompact)) {
          if (atExplicitKey) {
            keyNode = state.result;
          } else {
            valueNode = state.result;
          }
        }
  
        if (!atExplicitKey) {
          storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, valueNode, _line, _pos);
          keyTag = keyNode = valueNode = null;
        }
  
        skipSeparationSpace(state, true, -1);
        ch = state.input.charCodeAt(state.position);
      }
  
      if (state.lineIndent > nodeIndent && (ch !== 0)) {
        throwError(state, 'bad indentation of a mapping entry');
      } else if (state.lineIndent < nodeIndent) {
        break;
      }
    }
  
    //
    // Epilogue.
    //
  
    // Special case: last mapping's node contains only the key in explicit notation.
    if (atExplicitKey) {
      storeMappingPair(state, _result, overridableKeys, keyTag, keyNode, null);
    }
  
    // Expose the resulting mapping.
    if (detected) {
      state.tag = _tag;
      state.anchor = _anchor;
      state.kind = 'mapping';
      state.result = _result;
    }
  
    return detected;
  }
  
  function readTagProperty(state) {
    var _position,
        isVerbatim = false,
        isNamed    = false,
        tagHandle,
        tagName,
        ch;
  
    ch = state.input.charCodeAt(state.position);
  
    if (ch !== 0x21/* ! */) return false;
  
    if (state.tag !== null) {
      throwError(state, 'duplication of a tag property');
    }
  
    ch = state.input.charCodeAt(++state.position);
  
    if (ch === 0x3C/* < */) {
      isVerbatim = true;
      ch = state.input.charCodeAt(++state.position);
  
    } else if (ch === 0x21/* ! */) {
      isNamed = true;
      tagHandle = '!!';
      ch = state.input.charCodeAt(++state.position);
  
    } else {
      tagHandle = '!';
    }
  
    _position = state.position;
  
    if (isVerbatim) {
      do { ch = state.input.charCodeAt(++state.position); }
      while (ch !== 0 && ch !== 0x3E/* > */);
  
      if (state.position < state.length) {
        tagName = state.input.slice(_position, state.position);
        ch = state.input.charCodeAt(++state.position);
      } else {
        throwError(state, 'unexpected end of the stream within a verbatim tag');
      }
    } else {
      while (ch !== 0 && !is_WS_OR_EOL(ch)) {
  
        if (ch === 0x21/* ! */) {
          if (!isNamed) {
            tagHandle = state.input.slice(_position - 1, state.position + 1);
  
            if (!PATTERN_TAG_HANDLE.test(tagHandle)) {
              throwError(state, 'named tag handle cannot contain such characters');
            }
  
            isNamed = true;
            _position = state.position + 1;
          } else {
            throwError(state, 'tag suffix cannot contain exclamation marks');
          }
        }
  
        ch = state.input.charCodeAt(++state.position);
      }
  
      tagName = state.input.slice(_position, state.position);
  
      if (PATTERN_FLOW_INDICATORS.test(tagName)) {
        throwError(state, 'tag suffix cannot contain flow indicator characters');
      }
    }
  
    if (tagName && !PATTERN_TAG_URI.test(tagName)) {
      throwError(state, 'tag name cannot contain such characters: ' + tagName);
    }
  
    if (isVerbatim) {
      state.tag = tagName;
  
    } else if (_hasOwnProperty.call(state.tagMap, tagHandle)) {
      state.tag = state.tagMap[tagHandle] + tagName;
  
    } else if (tagHandle === '!') {
      state.tag = '!' + tagName;
  
    } else if (tagHandle === '!!') {
      state.tag = 'tag:yaml.org,2002:' + tagName;
  
    } else {
      throwError(state, 'undeclared tag handle "' + tagHandle + '"');
    }
  
    return true;
  }
  
  function readAnchorProperty(state) {
    var _position,
        ch;
  
    ch = state.input.charCodeAt(state.position);
  
    if (ch !== 0x26/* & */) return false;
  
    if (state.anchor !== null) {
      throwError(state, 'duplication of an anchor property');
    }
  
    ch = state.input.charCodeAt(++state.position);
    _position = state.position;
  
    while (ch !== 0 && !is_WS_OR_EOL(ch) && !is_FLOW_INDICATOR(ch)) {
      ch = state.input.charCodeAt(++state.position);
    }
  
    if (state.position === _position) {
      throwError(state, 'name of an anchor node must contain at least one character');
    }
  
    state.anchor = state.input.slice(_position, state.position);
    return true;
  }
  
  function readAlias(state) {
    var _position, alias,
        ch;
  
    ch = state.input.charCodeAt(state.position);
  
    if (ch !== 0x2A/* * */) return false;
  
    ch = state.input.charCodeAt(++state.position);
    _position = state.position;
  
    while (ch !== 0 && !is_WS_OR_EOL(ch) && !is_FLOW_INDICATOR(ch)) {
      ch = state.input.charCodeAt(++state.position);
    }
  
    if (state.position === _position) {
      throwError(state, 'name of an alias node must contain at least one character');
    }
  
    alias = state.input.slice(_position, state.position);
  
    if (!state.anchorMap.hasOwnProperty(alias)) {
      throwError(state, 'unidentified alias "' + alias + '"');
    }
  
    state.result = state.anchorMap[alias];
    skipSeparationSpace(state, true, -1);
    return true;
  }
  
  function composeNode(state, parentIndent, nodeContext, allowToSeek, allowCompact) {
    var allowBlockStyles,
        allowBlockScalars,
        allowBlockCollections,
        indentStatus = 1, // 1: this>parent, 0: this=parent, -1: this<parent
        atNewLine  = false,
        hasContent = false,
        typeIndex,
        typeQuantity,
        type,
        flowIndent,
        blockIndent;
  
    if (state.listener !== null) {
      state.listener('open', state);
    }
  
    state.tag    = null;
    state.anchor = null;
    state.kind   = null;
    state.result = null;
  
    allowBlockStyles = allowBlockScalars = allowBlockCollections =
      CONTEXT_BLOCK_OUT === nodeContext ||
      CONTEXT_BLOCK_IN  === nodeContext;
  
    if (allowToSeek) {
      if (skipSeparationSpace(state, true, -1)) {
        atNewLine = true;
  
        if (state.lineIndent > parentIndent) {
          indentStatus = 1;
        } else if (state.lineIndent === parentIndent) {
          indentStatus = 0;
        } else if (state.lineIndent < parentIndent) {
          indentStatus = -1;
        }
      }
    }
  
    if (indentStatus === 1) {
      while (readTagProperty(state) || readAnchorProperty(state)) {
        if (skipSeparationSpace(state, true, -1)) {
          atNewLine = true;
          allowBlockCollections = allowBlockStyles;
  
          if (state.lineIndent > parentIndent) {
            indentStatus = 1;
          } else if (state.lineIndent === parentIndent) {
            indentStatus = 0;
          } else if (state.lineIndent < parentIndent) {
            indentStatus = -1;
          }
        } else {
          allowBlockCollections = false;
        }
      }
    }
  
    if (allowBlockCollections) {
      allowBlockCollections = atNewLine || allowCompact;
    }
  
    if (indentStatus === 1 || CONTEXT_BLOCK_OUT === nodeContext) {
      if (CONTEXT_FLOW_IN === nodeContext || CONTEXT_FLOW_OUT === nodeContext) {
        flowIndent = parentIndent;
      } else {
        flowIndent = parentIndent + 1;
      }
  
      blockIndent = state.position - state.lineStart;
  
      if (indentStatus === 1) {
        if (allowBlockCollections &&
            (readBlockSequence(state, blockIndent) ||
             readBlockMapping(state, blockIndent, flowIndent)) ||
            readFlowCollection(state, flowIndent)) {
          hasContent = true;
        } else {
          if ((allowBlockScalars && readBlockScalar(state, flowIndent)) ||
              readSingleQuotedScalar(state, flowIndent) ||
              readDoubleQuotedScalar(state, flowIndent)) {
            hasContent = true;
  
          } else if (readAlias(state)) {
            hasContent = true;
  
            if (state.tag !== null || state.anchor !== null) {
              throwError(state, 'alias node should not have any properties');
            }
  
          } else if (readPlainScalar(state, flowIndent, CONTEXT_FLOW_IN === nodeContext)) {
            hasContent = true;
  
            if (state.tag === null) {
              state.tag = '?';
            }
          }
  
          if (state.anchor !== null) {
            state.anchorMap[state.anchor] = state.result;
          }
        }
      } else if (indentStatus === 0) {
        // Special case: block sequences are allowed to have same indentation level as the parent.
        // http://www.yaml.org/spec/1.2/spec.html#id2799784
        hasContent = allowBlockCollections && readBlockSequence(state, blockIndent);
      }
    }
  
    if (state.tag !== null && state.tag !== '!') {
      if (state.tag === '?') {
        for (typeIndex = 0, typeQuantity = state.implicitTypes.length; typeIndex < typeQuantity; typeIndex += 1) {
          type = state.implicitTypes[typeIndex];
  
          // Implicit resolving is not allowed for non-scalar types, and '?'
          // non-specific tag is only assigned to plain scalars. So, it isn't
          // needed to check for 'kind' conformity.
  
          if (type.resolve(state.result)) { // `state.result` updated in resolver if matched
            state.result = type.construct(state.result);
            state.tag = type.tag;
            if (state.anchor !== null) {
              state.anchorMap[state.anchor] = state.result;
            }
            break;
          }
        }
      } else if (_hasOwnProperty.call(state.typeMap[state.kind || 'fallback'], state.tag)) {
        type = state.typeMap[state.kind || 'fallback'][state.tag];
  
        if (state.result !== null && type.kind !== state.kind) {
          throwError(state, 'unacceptable node kind for !<' + state.tag + '> tag; it should be "' + type.kind + '", not "' + state.kind + '"');
        }
  
        if (!type.resolve(state.result)) { // `state.result` updated in resolver if matched
          throwError(state, 'cannot resolve a node with !<' + state.tag + '> explicit tag');
        } else {
          state.result = type.construct(state.result);
          if (state.anchor !== null) {
            state.anchorMap[state.anchor] = state.result;
          }
        }
      } else {
        throwError(state, 'unknown tag !<' + state.tag + '>');
      }
    }
  
    if (state.listener !== null) {
      state.listener('close', state);
    }
    return state.tag !== null ||  state.anchor !== null || hasContent;
  }
  
  function readDocument(state) {
    var documentStart = state.position,
        _position,
        directiveName,
        directiveArgs,
        hasDirectives = false,
        ch;
  
    state.version = null;
    state.checkLineBreaks = state.legacy;
    state.tagMap = {};
    state.anchorMap = {};
  
    while ((ch = state.input.charCodeAt(state.position)) !== 0) {
      skipSeparationSpace(state, true, -1);
  
      ch = state.input.charCodeAt(state.position);
  
      if (state.lineIndent > 0 || ch !== 0x25/* % */) {
        break;
      }
  
      hasDirectives = true;
      ch = state.input.charCodeAt(++state.position);
      _position = state.position;
  
      while (ch !== 0 && !is_WS_OR_EOL(ch)) {
        ch = state.input.charCodeAt(++state.position);
      }
  
      directiveName = state.input.slice(_position, state.position);
      directiveArgs = [];
  
      if (directiveName.length < 1) {
        throwError(state, 'directive name must not be less than one character in length');
      }
  
      while (ch !== 0) {
        while (is_WHITE_SPACE(ch)) {
          ch = state.input.charCodeAt(++state.position);
        }
  
        if (ch === 0x23/* # */) {
          do { ch = state.input.charCodeAt(++state.position); }
          while (ch !== 0 && !is_EOL(ch));
          break;
        }
  
        if (is_EOL(ch)) break;
  
        _position = state.position;
  
        while (ch !== 0 && !is_WS_OR_EOL(ch)) {
          ch = state.input.charCodeAt(++state.position);
        }
  
        directiveArgs.push(state.input.slice(_position, state.position));
      }
  
      if (ch !== 0) readLineBreak(state);
  
      if (_hasOwnProperty.call(directiveHandlers, directiveName)) {
        directiveHandlers[directiveName](state, directiveName, directiveArgs);
      } else {
        throwWarning(state, 'unknown document directive "' + directiveName + '"');
      }
    }
  
    skipSeparationSpace(state, true, -1);
  
    if (state.lineIndent === 0 &&
        state.input.charCodeAt(state.position)     === 0x2D/* - */ &&
        state.input.charCodeAt(state.position + 1) === 0x2D/* - */ &&
        state.input.charCodeAt(state.position + 2) === 0x2D/* - */) {
      state.position += 3;
      skipSeparationSpace(state, true, -1);
  
    } else if (hasDirectives) {
      throwError(state, 'directives end mark is expected');
    }
  
    composeNode(state, state.lineIndent - 1, CONTEXT_BLOCK_OUT, false, true);
    skipSeparationSpace(state, true, -1);
  
    if (state.checkLineBreaks &&
        PATTERN_NON_ASCII_LINE_BREAKS.test(state.input.slice(documentStart, state.position))) {
      throwWarning(state, 'non-ASCII line breaks are interpreted as content');
    }
  
    state.documents.push(state.result);
  
    if (state.position === state.lineStart && testDocumentSeparator(state)) {
  
      if (state.input.charCodeAt(state.position) === 0x2E/* . */) {
        state.position += 3;
        skipSeparationSpace(state, true, -1);
      }
      return;
    }
  
    if (state.position < (state.length - 1)) {
      throwError(state, 'end of the stream or a document separator is expected');
    } else {
      return;
    }
  }
  
  
  function loadDocuments(input, options) {
    input = String(input);
    options = options || {};
  
    if (input.length !== 0) {
  
      // Add tailing `\n` if not exists
      if (input.charCodeAt(input.length - 1) !== 0x0A/* LF */ &&
          input.charCodeAt(input.length - 1) !== 0x0D/* CR */) {
        input += '\n';
      }
  
      // Strip BOM
      if (input.charCodeAt(0) === 0xFEFF) {
        input = input.slice(1);
      }
    }
  
    var state = new State(input, options);
  
    // Use 0 as string terminator. That significantly simplifies bounds check.
    state.input += '\0';
  
    while (state.input.charCodeAt(state.position) === 0x20/* Space */) {
      state.lineIndent += 1;
      state.position += 1;
    }
  
    while (state.position < (state.length - 1)) {
      readDocument(state);
    }
  
    return state.documents;
  }
  
  
  function loadAll(input, iterator, options) {
    var documents = loadDocuments(input, options), index, length;
  
    if (typeof iterator !== 'function') {
      return documents;
    }
  
    for (index = 0, length = documents.length; index < length; index += 1) {
      iterator(documents[index]);
    }
  }
  
  
  function load(input, options) {
    var documents = loadDocuments(input, options);
  
    if (documents.length === 0) {
      /*eslint-disable no-undefined*/
      return undefined;
    } else if (documents.length === 1) {
      return documents[0];
    }
    throw new YAMLException('expected a single document in the stream, but found more');
  }
  
  
  function safeLoadAll(input, output, options) {
    if (typeof output === 'function') {
      loadAll(input, output, common.extend({ schema: DEFAULT_SAFE_SCHEMA }, options));
    } else {
      return loadAll(input, common.extend({ schema: DEFAULT_SAFE_SCHEMA }, options));
    }
  }
  
  
  function safeLoad(input, options) {
    return load(input, common.extend({ schema: DEFAULT_SAFE_SCHEMA }, options));
  }
  
  
  module.exports.loadAll     = loadAll;
  module.exports.load        = load;
  module.exports.safeLoadAll = safeLoadAll;
  module.exports.safeLoad    = safeLoad;
  
  },{"./common":92,"./exception":94,"./mark":96,"./schema/default_full":99,"./schema/default_safe":100}],96:[function(require,module,exports){
  'use strict';
  
  
  var common = require('./common');
  
  
  function Mark(name, buffer, position, line, column) {
    this.name     = name;
    this.buffer   = buffer;
    this.position = position;
    this.line     = line;
    this.column   = column;
  }
  
  
  Mark.prototype.getSnippet = function getSnippet(indent, maxLength) {
    var head, start, tail, end, snippet;
  
    if (!this.buffer) return null;
  
    indent = indent || 4;
    maxLength = maxLength || 75;
  
    head = '';
    start = this.position;
  
    while (start > 0 && '\x00\r\n\x85\u2028\u2029'.indexOf(this.buffer.charAt(start - 1)) === -1) {
      start -= 1;
      if (this.position - start > (maxLength / 2 - 1)) {
        head = ' ... ';
        start += 5;
        break;
      }
    }
  
    tail = '';
    end = this.position;
  
    while (end < this.buffer.length && '\x00\r\n\x85\u2028\u2029'.indexOf(this.buffer.charAt(end)) === -1) {
      end += 1;
      if (end - this.position > (maxLength / 2 - 1)) {
        tail = ' ... ';
        end -= 5;
        break;
      }
    }
  
    snippet = this.buffer.slice(start, end);
  
    return common.repeat(' ', indent) + head + snippet + tail + '\n' +
           common.repeat(' ', indent + this.position - start + head.length) + '^';
  };
  
  
  Mark.prototype.toString = function toString(compact) {
    var snippet, where = '';
  
    if (this.name) {
      where += 'in "' + this.name + '" ';
    }
  
    where += 'at line ' + (this.line + 1) + ', column ' + (this.column + 1);
  
    if (!compact) {
      snippet = this.getSnippet();
  
      if (snippet) {
        where += ':\n' + snippet;
      }
    }
  
    return where;
  };
  
  
  module.exports = Mark;
  
  },{"./common":92}],97:[function(require,module,exports){
  'use strict';
  
  /*eslint-disable max-len*/
  
  var common        = require('./common');
  var YAMLException = require('./exception');
  var Type          = require('./type');
  
  
  function compileList(schema, name, result) {
    var exclude = [];
  
    schema.include.forEach(function (includedSchema) {
      result = compileList(includedSchema, name, result);
    });
  
    schema[name].forEach(function (currentType) {
      result.forEach(function (previousType, previousIndex) {
        if (previousType.tag === currentType.tag && previousType.kind === currentType.kind) {
          exclude.push(previousIndex);
        }
      });
  
      result.push(currentType);
    });
  
    return result.filter(function (type, index) {
      return exclude.indexOf(index) === -1;
    });
  }
  
  
  function compileMap(/* lists... */) {
    var result = {
          scalar: {},
          sequence: {},
          mapping: {},
          fallback: {}
        }, index, length;
  
    function collectType(type) {
      result[type.kind][type.tag] = result['fallback'][type.tag] = type;
    }
  
    for (index = 0, length = arguments.length; index < length; index += 1) {
      arguments[index].forEach(collectType);
    }
    return result;
  }
  
  
  function Schema(definition) {
    this.include  = definition.include  || [];
    this.implicit = definition.implicit || [];
    this.explicit = definition.explicit || [];
  
    this.implicit.forEach(function (type) {
      if (type.loadKind && type.loadKind !== 'scalar') {
        throw new YAMLException('There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.');
      }
    });
  
    this.compiledImplicit = compileList(this, 'implicit', []);
    this.compiledExplicit = compileList(this, 'explicit', []);
    this.compiledTypeMap  = compileMap(this.compiledImplicit, this.compiledExplicit);
  }
  
  
  Schema.DEFAULT = null;
  
  
  Schema.create = function createSchema() {
    var schemas, types;
  
    switch (arguments.length) {
      case 1:
        schemas = Schema.DEFAULT;
        types = arguments[0];
        break;
  
      case 2:
        schemas = arguments[0];
        types = arguments[1];
        break;
  
      default:
        throw new YAMLException('Wrong number of arguments for Schema.create function');
    }
  
    schemas = common.toArray(schemas);
    types = common.toArray(types);
  
    if (!schemas.every(function (schema) { return schema instanceof Schema; })) {
      throw new YAMLException('Specified list of super schemas (or a single Schema object) contains a non-Schema object.');
    }
  
    if (!types.every(function (type) { return type instanceof Type; })) {
      throw new YAMLException('Specified list of YAML types (or a single Type object) contains a non-Type object.');
    }
  
    return new Schema({
      include: schemas,
      explicit: types
    });
  };
  
  
  module.exports = Schema;
  
  },{"./common":92,"./exception":94,"./type":103}],98:[function(require,module,exports){
  // Standard YAML's Core schema.
  // http://www.yaml.org/spec/1.2/spec.html#id2804923
  //
  // NOTE: JS-YAML does not support schema-specific tag resolution restrictions.
  // So, Core schema has no distinctions from JSON schema is JS-YAML.
  
  
  'use strict';
  
  
  var Schema = require('../schema');
  
  
  module.exports = new Schema({
    include: [
      require('./json')
    ]
  });
  
  },{"../schema":97,"./json":102}],99:[function(require,module,exports){
  // JS-YAML's default schema for `load` function.
  // It is not described in the YAML specification.
  //
  // This schema is based on JS-YAML's default safe schema and includes
  // JavaScript-specific types: !!js/undefined, !!js/regexp and !!js/function.
  //
  // Also this schema is used as default base schema at `Schema.create` function.
  
  
  'use strict';
  
  
  var Schema = require('../schema');
  
  
  module.exports = Schema.DEFAULT = new Schema({
    include: [
      require('./default_safe')
    ],
    explicit: [
      require('../type/js/undefined'),
      require('../type/js/regexp'),
      require('../type/js/function')
    ]
  });
  
  },{"../schema":97,"../type/js/function":108,"../type/js/regexp":109,"../type/js/undefined":110,"./default_safe":100}],100:[function(require,module,exports){
  // JS-YAML's default schema for `safeLoad` function.
  // It is not described in the YAML specification.
  //
  // This schema is based on standard YAML's Core schema and includes most of
  // extra types described at YAML tag repository. (http://yaml.org/type/)
  
  
  'use strict';
  
  
  var Schema = require('../schema');
  
  
  module.exports = new Schema({
    include: [
      require('./core')
    ],
    implicit: [
      require('../type/timestamp'),
      require('../type/merge')
    ],
    explicit: [
      require('../type/binary'),
      require('../type/omap'),
      require('../type/pairs'),
      require('../type/set')
    ]
  });
  
  },{"../schema":97,"../type/binary":104,"../type/merge":112,"../type/omap":114,"../type/pairs":115,"../type/set":117,"../type/timestamp":119,"./core":98}],101:[function(require,module,exports){
  // Standard YAML's Failsafe schema.
  // http://www.yaml.org/spec/1.2/spec.html#id2802346
  
  
  'use strict';
  
  
  var Schema = require('../schema');
  
  
  module.exports = new Schema({
    explicit: [
      require('../type/str'),
      require('../type/seq'),
      require('../type/map')
    ]
  });
  
  },{"../schema":97,"../type/map":111,"../type/seq":116,"../type/str":118}],102:[function(require,module,exports){
  // Standard YAML's JSON schema.
  // http://www.yaml.org/spec/1.2/spec.html#id2803231
  //
  // NOTE: JS-YAML does not support schema-specific tag resolution restrictions.
  // So, this schema is not such strict as defined in the YAML specification.
  // It allows numbers in binary notaion, use `Null` and `NULL` as `null`, etc.
  
  
  'use strict';
  
  
  var Schema = require('../schema');
  
  
  module.exports = new Schema({
    include: [
      require('./failsafe')
    ],
    implicit: [
      require('../type/null'),
      require('../type/bool'),
      require('../type/int'),
      require('../type/float')
    ]
  });
  
  },{"../schema":97,"../type/bool":105,"../type/float":106,"../type/int":107,"../type/null":113,"./failsafe":101}],103:[function(require,module,exports){
  'use strict';
  
  var YAMLException = require('./exception');
  
  var TYPE_CONSTRUCTOR_OPTIONS = [
    'kind',
    'resolve',
    'construct',
    'instanceOf',
    'predicate',
    'represent',
    'defaultStyle',
    'styleAliases'
  ];
  
  var YAML_NODE_KINDS = [
    'scalar',
    'sequence',
    'mapping'
  ];
  
  function compileStyleAliases(map) {
    var result = {};
  
    if (map !== null) {
      Object.keys(map).forEach(function (style) {
        map[style].forEach(function (alias) {
          result[String(alias)] = style;
        });
      });
    }
  
    return result;
  }
  
  function Type(tag, options) {
    options = options || {};
  
    Object.keys(options).forEach(function (name) {
      if (TYPE_CONSTRUCTOR_OPTIONS.indexOf(name) === -1) {
        throw new YAMLException('Unknown option "' + name + '" is met in definition of "' + tag + '" YAML type.');
      }
    });
  
    // TODO: Add tag format check.
    this.tag          = tag;
    this.kind         = options['kind']         || null;
    this.resolve      = options['resolve']      || function () { return true; };
    this.construct    = options['construct']    || function (data) { return data; };
    this.instanceOf   = options['instanceOf']   || null;
    this.predicate    = options['predicate']    || null;
    this.represent    = options['represent']    || null;
    this.defaultStyle = options['defaultStyle'] || null;
    this.styleAliases = compileStyleAliases(options['styleAliases'] || null);
  
    if (YAML_NODE_KINDS.indexOf(this.kind) === -1) {
      throw new YAMLException('Unknown kind "' + this.kind + '" is specified for "' + tag + '" YAML type.');
    }
  }
  
  module.exports = Type;
  
  },{"./exception":94}],104:[function(require,module,exports){
  'use strict';
  
  /*eslint-disable no-bitwise*/
  
  var NodeBuffer;
  
  try {
    // A trick for browserified version, to not include `Buffer` shim
    var _require = require;
    NodeBuffer = _require('buffer').Buffer;
  } catch (__) {}
  
  var Type       = require('../type');
  
  
  // [ 64, 65, 66 ] -> [ padding, CR, LF ]
  var BASE64_MAP = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=\n\r';
  
  
  function resolveYamlBinary(data) {
    if (data === null) return false;
  
    var code, idx, bitlen = 0, max = data.length, map = BASE64_MAP;
  
    // Convert one by one.
    for (idx = 0; idx < max; idx++) {
      code = map.indexOf(data.charAt(idx));
  
      // Skip CR/LF
      if (code > 64) continue;
  
      // Fail on illegal characters
      if (code < 0) return false;
  
      bitlen += 6;
    }
  
    // If there are any bits left, source was corrupted
    return (bitlen % 8) === 0;
  }
  
  function constructYamlBinary(data) {
    var idx, tailbits,
        input = data.replace(/[\r\n=]/g, ''), // remove CR/LF & padding to simplify scan
        max = input.length,
        map = BASE64_MAP,
        bits = 0,
        result = [];
  
    // Collect by 6*4 bits (3 bytes)
  
    for (idx = 0; idx < max; idx++) {
      if ((idx % 4 === 0) && idx) {
        result.push((bits >> 16) & 0xFF);
        result.push((bits >> 8) & 0xFF);
        result.push(bits & 0xFF);
      }
  
      bits = (bits << 6) | map.indexOf(input.charAt(idx));
    }
  
    // Dump tail
  
    tailbits = (max % 4) * 6;
  
    if (tailbits === 0) {
      result.push((bits >> 16) & 0xFF);
      result.push((bits >> 8) & 0xFF);
      result.push(bits & 0xFF);
    } else if (tailbits === 18) {
      result.push((bits >> 10) & 0xFF);
      result.push((bits >> 2) & 0xFF);
    } else if (tailbits === 12) {
      result.push((bits >> 4) & 0xFF);
    }
  
    // Wrap into Buffer for NodeJS and leave Array for browser
    if (NodeBuffer) {
      // Support node 6.+ Buffer API when available
      return NodeBuffer.from ? NodeBuffer.from(result) : new NodeBuffer(result);
    }
  
    return result;
  }
  
  function representYamlBinary(object /*, style*/) {
    var result = '', bits = 0, idx, tail,
        max = object.length,
        map = BASE64_MAP;
  
    // Convert every three bytes to 4 ASCII characters.
  
    for (idx = 0; idx < max; idx++) {
      if ((idx % 3 === 0) && idx) {
        result += map[(bits >> 18) & 0x3F];
        result += map[(bits >> 12) & 0x3F];
        result += map[(bits >> 6) & 0x3F];
        result += map[bits & 0x3F];
      }
  
      bits = (bits << 8) + object[idx];
    }
  
    // Dump tail
  
    tail = max % 3;
  
    if (tail === 0) {
      result += map[(bits >> 18) & 0x3F];
      result += map[(bits >> 12) & 0x3F];
      result += map[(bits >> 6) & 0x3F];
      result += map[bits & 0x3F];
    } else if (tail === 2) {
      result += map[(bits >> 10) & 0x3F];
      result += map[(bits >> 4) & 0x3F];
      result += map[(bits << 2) & 0x3F];
      result += map[64];
    } else if (tail === 1) {
      result += map[(bits >> 2) & 0x3F];
      result += map[(bits << 4) & 0x3F];
      result += map[64];
      result += map[64];
    }
  
    return result;
  }
  
  function isBinary(object) {
    return NodeBuffer && NodeBuffer.isBuffer(object);
  }
  
  module.exports = new Type('tag:yaml.org,2002:binary', {
    kind: 'scalar',
    resolve: resolveYamlBinary,
    construct: constructYamlBinary,
    predicate: isBinary,
    represent: representYamlBinary
  });
  
  },{"../type":103}],105:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  function resolveYamlBoolean(data) {
    if (data === null) return false;
  
    var max = data.length;
  
    return (max === 4 && (data === 'true' || data === 'True' || data === 'TRUE')) ||
           (max === 5 && (data === 'false' || data === 'False' || data === 'FALSE'));
  }
  
  function constructYamlBoolean(data) {
    return data === 'true' ||
           data === 'True' ||
           data === 'TRUE';
  }
  
  function isBoolean(object) {
    return Object.prototype.toString.call(object) === '[object Boolean]';
  }
  
  module.exports = new Type('tag:yaml.org,2002:bool', {
    kind: 'scalar',
    resolve: resolveYamlBoolean,
    construct: constructYamlBoolean,
    predicate: isBoolean,
    represent: {
      lowercase: function (object) { return object ? 'true' : 'false'; },
      uppercase: function (object) { return object ? 'TRUE' : 'FALSE'; },
      camelcase: function (object) { return object ? 'True' : 'False'; }
    },
    defaultStyle: 'lowercase'
  });
  
  },{"../type":103}],106:[function(require,module,exports){
  'use strict';
  
  var common = require('../common');
  var Type   = require('../type');
  
  var YAML_FLOAT_PATTERN = new RegExp(
    // 2.5e4, 2.5 and integers
    '^(?:[-+]?(?:0|[1-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?' +
    // .2e4, .2
    // special case, seems not from spec
    '|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?' +
    // 20:59
    '|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*' +
    // .inf
    '|[-+]?\\.(?:inf|Inf|INF)' +
    // .nan
    '|\\.(?:nan|NaN|NAN))$');
  
  function resolveYamlFloat(data) {
    if (data === null) return false;
  
    if (!YAML_FLOAT_PATTERN.test(data) ||
        // Quick hack to not allow integers end with `_`
        // Probably should update regexp & check speed
        data[data.length - 1] === '_') {
      return false;
    }
  
    return true;
  }
  
  function constructYamlFloat(data) {
    var value, sign, base, digits;
  
    value  = data.replace(/_/g, '').toLowerCase();
    sign   = value[0] === '-' ? -1 : 1;
    digits = [];
  
    if ('+-'.indexOf(value[0]) >= 0) {
      value = value.slice(1);
    }
  
    if (value === '.inf') {
      return (sign === 1) ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY;
  
    } else if (value === '.nan') {
      return NaN;
  
    } else if (value.indexOf(':') >= 0) {
      value.split(':').forEach(function (v) {
        digits.unshift(parseFloat(v, 10));
      });
  
      value = 0.0;
      base = 1;
  
      digits.forEach(function (d) {
        value += d * base;
        base *= 60;
      });
  
      return sign * value;
  
    }
    return sign * parseFloat(value, 10);
  }
  
  
  var SCIENTIFIC_WITHOUT_DOT = /^[-+]?[0-9]+e/;
  
  function representYamlFloat(object, style) {
    var res;
  
    if (isNaN(object)) {
      switch (style) {
        case 'lowercase': return '.nan';
        case 'uppercase': return '.NAN';
        case 'camelcase': return '.NaN';
      }
    } else if (Number.POSITIVE_INFINITY === object) {
      switch (style) {
        case 'lowercase': return '.inf';
        case 'uppercase': return '.INF';
        case 'camelcase': return '.Inf';
      }
    } else if (Number.NEGATIVE_INFINITY === object) {
      switch (style) {
        case 'lowercase': return '-.inf';
        case 'uppercase': return '-.INF';
        case 'camelcase': return '-.Inf';
      }
    } else if (common.isNegativeZero(object)) {
      return '-0.0';
    }
  
    res = object.toString(10);
  
    // JS stringifier can build scientific format without dots: 5e-100,
    // while YAML requres dot: 5.e-100. Fix it with simple hack
  
    return SCIENTIFIC_WITHOUT_DOT.test(res) ? res.replace('e', '.e') : res;
  }
  
  function isFloat(object) {
    return (Object.prototype.toString.call(object) === '[object Number]') &&
           (object % 1 !== 0 || common.isNegativeZero(object));
  }
  
  module.exports = new Type('tag:yaml.org,2002:float', {
    kind: 'scalar',
    resolve: resolveYamlFloat,
    construct: constructYamlFloat,
    predicate: isFloat,
    represent: representYamlFloat,
    defaultStyle: 'lowercase'
  });
  
  },{"../common":92,"../type":103}],107:[function(require,module,exports){
  'use strict';
  
  var common = require('../common');
  var Type   = require('../type');
  
  function isHexCode(c) {
    return ((0x30/* 0 */ <= c) && (c <= 0x39/* 9 */)) ||
           ((0x41/* A */ <= c) && (c <= 0x46/* F */)) ||
           ((0x61/* a */ <= c) && (c <= 0x66/* f */));
  }
  
  function isOctCode(c) {
    return ((0x30/* 0 */ <= c) && (c <= 0x37/* 7 */));
  }
  
  function isDecCode(c) {
    return ((0x30/* 0 */ <= c) && (c <= 0x39/* 9 */));
  }
  
  function resolveYamlInteger(data) {
    if (data === null) return false;
  
    var max = data.length,
        index = 0,
        hasDigits = false,
        ch;
  
    if (!max) return false;
  
    ch = data[index];
  
    // sign
    if (ch === '-' || ch === '+') {
      ch = data[++index];
    }
  
    if (ch === '0') {
      // 0
      if (index + 1 === max) return true;
      ch = data[++index];
  
      // base 2, base 8, base 16
  
      if (ch === 'b') {
        // base 2
        index++;
  
        for (; index < max; index++) {
          ch = data[index];
          if (ch === '_') continue;
          if (ch !== '0' && ch !== '1') return false;
          hasDigits = true;
        }
        return hasDigits && ch !== '_';
      }
  
  
      if (ch === 'x') {
        // base 16
        index++;
  
        for (; index < max; index++) {
          ch = data[index];
          if (ch === '_') continue;
          if (!isHexCode(data.charCodeAt(index))) return false;
          hasDigits = true;
        }
        return hasDigits && ch !== '_';
      }
  
      // base 8
      for (; index < max; index++) {
        ch = data[index];
        if (ch === '_') continue;
        if (!isOctCode(data.charCodeAt(index))) return false;
        hasDigits = true;
      }
      return hasDigits && ch !== '_';
    }
  
    // base 10 (except 0) or base 60
  
    // value should not start with `_`;
    if (ch === '_') return false;
  
    for (; index < max; index++) {
      ch = data[index];
      if (ch === '_') continue;
      if (ch === ':') break;
      if (!isDecCode(data.charCodeAt(index))) {
        return false;
      }
      hasDigits = true;
    }
  
    // Should have digits and should not end with `_`
    if (!hasDigits || ch === '_') return false;
  
    // if !base60 - done;
    if (ch !== ':') return true;
  
    // base60 almost not used, no needs to optimize
    return /^(:[0-5]?[0-9])+$/.test(data.slice(index));
  }
  
  function constructYamlInteger(data) {
    var value = data, sign = 1, ch, base, digits = [];
  
    if (value.indexOf('_') !== -1) {
      value = value.replace(/_/g, '');
    }
  
    ch = value[0];
  
    if (ch === '-' || ch === '+') {
      if (ch === '-') sign = -1;
      value = value.slice(1);
      ch = value[0];
    }
  
    if (value === '0') return 0;
  
    if (ch === '0') {
      if (value[1] === 'b') return sign * parseInt(value.slice(2), 2);
      if (value[1] === 'x') return sign * parseInt(value, 16);
      return sign * parseInt(value, 8);
    }
  
    if (value.indexOf(':') !== -1) {
      value.split(':').forEach(function (v) {
        digits.unshift(parseInt(v, 10));
      });
  
      value = 0;
      base = 1;
  
      digits.forEach(function (d) {
        value += (d * base);
        base *= 60;
      });
  
      return sign * value;
  
    }
  
    return sign * parseInt(value, 10);
  }
  
  function isInteger(object) {
    return (Object.prototype.toString.call(object)) === '[object Number]' &&
           (object % 1 === 0 && !common.isNegativeZero(object));
  }
  
  module.exports = new Type('tag:yaml.org,2002:int', {
    kind: 'scalar',
    resolve: resolveYamlInteger,
    construct: constructYamlInteger,
    predicate: isInteger,
    represent: {
      binary:      function (obj) { return obj >= 0 ? '0b' + obj.toString(2) : '-0b' + obj.toString(2).slice(1); },
      octal:       function (obj) { return obj >= 0 ? '0'  + obj.toString(8) : '-0'  + obj.toString(8).slice(1); },
      decimal:     function (obj) { return obj.toString(10); },
      /* eslint-disable max-len */
      hexadecimal: function (obj) { return obj >= 0 ? '0x' + obj.toString(16).toUpperCase() :  '-0x' + obj.toString(16).toUpperCase().slice(1); }
    },
    defaultStyle: 'decimal',
    styleAliases: {
      binary:      [ 2,  'bin' ],
      octal:       [ 8,  'oct' ],
      decimal:     [ 10, 'dec' ],
      hexadecimal: [ 16, 'hex' ]
    }
  });
  
  },{"../common":92,"../type":103}],108:[function(require,module,exports){
  'use strict';
  
  var esprima;
  
  // Browserified version does not have esprima
  //
  // 1. For node.js just require module as deps
  // 2. For browser try to require mudule via external AMD system.
  //    If not found - try to fallback to window.esprima. If not
  //    found too - then fail to parse.
  //
  try {
    // workaround to exclude package from browserify list.
    var _require = require;
    esprima = _require('esprima');
  } catch (_) {
    /*global window */
    if (typeof window !== 'undefined') esprima = window.esprima;
  }
  
  var Type = require('../../type');
  
  function resolveJavascriptFunction(data) {
    if (data === null) return false;
  
    try {
      var source = '(' + data + ')',
          ast    = esprima.parse(source, { range: true });
  
      if (ast.type                    !== 'Program'             ||
          ast.body.length             !== 1                     ||
          ast.body[0].type            !== 'ExpressionStatement' ||
          (ast.body[0].expression.type !== 'ArrowFunctionExpression' &&
            ast.body[0].expression.type !== 'FunctionExpression')) {
        return false;
      }
  
      return true;
    } catch (err) {
      return false;
    }
  }
  
  function constructJavascriptFunction(data) {
    /*jslint evil:true*/
  
    var source = '(' + data + ')',
        ast    = esprima.parse(source, { range: true }),
        params = [],
        body;
  
    if (ast.type                    !== 'Program'             ||
        ast.body.length             !== 1                     ||
        ast.body[0].type            !== 'ExpressionStatement' ||
        (ast.body[0].expression.type !== 'ArrowFunctionExpression' &&
          ast.body[0].expression.type !== 'FunctionExpression')) {
      throw new Error('Failed to resolve function');
    }
  
    ast.body[0].expression.params.forEach(function (param) {
      params.push(param.name);
    });
  
    body = ast.body[0].expression.body.range;
  
    // Esprima's ranges include the first '{' and the last '}' characters on
    // function expressions. So cut them out.
    if (ast.body[0].expression.body.type === 'BlockStatement') {
      /*eslint-disable no-new-func*/
      return new Function(params, source.slice(body[0] + 1, body[1] - 1));
    }
    // ES6 arrow functions can omit the BlockStatement. In that case, just return
    // the body.
    /*eslint-disable no-new-func*/
    return new Function(params, 'return ' + source.slice(body[0], body[1]));
  }
  
  function representJavascriptFunction(object /*, style*/) {
    return object.toString();
  }
  
  function isFunction(object) {
    return Object.prototype.toString.call(object) === '[object Function]';
  }
  
  module.exports = new Type('tag:yaml.org,2002:js/function', {
    kind: 'scalar',
    resolve: resolveJavascriptFunction,
    construct: constructJavascriptFunction,
    predicate: isFunction,
    represent: representJavascriptFunction
  });
  
  },{"../../type":103}],109:[function(require,module,exports){
  'use strict';
  
  var Type = require('../../type');
  
  function resolveJavascriptRegExp(data) {
    if (data === null) return false;
    if (data.length === 0) return false;
  
    var regexp = data,
        tail   = /\/([gim]*)$/.exec(data),
        modifiers = '';
  
    // if regexp starts with '/' it can have modifiers and must be properly closed
    // `/foo/gim` - modifiers tail can be maximum 3 chars
    if (regexp[0] === '/') {
      if (tail) modifiers = tail[1];
  
      if (modifiers.length > 3) return false;
      // if expression starts with /, is should be properly terminated
      if (regexp[regexp.length - modifiers.length - 1] !== '/') return false;
    }
  
    return true;
  }
  
  function constructJavascriptRegExp(data) {
    var regexp = data,
        tail   = /\/([gim]*)$/.exec(data),
        modifiers = '';
  
    // `/foo/gim` - tail can be maximum 4 chars
    if (regexp[0] === '/') {
      if (tail) modifiers = tail[1];
      regexp = regexp.slice(1, regexp.length - modifiers.length - 1);
    }
  
    return new RegExp(regexp, modifiers);
  }
  
  function representJavascriptRegExp(object /*, style*/) {
    var result = '/' + object.source + '/';
  
    if (object.global) result += 'g';
    if (object.multiline) result += 'm';
    if (object.ignoreCase) result += 'i';
  
    return result;
  }
  
  function isRegExp(object) {
    return Object.prototype.toString.call(object) === '[object RegExp]';
  }
  
  module.exports = new Type('tag:yaml.org,2002:js/regexp', {
    kind: 'scalar',
    resolve: resolveJavascriptRegExp,
    construct: constructJavascriptRegExp,
    predicate: isRegExp,
    represent: representJavascriptRegExp
  });
  
  },{"../../type":103}],110:[function(require,module,exports){
  'use strict';
  
  var Type = require('../../type');
  
  function resolveJavascriptUndefined() {
    return true;
  }
  
  function constructJavascriptUndefined() {
    /*eslint-disable no-undefined*/
    return undefined;
  }
  
  function representJavascriptUndefined() {
    return '';
  }
  
  function isUndefined(object) {
    return typeof object === 'undefined';
  }
  
  module.exports = new Type('tag:yaml.org,2002:js/undefined', {
    kind: 'scalar',
    resolve: resolveJavascriptUndefined,
    construct: constructJavascriptUndefined,
    predicate: isUndefined,
    represent: representJavascriptUndefined
  });
  
  },{"../../type":103}],111:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  module.exports = new Type('tag:yaml.org,2002:map', {
    kind: 'mapping',
    construct: function (data) { return data !== null ? data : {}; }
  });
  
  },{"../type":103}],112:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  function resolveYamlMerge(data) {
    return data === '<<' || data === null;
  }
  
  module.exports = new Type('tag:yaml.org,2002:merge', {
    kind: 'scalar',
    resolve: resolveYamlMerge
  });
  
  },{"../type":103}],113:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  function resolveYamlNull(data) {
    if (data === null) return true;
  
    var max = data.length;
  
    return (max === 1 && data === '~') ||
           (max === 4 && (data === 'null' || data === 'Null' || data === 'NULL'));
  }
  
  function constructYamlNull() {
    return null;
  }
  
  function isNull(object) {
    return object === null;
  }
  
  module.exports = new Type('tag:yaml.org,2002:null', {
    kind: 'scalar',
    resolve: resolveYamlNull,
    construct: constructYamlNull,
    predicate: isNull,
    represent: {
      canonical: function () { return '~';    },
      lowercase: function () { return 'null'; },
      uppercase: function () { return 'NULL'; },
      camelcase: function () { return 'Null'; }
    },
    defaultStyle: 'lowercase'
  });
  
  },{"../type":103}],114:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  var _hasOwnProperty = Object.prototype.hasOwnProperty;
  var _toString       = Object.prototype.toString;
  
  function resolveYamlOmap(data) {
    if (data === null) return true;
  
    var objectKeys = [], index, length, pair, pairKey, pairHasKey,
        object = data;
  
    for (index = 0, length = object.length; index < length; index += 1) {
      pair = object[index];
      pairHasKey = false;
  
      if (_toString.call(pair) !== '[object Object]') return false;
  
      for (pairKey in pair) {
        if (_hasOwnProperty.call(pair, pairKey)) {
          if (!pairHasKey) pairHasKey = true;
          else return false;
        }
      }
  
      if (!pairHasKey) return false;
  
      if (objectKeys.indexOf(pairKey) === -1) objectKeys.push(pairKey);
      else return false;
    }
  
    return true;
  }
  
  function constructYamlOmap(data) {
    return data !== null ? data : [];
  }
  
  module.exports = new Type('tag:yaml.org,2002:omap', {
    kind: 'sequence',
    resolve: resolveYamlOmap,
    construct: constructYamlOmap
  });
  
  },{"../type":103}],115:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  var _toString = Object.prototype.toString;
  
  function resolveYamlPairs(data) {
    if (data === null) return true;
  
    var index, length, pair, keys, result,
        object = data;
  
    result = new Array(object.length);
  
    for (index = 0, length = object.length; index < length; index += 1) {
      pair = object[index];
  
      if (_toString.call(pair) !== '[object Object]') return false;
  
      keys = Object.keys(pair);
  
      if (keys.length !== 1) return false;
  
      result[index] = [ keys[0], pair[keys[0]] ];
    }
  
    return true;
  }
  
  function constructYamlPairs(data) {
    if (data === null) return [];
  
    var index, length, pair, keys, result,
        object = data;
  
    result = new Array(object.length);
  
    for (index = 0, length = object.length; index < length; index += 1) {
      pair = object[index];
  
      keys = Object.keys(pair);
  
      result[index] = [ keys[0], pair[keys[0]] ];
    }
  
    return result;
  }
  
  module.exports = new Type('tag:yaml.org,2002:pairs', {
    kind: 'sequence',
    resolve: resolveYamlPairs,
    construct: constructYamlPairs
  });
  
  },{"../type":103}],116:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  module.exports = new Type('tag:yaml.org,2002:seq', {
    kind: 'sequence',
    construct: function (data) { return data !== null ? data : []; }
  });
  
  },{"../type":103}],117:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  var _hasOwnProperty = Object.prototype.hasOwnProperty;
  
  function resolveYamlSet(data) {
    if (data === null) return true;
  
    var key, object = data;
  
    for (key in object) {
      if (_hasOwnProperty.call(object, key)) {
        if (object[key] !== null) return false;
      }
    }
  
    return true;
  }
  
  function constructYamlSet(data) {
    return data !== null ? data : {};
  }
  
  module.exports = new Type('tag:yaml.org,2002:set', {
    kind: 'mapping',
    resolve: resolveYamlSet,
    construct: constructYamlSet
  });
  
  },{"../type":103}],118:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  module.exports = new Type('tag:yaml.org,2002:str', {
    kind: 'scalar',
    construct: function (data) { return data !== null ? data : ''; }
  });
  
  },{"../type":103}],119:[function(require,module,exports){
  'use strict';
  
  var Type = require('../type');
  
  var YAML_DATE_REGEXP = new RegExp(
    '^([0-9][0-9][0-9][0-9])'          + // [1] year
    '-([0-9][0-9])'                    + // [2] month
    '-([0-9][0-9])$');                   // [3] day
  
  var YAML_TIMESTAMP_REGEXP = new RegExp(
    '^([0-9][0-9][0-9][0-9])'          + // [1] year
    '-([0-9][0-9]?)'                   + // [2] month
    '-([0-9][0-9]?)'                   + // [3] day
    '(?:[Tt]|[ \\t]+)'                 + // ...
    '([0-9][0-9]?)'                    + // [4] hour
    ':([0-9][0-9])'                    + // [5] minute
    ':([0-9][0-9])'                    + // [6] second
    '(?:\\.([0-9]*))?'                 + // [7] fraction
    '(?:[ \\t]*(Z|([-+])([0-9][0-9]?)' + // [8] tz [9] tz_sign [10] tz_hour
    '(?::([0-9][0-9]))?))?$');           // [11] tz_minute
  
  function resolveYamlTimestamp(data) {
    if (data === null) return false;
    if (YAML_DATE_REGEXP.exec(data) !== null) return true;
    if (YAML_TIMESTAMP_REGEXP.exec(data) !== null) return true;
    return false;
  }
  
  function constructYamlTimestamp(data) {
    var match, year, month, day, hour, minute, second, fraction = 0,
        delta = null, tz_hour, tz_minute, date;
  
    match = YAML_DATE_REGEXP.exec(data);
    if (match === null) match = YAML_TIMESTAMP_REGEXP.exec(data);
  
    if (match === null) throw new Error('Date resolve error');
  
    // match: [1] year [2] month [3] day
  
    year = +(match[1]);
    month = +(match[2]) - 1; // JS month starts with 0
    day = +(match[3]);
  
    if (!match[4]) { // no hour
      return new Date(Date.UTC(year, month, day));
    }
  
    // match: [4] hour [5] minute [6] second [7] fraction
  
    hour = +(match[4]);
    minute = +(match[5]);
    second = +(match[6]);
  
    if (match[7]) {
      fraction = match[7].slice(0, 3);
      while (fraction.length < 3) { // milli-seconds
        fraction += '0';
      }
      fraction = +fraction;
    }
  
    // match: [8] tz [9] tz_sign [10] tz_hour [11] tz_minute
  
    if (match[9]) {
      tz_hour = +(match[10]);
      tz_minute = +(match[11] || 0);
      delta = (tz_hour * 60 + tz_minute) * 60000; // delta in mili-seconds
      if (match[9] === '-') delta = -delta;
    }
  
    date = new Date(Date.UTC(year, month, day, hour, minute, second, fraction));
  
    if (delta) date.setTime(date.getTime() - delta);
  
    return date;
  }
  
  function representYamlTimestamp(object /*, style*/) {
    return object.toISOString();
  }
  
  module.exports = new Type('tag:yaml.org,2002:timestamp', {
    kind: 'scalar',
    resolve: resolveYamlTimestamp,
    construct: constructYamlTimestamp,
    instanceOf: Date,
    represent: representYamlTimestamp
  });
  
  },{"../type":103}],120:[function(require,module,exports){
  (function (global){
  /**
   * lodash (Custom Build) <https://lodash.com/>
   * Build: `lodash modularize exports="npm" -o ./`
   * Copyright jQuery Foundation and other contributors <https://jquery.org/>
   * Released under MIT license <https://lodash.com/license>
   * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
   * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
   */
  
  /** Used as the `TypeError` message for "Functions" methods. */
  var FUNC_ERROR_TEXT = 'Expected a function';
  
  /** Used to stand-in for `undefined` hash values. */
  var HASH_UNDEFINED = '__lodash_hash_undefined__';
  
  /** Used as references for various `Number` constants. */
  var INFINITY = 1 / 0;
  
  /** `Object#toString` result references. */
  var funcTag = '[object Function]',
      genTag = '[object GeneratorFunction]',
      symbolTag = '[object Symbol]';
  
  /** Used to match property names within property paths. */
  var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
      reIsPlainProp = /^\w*$/,
      reLeadingDot = /^\./,
      rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
  
  /**
   * Used to match `RegExp`
   * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
   */
  var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
  
  /** Used to match backslashes in property paths. */
  var reEscapeChar = /\\(\\)?/g;
  
  /** Used to detect host constructors (Safari). */
  var reIsHostCtor = /^\[object .+?Constructor\]$/;
  
  /** Detect free variable `global` from Node.js. */
  var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;
  
  /** Detect free variable `self`. */
  var freeSelf = typeof self == 'object' && self && self.Object === Object && self;
  
  /** Used as a reference to the global object. */
  var root = freeGlobal || freeSelf || Function('return this')();
  
  /**
   * Gets the value at `key` of `object`.
   *
   * @private
   * @param {Object} [object] The object to query.
   * @param {string} key The key of the property to get.
   * @returns {*} Returns the property value.
   */
  function getValue(object, key) {
    return object == null ? undefined : object[key];
  }
  
  /**
   * Checks if `value` is a host object in IE < 9.
   *
   * @private
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a host object, else `false`.
   */
  function isHostObject(value) {
    // Many host objects are `Object` objects that can coerce to strings
    // despite having improperly defined `toString` methods.
    var result = false;
    if (value != null && typeof value.toString != 'function') {
      try {
        result = !!(value + '');
      } catch (e) {}
    }
    return result;
  }
  
  /** Used for built-in method references. */
  var arrayProto = Array.prototype,
      funcProto = Function.prototype,
      objectProto = Object.prototype;
  
  /** Used to detect overreaching core-js shims. */
  var coreJsData = root['__core-js_shared__'];
  
  /** Used to detect methods masquerading as native. */
  var maskSrcKey = (function() {
    var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
    return uid ? ('Symbol(src)_1.' + uid) : '';
  }());
  
  /** Used to resolve the decompiled source of functions. */
  var funcToString = funcProto.toString;
  
  /** Used to check objects for own properties. */
  var hasOwnProperty = objectProto.hasOwnProperty;
  
  /**
   * Used to resolve the
   * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
   * of values.
   */
  var objectToString = objectProto.toString;
  
  /** Used to detect if a method is native. */
  var reIsNative = RegExp('^' +
    funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&')
    .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
  );
  
  /** Built-in value references. */
  var Symbol = root.Symbol,
      splice = arrayProto.splice;
  
  /* Built-in method references that are verified to be native. */
  var Map = getNative(root, 'Map'),
      nativeCreate = getNative(Object, 'create');
  
  /** Used to convert symbols to primitives and strings. */
  var symbolProto = Symbol ? Symbol.prototype : undefined,
      symbolToString = symbolProto ? symbolProto.toString : undefined;
  
  /**
   * Creates a hash object.
   *
   * @private
   * @constructor
   * @param {Array} [entries] The key-value pairs to cache.
   */
  function Hash(entries) {
    var index = -1,
        length = entries ? entries.length : 0;
  
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  
  /**
   * Removes all key-value entries from the hash.
   *
   * @private
   * @name clear
   * @memberOf Hash
   */
  function hashClear() {
    this.__data__ = nativeCreate ? nativeCreate(null) : {};
  }
  
  /**
   * Removes `key` and its value from the hash.
   *
   * @private
   * @name delete
   * @memberOf Hash
   * @param {Object} hash The hash to modify.
   * @param {string} key The key of the value to remove.
   * @returns {boolean} Returns `true` if the entry was removed, else `false`.
   */
  function hashDelete(key) {
    return this.has(key) && delete this.__data__[key];
  }
  
  /**
   * Gets the hash value for `key`.
   *
   * @private
   * @name get
   * @memberOf Hash
   * @param {string} key The key of the value to get.
   * @returns {*} Returns the entry value.
   */
  function hashGet(key) {
    var data = this.__data__;
    if (nativeCreate) {
      var result = data[key];
      return result === HASH_UNDEFINED ? undefined : result;
    }
    return hasOwnProperty.call(data, key) ? data[key] : undefined;
  }
  
  /**
   * Checks if a hash value for `key` exists.
   *
   * @private
   * @name has
   * @memberOf Hash
   * @param {string} key The key of the entry to check.
   * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
   */
  function hashHas(key) {
    var data = this.__data__;
    return nativeCreate ? data[key] !== undefined : hasOwnProperty.call(data, key);
  }
  
  /**
   * Sets the hash `key` to `value`.
   *
   * @private
   * @name set
   * @memberOf Hash
   * @param {string} key The key of the value to set.
   * @param {*} value The value to set.
   * @returns {Object} Returns the hash instance.
   */
  function hashSet(key, value) {
    var data = this.__data__;
    data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
    return this;
  }
  
  // Add methods to `Hash`.
  Hash.prototype.clear = hashClear;
  Hash.prototype['delete'] = hashDelete;
  Hash.prototype.get = hashGet;
  Hash.prototype.has = hashHas;
  Hash.prototype.set = hashSet;
  
  /**
   * Creates an list cache object.
   *
   * @private
   * @constructor
   * @param {Array} [entries] The key-value pairs to cache.
   */
  function ListCache(entries) {
    var index = -1,
        length = entries ? entries.length : 0;
  
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  
  /**
   * Removes all key-value entries from the list cache.
   *
   * @private
   * @name clear
   * @memberOf ListCache
   */
  function listCacheClear() {
    this.__data__ = [];
  }
  
  /**
   * Removes `key` and its value from the list cache.
   *
   * @private
   * @name delete
   * @memberOf ListCache
   * @param {string} key The key of the value to remove.
   * @returns {boolean} Returns `true` if the entry was removed, else `false`.
   */
  function listCacheDelete(key) {
    var data = this.__data__,
        index = assocIndexOf(data, key);
  
    if (index < 0) {
      return false;
    }
    var lastIndex = data.length - 1;
    if (index == lastIndex) {
      data.pop();
    } else {
      splice.call(data, index, 1);
    }
    return true;
  }
  
  /**
   * Gets the list cache value for `key`.
   *
   * @private
   * @name get
   * @memberOf ListCache
   * @param {string} key The key of the value to get.
   * @returns {*} Returns the entry value.
   */
  function listCacheGet(key) {
    var data = this.__data__,
        index = assocIndexOf(data, key);
  
    return index < 0 ? undefined : data[index][1];
  }
  
  /**
   * Checks if a list cache value for `key` exists.
   *
   * @private
   * @name has
   * @memberOf ListCache
   * @param {string} key The key of the entry to check.
   * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
   */
  function listCacheHas(key) {
    return assocIndexOf(this.__data__, key) > -1;
  }
  
  /**
   * Sets the list cache `key` to `value`.
   *
   * @private
   * @name set
   * @memberOf ListCache
   * @param {string} key The key of the value to set.
   * @param {*} value The value to set.
   * @returns {Object} Returns the list cache instance.
   */
  function listCacheSet(key, value) {
    var data = this.__data__,
        index = assocIndexOf(data, key);
  
    if (index < 0) {
      data.push([key, value]);
    } else {
      data[index][1] = value;
    }
    return this;
  }
  
  // Add methods to `ListCache`.
  ListCache.prototype.clear = listCacheClear;
  ListCache.prototype['delete'] = listCacheDelete;
  ListCache.prototype.get = listCacheGet;
  ListCache.prototype.has = listCacheHas;
  ListCache.prototype.set = listCacheSet;
  
  /**
   * Creates a map cache object to store key-value pairs.
   *
   * @private
   * @constructor
   * @param {Array} [entries] The key-value pairs to cache.
   */
  function MapCache(entries) {
    var index = -1,
        length = entries ? entries.length : 0;
  
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  
  /**
   * Removes all key-value entries from the map.
   *
   * @private
   * @name clear
   * @memberOf MapCache
   */
  function mapCacheClear() {
    this.__data__ = {
      'hash': new Hash,
      'map': new (Map || ListCache),
      'string': new Hash
    };
  }
  
  /**
   * Removes `key` and its value from the map.
   *
   * @private
   * @name delete
   * @memberOf MapCache
   * @param {string} key The key of the value to remove.
   * @returns {boolean} Returns `true` if the entry was removed, else `false`.
   */
  function mapCacheDelete(key) {
    return getMapData(this, key)['delete'](key);
  }
  
  /**
   * Gets the map value for `key`.
   *
   * @private
   * @name get
   * @memberOf MapCache
   * @param {string} key The key of the value to get.
   * @returns {*} Returns the entry value.
   */
  function mapCacheGet(key) {
    return getMapData(this, key).get(key);
  }
  
  /**
   * Checks if a map value for `key` exists.
   *
   * @private
   * @name has
   * @memberOf MapCache
   * @param {string} key The key of the entry to check.
   * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
   */
  function mapCacheHas(key) {
    return getMapData(this, key).has(key);
  }
  
  /**
   * Sets the map `key` to `value`.
   *
   * @private
   * @name set
   * @memberOf MapCache
   * @param {string} key The key of the value to set.
   * @param {*} value The value to set.
   * @returns {Object} Returns the map cache instance.
   */
  function mapCacheSet(key, value) {
    getMapData(this, key).set(key, value);
    return this;
  }
  
  // Add methods to `MapCache`.
  MapCache.prototype.clear = mapCacheClear;
  MapCache.prototype['delete'] = mapCacheDelete;
  MapCache.prototype.get = mapCacheGet;
  MapCache.prototype.has = mapCacheHas;
  MapCache.prototype.set = mapCacheSet;
  
  /**
   * Gets the index at which the `key` is found in `array` of key-value pairs.
   *
   * @private
   * @param {Array} array The array to inspect.
   * @param {*} key The key to search for.
   * @returns {number} Returns the index of the matched value, else `-1`.
   */
  function assocIndexOf(array, key) {
    var length = array.length;
    while (length--) {
      if (eq(array[length][0], key)) {
        return length;
      }
    }
    return -1;
  }
  
  /**
   * The base implementation of `_.get` without support for default values.
   *
   * @private
   * @param {Object} object The object to query.
   * @param {Array|string} path The path of the property to get.
   * @returns {*} Returns the resolved value.
   */
  function baseGet(object, path) {
    path = isKey(path, object) ? [path] : castPath(path);
  
    var index = 0,
        length = path.length;
  
    while (object != null && index < length) {
      object = object[toKey(path[index++])];
    }
    return (index && index == length) ? object : undefined;
  }
  
  /**
   * The base implementation of `_.isNative` without bad shim checks.
   *
   * @private
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a native function,
   *  else `false`.
   */
  function baseIsNative(value) {
    if (!isObject(value) || isMasked(value)) {
      return false;
    }
    var pattern = (isFunction(value) || isHostObject(value)) ? reIsNative : reIsHostCtor;
    return pattern.test(toSource(value));
  }
  
  /**
   * The base implementation of `_.toString` which doesn't convert nullish
   * values to empty strings.
   *
   * @private
   * @param {*} value The value to process.
   * @returns {string} Returns the string.
   */
  function baseToString(value) {
    // Exit early for strings to avoid a performance hit in some environments.
    if (typeof value == 'string') {
      return value;
    }
    if (isSymbol(value)) {
      return symbolToString ? symbolToString.call(value) : '';
    }
    var result = (value + '');
    return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
  }
  
  /**
   * Casts `value` to a path array if it's not one.
   *
   * @private
   * @param {*} value The value to inspect.
   * @returns {Array} Returns the cast property path array.
   */
  function castPath(value) {
    return isArray(value) ? value : stringToPath(value);
  }
  
  /**
   * Gets the data for `map`.
   *
   * @private
   * @param {Object} map The map to query.
   * @param {string} key The reference key.
   * @returns {*} Returns the map data.
   */
  function getMapData(map, key) {
    var data = map.__data__;
    return isKeyable(key)
      ? data[typeof key == 'string' ? 'string' : 'hash']
      : data.map;
  }
  
  /**
   * Gets the native function at `key` of `object`.
   *
   * @private
   * @param {Object} object The object to query.
   * @param {string} key The key of the method to get.
   * @returns {*} Returns the function if it's native, else `undefined`.
   */
  function getNative(object, key) {
    var value = getValue(object, key);
    return baseIsNative(value) ? value : undefined;
  }
  
  /**
   * Checks if `value` is a property name and not a property path.
   *
   * @private
   * @param {*} value The value to check.
   * @param {Object} [object] The object to query keys on.
   * @returns {boolean} Returns `true` if `value` is a property name, else `false`.
   */
  function isKey(value, object) {
    if (isArray(value)) {
      return false;
    }
    var type = typeof value;
    if (type == 'number' || type == 'symbol' || type == 'boolean' ||
        value == null || isSymbol(value)) {
      return true;
    }
    return reIsPlainProp.test(value) || !reIsDeepProp.test(value) ||
      (object != null && value in Object(object));
  }
  
  /**
   * Checks if `value` is suitable for use as unique object key.
   *
   * @private
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
   */
  function isKeyable(value) {
    var type = typeof value;
    return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
      ? (value !== '__proto__')
      : (value === null);
  }
  
  /**
   * Checks if `func` has its source masked.
   *
   * @private
   * @param {Function} func The function to check.
   * @returns {boolean} Returns `true` if `func` is masked, else `false`.
   */
  function isMasked(func) {
    return !!maskSrcKey && (maskSrcKey in func);
  }
  
  /**
   * Converts `string` to a property path array.
   *
   * @private
   * @param {string} string The string to convert.
   * @returns {Array} Returns the property path array.
   */
  var stringToPath = memoize(function(string) {
    string = toString(string);
  
    var result = [];
    if (reLeadingDot.test(string)) {
      result.push('');
    }
    string.replace(rePropName, function(match, number, quote, string) {
      result.push(quote ? string.replace(reEscapeChar, '$1') : (number || match));
    });
    return result;
  });
  
  /**
   * Converts `value` to a string key if it's not a string or symbol.
   *
   * @private
   * @param {*} value The value to inspect.
   * @returns {string|symbol} Returns the key.
   */
  function toKey(value) {
    if (typeof value == 'string' || isSymbol(value)) {
      return value;
    }
    var result = (value + '');
    return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
  }
  
  /**
   * Converts `func` to its source code.
   *
   * @private
   * @param {Function} func The function to process.
   * @returns {string} Returns the source code.
   */
  function toSource(func) {
    if (func != null) {
      try {
        return funcToString.call(func);
      } catch (e) {}
      try {
        return (func + '');
      } catch (e) {}
    }
    return '';
  }
  
  /**
   * Creates a function that memoizes the result of `func`. If `resolver` is
   * provided, it determines the cache key for storing the result based on the
   * arguments provided to the memoized function. By default, the first argument
   * provided to the memoized function is used as the map cache key. The `func`
   * is invoked with the `this` binding of the memoized function.
   *
   * **Note:** The cache is exposed as the `cache` property on the memoized
   * function. Its creation may be customized by replacing the `_.memoize.Cache`
   * constructor with one whose instances implement the
   * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
   * method interface of `delete`, `get`, `has`, and `set`.
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Function
   * @param {Function} func The function to have its output memoized.
   * @param {Function} [resolver] The function to resolve the cache key.
   * @returns {Function} Returns the new memoized function.
   * @example
   *
   * var object = { 'a': 1, 'b': 2 };
   * var other = { 'c': 3, 'd': 4 };
   *
   * var values = _.memoize(_.values);
   * values(object);
   * // => [1, 2]
   *
   * values(other);
   * // => [3, 4]
   *
   * object.a = 2;
   * values(object);
   * // => [1, 2]
   *
   * // Modify the result cache.
   * values.cache.set(object, ['a', 'b']);
   * values(object);
   * // => ['a', 'b']
   *
   * // Replace `_.memoize.Cache`.
   * _.memoize.Cache = WeakMap;
   */
  function memoize(func, resolver) {
    if (typeof func != 'function' || (resolver && typeof resolver != 'function')) {
      throw new TypeError(FUNC_ERROR_TEXT);
    }
    var memoized = function() {
      var args = arguments,
          key = resolver ? resolver.apply(this, args) : args[0],
          cache = memoized.cache;
  
      if (cache.has(key)) {
        return cache.get(key);
      }
      var result = func.apply(this, args);
      memoized.cache = cache.set(key, result);
      return result;
    };
    memoized.cache = new (memoize.Cache || MapCache);
    return memoized;
  }
  
  // Assign cache to `_.memoize`.
  memoize.Cache = MapCache;
  
  /**
   * Performs a
   * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
   * comparison between two values to determine if they are equivalent.
   *
   * @static
   * @memberOf _
   * @since 4.0.0
   * @category Lang
   * @param {*} value The value to compare.
   * @param {*} other The other value to compare.
   * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
   * @example
   *
   * var object = { 'a': 1 };
   * var other = { 'a': 1 };
   *
   * _.eq(object, object);
   * // => true
   *
   * _.eq(object, other);
   * // => false
   *
   * _.eq('a', 'a');
   * // => true
   *
   * _.eq('a', Object('a'));
   * // => false
   *
   * _.eq(NaN, NaN);
   * // => true
   */
  function eq(value, other) {
    return value === other || (value !== value && other !== other);
  }
  
  /**
   * Checks if `value` is classified as an `Array` object.
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is an array, else `false`.
   * @example
   *
   * _.isArray([1, 2, 3]);
   * // => true
   *
   * _.isArray(document.body.children);
   * // => false
   *
   * _.isArray('abc');
   * // => false
   *
   * _.isArray(_.noop);
   * // => false
   */
  var isArray = Array.isArray;
  
  /**
   * Checks if `value` is classified as a `Function` object.
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a function, else `false`.
   * @example
   *
   * _.isFunction(_);
   * // => true
   *
   * _.isFunction(/abc/);
   * // => false
   */
  function isFunction(value) {
    // The use of `Object#toString` avoids issues with the `typeof` operator
    // in Safari 8-9 which returns 'object' for typed array and other constructors.
    var tag = isObject(value) ? objectToString.call(value) : '';
    return tag == funcTag || tag == genTag;
  }
  
  /**
   * Checks if `value` is the
   * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
   * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is an object, else `false`.
   * @example
   *
   * _.isObject({});
   * // => true
   *
   * _.isObject([1, 2, 3]);
   * // => true
   *
   * _.isObject(_.noop);
   * // => true
   *
   * _.isObject(null);
   * // => false
   */
  function isObject(value) {
    var type = typeof value;
    return !!value && (type == 'object' || type == 'function');
  }
  
  /**
   * Checks if `value` is object-like. A value is object-like if it's not `null`
   * and has a `typeof` result of "object".
   *
   * @static
   * @memberOf _
   * @since 4.0.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
   * @example
   *
   * _.isObjectLike({});
   * // => true
   *
   * _.isObjectLike([1, 2, 3]);
   * // => true
   *
   * _.isObjectLike(_.noop);
   * // => false
   *
   * _.isObjectLike(null);
   * // => false
   */
  function isObjectLike(value) {
    return !!value && typeof value == 'object';
  }
  
  /**
   * Checks if `value` is classified as a `Symbol` primitive or object.
   *
   * @static
   * @memberOf _
   * @since 4.0.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
   * @example
   *
   * _.isSymbol(Symbol.iterator);
   * // => true
   *
   * _.isSymbol('abc');
   * // => false
   */
  function isSymbol(value) {
    return typeof value == 'symbol' ||
      (isObjectLike(value) && objectToString.call(value) == symbolTag);
  }
  
  /**
   * Converts `value` to a string. An empty string is returned for `null`
   * and `undefined` values. The sign of `-0` is preserved.
   *
   * @static
   * @memberOf _
   * @since 4.0.0
   * @category Lang
   * @param {*} value The value to process.
   * @returns {string} Returns the string.
   * @example
   *
   * _.toString(null);
   * // => ''
   *
   * _.toString(-0);
   * // => '-0'
   *
   * _.toString([1, 2, 3]);
   * // => '1,2,3'
   */
  function toString(value) {
    return value == null ? '' : baseToString(value);
  }
  
  /**
   * Gets the value at `path` of `object`. If the resolved value is
   * `undefined`, the `defaultValue` is returned in its place.
   *
   * @static
   * @memberOf _
   * @since 3.7.0
   * @category Object
   * @param {Object} object The object to query.
   * @param {Array|string} path The path of the property to get.
   * @param {*} [defaultValue] The value returned for `undefined` resolved values.
   * @returns {*} Returns the resolved value.
   * @example
   *
   * var object = { 'a': [{ 'b': { 'c': 3 } }] };
   *
   * _.get(object, 'a[0].b.c');
   * // => 3
   *
   * _.get(object, ['a', '0', 'b', 'c']);
   * // => 3
   *
   * _.get(object, 'a.b.c', 'default');
   * // => 'default'
   */
  function get(object, path, defaultValue) {
    var result = object == null ? undefined : baseGet(object, path);
    return result === undefined ? defaultValue : result;
  }
  
  module.exports = get;
  
  }).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{}],121:[function(require,module,exports){
  (function (global){
  /**
   * Lodash (Custom Build) <https://lodash.com/>
   * Build: `lodash modularize exports="npm" -o ./`
   * Copyright JS Foundation and other contributors <https://js.foundation/>
   * Released under MIT license <https://lodash.com/license>
   * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
   * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
   */
  
  /** Used as the size to enable large array optimizations. */
  var LARGE_ARRAY_SIZE = 200;
  
  /** Used to stand-in for `undefined` hash values. */
  var HASH_UNDEFINED = '__lodash_hash_undefined__';
  
  /** Used to compose bitmasks for value comparisons. */
  var COMPARE_PARTIAL_FLAG = 1,
      COMPARE_UNORDERED_FLAG = 2;
  
  /** Used as references for various `Number` constants. */
  var MAX_SAFE_INTEGER = 9007199254740991;
  
  /** `Object#toString` result references. */
  var argsTag = '[object Arguments]',
      arrayTag = '[object Array]',
      asyncTag = '[object AsyncFunction]',
      boolTag = '[object Boolean]',
      dateTag = '[object Date]',
      errorTag = '[object Error]',
      funcTag = '[object Function]',
      genTag = '[object GeneratorFunction]',
      mapTag = '[object Map]',
      numberTag = '[object Number]',
      nullTag = '[object Null]',
      objectTag = '[object Object]',
      promiseTag = '[object Promise]',
      proxyTag = '[object Proxy]',
      regexpTag = '[object RegExp]',
      setTag = '[object Set]',
      stringTag = '[object String]',
      symbolTag = '[object Symbol]',
      undefinedTag = '[object Undefined]',
      weakMapTag = '[object WeakMap]';
  
  var arrayBufferTag = '[object ArrayBuffer]',
      dataViewTag = '[object DataView]',
      float32Tag = '[object Float32Array]',
      float64Tag = '[object Float64Array]',
      int8Tag = '[object Int8Array]',
      int16Tag = '[object Int16Array]',
      int32Tag = '[object Int32Array]',
      uint8Tag = '[object Uint8Array]',
      uint8ClampedTag = '[object Uint8ClampedArray]',
      uint16Tag = '[object Uint16Array]',
      uint32Tag = '[object Uint32Array]';
  
  /**
   * Used to match `RegExp`
   * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
   */
  var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
  
  /** Used to detect host constructors (Safari). */
  var reIsHostCtor = /^\[object .+?Constructor\]$/;
  
  /** Used to detect unsigned integer values. */
  var reIsUint = /^(?:0|[1-9]\d*)$/;
  
  /** Used to identify `toStringTag` values of typed arrays. */
  var typedArrayTags = {};
  typedArrayTags[float32Tag] = typedArrayTags[float64Tag] =
  typedArrayTags[int8Tag] = typedArrayTags[int16Tag] =
  typedArrayTags[int32Tag] = typedArrayTags[uint8Tag] =
  typedArrayTags[uint8ClampedTag] = typedArrayTags[uint16Tag] =
  typedArrayTags[uint32Tag] = true;
  typedArrayTags[argsTag] = typedArrayTags[arrayTag] =
  typedArrayTags[arrayBufferTag] = typedArrayTags[boolTag] =
  typedArrayTags[dataViewTag] = typedArrayTags[dateTag] =
  typedArrayTags[errorTag] = typedArrayTags[funcTag] =
  typedArrayTags[mapTag] = typedArrayTags[numberTag] =
  typedArrayTags[objectTag] = typedArrayTags[regexpTag] =
  typedArrayTags[setTag] = typedArrayTags[stringTag] =
  typedArrayTags[weakMapTag] = false;
  
  /** Detect free variable `global` from Node.js. */
  var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;
  
  /** Detect free variable `self`. */
  var freeSelf = typeof self == 'object' && self && self.Object === Object && self;
  
  /** Used as a reference to the global object. */
  var root = freeGlobal || freeSelf || Function('return this')();
  
  /** Detect free variable `exports`. */
  var freeExports = typeof exports == 'object' && exports && !exports.nodeType && exports;
  
  /** Detect free variable `module`. */
  var freeModule = freeExports && typeof module == 'object' && module && !module.nodeType && module;
  
  /** Detect the popular CommonJS extension `module.exports`. */
  var moduleExports = freeModule && freeModule.exports === freeExports;
  
  /** Detect free variable `process` from Node.js. */
  var freeProcess = moduleExports && freeGlobal.process;
  
  /** Used to access faster Node.js helpers. */
  var nodeUtil = (function() {
    try {
      return freeProcess && freeProcess.binding && freeProcess.binding('util');
    } catch (e) {}
  }());
  
  /* Node.js helper references. */
  var nodeIsTypedArray = nodeUtil && nodeUtil.isTypedArray;
  
  /**
   * A specialized version of `_.filter` for arrays without support for
   * iteratee shorthands.
   *
   * @private
   * @param {Array} [array] The array to iterate over.
   * @param {Function} predicate The function invoked per iteration.
   * @returns {Array} Returns the new filtered array.
   */
  function arrayFilter(array, predicate) {
    var index = -1,
        length = array == null ? 0 : array.length,
        resIndex = 0,
        result = [];
  
    while (++index < length) {
      var value = array[index];
      if (predicate(value, index, array)) {
        result[resIndex++] = value;
      }
    }
    return result;
  }
  
  /**
   * Appends the elements of `values` to `array`.
   *
   * @private
   * @param {Array} array The array to modify.
   * @param {Array} values The values to append.
   * @returns {Array} Returns `array`.
   */
  function arrayPush(array, values) {
    var index = -1,
        length = values.length,
        offset = array.length;
  
    while (++index < length) {
      array[offset + index] = values[index];
    }
    return array;
  }
  
  /**
   * A specialized version of `_.some` for arrays without support for iteratee
   * shorthands.
   *
   * @private
   * @param {Array} [array] The array to iterate over.
   * @param {Function} predicate The function invoked per iteration.
   * @returns {boolean} Returns `true` if any element passes the predicate check,
   *  else `false`.
   */
  function arraySome(array, predicate) {
    var index = -1,
        length = array == null ? 0 : array.length;
  
    while (++index < length) {
      if (predicate(array[index], index, array)) {
        return true;
      }
    }
    return false;
  }
  
  /**
   * The base implementation of `_.times` without support for iteratee shorthands
   * or max array length checks.
   *
   * @private
   * @param {number} n The number of times to invoke `iteratee`.
   * @param {Function} iteratee The function invoked per iteration.
   * @returns {Array} Returns the array of results.
   */
  function baseTimes(n, iteratee) {
    var index = -1,
        result = Array(n);
  
    while (++index < n) {
      result[index] = iteratee(index);
    }
    return result;
  }
  
  /**
   * The base implementation of `_.unary` without support for storing metadata.
   *
   * @private
   * @param {Function} func The function to cap arguments for.
   * @returns {Function} Returns the new capped function.
   */
  function baseUnary(func) {
    return function(value) {
      return func(value);
    };
  }
  
  /**
   * Checks if a `cache` value for `key` exists.
   *
   * @private
   * @param {Object} cache The cache to query.
   * @param {string} key The key of the entry to check.
   * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
   */
  function cacheHas(cache, key) {
    return cache.has(key);
  }
  
  /**
   * Gets the value at `key` of `object`.
   *
   * @private
   * @param {Object} [object] The object to query.
   * @param {string} key The key of the property to get.
   * @returns {*} Returns the property value.
   */
  function getValue(object, key) {
    return object == null ? undefined : object[key];
  }
  
  /**
   * Converts `map` to its key-value pairs.
   *
   * @private
   * @param {Object} map The map to convert.
   * @returns {Array} Returns the key-value pairs.
   */
  function mapToArray(map) {
    var index = -1,
        result = Array(map.size);
  
    map.forEach(function(value, key) {
      result[++index] = [key, value];
    });
    return result;
  }
  
  /**
   * Creates a unary function that invokes `func` with its argument transformed.
   *
   * @private
   * @param {Function} func The function to wrap.
   * @param {Function} transform The argument transform.
   * @returns {Function} Returns the new function.
   */
  function overArg(func, transform) {
    return function(arg) {
      return func(transform(arg));
    };
  }
  
  /**
   * Converts `set` to an array of its values.
   *
   * @private
   * @param {Object} set The set to convert.
   * @returns {Array} Returns the values.
   */
  function setToArray(set) {
    var index = -1,
        result = Array(set.size);
  
    set.forEach(function(value) {
      result[++index] = value;
    });
    return result;
  }
  
  /** Used for built-in method references. */
  var arrayProto = Array.prototype,
      funcProto = Function.prototype,
      objectProto = Object.prototype;
  
  /** Used to detect overreaching core-js shims. */
  var coreJsData = root['__core-js_shared__'];
  
  /** Used to resolve the decompiled source of functions. */
  var funcToString = funcProto.toString;
  
  /** Used to check objects for own properties. */
  var hasOwnProperty = objectProto.hasOwnProperty;
  
  /** Used to detect methods masquerading as native. */
  var maskSrcKey = (function() {
    var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
    return uid ? ('Symbol(src)_1.' + uid) : '';
  }());
  
  /**
   * Used to resolve the
   * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
   * of values.
   */
  var nativeObjectToString = objectProto.toString;
  
  /** Used to detect if a method is native. */
  var reIsNative = RegExp('^' +
    funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&')
    .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
  );
  
  /** Built-in value references. */
  var Buffer = moduleExports ? root.Buffer : undefined,
      Symbol = root.Symbol,
      Uint8Array = root.Uint8Array,
      propertyIsEnumerable = objectProto.propertyIsEnumerable,
      splice = arrayProto.splice,
      symToStringTag = Symbol ? Symbol.toStringTag : undefined;
  
  /* Built-in method references for those with the same name as other `lodash` methods. */
  var nativeGetSymbols = Object.getOwnPropertySymbols,
      nativeIsBuffer = Buffer ? Buffer.isBuffer : undefined,
      nativeKeys = overArg(Object.keys, Object);
  
  /* Built-in method references that are verified to be native. */
  var DataView = getNative(root, 'DataView'),
      Map = getNative(root, 'Map'),
      Promise = getNative(root, 'Promise'),
      Set = getNative(root, 'Set'),
      WeakMap = getNative(root, 'WeakMap'),
      nativeCreate = getNative(Object, 'create');
  
  /** Used to detect maps, sets, and weakmaps. */
  var dataViewCtorString = toSource(DataView),
      mapCtorString = toSource(Map),
      promiseCtorString = toSource(Promise),
      setCtorString = toSource(Set),
      weakMapCtorString = toSource(WeakMap);
  
  /** Used to convert symbols to primitives and strings. */
  var symbolProto = Symbol ? Symbol.prototype : undefined,
      symbolValueOf = symbolProto ? symbolProto.valueOf : undefined;
  
  /**
   * Creates a hash object.
   *
   * @private
   * @constructor
   * @param {Array} [entries] The key-value pairs to cache.
   */
  function Hash(entries) {
    var index = -1,
        length = entries == null ? 0 : entries.length;
  
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  
  /**
   * Removes all key-value entries from the hash.
   *
   * @private
   * @name clear
   * @memberOf Hash
   */
  function hashClear() {
    this.__data__ = nativeCreate ? nativeCreate(null) : {};
    this.size = 0;
  }
  
  /**
   * Removes `key` and its value from the hash.
   *
   * @private
   * @name delete
   * @memberOf Hash
   * @param {Object} hash The hash to modify.
   * @param {string} key The key of the value to remove.
   * @returns {boolean} Returns `true` if the entry was removed, else `false`.
   */
  function hashDelete(key) {
    var result = this.has(key) && delete this.__data__[key];
    this.size -= result ? 1 : 0;
    return result;
  }
  
  /**
   * Gets the hash value for `key`.
   *
   * @private
   * @name get
   * @memberOf Hash
   * @param {string} key The key of the value to get.
   * @returns {*} Returns the entry value.
   */
  function hashGet(key) {
    var data = this.__data__;
    if (nativeCreate) {
      var result = data[key];
      return result === HASH_UNDEFINED ? undefined : result;
    }
    return hasOwnProperty.call(data, key) ? data[key] : undefined;
  }
  
  /**
   * Checks if a hash value for `key` exists.
   *
   * @private
   * @name has
   * @memberOf Hash
   * @param {string} key The key of the entry to check.
   * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
   */
  function hashHas(key) {
    var data = this.__data__;
    return nativeCreate ? (data[key] !== undefined) : hasOwnProperty.call(data, key);
  }
  
  /**
   * Sets the hash `key` to `value`.
   *
   * @private
   * @name set
   * @memberOf Hash
   * @param {string} key The key of the value to set.
   * @param {*} value The value to set.
   * @returns {Object} Returns the hash instance.
   */
  function hashSet(key, value) {
    var data = this.__data__;
    this.size += this.has(key) ? 0 : 1;
    data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
    return this;
  }
  
  // Add methods to `Hash`.
  Hash.prototype.clear = hashClear;
  Hash.prototype['delete'] = hashDelete;
  Hash.prototype.get = hashGet;
  Hash.prototype.has = hashHas;
  Hash.prototype.set = hashSet;
  
  /**
   * Creates an list cache object.
   *
   * @private
   * @constructor
   * @param {Array} [entries] The key-value pairs to cache.
   */
  function ListCache(entries) {
    var index = -1,
        length = entries == null ? 0 : entries.length;
  
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  
  /**
   * Removes all key-value entries from the list cache.
   *
   * @private
   * @name clear
   * @memberOf ListCache
   */
  function listCacheClear() {
    this.__data__ = [];
    this.size = 0;
  }
  
  /**
   * Removes `key` and its value from the list cache.
   *
   * @private
   * @name delete
   * @memberOf ListCache
   * @param {string} key The key of the value to remove.
   * @returns {boolean} Returns `true` if the entry was removed, else `false`.
   */
  function listCacheDelete(key) {
    var data = this.__data__,
        index = assocIndexOf(data, key);
  
    if (index < 0) {
      return false;
    }
    var lastIndex = data.length - 1;
    if (index == lastIndex) {
      data.pop();
    } else {
      splice.call(data, index, 1);
    }
    --this.size;
    return true;
  }
  
  /**
   * Gets the list cache value for `key`.
   *
   * @private
   * @name get
   * @memberOf ListCache
   * @param {string} key The key of the value to get.
   * @returns {*} Returns the entry value.
   */
  function listCacheGet(key) {
    var data = this.__data__,
        index = assocIndexOf(data, key);
  
    return index < 0 ? undefined : data[index][1];
  }
  
  /**
   * Checks if a list cache value for `key` exists.
   *
   * @private
   * @name has
   * @memberOf ListCache
   * @param {string} key The key of the entry to check.
   * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
   */
  function listCacheHas(key) {
    return assocIndexOf(this.__data__, key) > -1;
  }
  
  /**
   * Sets the list cache `key` to `value`.
   *
   * @private
   * @name set
   * @memberOf ListCache
   * @param {string} key The key of the value to set.
   * @param {*} value The value to set.
   * @returns {Object} Returns the list cache instance.
   */
  function listCacheSet(key, value) {
    var data = this.__data__,
        index = assocIndexOf(data, key);
  
    if (index < 0) {
      ++this.size;
      data.push([key, value]);
    } else {
      data[index][1] = value;
    }
    return this;
  }
  
  // Add methods to `ListCache`.
  ListCache.prototype.clear = listCacheClear;
  ListCache.prototype['delete'] = listCacheDelete;
  ListCache.prototype.get = listCacheGet;
  ListCache.prototype.has = listCacheHas;
  ListCache.prototype.set = listCacheSet;
  
  /**
   * Creates a map cache object to store key-value pairs.
   *
   * @private
   * @constructor
   * @param {Array} [entries] The key-value pairs to cache.
   */
  function MapCache(entries) {
    var index = -1,
        length = entries == null ? 0 : entries.length;
  
    this.clear();
    while (++index < length) {
      var entry = entries[index];
      this.set(entry[0], entry[1]);
    }
  }
  
  /**
   * Removes all key-value entries from the map.
   *
   * @private
   * @name clear
   * @memberOf MapCache
   */
  function mapCacheClear() {
    this.size = 0;
    this.__data__ = {
      'hash': new Hash,
      'map': new (Map || ListCache),
      'string': new Hash
    };
  }
  
  /**
   * Removes `key` and its value from the map.
   *
   * @private
   * @name delete
   * @memberOf MapCache
   * @param {string} key The key of the value to remove.
   * @returns {boolean} Returns `true` if the entry was removed, else `false`.
   */
  function mapCacheDelete(key) {
    var result = getMapData(this, key)['delete'](key);
    this.size -= result ? 1 : 0;
    return result;
  }
  
  /**
   * Gets the map value for `key`.
   *
   * @private
   * @name get
   * @memberOf MapCache
   * @param {string} key The key of the value to get.
   * @returns {*} Returns the entry value.
   */
  function mapCacheGet(key) {
    return getMapData(this, key).get(key);
  }
  
  /**
   * Checks if a map value for `key` exists.
   *
   * @private
   * @name has
   * @memberOf MapCache
   * @param {string} key The key of the entry to check.
   * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
   */
  function mapCacheHas(key) {
    return getMapData(this, key).has(key);
  }
  
  /**
   * Sets the map `key` to `value`.
   *
   * @private
   * @name set
   * @memberOf MapCache
   * @param {string} key The key of the value to set.
   * @param {*} value The value to set.
   * @returns {Object} Returns the map cache instance.
   */
  function mapCacheSet(key, value) {
    var data = getMapData(this, key),
        size = data.size;
  
    data.set(key, value);
    this.size += data.size == size ? 0 : 1;
    return this;
  }
  
  // Add methods to `MapCache`.
  MapCache.prototype.clear = mapCacheClear;
  MapCache.prototype['delete'] = mapCacheDelete;
  MapCache.prototype.get = mapCacheGet;
  MapCache.prototype.has = mapCacheHas;
  MapCache.prototype.set = mapCacheSet;
  
  /**
   *
   * Creates an array cache object to store unique values.
   *
   * @private
   * @constructor
   * @param {Array} [values] The values to cache.
   */
  function SetCache(values) {
    var index = -1,
        length = values == null ? 0 : values.length;
  
    this.__data__ = new MapCache;
    while (++index < length) {
      this.add(values[index]);
    }
  }
  
  /**
   * Adds `value` to the array cache.
   *
   * @private
   * @name add
   * @memberOf SetCache
   * @alias push
   * @param {*} value The value to cache.
   * @returns {Object} Returns the cache instance.
   */
  function setCacheAdd(value) {
    this.__data__.set(value, HASH_UNDEFINED);
    return this;
  }
  
  /**
   * Checks if `value` is in the array cache.
   *
   * @private
   * @name has
   * @memberOf SetCache
   * @param {*} value The value to search for.
   * @returns {number} Returns `true` if `value` is found, else `false`.
   */
  function setCacheHas(value) {
    return this.__data__.has(value);
  }
  
  // Add methods to `SetCache`.
  SetCache.prototype.add = SetCache.prototype.push = setCacheAdd;
  SetCache.prototype.has = setCacheHas;
  
  /**
   * Creates a stack cache object to store key-value pairs.
   *
   * @private
   * @constructor
   * @param {Array} [entries] The key-value pairs to cache.
   */
  function Stack(entries) {
    var data = this.__data__ = new ListCache(entries);
    this.size = data.size;
  }
  
  /**
   * Removes all key-value entries from the stack.
   *
   * @private
   * @name clear
   * @memberOf Stack
   */
  function stackClear() {
    this.__data__ = new ListCache;
    this.size = 0;
  }
  
  /**
   * Removes `key` and its value from the stack.
   *
   * @private
   * @name delete
   * @memberOf Stack
   * @param {string} key The key of the value to remove.
   * @returns {boolean} Returns `true` if the entry was removed, else `false`.
   */
  function stackDelete(key) {
    var data = this.__data__,
        result = data['delete'](key);
  
    this.size = data.size;
    return result;
  }
  
  /**
   * Gets the stack value for `key`.
   *
   * @private
   * @name get
   * @memberOf Stack
   * @param {string} key The key of the value to get.
   * @returns {*} Returns the entry value.
   */
  function stackGet(key) {
    return this.__data__.get(key);
  }
  
  /**
   * Checks if a stack value for `key` exists.
   *
   * @private
   * @name has
   * @memberOf Stack
   * @param {string} key The key of the entry to check.
   * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
   */
  function stackHas(key) {
    return this.__data__.has(key);
  }
  
  /**
   * Sets the stack `key` to `value`.
   *
   * @private
   * @name set
   * @memberOf Stack
   * @param {string} key The key of the value to set.
   * @param {*} value The value to set.
   * @returns {Object} Returns the stack cache instance.
   */
  function stackSet(key, value) {
    var data = this.__data__;
    if (data instanceof ListCache) {
      var pairs = data.__data__;
      if (!Map || (pairs.length < LARGE_ARRAY_SIZE - 1)) {
        pairs.push([key, value]);
        this.size = ++data.size;
        return this;
      }
      data = this.__data__ = new MapCache(pairs);
    }
    data.set(key, value);
    this.size = data.size;
    return this;
  }
  
  // Add methods to `Stack`.
  Stack.prototype.clear = stackClear;
  Stack.prototype['delete'] = stackDelete;
  Stack.prototype.get = stackGet;
  Stack.prototype.has = stackHas;
  Stack.prototype.set = stackSet;
  
  /**
   * Creates an array of the enumerable property names of the array-like `value`.
   *
   * @private
   * @param {*} value The value to query.
   * @param {boolean} inherited Specify returning inherited property names.
   * @returns {Array} Returns the array of property names.
   */
  function arrayLikeKeys(value, inherited) {
    var isArr = isArray(value),
        isArg = !isArr && isArguments(value),
        isBuff = !isArr && !isArg && isBuffer(value),
        isType = !isArr && !isArg && !isBuff && isTypedArray(value),
        skipIndexes = isArr || isArg || isBuff || isType,
        result = skipIndexes ? baseTimes(value.length, String) : [],
        length = result.length;
  
    for (var key in value) {
      if ((inherited || hasOwnProperty.call(value, key)) &&
          !(skipIndexes && (
             // Safari 9 has enumerable `arguments.length` in strict mode.
             key == 'length' ||
             // Node.js 0.10 has enumerable non-index properties on buffers.
             (isBuff && (key == 'offset' || key == 'parent')) ||
             // PhantomJS 2 has enumerable non-index properties on typed arrays.
             (isType && (key == 'buffer' || key == 'byteLength' || key == 'byteOffset')) ||
             // Skip index properties.
             isIndex(key, length)
          ))) {
        result.push(key);
      }
    }
    return result;
  }
  
  /**
   * Gets the index at which the `key` is found in `array` of key-value pairs.
   *
   * @private
   * @param {Array} array The array to inspect.
   * @param {*} key The key to search for.
   * @returns {number} Returns the index of the matched value, else `-1`.
   */
  function assocIndexOf(array, key) {
    var length = array.length;
    while (length--) {
      if (eq(array[length][0], key)) {
        return length;
      }
    }
    return -1;
  }
  
  /**
   * The base implementation of `getAllKeys` and `getAllKeysIn` which uses
   * `keysFunc` and `symbolsFunc` to get the enumerable property names and
   * symbols of `object`.
   *
   * @private
   * @param {Object} object The object to query.
   * @param {Function} keysFunc The function to get the keys of `object`.
   * @param {Function} symbolsFunc The function to get the symbols of `object`.
   * @returns {Array} Returns the array of property names and symbols.
   */
  function baseGetAllKeys(object, keysFunc, symbolsFunc) {
    var result = keysFunc(object);
    return isArray(object) ? result : arrayPush(result, symbolsFunc(object));
  }
  
  /**
   * The base implementation of `getTag` without fallbacks for buggy environments.
   *
   * @private
   * @param {*} value The value to query.
   * @returns {string} Returns the `toStringTag`.
   */
  function baseGetTag(value) {
    if (value == null) {
      return value === undefined ? undefinedTag : nullTag;
    }
    return (symToStringTag && symToStringTag in Object(value))
      ? getRawTag(value)
      : objectToString(value);
  }
  
  /**
   * The base implementation of `_.isArguments`.
   *
   * @private
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is an `arguments` object,
   */
  function baseIsArguments(value) {
    return isObjectLike(value) && baseGetTag(value) == argsTag;
  }
  
  /**
   * The base implementation of `_.isEqual` which supports partial comparisons
   * and tracks traversed objects.
   *
   * @private
   * @param {*} value The value to compare.
   * @param {*} other The other value to compare.
   * @param {boolean} bitmask The bitmask flags.
   *  1 - Unordered comparison
   *  2 - Partial comparison
   * @param {Function} [customizer] The function to customize comparisons.
   * @param {Object} [stack] Tracks traversed `value` and `other` objects.
   * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
   */
  function baseIsEqual(value, other, bitmask, customizer, stack) {
    if (value === other) {
      return true;
    }
    if (value == null || other == null || (!isObjectLike(value) && !isObjectLike(other))) {
      return value !== value && other !== other;
    }
    return baseIsEqualDeep(value, other, bitmask, customizer, baseIsEqual, stack);
  }
  
  /**
   * A specialized version of `baseIsEqual` for arrays and objects which performs
   * deep comparisons and tracks traversed objects enabling objects with circular
   * references to be compared.
   *
   * @private
   * @param {Object} object The object to compare.
   * @param {Object} other The other object to compare.
   * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
   * @param {Function} customizer The function to customize comparisons.
   * @param {Function} equalFunc The function to determine equivalents of values.
   * @param {Object} [stack] Tracks traversed `object` and `other` objects.
   * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
   */
  function baseIsEqualDeep(object, other, bitmask, customizer, equalFunc, stack) {
    var objIsArr = isArray(object),
        othIsArr = isArray(other),
        objTag = objIsArr ? arrayTag : getTag(object),
        othTag = othIsArr ? arrayTag : getTag(other);
  
    objTag = objTag == argsTag ? objectTag : objTag;
    othTag = othTag == argsTag ? objectTag : othTag;
  
    var objIsObj = objTag == objectTag,
        othIsObj = othTag == objectTag,
        isSameTag = objTag == othTag;
  
    if (isSameTag && isBuffer(object)) {
      if (!isBuffer(other)) {
        return false;
      }
      objIsArr = true;
      objIsObj = false;
    }
    if (isSameTag && !objIsObj) {
      stack || (stack = new Stack);
      return (objIsArr || isTypedArray(object))
        ? equalArrays(object, other, bitmask, customizer, equalFunc, stack)
        : equalByTag(object, other, objTag, bitmask, customizer, equalFunc, stack);
    }
    if (!(bitmask & COMPARE_PARTIAL_FLAG)) {
      var objIsWrapped = objIsObj && hasOwnProperty.call(object, '__wrapped__'),
          othIsWrapped = othIsObj && hasOwnProperty.call(other, '__wrapped__');
  
      if (objIsWrapped || othIsWrapped) {
        var objUnwrapped = objIsWrapped ? object.value() : object,
            othUnwrapped = othIsWrapped ? other.value() : other;
  
        stack || (stack = new Stack);
        return equalFunc(objUnwrapped, othUnwrapped, bitmask, customizer, stack);
      }
    }
    if (!isSameTag) {
      return false;
    }
    stack || (stack = new Stack);
    return equalObjects(object, other, bitmask, customizer, equalFunc, stack);
  }
  
  /**
   * The base implementation of `_.isNative` without bad shim checks.
   *
   * @private
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a native function,
   *  else `false`.
   */
  function baseIsNative(value) {
    if (!isObject(value) || isMasked(value)) {
      return false;
    }
    var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
    return pattern.test(toSource(value));
  }
  
  /**
   * The base implementation of `_.isTypedArray` without Node.js optimizations.
   *
   * @private
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
   */
  function baseIsTypedArray(value) {
    return isObjectLike(value) &&
      isLength(value.length) && !!typedArrayTags[baseGetTag(value)];
  }
  
  /**
   * The base implementation of `_.keys` which doesn't treat sparse arrays as dense.
   *
   * @private
   * @param {Object} object The object to query.
   * @returns {Array} Returns the array of property names.
   */
  function baseKeys(object) {
    if (!isPrototype(object)) {
      return nativeKeys(object);
    }
    var result = [];
    for (var key in Object(object)) {
      if (hasOwnProperty.call(object, key) && key != 'constructor') {
        result.push(key);
      }
    }
    return result;
  }
  
  /**
   * A specialized version of `baseIsEqualDeep` for arrays with support for
   * partial deep comparisons.
   *
   * @private
   * @param {Array} array The array to compare.
   * @param {Array} other The other array to compare.
   * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
   * @param {Function} customizer The function to customize comparisons.
   * @param {Function} equalFunc The function to determine equivalents of values.
   * @param {Object} stack Tracks traversed `array` and `other` objects.
   * @returns {boolean} Returns `true` if the arrays are equivalent, else `false`.
   */
  function equalArrays(array, other, bitmask, customizer, equalFunc, stack) {
    var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
        arrLength = array.length,
        othLength = other.length;
  
    if (arrLength != othLength && !(isPartial && othLength > arrLength)) {
      return false;
    }
    // Assume cyclic values are equal.
    var stacked = stack.get(array);
    if (stacked && stack.get(other)) {
      return stacked == other;
    }
    var index = -1,
        result = true,
        seen = (bitmask & COMPARE_UNORDERED_FLAG) ? new SetCache : undefined;
  
    stack.set(array, other);
    stack.set(other, array);
  
    // Ignore non-index properties.
    while (++index < arrLength) {
      var arrValue = array[index],
          othValue = other[index];
  
      if (customizer) {
        var compared = isPartial
          ? customizer(othValue, arrValue, index, other, array, stack)
          : customizer(arrValue, othValue, index, array, other, stack);
      }
      if (compared !== undefined) {
        if (compared) {
          continue;
        }
        result = false;
        break;
      }
      // Recursively compare arrays (susceptible to call stack limits).
      if (seen) {
        if (!arraySome(other, function(othValue, othIndex) {
              if (!cacheHas(seen, othIndex) &&
                  (arrValue === othValue || equalFunc(arrValue, othValue, bitmask, customizer, stack))) {
                return seen.push(othIndex);
              }
            })) {
          result = false;
          break;
        }
      } else if (!(
            arrValue === othValue ||
              equalFunc(arrValue, othValue, bitmask, customizer, stack)
          )) {
        result = false;
        break;
      }
    }
    stack['delete'](array);
    stack['delete'](other);
    return result;
  }
  
  /**
   * A specialized version of `baseIsEqualDeep` for comparing objects of
   * the same `toStringTag`.
   *
   * **Note:** This function only supports comparing values with tags of
   * `Boolean`, `Date`, `Error`, `Number`, `RegExp`, or `String`.
   *
   * @private
   * @param {Object} object The object to compare.
   * @param {Object} other The other object to compare.
   * @param {string} tag The `toStringTag` of the objects to compare.
   * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
   * @param {Function} customizer The function to customize comparisons.
   * @param {Function} equalFunc The function to determine equivalents of values.
   * @param {Object} stack Tracks traversed `object` and `other` objects.
   * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
   */
  function equalByTag(object, other, tag, bitmask, customizer, equalFunc, stack) {
    switch (tag) {
      case dataViewTag:
        if ((object.byteLength != other.byteLength) ||
            (object.byteOffset != other.byteOffset)) {
          return false;
        }
        object = object.buffer;
        other = other.buffer;
  
      case arrayBufferTag:
        if ((object.byteLength != other.byteLength) ||
            !equalFunc(new Uint8Array(object), new Uint8Array(other))) {
          return false;
        }
        return true;
  
      case boolTag:
      case dateTag:
      case numberTag:
        // Coerce booleans to `1` or `0` and dates to milliseconds.
        // Invalid dates are coerced to `NaN`.
        return eq(+object, +other);
  
      case errorTag:
        return object.name == other.name && object.message == other.message;
  
      case regexpTag:
      case stringTag:
        // Coerce regexes to strings and treat strings, primitives and objects,
        // as equal. See http://www.ecma-international.org/ecma-262/7.0/#sec-regexp.prototype.tostring
        // for more details.
        return object == (other + '');
  
      case mapTag:
        var convert = mapToArray;
  
      case setTag:
        var isPartial = bitmask & COMPARE_PARTIAL_FLAG;
        convert || (convert = setToArray);
  
        if (object.size != other.size && !isPartial) {
          return false;
        }
        // Assume cyclic values are equal.
        var stacked = stack.get(object);
        if (stacked) {
          return stacked == other;
        }
        bitmask |= COMPARE_UNORDERED_FLAG;
  
        // Recursively compare objects (susceptible to call stack limits).
        stack.set(object, other);
        var result = equalArrays(convert(object), convert(other), bitmask, customizer, equalFunc, stack);
        stack['delete'](object);
        return result;
  
      case symbolTag:
        if (symbolValueOf) {
          return symbolValueOf.call(object) == symbolValueOf.call(other);
        }
    }
    return false;
  }
  
  /**
   * A specialized version of `baseIsEqualDeep` for objects with support for
   * partial deep comparisons.
   *
   * @private
   * @param {Object} object The object to compare.
   * @param {Object} other The other object to compare.
   * @param {number} bitmask The bitmask flags. See `baseIsEqual` for more details.
   * @param {Function} customizer The function to customize comparisons.
   * @param {Function} equalFunc The function to determine equivalents of values.
   * @param {Object} stack Tracks traversed `object` and `other` objects.
   * @returns {boolean} Returns `true` if the objects are equivalent, else `false`.
   */
  function equalObjects(object, other, bitmask, customizer, equalFunc, stack) {
    var isPartial = bitmask & COMPARE_PARTIAL_FLAG,
        objProps = getAllKeys(object),
        objLength = objProps.length,
        othProps = getAllKeys(other),
        othLength = othProps.length;
  
    if (objLength != othLength && !isPartial) {
      return false;
    }
    var index = objLength;
    while (index--) {
      var key = objProps[index];
      if (!(isPartial ? key in other : hasOwnProperty.call(other, key))) {
        return false;
      }
    }
    // Assume cyclic values are equal.
    var stacked = stack.get(object);
    if (stacked && stack.get(other)) {
      return stacked == other;
    }
    var result = true;
    stack.set(object, other);
    stack.set(other, object);
  
    var skipCtor = isPartial;
    while (++index < objLength) {
      key = objProps[index];
      var objValue = object[key],
          othValue = other[key];
  
      if (customizer) {
        var compared = isPartial
          ? customizer(othValue, objValue, key, other, object, stack)
          : customizer(objValue, othValue, key, object, other, stack);
      }
      // Recursively compare objects (susceptible to call stack limits).
      if (!(compared === undefined
            ? (objValue === othValue || equalFunc(objValue, othValue, bitmask, customizer, stack))
            : compared
          )) {
        result = false;
        break;
      }
      skipCtor || (skipCtor = key == 'constructor');
    }
    if (result && !skipCtor) {
      var objCtor = object.constructor,
          othCtor = other.constructor;
  
      // Non `Object` object instances with different constructors are not equal.
      if (objCtor != othCtor &&
          ('constructor' in object && 'constructor' in other) &&
          !(typeof objCtor == 'function' && objCtor instanceof objCtor &&
            typeof othCtor == 'function' && othCtor instanceof othCtor)) {
        result = false;
      }
    }
    stack['delete'](object);
    stack['delete'](other);
    return result;
  }
  
  /**
   * Creates an array of own enumerable property names and symbols of `object`.
   *
   * @private
   * @param {Object} object The object to query.
   * @returns {Array} Returns the array of property names and symbols.
   */
  function getAllKeys(object) {
    return baseGetAllKeys(object, keys, getSymbols);
  }
  
  /**
   * Gets the data for `map`.
   *
   * @private
   * @param {Object} map The map to query.
   * @param {string} key The reference key.
   * @returns {*} Returns the map data.
   */
  function getMapData(map, key) {
    var data = map.__data__;
    return isKeyable(key)
      ? data[typeof key == 'string' ? 'string' : 'hash']
      : data.map;
  }
  
  /**
   * Gets the native function at `key` of `object`.
   *
   * @private
   * @param {Object} object The object to query.
   * @param {string} key The key of the method to get.
   * @returns {*} Returns the function if it's native, else `undefined`.
   */
  function getNative(object, key) {
    var value = getValue(object, key);
    return baseIsNative(value) ? value : undefined;
  }
  
  /**
   * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
   *
   * @private
   * @param {*} value The value to query.
   * @returns {string} Returns the raw `toStringTag`.
   */
  function getRawTag(value) {
    var isOwn = hasOwnProperty.call(value, symToStringTag),
        tag = value[symToStringTag];
  
    try {
      value[symToStringTag] = undefined;
      var unmasked = true;
    } catch (e) {}
  
    var result = nativeObjectToString.call(value);
    if (unmasked) {
      if (isOwn) {
        value[symToStringTag] = tag;
      } else {
        delete value[symToStringTag];
      }
    }
    return result;
  }
  
  /**
   * Creates an array of the own enumerable symbols of `object`.
   *
   * @private
   * @param {Object} object The object to query.
   * @returns {Array} Returns the array of symbols.
   */
  var getSymbols = !nativeGetSymbols ? stubArray : function(object) {
    if (object == null) {
      return [];
    }
    object = Object(object);
    return arrayFilter(nativeGetSymbols(object), function(symbol) {
      return propertyIsEnumerable.call(object, symbol);
    });
  };
  
  /**
   * Gets the `toStringTag` of `value`.
   *
   * @private
   * @param {*} value The value to query.
   * @returns {string} Returns the `toStringTag`.
   */
  var getTag = baseGetTag;
  
  // Fallback for data views, maps, sets, and weak maps in IE 11 and promises in Node.js < 6.
  if ((DataView && getTag(new DataView(new ArrayBuffer(1))) != dataViewTag) ||
      (Map && getTag(new Map) != mapTag) ||
      (Promise && getTag(Promise.resolve()) != promiseTag) ||
      (Set && getTag(new Set) != setTag) ||
      (WeakMap && getTag(new WeakMap) != weakMapTag)) {
    getTag = function(value) {
      var result = baseGetTag(value),
          Ctor = result == objectTag ? value.constructor : undefined,
          ctorString = Ctor ? toSource(Ctor) : '';
  
      if (ctorString) {
        switch (ctorString) {
          case dataViewCtorString: return dataViewTag;
          case mapCtorString: return mapTag;
          case promiseCtorString: return promiseTag;
          case setCtorString: return setTag;
          case weakMapCtorString: return weakMapTag;
        }
      }
      return result;
    };
  }
  
  /**
   * Checks if `value` is a valid array-like index.
   *
   * @private
   * @param {*} value The value to check.
   * @param {number} [length=MAX_SAFE_INTEGER] The upper bounds of a valid index.
   * @returns {boolean} Returns `true` if `value` is a valid index, else `false`.
   */
  function isIndex(value, length) {
    length = length == null ? MAX_SAFE_INTEGER : length;
    return !!length &&
      (typeof value == 'number' || reIsUint.test(value)) &&
      (value > -1 && value % 1 == 0 && value < length);
  }
  
  /**
   * Checks if `value` is suitable for use as unique object key.
   *
   * @private
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
   */
  function isKeyable(value) {
    var type = typeof value;
    return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
      ? (value !== '__proto__')
      : (value === null);
  }
  
  /**
   * Checks if `func` has its source masked.
   *
   * @private
   * @param {Function} func The function to check.
   * @returns {boolean} Returns `true` if `func` is masked, else `false`.
   */
  function isMasked(func) {
    return !!maskSrcKey && (maskSrcKey in func);
  }
  
  /**
   * Checks if `value` is likely a prototype object.
   *
   * @private
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a prototype, else `false`.
   */
  function isPrototype(value) {
    var Ctor = value && value.constructor,
        proto = (typeof Ctor == 'function' && Ctor.prototype) || objectProto;
  
    return value === proto;
  }
  
  /**
   * Converts `value` to a string using `Object.prototype.toString`.
   *
   * @private
   * @param {*} value The value to convert.
   * @returns {string} Returns the converted string.
   */
  function objectToString(value) {
    return nativeObjectToString.call(value);
  }
  
  /**
   * Converts `func` to its source code.
   *
   * @private
   * @param {Function} func The function to convert.
   * @returns {string} Returns the source code.
   */
  function toSource(func) {
    if (func != null) {
      try {
        return funcToString.call(func);
      } catch (e) {}
      try {
        return (func + '');
      } catch (e) {}
    }
    return '';
  }
  
  /**
   * Performs a
   * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
   * comparison between two values to determine if they are equivalent.
   *
   * @static
   * @memberOf _
   * @since 4.0.0
   * @category Lang
   * @param {*} value The value to compare.
   * @param {*} other The other value to compare.
   * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
   * @example
   *
   * var object = { 'a': 1 };
   * var other = { 'a': 1 };
   *
   * _.eq(object, object);
   * // => true
   *
   * _.eq(object, other);
   * // => false
   *
   * _.eq('a', 'a');
   * // => true
   *
   * _.eq('a', Object('a'));
   * // => false
   *
   * _.eq(NaN, NaN);
   * // => true
   */
  function eq(value, other) {
    return value === other || (value !== value && other !== other);
  }
  
  /**
   * Checks if `value` is likely an `arguments` object.
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is an `arguments` object,
   *  else `false`.
   * @example
   *
   * _.isArguments(function() { return arguments; }());
   * // => true
   *
   * _.isArguments([1, 2, 3]);
   * // => false
   */
  var isArguments = baseIsArguments(function() { return arguments; }()) ? baseIsArguments : function(value) {
    return isObjectLike(value) && hasOwnProperty.call(value, 'callee') &&
      !propertyIsEnumerable.call(value, 'callee');
  };
  
  /**
   * Checks if `value` is classified as an `Array` object.
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is an array, else `false`.
   * @example
   *
   * _.isArray([1, 2, 3]);
   * // => true
   *
   * _.isArray(document.body.children);
   * // => false
   *
   * _.isArray('abc');
   * // => false
   *
   * _.isArray(_.noop);
   * // => false
   */
  var isArray = Array.isArray;
  
  /**
   * Checks if `value` is array-like. A value is considered array-like if it's
   * not a function and has a `value.length` that's an integer greater than or
   * equal to `0` and less than or equal to `Number.MAX_SAFE_INTEGER`.
   *
   * @static
   * @memberOf _
   * @since 4.0.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is array-like, else `false`.
   * @example
   *
   * _.isArrayLike([1, 2, 3]);
   * // => true
   *
   * _.isArrayLike(document.body.children);
   * // => true
   *
   * _.isArrayLike('abc');
   * // => true
   *
   * _.isArrayLike(_.noop);
   * // => false
   */
  function isArrayLike(value) {
    return value != null && isLength(value.length) && !isFunction(value);
  }
  
  /**
   * Checks if `value` is a buffer.
   *
   * @static
   * @memberOf _
   * @since 4.3.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a buffer, else `false`.
   * @example
   *
   * _.isBuffer(new Buffer(2));
   * // => true
   *
   * _.isBuffer(new Uint8Array(2));
   * // => false
   */
  var isBuffer = nativeIsBuffer || stubFalse;
  
  /**
   * Performs a deep comparison between two values to determine if they are
   * equivalent.
   *
   * **Note:** This method supports comparing arrays, array buffers, booleans,
   * date objects, error objects, maps, numbers, `Object` objects, regexes,
   * sets, strings, symbols, and typed arrays. `Object` objects are compared
   * by their own, not inherited, enumerable properties. Functions and DOM
   * nodes are compared by strict equality, i.e. `===`.
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Lang
   * @param {*} value The value to compare.
   * @param {*} other The other value to compare.
   * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
   * @example
   *
   * var object = { 'a': 1 };
   * var other = { 'a': 1 };
   *
   * _.isEqual(object, other);
   * // => true
   *
   * object === other;
   * // => false
   */
  function isEqual(value, other) {
    return baseIsEqual(value, other);
  }
  
  /**
   * Checks if `value` is classified as a `Function` object.
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a function, else `false`.
   * @example
   *
   * _.isFunction(_);
   * // => true
   *
   * _.isFunction(/abc/);
   * // => false
   */
  function isFunction(value) {
    if (!isObject(value)) {
      return false;
    }
    // The use of `Object#toString` avoids issues with the `typeof` operator
    // in Safari 9 which returns 'object' for typed arrays and other constructors.
    var tag = baseGetTag(value);
    return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
  }
  
  /**
   * Checks if `value` is a valid array-like length.
   *
   * **Note:** This method is loosely based on
   * [`ToLength`](http://ecma-international.org/ecma-262/7.0/#sec-tolength).
   *
   * @static
   * @memberOf _
   * @since 4.0.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a valid length, else `false`.
   * @example
   *
   * _.isLength(3);
   * // => true
   *
   * _.isLength(Number.MIN_VALUE);
   * // => false
   *
   * _.isLength(Infinity);
   * // => false
   *
   * _.isLength('3');
   * // => false
   */
  function isLength(value) {
    return typeof value == 'number' &&
      value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
  }
  
  /**
   * Checks if `value` is the
   * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
   * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
   *
   * @static
   * @memberOf _
   * @since 0.1.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is an object, else `false`.
   * @example
   *
   * _.isObject({});
   * // => true
   *
   * _.isObject([1, 2, 3]);
   * // => true
   *
   * _.isObject(_.noop);
   * // => true
   *
   * _.isObject(null);
   * // => false
   */
  function isObject(value) {
    var type = typeof value;
    return value != null && (type == 'object' || type == 'function');
  }
  
  /**
   * Checks if `value` is object-like. A value is object-like if it's not `null`
   * and has a `typeof` result of "object".
   *
   * @static
   * @memberOf _
   * @since 4.0.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
   * @example
   *
   * _.isObjectLike({});
   * // => true
   *
   * _.isObjectLike([1, 2, 3]);
   * // => true
   *
   * _.isObjectLike(_.noop);
   * // => false
   *
   * _.isObjectLike(null);
   * // => false
   */
  function isObjectLike(value) {
    return value != null && typeof value == 'object';
  }
  
  /**
   * Checks if `value` is classified as a typed array.
   *
   * @static
   * @memberOf _
   * @since 3.0.0
   * @category Lang
   * @param {*} value The value to check.
   * @returns {boolean} Returns `true` if `value` is a typed array, else `false`.
   * @example
   *
   * _.isTypedArray(new Uint8Array);
   * // => true
   *
   * _.isTypedArray([]);
   * // => false
   */
  var isTypedArray = nodeIsTypedArray ? baseUnary(nodeIsTypedArray) : baseIsTypedArray;
  
  /**
   * Creates an array of the own enumerable property names of `object`.
   *
   * **Note:** Non-object values are coerced to objects. See the
   * [ES spec](http://ecma-international.org/ecma-262/7.0/#sec-object.keys)
   * for more details.
   *
   * @static
   * @since 0.1.0
   * @memberOf _
   * @category Object
   * @param {Object} object The object to query.
   * @returns {Array} Returns the array of property names.
   * @example
   *
   * function Foo() {
   *   this.a = 1;
   *   this.b = 2;
   * }
   *
   * Foo.prototype.c = 3;
   *
   * _.keys(new Foo);
   * // => ['a', 'b'] (iteration order is not guaranteed)
   *
   * _.keys('hi');
   * // => ['0', '1']
   */
  function keys(object) {
    return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
  }
  
  /**
   * This method returns a new empty array.
   *
   * @static
   * @memberOf _
   * @since 4.13.0
   * @category Util
   * @returns {Array} Returns the new empty array.
   * @example
   *
   * var arrays = _.times(2, _.stubArray);
   *
   * console.log(arrays);
   * // => [[], []]
   *
   * console.log(arrays[0] === arrays[1]);
   * // => false
   */
  function stubArray() {
    return [];
  }
  
  /**
   * This method returns `false`.
   *
   * @static
   * @memberOf _
   * @since 4.13.0
   * @category Util
   * @returns {boolean} Returns `false`.
   * @example
   *
   * _.times(2, _.stubFalse);
   * // => [false, false]
   */
  function stubFalse() {
    return false;
  }
  
  module.exports = isEqual;
  
  }).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{}],122:[function(require,module,exports){
  "use strict";
  
  var format = require("format-util");
  var slice = Array.prototype.slice;
  var protectedProperties = ["name", "message", "stack"];
  var errorPrototypeProperties = [
    "name", "message", "description", "number", "code", "fileName", "lineNumber", "columnNumber",
    "sourceURL", "line", "column", "stack"
  ];
  
  module.exports = create(Error);
  module.exports.error = create(Error);
  module.exports.eval = create(EvalError);
  module.exports.range = create(RangeError);
  module.exports.reference = create(ReferenceError);
  module.exports.syntax = create(SyntaxError);
  module.exports.type = create(TypeError);
  module.exports.uri = create(URIError);
  module.exports.formatter = format;
  
  /**
   * Creates a new {@link ono} function that creates the given Error class.
   *
   * @param {Class} Klass - The Error subclass to create
   * @returns {ono}
   */
  function create (Klass) {
    /**
     * @param {Error}   [err]     - The original error, if any
     * @param {object}  [props]   - An object whose properties will be added to the error object
     * @param {string}  [message] - The error message. May contain {@link util#format} placeholders
     * @param {...*}    [params]  - Parameters that map to the `message` placeholders
     * @returns {Error}
     */
    return function onoFactory (err, props, message, params) {   // eslint-disable-line no-unused-vars
      var formatArgs = [];
      var formattedMessage = "";
  
      // Determine which arguments were actually specified
      if (typeof err === "string") {
        formatArgs = slice.call(arguments);
        err = props = undefined;
      }
      else if (typeof props === "string") {
        formatArgs = slice.call(arguments, 1);
        props = undefined;
      }
      else if (typeof message === "string") {
        formatArgs = slice.call(arguments, 2);
      }
  
      // If there are any format arguments, then format the error message
      if (formatArgs.length > 0) {
        formattedMessage = module.exports.formatter.apply(null, formatArgs);
      }
  
      if (err && err.message) {
        // The inner-error's message will be added to the new message
        formattedMessage += (formattedMessage ? " \n" : "") + err.message;
      }
  
      // Create the new error
      // NOTE: DON'T move this to a separate function! We don't want to pollute the stack trace
      var newError = new Klass(formattedMessage);
  
      // Extend the new error with the additional properties
      extendError(newError, err);   // Copy properties of the original error
      extendToJSON(newError);       // Replace the original toJSON method
      extend(newError, props);      // Copy custom properties, possibly including a custom toJSON method
  
      return newError;
    };
  }
  
  /**
   * Extends the targetError with the properties of the source error.
   *
   * @param {Error}   targetError - The error object to extend
   * @param {?Error}  sourceError - The source error object, if any
   */
  function extendError (targetError, sourceError) {
    extendStack(targetError, sourceError);
    extend(targetError, sourceError);
  }
  
  /**
   * JavaScript engines differ in how errors are serialized to JSON - especially when it comes
   * to custom error properties and stack traces.  So we add our own toJSON method that ALWAYS
   * outputs every property of the error.
   */
  function extendToJSON (error) {
    error.toJSON = errorToJSON;
  
    // Also add an inspect() method, for compatibility with Node.js' `util.inspect()` method
    error.inspect = errorToString;
  }
  
  /**
   * Extends the target object with the properties of the source object.
   *
   * @param {object}  target - The object to extend
   * @param {?source} source - The object whose properties are copied
   */
  function extend (target, source) {
    if (source && typeof source === "object") {
      var keys = Object.keys(source);
      for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
  
        // Don't copy "protected" properties, since they have special meaning/behavior
        // and are set by the onoFactory function
        if (protectedProperties.indexOf(key) >= 0) {
          continue;
        }
  
        try {
          target[key] = source[key];
        }
        catch (e) {
          // This property is read-only, so it can't be copied
        }
      }
    }
  }
  
  /**
   * Custom JSON serializer for Error objects.
   * Returns all built-in error properties, as well as extended properties.
   *
   * @returns {object}
   */
  function errorToJSON () {
    var json = {};
  
    // Get all the properties of this error
    var keys = Object.keys(this);
  
    // Also include properties from the Error prototype
    keys = keys.concat(errorPrototypeProperties);
  
    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      var value = this[key];
      var type = typeof value;
      if (type !== "undefined" && type !== "function") {
        json[key] = value;
      }
    }
  
    return json;
  }
  
  /**
   * Serializes Error objects as human-readable JSON strings for debugging/logging purposes.
   *
   * @returns {string}
   */
  function errorToString () {
    return JSON.stringify(this, null, 2).replace(/\\n/g, "\n");
  }
  
  /**
   * Extend the error stack to include its cause
   *
   * @param {Error} targetError
   * @param {Error} sourceError
   */
  function extendStack (targetError, sourceError) {
    if (hasLazyStack(targetError)) {
      if (sourceError) {
        lazyJoinStacks(targetError, sourceError);
      }
      else {
        lazyPopStack(targetError);
      }
    }
    else {
      if (sourceError) {
        targetError.stack = joinStacks(targetError.stack, sourceError.stack);
      }
      else {
        targetError.stack = popStack(targetError.stack);
      }
    }
  }
  
  /**
   * Appends the original {@link Error#stack} property to the new Error's stack.
   *
   * @param {string} newStack
   * @param {string} originalStack
   * @returns {string}
   */
  function joinStacks (newStack, originalStack) {
    newStack = popStack(newStack);
  
    if (newStack && originalStack) {
      return newStack + "\n\n" + originalStack;
    }
    else {
      return newStack || originalStack;
    }
  }
  
  /**
   * Removes Ono from the stack, so that the stack starts at the original error location
   *
   * @param {string} stack
   * @returns {string}
   */
  function popStack (stack) {
    if (stack) {
      var lines = stack.split("\n");
  
      if (lines.length < 2) {
        // The stack only has one line, so there's nothing we can remove
        return stack;
      }
  
      // Find the `onoFactory` call in the stack, and remove it
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i];
        if (line.indexOf("onoFactory") >= 0) {
          lines.splice(i, 1);
          return lines.join("\n");
        }
      }
  
      // If we get here, then the stack doesn't contain a call to `onoFactory`.
      // This may be due to minification or some optimization of the JS engine.
      // So just return the stack as-is.
      return stack;
    }
  }
  
  /**
   * Does a one-time determination of whether this JavaScript engine
   * supports lazy `Error.stack` properties.
   */
  var supportsLazyStack = (function () {
    return !!(
      // ES5 property descriptors must be supported
      Object.getOwnPropertyDescriptor && Object.defineProperty &&
  
      // Chrome on Android doesn't support lazy stacks :(
      (typeof navigator === "undefined" || !/Android/.test(navigator.userAgent))
    );
  }());
  
  /**
   * Does this error have a lazy stack property?
   *
   * @param {Error} err
   * @returns {boolean}
   */
  function hasLazyStack (err) {
    if (!supportsLazyStack) {
      return false;
    }
  
    var descriptor = Object.getOwnPropertyDescriptor(err, "stack");
    if (!descriptor) {
      return false;
    }
    return typeof descriptor.get === "function";
  }
  
  /**
   * Calls {@link joinStacks} lazily, when the {@link Error#stack} property is accessed.
   *
   * @param {Error} targetError
   * @param {Error} sourceError
   */
  function lazyJoinStacks (targetError, sourceError) {
    var targetStack = Object.getOwnPropertyDescriptor(targetError, "stack");
  
    Object.defineProperty(targetError, "stack", {
      get: function () {
        return joinStacks(targetStack.get.apply(targetError), sourceError.stack);
      },
      enumerable: false,
      configurable: true
    });
  }
  
  /**
   * Calls {@link popStack} lazily, when the {@link Error#stack} property is accessed.
   *
   * @param {Error} error
   */
  function lazyPopStack (error) {
    var targetStack = Object.getOwnPropertyDescriptor(error, "stack");
  
    Object.defineProperty(error, "stack", {
      get: function () {
        return popStack(targetStack.get.apply(error));
      },
      enumerable: false,
      configurable: true
    });
  }
  
  },{"format-util":65}],123:[function(require,module,exports){
  module.exports={
    "title": "A JSON Schema for OpenAPI 3.0.",
    "id": "http://openapis.org/v3/schema.json#",
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "description": "This is the root document object of the OpenAPI document.",
    "required": [
      "openapi",
      "info",
      "paths"
    ],
    "additionalProperties": false,
    "patternProperties": {
      "^x-": {
        "$ref": "#/definitions/specificationExtension"
      }
    },
    "properties": {
      "openapi": {
        "type": "string"
      },
      "info": {
        "$ref": "#/definitions/info"
      },
      "servers": {
        "type": "array",
        "items": {
          "$ref": "#/definitions/server"
        },
        "uniqueItems": true
      },
      "paths": {
        "$ref": "#/definitions/paths"
      },
      "components": {
        "$ref": "#/definitions/components"
      },
      "security": {
        "type": "array",
        "items": {
          "$ref": "#/definitions/securityRequirement"
        },
        "uniqueItems": true
      },
      "tags": {
        "type": "array",
        "items": {
          "$ref": "#/definitions/tag"
        },
        "uniqueItems": true
      },
      "externalDocs": {
        "$ref": "#/definitions/externalDocs"
      }
    },
    "definitions": {
      "info": {
        "type": "object",
        "description": "The object provides metadata about the API. The metadata MAY be used by the clients if needed, and MAY be presented in editing or documentation generation tools for convenience.",
        "required": [
          "title",
          "version"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "title": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "termsOfService": {
            "type": "string"
          },
          "contact": {
            "$ref": "#/definitions/contact"
          },
          "license": {
            "$ref": "#/definitions/license"
          },
          "version": {
            "type": "string"
          }
        }
      },
      "contact": {
        "type": "object",
        "description": "Contact information for the exposed API.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "name": {
            "type": "string"
          },
          "url": {
            "type": "string"
          },
          "email": {
            "type": "string"
          }
        }
      },
      "license": {
        "type": "object",
        "description": "License information for the exposed API.",
        "required": [
          "name"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "name": {
            "type": "string"
          },
          "url": {
            "type": "string"
          }
        }
      },
      "server": {
        "type": "object",
        "description": "An object representing a Server.",
        "required": [
          "url"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "url": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "variables": {
            "$ref": "#/definitions/serverVariables"
          }
        }
      },
      "serverVariable": {
        "type": "object",
        "description": "An object representing a Server Variable for server URL template substitution.",
        "required": [
          "default"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "enum": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "uniqueItems": true
          },
          "default": {
            "type": "string"
          },
          "description": {
            "type": "string"
          }
        }
      },
      "components": {
        "type": "object",
        "description": "Holds a set of reusable objects for different aspects of the OAS. All objects defined within the components object will have no effect on the API unless they are explicitly referenced from properties outside the components object.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "schemas": {
            "$ref": "#/definitions/schemasOrReferences"
          },
          "responses": {
            "$ref": "#/definitions/responsesOrReferences"
          },
          "parameters": {
            "$ref": "#/definitions/parametersOrReferences"
          },
          "examples": {
            "$ref": "#/definitions/examplesOrReferences"
          },
          "requestBodies": {
            "$ref": "#/definitions/requestBodiesOrReferences"
          },
          "headers": {
            "$ref": "#/definitions/headersOrReferences"
          },
          "securitySchemes": {
            "$ref": "#/definitions/securitySchemesOrReferences"
          },
          "links": {
            "$ref": "#/definitions/linksOrReferences"
          },
          "callbacks": {
            "$ref": "#/definitions/callbacksOrReferences"
          }
        }
      },
      "paths": {
        "type": "object",
        "description": "Holds the relative paths to the individual endpoints and their operations. The path is appended to the URL from the `Server Object` in order to construct the full URL.  The Paths MAY be empty, due to ACL constraints.",
        "additionalProperties": false,
        "patternProperties": {
          "^/": {
            "$ref": "#/definitions/pathItem"
          },
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        }
      },
      "pathItem": {
        "type": "object",
        "description": "Describes the operations available on a single path. A Path Item MAY be empty, due to ACL constraints. The path itself is still exposed to the documentation viewer but they will not know which operations and parameters are available.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "$ref": {
            "type": "string"
          },
          "summary": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "get": {
            "$ref": "#/definitions/operation"
          },
          "put": {
            "$ref": "#/definitions/operation"
          },
          "post": {
            "$ref": "#/definitions/operation"
          },
          "delete": {
            "$ref": "#/definitions/operation"
          },
          "options": {
            "$ref": "#/definitions/operation"
          },
          "head": {
            "$ref": "#/definitions/operation"
          },
          "patch": {
            "$ref": "#/definitions/operation"
          },
          "trace": {
            "$ref": "#/definitions/operation"
          },
          "servers": {
            "type": "array",
            "items": {
              "$ref": "#/definitions/server"
            },
            "uniqueItems": true
          },
          "parameters": {
            "type": "array",
            "items": {
              "$ref": "#/definitions/parameterOrReference"
            },
            "uniqueItems": true
          }
        }
      },
      "operation": {
        "type": "object",
        "description": "Describes a single API operation on a path.",
        "required": [
          "responses"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "tags": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "uniqueItems": true
          },
          "summary": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "externalDocs": {
            "$ref": "#/definitions/externalDocs"
          },
          "operationId": {
            "type": "string"
          },
          "parameters": {
            "type": "array",
            "items": {
              "$ref": "#/definitions/parameterOrReference"
            },
            "uniqueItems": true
          },
          "requestBody": {
            "$ref": "#/definitions/requestBodyOrReference"
          },
          "responses": {
            "$ref": "#/definitions/responses"
          },
          "callbacks": {
            "$ref": "#/definitions/callbacksOrReferences"
          },
          "deprecated": {
            "type": "boolean"
          },
          "security": {
            "type": "array",
            "items": {
              "$ref": "#/definitions/securityRequirement"
            },
            "uniqueItems": true
          },
          "servers": {
            "type": "array",
            "items": {
              "$ref": "#/definitions/server"
            },
            "uniqueItems": true
          }
        }
      },
      "externalDocs": {
        "type": "object",
        "description": "Allows referencing an external resource for extended documentation.",
        "required": [
          "url"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "description": {
            "type": "string"
          },
          "url": {
            "type": "string"
          }
        }
      },
      "parameter": {
        "type": "object",
        "description": "Describes a single operation parameter.  A unique parameter is defined by a combination of a name and location.",
        "required": [
          "name",
          "in"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "name": {
            "type": "string"
          },
          "in": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "required": {
            "type": "boolean"
          },
          "deprecated": {
            "type": "boolean"
          },
          "allowEmptyValue": {
            "type": "boolean"
          },
          "style": {
            "type": "string"
          },
          "explode": {
            "type": "boolean"
          },
          "allowReserved": {
            "type": "boolean"
          },
          "schema": {
            "$ref": "#/definitions/schemaOrReference"
          },
          "example": {
            "$ref": "#/definitions/any"
          },
          "examples": {
            "$ref": "#/definitions/examplesOrReferences"
          },
          "content": {
            "$ref": "#/definitions/mediaTypes"
          }
        }
      },
      "requestBody": {
        "type": "object",
        "description": "Describes a single request body.",
        "required": [
          "content"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "description": {
            "type": "string"
          },
          "content": {
            "$ref": "#/definitions/mediaTypes"
          },
          "required": {
            "type": "boolean"
          }
        }
      },
      "mediaType": {
        "type": "object",
        "description": "Each Media Type Object provides schema and examples for the media type identified by its key.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "schema": {
            "$ref": "#/definitions/schemaOrReference"
          },
          "example": {
            "$ref": "#/definitions/any"
          },
          "examples": {
            "$ref": "#/definitions/examplesOrReferences"
          },
          "encoding": {
            "$ref": "#/definitions/encodings"
          }
        }
      },
      "encoding": {
        "type": "object",
        "description": "A single encoding definition applied to a single schema property.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "contentType": {
            "type": "string"
          },
          "headers": {
            "$ref": "#/definitions/headersOrReferences"
          },
          "style": {
            "type": "string"
          },
          "explode": {
            "type": "boolean"
          },
          "allowReserved": {
            "type": "boolean"
          }
        }
      },
      "responses": {
        "type": "object",
        "description": "A container for the expected responses of an operation. The container maps a HTTP response code to the expected response.  The documentation is not necessarily expected to cover all possible HTTP response codes because they may not be known in advance. However, documentation is expected to cover a successful operation response and any known errors.  The `default` MAY be used as a default response object for all HTTP codes  that are not covered individually by the specification.  The `Responses Object` MUST contain at least one response code, and it  SHOULD be the response for a successful operation call.",
        "additionalProperties": false,
        "patternProperties": {
          "^([0-9X]{3})$": {
            "$ref": "#/definitions/responseOrReference"
          },
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "default": {
            "$ref": "#/definitions/responseOrReference"
          }
        }
      },
      "response": {
        "type": "object",
        "description": "Describes a single response from an API Operation, including design-time, static  `links` to operations based on the response.",
        "required": [
          "description"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "description": {
            "type": "string"
          },
          "headers": {
            "$ref": "#/definitions/headersOrReferences"
          },
          "content": {
            "$ref": "#/definitions/mediaTypes"
          },
          "links": {
            "$ref": "#/definitions/linksOrReferences"
          }
        }
      },
      "callback": {
        "type": "object",
        "description": "A map of possible out-of band callbacks related to the parent operation. Each value in the map is a Path Item Object that describes a set of requests that may be initiated by the API provider and the expected responses. The key value used to identify the callback object is an expression, evaluated at runtime, that identifies a URL to use for the callback operation.",
        "additionalProperties": false,
        "patternProperties": {
          "^": {
            "$ref": "#/definitions/pathItem"
          },
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        }
      },
      "example": {
        "type": "object",
        "description": "",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "summary": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "value": {
            "$ref": "#/definitions/any"
          },
          "externalValue": {
            "type": "string"
          }
        }
      },
      "link": {
        "type": "object",
        "description": "The `Link object` represents a possible design-time link for a response. The presence of a link does not guarantee the caller's ability to successfully invoke it, rather it provides a known relationship and traversal mechanism between responses and other operations.  Unlike _dynamic_ links (i.e. links provided **in** the response payload), the OAS linking mechanism does not require link information in the runtime response.  For computing links, and providing instructions to execute them, a runtime expression is used for accessing values in an operation and using them as parameters while invoking the linked operation.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "operationRef": {
            "type": "string"
          },
          "operationId": {
            "type": "string"
          },
          "parameters": {
            "$ref": "#/definitions/anysOrExpressions"
          },
          "requestBody": {
            "$ref": "#/definitions/anyOrExpression"
          },
          "description": {
            "type": "string"
          },
          "server": {
            "$ref": "#/definitions/server"
          }
        }
      },
      "header": {
        "type": "object",
        "description": "The Header Object follows the structure of the Parameter Object with the following changes:  1. `name` MUST NOT be specified, it is given in the corresponding `headers` map. 1. `in` MUST NOT be specified, it is implicitly in `header`. 1. All traits that are affected by the location MUST be applicable to a location of `header` (for example, `style`).",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "description": {
            "type": "string"
          },
          "required": {
            "type": "boolean"
          },
          "deprecated": {
            "type": "boolean"
          },
          "allowEmptyValue": {
            "type": "boolean"
          },
          "style": {
            "type": "string"
          },
          "explode": {
            "type": "boolean"
          },
          "allowReserved": {
            "type": "boolean"
          },
          "schema": {
            "$ref": "#/definitions/schemaOrReference"
          },
          "example": {
            "$ref": "#/definitions/any"
          },
          "examples": {
            "$ref": "#/definitions/examplesOrReferences"
          },
          "content": {
            "$ref": "#/definitions/mediaTypes"
          }
        }
      },
      "tag": {
        "type": "object",
        "description": "Adds metadata to a single tag that is used by the Operation Object. It is not mandatory to have a Tag Object per tag defined in the Operation Object instances.",
        "required": [
          "name"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "name": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "externalDocs": {
            "$ref": "#/definitions/externalDocs"
          }
        }
      },
      "examples": {
        "type": "object",
        "description": "",
        "additionalProperties": false
      },
      "reference": {
        "type": "object",
        "description": "A simple object to allow referencing other components in the specification, internally and externally.  The Reference Object is defined by JSON Reference and follows the same structure, behavior and rules.   For this specification, reference resolution is accomplished as defined by the JSON Reference specification and not by the JSON Schema specification.",
        "required": [
          "$ref"
        ],
        "additionalProperties": false,
        "properties": {
          "$ref": {
            "type": "string"
          }
        }
      },
      "schema": {
        "type": "object",
        "description": "The Schema Object allows the definition of input and output data types. These types can be objects, but also primitives and arrays. This object is an extended subset of the JSON Schema Specification Wright Draft 00.  For more information about the properties, see JSON Schema Core and JSON Schema Validation. Unless stated otherwise, the property definitions follow the JSON Schema.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "nullable": {
            "type": "boolean"
          },
          "discriminator": {
            "$ref": "#/definitions/discriminator"
          },
          "readOnly": {
            "type": "boolean"
          },
          "writeOnly": {
            "type": "boolean"
          },
          "xml": {
            "$ref": "#/definitions/xml"
          },
          "externalDocs": {
            "$ref": "#/definitions/externalDocs"
          },
          "example": {
            "$ref": "#/definitions/any"
          },
          "deprecated": {
            "type": "boolean"
          },
          "title": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/title"
          },
          "multipleOf": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/multipleOf"
          },
          "maximum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/maximum"
          },
          "exclusiveMaximum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/exclusiveMaximum"
          },
          "minimum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/minimum"
          },
          "exclusiveMinimum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/exclusiveMinimum"
          },
          "maxLength": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/maxLength"
          },
          "minLength": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/minLength"
          },
          "pattern": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/pattern"
          },
          "maxItems": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/maxItems"
          },
          "minItems": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/minItems"
          },
          "uniqueItems": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/uniqueItems"
          },
          "maxProperties": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/maxProperties"
          },
          "minProperties": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/minProperties"
          },
          "required": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/required"
          },
          "enum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/enum"
          },
          "type": {
            "type": "string"
          },
          "allOf": {
            "type": "array",
            "items": {
              "$ref": "#/definitions/schemaOrReference"
            },
            "minItems": 1
          },
          "oneOf": {
            "type": "array",
            "items": {
              "$ref": "#/definitions/schemaOrReference"
            },
            "minItems": 1
          },
          "anyOf": {
            "type": "array",
            "items": {
              "$ref": "#/definitions/schemaOrReference"
            },
            "minItems": 1
          },
          "not": {
            "$ref": "#/definitions/schema"
          },
          "items": {
            "anyOf": [
              {
                "$ref": "#/definitions/schemaOrReference"
              },
              {
                "type": "array",
                "items": {
                  "$ref": "#/definitions/schemaOrReference"
                },
                "minItems": 1
              }
            ]
          },
          "properties": {
            "type": "object",
            "additionalProperties": {
              "$ref": "#/definitions/schemaOrReference"
            }
          },
          "additionalProperties": {
            "oneOf": [
              {
                "$ref": "#/definitions/schemaOrReference"
              },
              {
                "type": "boolean"
              }
            ]
          },
          "default": {
            "$ref": "#/definitions/defaultType"
          },
          "description": {
            "type": "string"
          },
          "format": {
            "type": "string"
          }
        }
      },
      "discriminator": {
        "type": "object",
        "description": "When request bodies or response payloads may be one of a number of different schemas, a `discriminator` object can be used to aid in serialization, deserialization, and validation.  The discriminator is a specific object in a schema which is used to inform the consumer of the specification of an alternative schema based on the value associated with it.  When using the discriminator, _inline_ schemas will not be considered.",
        "required": [
          "propertyName"
        ],
        "additionalProperties": false,
        "properties": {
          "propertyName": {
            "type": "string"
          },
          "mapping": {
            "$ref": "#/definitions/strings"
          }
        }
      },
      "xml": {
        "type": "object",
        "description": "A metadata object that allows for more fine-tuned XML model definitions.  When using arrays, XML element names are *not* inferred (for singular/plural forms) and the `name` property SHOULD be used to add that information. See examples for expected behavior.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "name": {
            "type": "string"
          },
          "namespace": {
            "type": "string"
          },
          "prefix": {
            "type": "string"
          },
          "attribute": {
            "type": "boolean"
          },
          "wrapped": {
            "type": "boolean"
          }
        }
      },
      "securityScheme": {
        "type": "object",
        "description": "Defines a security scheme that can be used by the operations. Supported schemes are HTTP authentication, an API key (either as a header or as a query parameter), OAuth2's common flows (implicit, password, application and access code) as defined in RFC6749, and OpenID Connect Discovery.",
        "required": [
          "type"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "type": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "name": {
            "type": "string"
          },
          "in": {
            "type": "string"
          },
          "scheme": {
            "type": "string"
          },
          "bearerFormat": {
            "type": "string"
          },
          "flows": {
            "$ref": "#/definitions/oauthFlows"
          },
          "openIdConnectUrl": {
            "type": "string"
          }
        }
      },
      "oauthFlows": {
        "type": "object",
        "description": "Allows configuration of the supported OAuth Flows.",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "implicit": {
            "$ref": "#/definitions/oauthFlow"
          },
          "password": {
            "$ref": "#/definitions/oauthFlow"
          },
          "clientCredentials": {
            "$ref": "#/definitions/oauthFlow"
          },
          "authorizationCode": {
            "$ref": "#/definitions/oauthFlow"
          }
        }
      },
      "oauthFlow": {
        "type": "object",
        "description": "Configuration details for a supported OAuth Flow",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/specificationExtension"
          }
        },
        "properties": {
          "authorizationUrl": {
            "type": "string"
          },
          "tokenUrl": {
            "type": "string"
          },
          "refreshUrl": {
            "type": "string"
          },
          "scopes": {
            "$ref": "#/definitions/strings"
          }
        }
      },
      "securityRequirement": {
        "type": "object",
        "description": "Lists the required security schemes to execute this operation. The name used for each property MUST correspond to a security scheme declared in the Security Schemes under the Components Object.  Security Requirement Objects that contain multiple schemes require that all schemes MUST be satisfied for a request to be authorized. This enables support for scenarios where multiple query parameters or HTTP headers are required to convey security information.  When a list of Security Requirement Objects is defined on the Open API object or Operation Object, only one of Security Requirement Objects in the list needs to be satisfied to authorize the request.",
        "additionalProperties": false,
        "patternProperties": {
          "^[a-zA-Z0-9\\.\\-_]+$": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "uniqueItems": true
          }
        }
      },
      "anyOrExpression": {
        "oneOf": [
          {
            "$ref": "#/definitions/any"
          },
          {
            "$ref": "#/definitions/expression"
          }
        ]
      },
      "callbackOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/callback"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "exampleOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/example"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "headerOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/header"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "linkOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/link"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "parameterOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/parameter"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "requestBodyOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/requestBody"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "responseOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/response"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "schemaOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/schema"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "securitySchemeOrReference": {
        "oneOf": [
          {
            "$ref": "#/definitions/securityScheme"
          },
          {
            "$ref": "#/definitions/reference"
          }
        ]
      },
      "anysOrExpressions": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/anyOrExpression"
        }
      },
      "callbacksOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/callbackOrReference"
        }
      },
      "encodings": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/encoding"
        }
      },
      "examplesOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/exampleOrReference"
        }
      },
      "headersOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/headerOrReference"
        }
      },
      "linksOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/linkOrReference"
        }
      },
      "mediaTypes": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/mediaType"
        }
      },
      "parametersOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/parameterOrReference"
        }
      },
      "requestBodiesOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/requestBodyOrReference"
        }
      },
      "responsesOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/responseOrReference"
        }
      },
      "schemasOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/schemaOrReference"
        }
      },
      "securitySchemesOrReferences": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/securitySchemeOrReference"
        }
      },
      "serverVariables": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/serverVariable"
        }
      },
      "strings": {
        "type": "object",
        "additionalProperties": {
          "type": "string"
        }
      },
      "object": {
        "type": "object",
        "additionalProperties": true
      },
      "any": {
        "additionalProperties": true
      },
      "expression": {
        "type": "object",
        "additionalProperties": true
      },
      "specificationExtension": {
        "description": "Any property starting with x- is valid.",
        "oneOf": [
          {
            "type": "null"
          },
          {
            "type": "number"
          },
          {
            "type": "boolean"
          },
          {
            "type": "string"
          },
          {
            "type": "object"
          },
          {
            "type": "array"
          }
        ]
      },
      "defaultType": {
        "oneOf": [
          {
            "type": "null"
          },
          {
            "type": "array"
          },
          {
            "type": "object"
          },
          {
            "type": "number"
          },
          {
            "type": "boolean"
          },
          {
            "type": "string"
          }
        ]
      }
    }
  }
  
  },{}],124:[function(require,module,exports){
  (function (process){
  'use strict';
  
  if (!process.version ||
      process.version.indexOf('v0.') === 0 ||
      process.version.indexOf('v1.') === 0 && process.version.indexOf('v1.8.') !== 0) {
    module.exports = { nextTick: nextTick };
  } else {
    module.exports = process
  }
  
  function nextTick(fn, arg1, arg2, arg3) {
    if (typeof fn !== 'function') {
      throw new TypeError('"callback" argument must be a function');
    }
    var len = arguments.length;
    var args, i;
    switch (len) {
    case 0:
    case 1:
      return process.nextTick(fn);
    case 2:
      return process.nextTick(function afterTickOne() {
        fn.call(null, arg1);
      });
    case 3:
      return process.nextTick(function afterTickTwo() {
        fn.call(null, arg1, arg2);
      });
    case 4:
      return process.nextTick(function afterTickThree() {
        fn.call(null, arg1, arg2, arg3);
      });
    default:
      args = new Array(len - 1);
      i = 0;
      while (i < args.length) {
        args[i++] = arguments[i];
      }
      return process.nextTick(function afterTick() {
        fn.apply(null, args);
      });
    }
  }
  
  
  }).call(this,require('_process'))
  
  },{"_process":125}],125:[function(require,module,exports){
  // shim for using process in browser
  var process = module.exports = {};
  
  // cached from whatever global is present so that test runners that stub it
  // don't break things.  But we need to wrap it in a try catch in case it is
  // wrapped in strict mode code which doesn't define any globals.  It's inside a
  // function because try/catches deoptimize in certain engines.
  
  var cachedSetTimeout;
  var cachedClearTimeout;
  
  function defaultSetTimout() {
      throw new Error('setTimeout has not been defined');
  }
  function defaultClearTimeout () {
      throw new Error('clearTimeout has not been defined');
  }
  (function () {
      try {
          if (typeof setTimeout === 'function') {
              cachedSetTimeout = setTimeout;
          } else {
              cachedSetTimeout = defaultSetTimout;
          }
      } catch (e) {
          cachedSetTimeout = defaultSetTimout;
      }
      try {
          if (typeof clearTimeout === 'function') {
              cachedClearTimeout = clearTimeout;
          } else {
              cachedClearTimeout = defaultClearTimeout;
          }
      } catch (e) {
          cachedClearTimeout = defaultClearTimeout;
      }
  } ())
  function runTimeout(fun) {
      if (cachedSetTimeout === setTimeout) {
          //normal enviroments in sane situations
          return setTimeout(fun, 0);
      }
      // if setTimeout wasn't available but was latter defined
      if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
          cachedSetTimeout = setTimeout;
          return setTimeout(fun, 0);
      }
      try {
          // when when somebody has screwed with setTimeout but no I.E. maddness
          return cachedSetTimeout(fun, 0);
      } catch(e){
          try {
              // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
              return cachedSetTimeout.call(null, fun, 0);
          } catch(e){
              // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
              return cachedSetTimeout.call(this, fun, 0);
          }
      }
  
  
  }
  function runClearTimeout(marker) {
      if (cachedClearTimeout === clearTimeout) {
          //normal enviroments in sane situations
          return clearTimeout(marker);
      }
      // if clearTimeout wasn't available but was latter defined
      if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
          cachedClearTimeout = clearTimeout;
          return clearTimeout(marker);
      }
      try {
          // when when somebody has screwed with setTimeout but no I.E. maddness
          return cachedClearTimeout(marker);
      } catch (e){
          try {
              // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
              return cachedClearTimeout.call(null, marker);
          } catch (e){
              // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
              // Some versions of I.E. have different rules for clearTimeout vs setTimeout
              return cachedClearTimeout.call(this, marker);
          }
      }
  
  
  
  }
  var queue = [];
  var draining = false;
  var currentQueue;
  var queueIndex = -1;
  
  function cleanUpNextTick() {
      if (!draining || !currentQueue) {
          return;
      }
      draining = false;
      if (currentQueue.length) {
          queue = currentQueue.concat(queue);
      } else {
          queueIndex = -1;
      }
      if (queue.length) {
          drainQueue();
      }
  }
  
  function drainQueue() {
      if (draining) {
          return;
      }
      var timeout = runTimeout(cleanUpNextTick);
      draining = true;
  
      var len = queue.length;
      while(len) {
          currentQueue = queue;
          queue = [];
          while (++queueIndex < len) {
              if (currentQueue) {
                  currentQueue[queueIndex].run();
              }
          }
          queueIndex = -1;
          len = queue.length;
      }
      currentQueue = null;
      draining = false;
      runClearTimeout(timeout);
  }
  
  process.nextTick = function (fun) {
      var args = new Array(arguments.length - 1);
      if (arguments.length > 1) {
          for (var i = 1; i < arguments.length; i++) {
              args[i - 1] = arguments[i];
          }
      }
      queue.push(new Item(fun, args));
      if (queue.length === 1 && !draining) {
          runTimeout(drainQueue);
      }
  };
  
  // v8 likes predictible objects
  function Item(fun, array) {
      this.fun = fun;
      this.array = array;
  }
  Item.prototype.run = function () {
      this.fun.apply(null, this.array);
  };
  process.title = 'browser';
  process.browser = true;
  process.env = {};
  process.argv = [];
  process.version = ''; // empty string to avoid regexp issues
  process.versions = {};
  
  function noop() {}
  
  process.on = noop;
  process.addListener = noop;
  process.once = noop;
  process.off = noop;
  process.removeListener = noop;
  process.removeAllListeners = noop;
  process.emit = noop;
  process.prependListener = noop;
  process.prependOnceListener = noop;
  
  process.listeners = function (name) { return [] }
  
  process.binding = function (name) {
      throw new Error('process.binding is not supported');
  };
  
  process.cwd = function () { return '/' };
  process.chdir = function (dir) {
      throw new Error('process.chdir is not supported');
  };
  process.umask = function() { return 0; };
  
  },{}],126:[function(require,module,exports){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  'use strict';
  
  // If obj.hasOwnProperty has been overridden, then calling
  // obj.hasOwnProperty(prop) will break.
  // See: https://github.com/joyent/node/issues/1707
  function hasOwnProperty(obj, prop) {
    return Object.prototype.hasOwnProperty.call(obj, prop);
  }
  
  module.exports = function(qs, sep, eq, options) {
    sep = sep || '&';
    eq = eq || '=';
    var obj = {};
  
    if (typeof qs !== 'string' || qs.length === 0) {
      return obj;
    }
  
    var regexp = /\+/g;
    qs = qs.split(sep);
  
    var maxKeys = 1000;
    if (options && typeof options.maxKeys === 'number') {
      maxKeys = options.maxKeys;
    }
  
    var len = qs.length;
    // maxKeys <= 0 means that we should not limit keys count
    if (maxKeys > 0 && len > maxKeys) {
      len = maxKeys;
    }
  
    for (var i = 0; i < len; ++i) {
      var x = qs[i].replace(regexp, '%20'),
          idx = x.indexOf(eq),
          kstr, vstr, k, v;
  
      if (idx >= 0) {
        kstr = x.substr(0, idx);
        vstr = x.substr(idx + 1);
      } else {
        kstr = x;
        vstr = '';
      }
  
      k = decodeURIComponent(kstr);
      v = decodeURIComponent(vstr);
  
      if (!hasOwnProperty(obj, k)) {
        obj[k] = v;
      } else if (isArray(obj[k])) {
        obj[k].push(v);
      } else {
        obj[k] = [obj[k], v];
      }
    }
  
    return obj;
  };
  
  var isArray = Array.isArray || function (xs) {
    return Object.prototype.toString.call(xs) === '[object Array]';
  };
  
  },{}],127:[function(require,module,exports){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  'use strict';
  
  var stringifyPrimitive = function(v) {
    switch (typeof v) {
      case 'string':
        return v;
  
      case 'boolean':
        return v ? 'true' : 'false';
  
      case 'number':
        return isFinite(v) ? v : '';
  
      default:
        return '';
    }
  };
  
  module.exports = function(obj, sep, eq, name) {
    sep = sep || '&';
    eq = eq || '=';
    if (obj === null) {
      obj = undefined;
    }
  
    if (typeof obj === 'object') {
      return map(objectKeys(obj), function(k) {
        var ks = encodeURIComponent(stringifyPrimitive(k)) + eq;
        if (isArray(obj[k])) {
          return map(obj[k], function(v) {
            return ks + encodeURIComponent(stringifyPrimitive(v));
          }).join(sep);
        } else {
          return ks + encodeURIComponent(stringifyPrimitive(obj[k]));
        }
      }).join(sep);
  
    }
  
    if (!name) return '';
    return encodeURIComponent(stringifyPrimitive(name)) + eq +
           encodeURIComponent(stringifyPrimitive(obj));
  };
  
  var isArray = Array.isArray || function (xs) {
    return Object.prototype.toString.call(xs) === '[object Array]';
  };
  
  function map (xs, f) {
    if (xs.map) return xs.map(f);
    var res = [];
    for (var i = 0; i < xs.length; i++) {
      res.push(f(xs[i], i));
    }
    return res;
  }
  
  var objectKeys = Object.keys || function (obj) {
    var res = [];
    for (var key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) res.push(key);
    }
    return res;
  };
  
  },{}],128:[function(require,module,exports){
  'use strict';
  
  exports.decode = exports.parse = require('./decode');
  exports.encode = exports.stringify = require('./encode');
  
  },{"./decode":126,"./encode":127}],129:[function(require,module,exports){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  // a duplex stream is just a stream that is both readable and writable.
  // Since JS doesn't have multiple prototypal inheritance, this class
  // prototypally inherits from Readable, and then parasitically from
  // Writable.
  
  'use strict';
  
  /*<replacement>*/
  
  var pna = require('process-nextick-args');
  /*</replacement>*/
  
  /*<replacement>*/
  var objectKeys = Object.keys || function (obj) {
    var keys = [];
    for (var key in obj) {
      keys.push(key);
    }return keys;
  };
  /*</replacement>*/
  
  module.exports = Duplex;
  
  /*<replacement>*/
  var util = require('core-util-is');
  util.inherits = require('inherits');
  /*</replacement>*/
  
  var Readable = require('./_stream_readable');
  var Writable = require('./_stream_writable');
  
  util.inherits(Duplex, Readable);
  
  {
    // avoid scope creep, the keys array can then be collected
    var keys = objectKeys(Writable.prototype);
    for (var v = 0; v < keys.length; v++) {
      var method = keys[v];
      if (!Duplex.prototype[method]) Duplex.prototype[method] = Writable.prototype[method];
    }
  }
  
  function Duplex(options) {
    if (!(this instanceof Duplex)) return new Duplex(options);
  
    Readable.call(this, options);
    Writable.call(this, options);
  
    if (options && options.readable === false) this.readable = false;
  
    if (options && options.writable === false) this.writable = false;
  
    this.allowHalfOpen = true;
    if (options && options.allowHalfOpen === false) this.allowHalfOpen = false;
  
    this.once('end', onend);
  }
  
  Object.defineProperty(Duplex.prototype, 'writableHighWaterMark', {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: false,
    get: function () {
      return this._writableState.highWaterMark;
    }
  });
  
  // the no-half-open enforcer
  function onend() {
    // if we allow half-open state, or if the writable side ended,
    // then we're ok.
    if (this.allowHalfOpen || this._writableState.ended) return;
  
    // no more data can be written.
    // But allow more writes to happen in this tick.
    pna.nextTick(onEndNT, this);
  }
  
  function onEndNT(self) {
    self.end();
  }
  
  Object.defineProperty(Duplex.prototype, 'destroyed', {
    get: function () {
      if (this._readableState === undefined || this._writableState === undefined) {
        return false;
      }
      return this._readableState.destroyed && this._writableState.destroyed;
    },
    set: function (value) {
      // we ignore the value if the stream
      // has not been initialized yet
      if (this._readableState === undefined || this._writableState === undefined) {
        return;
      }
  
      // backward compatibility, the user is explicitly
      // managing destroyed
      this._readableState.destroyed = value;
      this._writableState.destroyed = value;
    }
  });
  
  Duplex.prototype._destroy = function (err, cb) {
    this.push(null);
    this.end();
  
    pna.nextTick(cb, err);
  };
  },{"./_stream_readable":131,"./_stream_writable":133,"core-util-is":63,"inherits":68,"process-nextick-args":124}],130:[function(require,module,exports){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  // a passthrough stream.
  // basically just the most minimal sort of Transform stream.
  // Every written chunk gets output as-is.
  
  'use strict';
  
  module.exports = PassThrough;
  
  var Transform = require('./_stream_transform');
  
  /*<replacement>*/
  var util = require('core-util-is');
  util.inherits = require('inherits');
  /*</replacement>*/
  
  util.inherits(PassThrough, Transform);
  
  function PassThrough(options) {
    if (!(this instanceof PassThrough)) return new PassThrough(options);
  
    Transform.call(this, options);
  }
  
  PassThrough.prototype._transform = function (chunk, encoding, cb) {
    cb(null, chunk);
  };
  },{"./_stream_transform":132,"core-util-is":63,"inherits":68}],131:[function(require,module,exports){
  (function (process,global){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  'use strict';
  
  /*<replacement>*/
  
  var pna = require('process-nextick-args');
  /*</replacement>*/
  
  module.exports = Readable;
  
  /*<replacement>*/
  var isArray = require('isarray');
  /*</replacement>*/
  
  /*<replacement>*/
  var Duplex;
  /*</replacement>*/
  
  Readable.ReadableState = ReadableState;
  
  /*<replacement>*/
  var EE = require('events').EventEmitter;
  
  var EElistenerCount = function (emitter, type) {
    return emitter.listeners(type).length;
  };
  /*</replacement>*/
  
  /*<replacement>*/
  var Stream = require('./internal/streams/stream');
  /*</replacement>*/
  
  /*<replacement>*/
  
  var Buffer = require('safe-buffer').Buffer;
  var OurUint8Array = global.Uint8Array || function () {};
  function _uint8ArrayToBuffer(chunk) {
    return Buffer.from(chunk);
  }
  function _isUint8Array(obj) {
    return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
  }
  
  /*</replacement>*/
  
  /*<replacement>*/
  var util = require('core-util-is');
  util.inherits = require('inherits');
  /*</replacement>*/
  
  /*<replacement>*/
  var debugUtil = require('util');
  var debug = void 0;
  if (debugUtil && debugUtil.debuglog) {
    debug = debugUtil.debuglog('stream');
  } else {
    debug = function () {};
  }
  /*</replacement>*/
  
  var BufferList = require('./internal/streams/BufferList');
  var destroyImpl = require('./internal/streams/destroy');
  var StringDecoder;
  
  util.inherits(Readable, Stream);
  
  var kProxyEvents = ['error', 'close', 'destroy', 'pause', 'resume'];
  
  function prependListener(emitter, event, fn) {
    // Sadly this is not cacheable as some libraries bundle their own
    // event emitter implementation with them.
    if (typeof emitter.prependListener === 'function') return emitter.prependListener(event, fn);
  
    // This is a hack to make sure that our error handler is attached before any
    // userland ones.  NEVER DO THIS. This is here only because this code needs
    // to continue to work with older versions of Node.js that do not include
    // the prependListener() method. The goal is to eventually remove this hack.
    if (!emitter._events || !emitter._events[event]) emitter.on(event, fn);else if (isArray(emitter._events[event])) emitter._events[event].unshift(fn);else emitter._events[event] = [fn, emitter._events[event]];
  }
  
  function ReadableState(options, stream) {
    Duplex = Duplex || require('./_stream_duplex');
  
    options = options || {};
  
    // Duplex streams are both readable and writable, but share
    // the same options object.
    // However, some cases require setting options to different
    // values for the readable and the writable sides of the duplex stream.
    // These options can be provided separately as readableXXX and writableXXX.
    var isDuplex = stream instanceof Duplex;
  
    // object stream flag. Used to make read(n) ignore n and to
    // make all the buffer merging and length checks go away
    this.objectMode = !!options.objectMode;
  
    if (isDuplex) this.objectMode = this.objectMode || !!options.readableObjectMode;
  
    // the point at which it stops calling _read() to fill the buffer
    // Note: 0 is a valid value, means "don't call _read preemptively ever"
    var hwm = options.highWaterMark;
    var readableHwm = options.readableHighWaterMark;
    var defaultHwm = this.objectMode ? 16 : 16 * 1024;
  
    if (hwm || hwm === 0) this.highWaterMark = hwm;else if (isDuplex && (readableHwm || readableHwm === 0)) this.highWaterMark = readableHwm;else this.highWaterMark = defaultHwm;
  
    // cast to ints.
    this.highWaterMark = Math.floor(this.highWaterMark);
  
    // A linked list is used to store data chunks instead of an array because the
    // linked list can remove elements from the beginning faster than
    // array.shift()
    this.buffer = new BufferList();
    this.length = 0;
    this.pipes = null;
    this.pipesCount = 0;
    this.flowing = null;
    this.ended = false;
    this.endEmitted = false;
    this.reading = false;
  
    // a flag to be able to tell if the event 'readable'/'data' is emitted
    // immediately, or on a later tick.  We set this to true at first, because
    // any actions that shouldn't happen until "later" should generally also
    // not happen before the first read call.
    this.sync = true;
  
    // whenever we return null, then we set a flag to say
    // that we're awaiting a 'readable' event emission.
    this.needReadable = false;
    this.emittedReadable = false;
    this.readableListening = false;
    this.resumeScheduled = false;
  
    // has it been destroyed
    this.destroyed = false;
  
    // Crypto is kind of old and crusty.  Historically, its default string
    // encoding is 'binary' so we have to make this configurable.
    // Everything else in the universe uses 'utf8', though.
    this.defaultEncoding = options.defaultEncoding || 'utf8';
  
    // the number of writers that are awaiting a drain event in .pipe()s
    this.awaitDrain = 0;
  
    // if true, a maybeReadMore has been scheduled
    this.readingMore = false;
  
    this.decoder = null;
    this.encoding = null;
    if (options.encoding) {
      if (!StringDecoder) StringDecoder = require('string_decoder/').StringDecoder;
      this.decoder = new StringDecoder(options.encoding);
      this.encoding = options.encoding;
    }
  }
  
  function Readable(options) {
    Duplex = Duplex || require('./_stream_duplex');
  
    if (!(this instanceof Readable)) return new Readable(options);
  
    this._readableState = new ReadableState(options, this);
  
    // legacy
    this.readable = true;
  
    if (options) {
      if (typeof options.read === 'function') this._read = options.read;
  
      if (typeof options.destroy === 'function') this._destroy = options.destroy;
    }
  
    Stream.call(this);
  }
  
  Object.defineProperty(Readable.prototype, 'destroyed', {
    get: function () {
      if (this._readableState === undefined) {
        return false;
      }
      return this._readableState.destroyed;
    },
    set: function (value) {
      // we ignore the value if the stream
      // has not been initialized yet
      if (!this._readableState) {
        return;
      }
  
      // backward compatibility, the user is explicitly
      // managing destroyed
      this._readableState.destroyed = value;
    }
  });
  
  Readable.prototype.destroy = destroyImpl.destroy;
  Readable.prototype._undestroy = destroyImpl.undestroy;
  Readable.prototype._destroy = function (err, cb) {
    this.push(null);
    cb(err);
  };
  
  // Manually shove something into the read() buffer.
  // This returns true if the highWaterMark has not been hit yet,
  // similar to how Writable.write() returns true if you should
  // write() some more.
  Readable.prototype.push = function (chunk, encoding) {
    var state = this._readableState;
    var skipChunkCheck;
  
    if (!state.objectMode) {
      if (typeof chunk === 'string') {
        encoding = encoding || state.defaultEncoding;
        if (encoding !== state.encoding) {
          chunk = Buffer.from(chunk, encoding);
          encoding = '';
        }
        skipChunkCheck = true;
      }
    } else {
      skipChunkCheck = true;
    }
  
    return readableAddChunk(this, chunk, encoding, false, skipChunkCheck);
  };
  
  // Unshift should *always* be something directly out of read()
  Readable.prototype.unshift = function (chunk) {
    return readableAddChunk(this, chunk, null, true, false);
  };
  
  function readableAddChunk(stream, chunk, encoding, addToFront, skipChunkCheck) {
    var state = stream._readableState;
    if (chunk === null) {
      state.reading = false;
      onEofChunk(stream, state);
    } else {
      var er;
      if (!skipChunkCheck) er = chunkInvalid(state, chunk);
      if (er) {
        stream.emit('error', er);
      } else if (state.objectMode || chunk && chunk.length > 0) {
        if (typeof chunk !== 'string' && !state.objectMode && Object.getPrototypeOf(chunk) !== Buffer.prototype) {
          chunk = _uint8ArrayToBuffer(chunk);
        }
  
        if (addToFront) {
          if (state.endEmitted) stream.emit('error', new Error('stream.unshift() after end event'));else addChunk(stream, state, chunk, true);
        } else if (state.ended) {
          stream.emit('error', new Error('stream.push() after EOF'));
        } else {
          state.reading = false;
          if (state.decoder && !encoding) {
            chunk = state.decoder.write(chunk);
            if (state.objectMode || chunk.length !== 0) addChunk(stream, state, chunk, false);else maybeReadMore(stream, state);
          } else {
            addChunk(stream, state, chunk, false);
          }
        }
      } else if (!addToFront) {
        state.reading = false;
      }
    }
  
    return needMoreData(state);
  }
  
  function addChunk(stream, state, chunk, addToFront) {
    if (state.flowing && state.length === 0 && !state.sync) {
      stream.emit('data', chunk);
      stream.read(0);
    } else {
      // update the buffer info.
      state.length += state.objectMode ? 1 : chunk.length;
      if (addToFront) state.buffer.unshift(chunk);else state.buffer.push(chunk);
  
      if (state.needReadable) emitReadable(stream);
    }
    maybeReadMore(stream, state);
  }
  
  function chunkInvalid(state, chunk) {
    var er;
    if (!_isUint8Array(chunk) && typeof chunk !== 'string' && chunk !== undefined && !state.objectMode) {
      er = new TypeError('Invalid non-string/buffer chunk');
    }
    return er;
  }
  
  // if it's past the high water mark, we can push in some more.
  // Also, if we have no data yet, we can stand some
  // more bytes.  This is to work around cases where hwm=0,
  // such as the repl.  Also, if the push() triggered a
  // readable event, and the user called read(largeNumber) such that
  // needReadable was set, then we ought to push more, so that another
  // 'readable' event will be triggered.
  function needMoreData(state) {
    return !state.ended && (state.needReadable || state.length < state.highWaterMark || state.length === 0);
  }
  
  Readable.prototype.isPaused = function () {
    return this._readableState.flowing === false;
  };
  
  // backwards compatibility.
  Readable.prototype.setEncoding = function (enc) {
    if (!StringDecoder) StringDecoder = require('string_decoder/').StringDecoder;
    this._readableState.decoder = new StringDecoder(enc);
    this._readableState.encoding = enc;
    return this;
  };
  
  // Don't raise the hwm > 8MB
  var MAX_HWM = 0x800000;
  function computeNewHighWaterMark(n) {
    if (n >= MAX_HWM) {
      n = MAX_HWM;
    } else {
      // Get the next highest power of 2 to prevent increasing hwm excessively in
      // tiny amounts
      n--;
      n |= n >>> 1;
      n |= n >>> 2;
      n |= n >>> 4;
      n |= n >>> 8;
      n |= n >>> 16;
      n++;
    }
    return n;
  }
  
  // This function is designed to be inlinable, so please take care when making
  // changes to the function body.
  function howMuchToRead(n, state) {
    if (n <= 0 || state.length === 0 && state.ended) return 0;
    if (state.objectMode) return 1;
    if (n !== n) {
      // Only flow one buffer at a time
      if (state.flowing && state.length) return state.buffer.head.data.length;else return state.length;
    }
    // If we're asking for more than the current hwm, then raise the hwm.
    if (n > state.highWaterMark) state.highWaterMark = computeNewHighWaterMark(n);
    if (n <= state.length) return n;
    // Don't have enough
    if (!state.ended) {
      state.needReadable = true;
      return 0;
    }
    return state.length;
  }
  
  // you can override either this method, or the async _read(n) below.
  Readable.prototype.read = function (n) {
    debug('read', n);
    n = parseInt(n, 10);
    var state = this._readableState;
    var nOrig = n;
  
    if (n !== 0) state.emittedReadable = false;
  
    // if we're doing read(0) to trigger a readable event, but we
    // already have a bunch of data in the buffer, then just trigger
    // the 'readable' event and move on.
    if (n === 0 && state.needReadable && (state.length >= state.highWaterMark || state.ended)) {
      debug('read: emitReadable', state.length, state.ended);
      if (state.length === 0 && state.ended) endReadable(this);else emitReadable(this);
      return null;
    }
  
    n = howMuchToRead(n, state);
  
    // if we've ended, and we're now clear, then finish it up.
    if (n === 0 && state.ended) {
      if (state.length === 0) endReadable(this);
      return null;
    }
  
    // All the actual chunk generation logic needs to be
    // *below* the call to _read.  The reason is that in certain
    // synthetic stream cases, such as passthrough streams, _read
    // may be a completely synchronous operation which may change
    // the state of the read buffer, providing enough data when
    // before there was *not* enough.
    //
    // So, the steps are:
    // 1. Figure out what the state of things will be after we do
    // a read from the buffer.
    //
    // 2. If that resulting state will trigger a _read, then call _read.
    // Note that this may be asynchronous, or synchronous.  Yes, it is
    // deeply ugly to write APIs this way, but that still doesn't mean
    // that the Readable class should behave improperly, as streams are
    // designed to be sync/async agnostic.
    // Take note if the _read call is sync or async (ie, if the read call
    // has returned yet), so that we know whether or not it's safe to emit
    // 'readable' etc.
    //
    // 3. Actually pull the requested chunks out of the buffer and return.
  
    // if we need a readable event, then we need to do some reading.
    var doRead = state.needReadable;
    debug('need readable', doRead);
  
    // if we currently have less than the highWaterMark, then also read some
    if (state.length === 0 || state.length - n < state.highWaterMark) {
      doRead = true;
      debug('length less than watermark', doRead);
    }
  
    // however, if we've ended, then there's no point, and if we're already
    // reading, then it's unnecessary.
    if (state.ended || state.reading) {
      doRead = false;
      debug('reading or ended', doRead);
    } else if (doRead) {
      debug('do read');
      state.reading = true;
      state.sync = true;
      // if the length is currently zero, then we *need* a readable event.
      if (state.length === 0) state.needReadable = true;
      // call internal read method
      this._read(state.highWaterMark);
      state.sync = false;
      // If _read pushed data synchronously, then `reading` will be false,
      // and we need to re-evaluate how much data we can return to the user.
      if (!state.reading) n = howMuchToRead(nOrig, state);
    }
  
    var ret;
    if (n > 0) ret = fromList(n, state);else ret = null;
  
    if (ret === null) {
      state.needReadable = true;
      n = 0;
    } else {
      state.length -= n;
    }
  
    if (state.length === 0) {
      // If we have nothing in the buffer, then we want to know
      // as soon as we *do* get something into the buffer.
      if (!state.ended) state.needReadable = true;
  
      // If we tried to read() past the EOF, then emit end on the next tick.
      if (nOrig !== n && state.ended) endReadable(this);
    }
  
    if (ret !== null) this.emit('data', ret);
  
    return ret;
  };
  
  function onEofChunk(stream, state) {
    if (state.ended) return;
    if (state.decoder) {
      var chunk = state.decoder.end();
      if (chunk && chunk.length) {
        state.buffer.push(chunk);
        state.length += state.objectMode ? 1 : chunk.length;
      }
    }
    state.ended = true;
  
    // emit 'readable' now to make sure it gets picked up.
    emitReadable(stream);
  }
  
  // Don't emit readable right away in sync mode, because this can trigger
  // another read() call => stack overflow.  This way, it might trigger
  // a nextTick recursion warning, but that's not so bad.
  function emitReadable(stream) {
    var state = stream._readableState;
    state.needReadable = false;
    if (!state.emittedReadable) {
      debug('emitReadable', state.flowing);
      state.emittedReadable = true;
      if (state.sync) pna.nextTick(emitReadable_, stream);else emitReadable_(stream);
    }
  }
  
  function emitReadable_(stream) {
    debug('emit readable');
    stream.emit('readable');
    flow(stream);
  }
  
  // at this point, the user has presumably seen the 'readable' event,
  // and called read() to consume some data.  that may have triggered
  // in turn another _read(n) call, in which case reading = true if
  // it's in progress.
  // However, if we're not ended, or reading, and the length < hwm,
  // then go ahead and try to read some more preemptively.
  function maybeReadMore(stream, state) {
    if (!state.readingMore) {
      state.readingMore = true;
      pna.nextTick(maybeReadMore_, stream, state);
    }
  }
  
  function maybeReadMore_(stream, state) {
    var len = state.length;
    while (!state.reading && !state.flowing && !state.ended && state.length < state.highWaterMark) {
      debug('maybeReadMore read 0');
      stream.read(0);
      if (len === state.length)
        // didn't get any data, stop spinning.
        break;else len = state.length;
    }
    state.readingMore = false;
  }
  
  // abstract method.  to be overridden in specific implementation classes.
  // call cb(er, data) where data is <= n in length.
  // for virtual (non-string, non-buffer) streams, "length" is somewhat
  // arbitrary, and perhaps not very meaningful.
  Readable.prototype._read = function (n) {
    this.emit('error', new Error('_read() is not implemented'));
  };
  
  Readable.prototype.pipe = function (dest, pipeOpts) {
    var src = this;
    var state = this._readableState;
  
    switch (state.pipesCount) {
      case 0:
        state.pipes = dest;
        break;
      case 1:
        state.pipes = [state.pipes, dest];
        break;
      default:
        state.pipes.push(dest);
        break;
    }
    state.pipesCount += 1;
    debug('pipe count=%d opts=%j', state.pipesCount, pipeOpts);
  
    var doEnd = (!pipeOpts || pipeOpts.end !== false) && dest !== process.stdout && dest !== process.stderr;
  
    var endFn = doEnd ? onend : unpipe;
    if (state.endEmitted) pna.nextTick(endFn);else src.once('end', endFn);
  
    dest.on('unpipe', onunpipe);
    function onunpipe(readable, unpipeInfo) {
      debug('onunpipe');
      if (readable === src) {
        if (unpipeInfo && unpipeInfo.hasUnpiped === false) {
          unpipeInfo.hasUnpiped = true;
          cleanup();
        }
      }
    }
  
    function onend() {
      debug('onend');
      dest.end();
    }
  
    // when the dest drains, it reduces the awaitDrain counter
    // on the source.  This would be more elegant with a .once()
    // handler in flow(), but adding and removing repeatedly is
    // too slow.
    var ondrain = pipeOnDrain(src);
    dest.on('drain', ondrain);
  
    var cleanedUp = false;
    function cleanup() {
      debug('cleanup');
      // cleanup event handlers once the pipe is broken
      dest.removeListener('close', onclose);
      dest.removeListener('finish', onfinish);
      dest.removeListener('drain', ondrain);
      dest.removeListener('error', onerror);
      dest.removeListener('unpipe', onunpipe);
      src.removeListener('end', onend);
      src.removeListener('end', unpipe);
      src.removeListener('data', ondata);
  
      cleanedUp = true;
  
      // if the reader is waiting for a drain event from this
      // specific writer, then it would cause it to never start
      // flowing again.
      // So, if this is awaiting a drain, then we just call it now.
      // If we don't know, then assume that we are waiting for one.
      if (state.awaitDrain && (!dest._writableState || dest._writableState.needDrain)) ondrain();
    }
  
    // If the user pushes more data while we're writing to dest then we'll end up
    // in ondata again. However, we only want to increase awaitDrain once because
    // dest will only emit one 'drain' event for the multiple writes.
    // => Introduce a guard on increasing awaitDrain.
    var increasedAwaitDrain = false;
    src.on('data', ondata);
    function ondata(chunk) {
      debug('ondata');
      increasedAwaitDrain = false;
      var ret = dest.write(chunk);
      if (false === ret && !increasedAwaitDrain) {
        // If the user unpiped during `dest.write()`, it is possible
        // to get stuck in a permanently paused state if that write
        // also returned false.
        // => Check whether `dest` is still a piping destination.
        if ((state.pipesCount === 1 && state.pipes === dest || state.pipesCount > 1 && indexOf(state.pipes, dest) !== -1) && !cleanedUp) {
          debug('false write response, pause', src._readableState.awaitDrain);
          src._readableState.awaitDrain++;
          increasedAwaitDrain = true;
        }
        src.pause();
      }
    }
  
    // if the dest has an error, then stop piping into it.
    // however, don't suppress the throwing behavior for this.
    function onerror(er) {
      debug('onerror', er);
      unpipe();
      dest.removeListener('error', onerror);
      if (EElistenerCount(dest, 'error') === 0) dest.emit('error', er);
    }
  
    // Make sure our error handler is attached before userland ones.
    prependListener(dest, 'error', onerror);
  
    // Both close and finish should trigger unpipe, but only once.
    function onclose() {
      dest.removeListener('finish', onfinish);
      unpipe();
    }
    dest.once('close', onclose);
    function onfinish() {
      debug('onfinish');
      dest.removeListener('close', onclose);
      unpipe();
    }
    dest.once('finish', onfinish);
  
    function unpipe() {
      debug('unpipe');
      src.unpipe(dest);
    }
  
    // tell the dest that it's being piped to
    dest.emit('pipe', src);
  
    // start the flow if it hasn't been started already.
    if (!state.flowing) {
      debug('pipe resume');
      src.resume();
    }
  
    return dest;
  };
  
  function pipeOnDrain(src) {
    return function () {
      var state = src._readableState;
      debug('pipeOnDrain', state.awaitDrain);
      if (state.awaitDrain) state.awaitDrain--;
      if (state.awaitDrain === 0 && EElistenerCount(src, 'data')) {
        state.flowing = true;
        flow(src);
      }
    };
  }
  
  Readable.prototype.unpipe = function (dest) {
    var state = this._readableState;
    var unpipeInfo = { hasUnpiped: false };
  
    // if we're not piping anywhere, then do nothing.
    if (state.pipesCount === 0) return this;
  
    // just one destination.  most common case.
    if (state.pipesCount === 1) {
      // passed in one, but it's not the right one.
      if (dest && dest !== state.pipes) return this;
  
      if (!dest) dest = state.pipes;
  
      // got a match.
      state.pipes = null;
      state.pipesCount = 0;
      state.flowing = false;
      if (dest) dest.emit('unpipe', this, unpipeInfo);
      return this;
    }
  
    // slow case. multiple pipe destinations.
  
    if (!dest) {
      // remove all.
      var dests = state.pipes;
      var len = state.pipesCount;
      state.pipes = null;
      state.pipesCount = 0;
      state.flowing = false;
  
      for (var i = 0; i < len; i++) {
        dests[i].emit('unpipe', this, unpipeInfo);
      }return this;
    }
  
    // try to find the right one.
    var index = indexOf(state.pipes, dest);
    if (index === -1) return this;
  
    state.pipes.splice(index, 1);
    state.pipesCount -= 1;
    if (state.pipesCount === 1) state.pipes = state.pipes[0];
  
    dest.emit('unpipe', this, unpipeInfo);
  
    return this;
  };
  
  // set up data events if they are asked for
  // Ensure readable listeners eventually get something
  Readable.prototype.on = function (ev, fn) {
    var res = Stream.prototype.on.call(this, ev, fn);
  
    if (ev === 'data') {
      // Start flowing on next tick if stream isn't explicitly paused
      if (this._readableState.flowing !== false) this.resume();
    } else if (ev === 'readable') {
      var state = this._readableState;
      if (!state.endEmitted && !state.readableListening) {
        state.readableListening = state.needReadable = true;
        state.emittedReadable = false;
        if (!state.reading) {
          pna.nextTick(nReadingNextTick, this);
        } else if (state.length) {
          emitReadable(this);
        }
      }
    }
  
    return res;
  };
  Readable.prototype.addListener = Readable.prototype.on;
  
  function nReadingNextTick(self) {
    debug('readable nexttick read 0');
    self.read(0);
  }
  
  // pause() and resume() are remnants of the legacy readable stream API
  // If the user uses them, then switch into old mode.
  Readable.prototype.resume = function () {
    var state = this._readableState;
    if (!state.flowing) {
      debug('resume');
      state.flowing = true;
      resume(this, state);
    }
    return this;
  };
  
  function resume(stream, state) {
    if (!state.resumeScheduled) {
      state.resumeScheduled = true;
      pna.nextTick(resume_, stream, state);
    }
  }
  
  function resume_(stream, state) {
    if (!state.reading) {
      debug('resume read 0');
      stream.read(0);
    }
  
    state.resumeScheduled = false;
    state.awaitDrain = 0;
    stream.emit('resume');
    flow(stream);
    if (state.flowing && !state.reading) stream.read(0);
  }
  
  Readable.prototype.pause = function () {
    debug('call pause flowing=%j', this._readableState.flowing);
    if (false !== this._readableState.flowing) {
      debug('pause');
      this._readableState.flowing = false;
      this.emit('pause');
    }
    return this;
  };
  
  function flow(stream) {
    var state = stream._readableState;
    debug('flow', state.flowing);
    while (state.flowing && stream.read() !== null) {}
  }
  
  // wrap an old-style stream as the async data source.
  // This is *not* part of the readable stream interface.
  // It is an ugly unfortunate mess of history.
  Readable.prototype.wrap = function (stream) {
    var _this = this;
  
    var state = this._readableState;
    var paused = false;
  
    stream.on('end', function () {
      debug('wrapped end');
      if (state.decoder && !state.ended) {
        var chunk = state.decoder.end();
        if (chunk && chunk.length) _this.push(chunk);
      }
  
      _this.push(null);
    });
  
    stream.on('data', function (chunk) {
      debug('wrapped data');
      if (state.decoder) chunk = state.decoder.write(chunk);
  
      // don't skip over falsy values in objectMode
      if (state.objectMode && (chunk === null || chunk === undefined)) return;else if (!state.objectMode && (!chunk || !chunk.length)) return;
  
      var ret = _this.push(chunk);
      if (!ret) {
        paused = true;
        stream.pause();
      }
    });
  
    // proxy all the other methods.
    // important when wrapping filters and duplexes.
    for (var i in stream) {
      if (this[i] === undefined && typeof stream[i] === 'function') {
        this[i] = function (method) {
          return function () {
            return stream[method].apply(stream, arguments);
          };
        }(i);
      }
    }
  
    // proxy certain important events.
    for (var n = 0; n < kProxyEvents.length; n++) {
      stream.on(kProxyEvents[n], this.emit.bind(this, kProxyEvents[n]));
    }
  
    // when we try to consume some more bytes, simply unpause the
    // underlying stream.
    this._read = function (n) {
      debug('wrapped _read', n);
      if (paused) {
        paused = false;
        stream.resume();
      }
    };
  
    return this;
  };
  
  Object.defineProperty(Readable.prototype, 'readableHighWaterMark', {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: false,
    get: function () {
      return this._readableState.highWaterMark;
    }
  });
  
  // exposed for testing purposes only.
  Readable._fromList = fromList;
  
  // Pluck off n bytes from an array of buffers.
  // Length is the combined lengths of all the buffers in the list.
  // This function is designed to be inlinable, so please take care when making
  // changes to the function body.
  function fromList(n, state) {
    // nothing buffered
    if (state.length === 0) return null;
  
    var ret;
    if (state.objectMode) ret = state.buffer.shift();else if (!n || n >= state.length) {
      // read it all, truncate the list
      if (state.decoder) ret = state.buffer.join('');else if (state.buffer.length === 1) ret = state.buffer.head.data;else ret = state.buffer.concat(state.length);
      state.buffer.clear();
    } else {
      // read part of list
      ret = fromListPartial(n, state.buffer, state.decoder);
    }
  
    return ret;
  }
  
  // Extracts only enough buffered data to satisfy the amount requested.
  // This function is designed to be inlinable, so please take care when making
  // changes to the function body.
  function fromListPartial(n, list, hasStrings) {
    var ret;
    if (n < list.head.data.length) {
      // slice is the same for buffers and strings
      ret = list.head.data.slice(0, n);
      list.head.data = list.head.data.slice(n);
    } else if (n === list.head.data.length) {
      // first chunk is a perfect match
      ret = list.shift();
    } else {
      // result spans more than one buffer
      ret = hasStrings ? copyFromBufferString(n, list) : copyFromBuffer(n, list);
    }
    return ret;
  }
  
  // Copies a specified amount of characters from the list of buffered data
  // chunks.
  // This function is designed to be inlinable, so please take care when making
  // changes to the function body.
  function copyFromBufferString(n, list) {
    var p = list.head;
    var c = 1;
    var ret = p.data;
    n -= ret.length;
    while (p = p.next) {
      var str = p.data;
      var nb = n > str.length ? str.length : n;
      if (nb === str.length) ret += str;else ret += str.slice(0, n);
      n -= nb;
      if (n === 0) {
        if (nb === str.length) {
          ++c;
          if (p.next) list.head = p.next;else list.head = list.tail = null;
        } else {
          list.head = p;
          p.data = str.slice(nb);
        }
        break;
      }
      ++c;
    }
    list.length -= c;
    return ret;
  }
  
  // Copies a specified amount of bytes from the list of buffered data chunks.
  // This function is designed to be inlinable, so please take care when making
  // changes to the function body.
  function copyFromBuffer(n, list) {
    var ret = Buffer.allocUnsafe(n);
    var p = list.head;
    var c = 1;
    p.data.copy(ret);
    n -= p.data.length;
    while (p = p.next) {
      var buf = p.data;
      var nb = n > buf.length ? buf.length : n;
      buf.copy(ret, ret.length - n, 0, nb);
      n -= nb;
      if (n === 0) {
        if (nb === buf.length) {
          ++c;
          if (p.next) list.head = p.next;else list.head = list.tail = null;
        } else {
          list.head = p;
          p.data = buf.slice(nb);
        }
        break;
      }
      ++c;
    }
    list.length -= c;
    return ret;
  }
  
  function endReadable(stream) {
    var state = stream._readableState;
  
    // If we get here before consuming all the bytes, then that is a
    // bug in node.  Should never happen.
    if (state.length > 0) throw new Error('"endReadable()" called on non-empty stream');
  
    if (!state.endEmitted) {
      state.ended = true;
      pna.nextTick(endReadableNT, state, stream);
    }
  }
  
  function endReadableNT(state, stream) {
    // Check that we didn't get one last unshift.
    if (!state.endEmitted && state.length === 0) {
      state.endEmitted = true;
      stream.readable = false;
      stream.emit('end');
    }
  }
  
  function indexOf(xs, x) {
    for (var i = 0, l = xs.length; i < l; i++) {
      if (xs[i] === x) return i;
    }
    return -1;
  }
  }).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{"./_stream_duplex":129,"./internal/streams/BufferList":134,"./internal/streams/destroy":135,"./internal/streams/stream":136,"_process":125,"core-util-is":63,"events":64,"inherits":68,"isarray":70,"process-nextick-args":124,"safe-buffer":138,"string_decoder/":143,"util":7}],132:[function(require,module,exports){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  // a transform stream is a readable/writable stream where you do
  // something with the data.  Sometimes it's called a "filter",
  // but that's not a great name for it, since that implies a thing where
  // some bits pass through, and others are simply ignored.  (That would
  // be a valid example of a transform, of course.)
  //
  // While the output is causally related to the input, it's not a
  // necessarily symmetric or synchronous transformation.  For example,
  // a zlib stream might take multiple plain-text writes(), and then
  // emit a single compressed chunk some time in the future.
  //
  // Here's how this works:
  //
  // The Transform stream has all the aspects of the readable and writable
  // stream classes.  When you write(chunk), that calls _write(chunk,cb)
  // internally, and returns false if there's a lot of pending writes
  // buffered up.  When you call read(), that calls _read(n) until
  // there's enough pending readable data buffered up.
  //
  // In a transform stream, the written data is placed in a buffer.  When
  // _read(n) is called, it transforms the queued up data, calling the
  // buffered _write cb's as it consumes chunks.  If consuming a single
  // written chunk would result in multiple output chunks, then the first
  // outputted bit calls the readcb, and subsequent chunks just go into
  // the read buffer, and will cause it to emit 'readable' if necessary.
  //
  // This way, back-pressure is actually determined by the reading side,
  // since _read has to be called to start processing a new chunk.  However,
  // a pathological inflate type of transform can cause excessive buffering
  // here.  For example, imagine a stream where every byte of input is
  // interpreted as an integer from 0-255, and then results in that many
  // bytes of output.  Writing the 4 bytes {ff,ff,ff,ff} would result in
  // 1kb of data being output.  In this case, you could write a very small
  // amount of input, and end up with a very large amount of output.  In
  // such a pathological inflating mechanism, there'd be no way to tell
  // the system to stop doing the transform.  A single 4MB write could
  // cause the system to run out of memory.
  //
  // However, even in such a pathological case, only a single written chunk
  // would be consumed, and then the rest would wait (un-transformed) until
  // the results of the previous transformed chunk were consumed.
  
  'use strict';
  
  module.exports = Transform;
  
  var Duplex = require('./_stream_duplex');
  
  /*<replacement>*/
  var util = require('core-util-is');
  util.inherits = require('inherits');
  /*</replacement>*/
  
  util.inherits(Transform, Duplex);
  
  function afterTransform(er, data) {
    var ts = this._transformState;
    ts.transforming = false;
  
    var cb = ts.writecb;
  
    if (!cb) {
      return this.emit('error', new Error('write callback called multiple times'));
    }
  
    ts.writechunk = null;
    ts.writecb = null;
  
    if (data != null) // single equals check for both `null` and `undefined`
      this.push(data);
  
    cb(er);
  
    var rs = this._readableState;
    rs.reading = false;
    if (rs.needReadable || rs.length < rs.highWaterMark) {
      this._read(rs.highWaterMark);
    }
  }
  
  function Transform(options) {
    if (!(this instanceof Transform)) return new Transform(options);
  
    Duplex.call(this, options);
  
    this._transformState = {
      afterTransform: afterTransform.bind(this),
      needTransform: false,
      transforming: false,
      writecb: null,
      writechunk: null,
      writeencoding: null
    };
  
    // start out asking for a readable event once data is transformed.
    this._readableState.needReadable = true;
  
    // we have implemented the _read method, and done the other things
    // that Readable wants before the first _read call, so unset the
    // sync guard flag.
    this._readableState.sync = false;
  
    if (options) {
      if (typeof options.transform === 'function') this._transform = options.transform;
  
      if (typeof options.flush === 'function') this._flush = options.flush;
    }
  
    // When the writable side finishes, then flush out anything remaining.
    this.on('prefinish', prefinish);
  }
  
  function prefinish() {
    var _this = this;
  
    if (typeof this._flush === 'function') {
      this._flush(function (er, data) {
        done(_this, er, data);
      });
    } else {
      done(this, null, null);
    }
  }
  
  Transform.prototype.push = function (chunk, encoding) {
    this._transformState.needTransform = false;
    return Duplex.prototype.push.call(this, chunk, encoding);
  };
  
  // This is the part where you do stuff!
  // override this function in implementation classes.
  // 'chunk' is an input chunk.
  //
  // Call `push(newChunk)` to pass along transformed output
  // to the readable side.  You may call 'push' zero or more times.
  //
  // Call `cb(err)` when you are done with this chunk.  If you pass
  // an error, then that'll put the hurt on the whole operation.  If you
  // never call cb(), then you'll never get another chunk.
  Transform.prototype._transform = function (chunk, encoding, cb) {
    throw new Error('_transform() is not implemented');
  };
  
  Transform.prototype._write = function (chunk, encoding, cb) {
    var ts = this._transformState;
    ts.writecb = cb;
    ts.writechunk = chunk;
    ts.writeencoding = encoding;
    if (!ts.transforming) {
      var rs = this._readableState;
      if (ts.needTransform || rs.needReadable || rs.length < rs.highWaterMark) this._read(rs.highWaterMark);
    }
  };
  
  // Doesn't matter what the args are here.
  // _transform does all the work.
  // That we got here means that the readable side wants more data.
  Transform.prototype._read = function (n) {
    var ts = this._transformState;
  
    if (ts.writechunk !== null && ts.writecb && !ts.transforming) {
      ts.transforming = true;
      this._transform(ts.writechunk, ts.writeencoding, ts.afterTransform);
    } else {
      // mark that we need a transform, so that any data that comes in
      // will get processed, now that we've asked for it.
      ts.needTransform = true;
    }
  };
  
  Transform.prototype._destroy = function (err, cb) {
    var _this2 = this;
  
    Duplex.prototype._destroy.call(this, err, function (err2) {
      cb(err2);
      _this2.emit('close');
    });
  };
  
  function done(stream, er, data) {
    if (er) return stream.emit('error', er);
  
    if (data != null) // single equals check for both `null` and `undefined`
      stream.push(data);
  
    // if there's nothing in the write buffer, then that means
    // that nothing more will ever be provided
    if (stream._writableState.length) throw new Error('Calling transform done when ws.length != 0');
  
    if (stream._transformState.transforming) throw new Error('Calling transform done when still transforming');
  
    return stream.push(null);
  }
  },{"./_stream_duplex":129,"core-util-is":63,"inherits":68}],133:[function(require,module,exports){
  (function (process,global,setImmediate){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  // A bit simpler than readable streams.
  // Implement an async ._write(chunk, encoding, cb), and it'll handle all
  // the drain event emission and buffering.
  
  'use strict';
  
  /*<replacement>*/
  
  var pna = require('process-nextick-args');
  /*</replacement>*/
  
  module.exports = Writable;
  
  /* <replacement> */
  function WriteReq(chunk, encoding, cb) {
    this.chunk = chunk;
    this.encoding = encoding;
    this.callback = cb;
    this.next = null;
  }
  
  // It seems a linked list but it is not
  // there will be only 2 of these for each stream
  function CorkedRequest(state) {
    var _this = this;
  
    this.next = null;
    this.entry = null;
    this.finish = function () {
      onCorkedFinish(_this, state);
    };
  }
  /* </replacement> */
  
  /*<replacement>*/
  var asyncWrite = !process.browser && ['v0.10', 'v0.9.'].indexOf(process.version.slice(0, 5)) > -1 ? setImmediate : pna.nextTick;
  /*</replacement>*/
  
  /*<replacement>*/
  var Duplex;
  /*</replacement>*/
  
  Writable.WritableState = WritableState;
  
  /*<replacement>*/
  var util = require('core-util-is');
  util.inherits = require('inherits');
  /*</replacement>*/
  
  /*<replacement>*/
  var internalUtil = {
    deprecate: require('util-deprecate')
  };
  /*</replacement>*/
  
  /*<replacement>*/
  var Stream = require('./internal/streams/stream');
  /*</replacement>*/
  
  /*<replacement>*/
  
  var Buffer = require('safe-buffer').Buffer;
  var OurUint8Array = global.Uint8Array || function () {};
  function _uint8ArrayToBuffer(chunk) {
    return Buffer.from(chunk);
  }
  function _isUint8Array(obj) {
    return Buffer.isBuffer(obj) || obj instanceof OurUint8Array;
  }
  
  /*</replacement>*/
  
  var destroyImpl = require('./internal/streams/destroy');
  
  util.inherits(Writable, Stream);
  
  function nop() {}
  
  function WritableState(options, stream) {
    Duplex = Duplex || require('./_stream_duplex');
  
    options = options || {};
  
    // Duplex streams are both readable and writable, but share
    // the same options object.
    // However, some cases require setting options to different
    // values for the readable and the writable sides of the duplex stream.
    // These options can be provided separately as readableXXX and writableXXX.
    var isDuplex = stream instanceof Duplex;
  
    // object stream flag to indicate whether or not this stream
    // contains buffers or objects.
    this.objectMode = !!options.objectMode;
  
    if (isDuplex) this.objectMode = this.objectMode || !!options.writableObjectMode;
  
    // the point at which write() starts returning false
    // Note: 0 is a valid value, means that we always return false if
    // the entire buffer is not flushed immediately on write()
    var hwm = options.highWaterMark;
    var writableHwm = options.writableHighWaterMark;
    var defaultHwm = this.objectMode ? 16 : 16 * 1024;
  
    if (hwm || hwm === 0) this.highWaterMark = hwm;else if (isDuplex && (writableHwm || writableHwm === 0)) this.highWaterMark = writableHwm;else this.highWaterMark = defaultHwm;
  
    // cast to ints.
    this.highWaterMark = Math.floor(this.highWaterMark);
  
    // if _final has been called
    this.finalCalled = false;
  
    // drain event flag.
    this.needDrain = false;
    // at the start of calling end()
    this.ending = false;
    // when end() has been called, and returned
    this.ended = false;
    // when 'finish' is emitted
    this.finished = false;
  
    // has it been destroyed
    this.destroyed = false;
  
    // should we decode strings into buffers before passing to _write?
    // this is here so that some node-core streams can optimize string
    // handling at a lower level.
    var noDecode = options.decodeStrings === false;
    this.decodeStrings = !noDecode;
  
    // Crypto is kind of old and crusty.  Historically, its default string
    // encoding is 'binary' so we have to make this configurable.
    // Everything else in the universe uses 'utf8', though.
    this.defaultEncoding = options.defaultEncoding || 'utf8';
  
    // not an actual buffer we keep track of, but a measurement
    // of how much we're waiting to get pushed to some underlying
    // socket or file.
    this.length = 0;
  
    // a flag to see when we're in the middle of a write.
    this.writing = false;
  
    // when true all writes will be buffered until .uncork() call
    this.corked = 0;
  
    // a flag to be able to tell if the onwrite cb is called immediately,
    // or on a later tick.  We set this to true at first, because any
    // actions that shouldn't happen until "later" should generally also
    // not happen before the first write call.
    this.sync = true;
  
    // a flag to know if we're processing previously buffered items, which
    // may call the _write() callback in the same tick, so that we don't
    // end up in an overlapped onwrite situation.
    this.bufferProcessing = false;
  
    // the callback that's passed to _write(chunk,cb)
    this.onwrite = function (er) {
      onwrite(stream, er);
    };
  
    // the callback that the user supplies to write(chunk,encoding,cb)
    this.writecb = null;
  
    // the amount that is being written when _write is called.
    this.writelen = 0;
  
    this.bufferedRequest = null;
    this.lastBufferedRequest = null;
  
    // number of pending user-supplied write callbacks
    // this must be 0 before 'finish' can be emitted
    this.pendingcb = 0;
  
    // emit prefinish if the only thing we're waiting for is _write cbs
    // This is relevant for synchronous Transform streams
    this.prefinished = false;
  
    // True if the error was already emitted and should not be thrown again
    this.errorEmitted = false;
  
    // count buffered requests
    this.bufferedRequestCount = 0;
  
    // allocate the first CorkedRequest, there is always
    // one allocated and free to use, and we maintain at most two
    this.corkedRequestsFree = new CorkedRequest(this);
  }
  
  WritableState.prototype.getBuffer = function getBuffer() {
    var current = this.bufferedRequest;
    var out = [];
    while (current) {
      out.push(current);
      current = current.next;
    }
    return out;
  };
  
  (function () {
    try {
      Object.defineProperty(WritableState.prototype, 'buffer', {
        get: internalUtil.deprecate(function () {
          return this.getBuffer();
        }, '_writableState.buffer is deprecated. Use _writableState.getBuffer ' + 'instead.', 'DEP0003')
      });
    } catch (_) {}
  })();
  
  // Test _writableState for inheritance to account for Duplex streams,
  // whose prototype chain only points to Readable.
  var realHasInstance;
  if (typeof Symbol === 'function' && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] === 'function') {
    realHasInstance = Function.prototype[Symbol.hasInstance];
    Object.defineProperty(Writable, Symbol.hasInstance, {
      value: function (object) {
        if (realHasInstance.call(this, object)) return true;
        if (this !== Writable) return false;
  
        return object && object._writableState instanceof WritableState;
      }
    });
  } else {
    realHasInstance = function (object) {
      return object instanceof this;
    };
  }
  
  function Writable(options) {
    Duplex = Duplex || require('./_stream_duplex');
  
    // Writable ctor is applied to Duplexes, too.
    // `realHasInstance` is necessary because using plain `instanceof`
    // would return false, as no `_writableState` property is attached.
  
    // Trying to use the custom `instanceof` for Writable here will also break the
    // Node.js LazyTransform implementation, which has a non-trivial getter for
    // `_writableState` that would lead to infinite recursion.
    if (!realHasInstance.call(Writable, this) && !(this instanceof Duplex)) {
      return new Writable(options);
    }
  
    this._writableState = new WritableState(options, this);
  
    // legacy.
    this.writable = true;
  
    if (options) {
      if (typeof options.write === 'function') this._write = options.write;
  
      if (typeof options.writev === 'function') this._writev = options.writev;
  
      if (typeof options.destroy === 'function') this._destroy = options.destroy;
  
      if (typeof options.final === 'function') this._final = options.final;
    }
  
    Stream.call(this);
  }
  
  // Otherwise people can pipe Writable streams, which is just wrong.
  Writable.prototype.pipe = function () {
    this.emit('error', new Error('Cannot pipe, not readable'));
  };
  
  function writeAfterEnd(stream, cb) {
    var er = new Error('write after end');
    // TODO: defer error events consistently everywhere, not just the cb
    stream.emit('error', er);
    pna.nextTick(cb, er);
  }
  
  // Checks that a user-supplied chunk is valid, especially for the particular
  // mode the stream is in. Currently this means that `null` is never accepted
  // and undefined/non-string values are only allowed in object mode.
  function validChunk(stream, state, chunk, cb) {
    var valid = true;
    var er = false;
  
    if (chunk === null) {
      er = new TypeError('May not write null values to stream');
    } else if (typeof chunk !== 'string' && chunk !== undefined && !state.objectMode) {
      er = new TypeError('Invalid non-string/buffer chunk');
    }
    if (er) {
      stream.emit('error', er);
      pna.nextTick(cb, er);
      valid = false;
    }
    return valid;
  }
  
  Writable.prototype.write = function (chunk, encoding, cb) {
    var state = this._writableState;
    var ret = false;
    var isBuf = !state.objectMode && _isUint8Array(chunk);
  
    if (isBuf && !Buffer.isBuffer(chunk)) {
      chunk = _uint8ArrayToBuffer(chunk);
    }
  
    if (typeof encoding === 'function') {
      cb = encoding;
      encoding = null;
    }
  
    if (isBuf) encoding = 'buffer';else if (!encoding) encoding = state.defaultEncoding;
  
    if (typeof cb !== 'function') cb = nop;
  
    if (state.ended) writeAfterEnd(this, cb);else if (isBuf || validChunk(this, state, chunk, cb)) {
      state.pendingcb++;
      ret = writeOrBuffer(this, state, isBuf, chunk, encoding, cb);
    }
  
    return ret;
  };
  
  Writable.prototype.cork = function () {
    var state = this._writableState;
  
    state.corked++;
  };
  
  Writable.prototype.uncork = function () {
    var state = this._writableState;
  
    if (state.corked) {
      state.corked--;
  
      if (!state.writing && !state.corked && !state.finished && !state.bufferProcessing && state.bufferedRequest) clearBuffer(this, state);
    }
  };
  
  Writable.prototype.setDefaultEncoding = function setDefaultEncoding(encoding) {
    // node::ParseEncoding() requires lower case.
    if (typeof encoding === 'string') encoding = encoding.toLowerCase();
    if (!(['hex', 'utf8', 'utf-8', 'ascii', 'binary', 'base64', 'ucs2', 'ucs-2', 'utf16le', 'utf-16le', 'raw'].indexOf((encoding + '').toLowerCase()) > -1)) throw new TypeError('Unknown encoding: ' + encoding);
    this._writableState.defaultEncoding = encoding;
    return this;
  };
  
  function decodeChunk(state, chunk, encoding) {
    if (!state.objectMode && state.decodeStrings !== false && typeof chunk === 'string') {
      chunk = Buffer.from(chunk, encoding);
    }
    return chunk;
  }
  
  Object.defineProperty(Writable.prototype, 'writableHighWaterMark', {
    // making it explicit this property is not enumerable
    // because otherwise some prototype manipulation in
    // userland will fail
    enumerable: false,
    get: function () {
      return this._writableState.highWaterMark;
    }
  });
  
  // if we're already writing something, then just put this
  // in the queue, and wait our turn.  Otherwise, call _write
  // If we return false, then we need a drain event, so set that flag.
  function writeOrBuffer(stream, state, isBuf, chunk, encoding, cb) {
    if (!isBuf) {
      var newChunk = decodeChunk(state, chunk, encoding);
      if (chunk !== newChunk) {
        isBuf = true;
        encoding = 'buffer';
        chunk = newChunk;
      }
    }
    var len = state.objectMode ? 1 : chunk.length;
  
    state.length += len;
  
    var ret = state.length < state.highWaterMark;
    // we must ensure that previous needDrain will not be reset to false.
    if (!ret) state.needDrain = true;
  
    if (state.writing || state.corked) {
      var last = state.lastBufferedRequest;
      state.lastBufferedRequest = {
        chunk: chunk,
        encoding: encoding,
        isBuf: isBuf,
        callback: cb,
        next: null
      };
      if (last) {
        last.next = state.lastBufferedRequest;
      } else {
        state.bufferedRequest = state.lastBufferedRequest;
      }
      state.bufferedRequestCount += 1;
    } else {
      doWrite(stream, state, false, len, chunk, encoding, cb);
    }
  
    return ret;
  }
  
  function doWrite(stream, state, writev, len, chunk, encoding, cb) {
    state.writelen = len;
    state.writecb = cb;
    state.writing = true;
    state.sync = true;
    if (writev) stream._writev(chunk, state.onwrite);else stream._write(chunk, encoding, state.onwrite);
    state.sync = false;
  }
  
  function onwriteError(stream, state, sync, er, cb) {
    --state.pendingcb;
  
    if (sync) {
      // defer the callback if we are being called synchronously
      // to avoid piling up things on the stack
      pna.nextTick(cb, er);
      // this can emit finish, and it will always happen
      // after error
      pna.nextTick(finishMaybe, stream, state);
      stream._writableState.errorEmitted = true;
      stream.emit('error', er);
    } else {
      // the caller expect this to happen before if
      // it is async
      cb(er);
      stream._writableState.errorEmitted = true;
      stream.emit('error', er);
      // this can emit finish, but finish must
      // always follow error
      finishMaybe(stream, state);
    }
  }
  
  function onwriteStateUpdate(state) {
    state.writing = false;
    state.writecb = null;
    state.length -= state.writelen;
    state.writelen = 0;
  }
  
  function onwrite(stream, er) {
    var state = stream._writableState;
    var sync = state.sync;
    var cb = state.writecb;
  
    onwriteStateUpdate(state);
  
    if (er) onwriteError(stream, state, sync, er, cb);else {
      // Check if we're actually ready to finish, but don't emit yet
      var finished = needFinish(state);
  
      if (!finished && !state.corked && !state.bufferProcessing && state.bufferedRequest) {
        clearBuffer(stream, state);
      }
  
      if (sync) {
        /*<replacement>*/
        asyncWrite(afterWrite, stream, state, finished, cb);
        /*</replacement>*/
      } else {
        afterWrite(stream, state, finished, cb);
      }
    }
  }
  
  function afterWrite(stream, state, finished, cb) {
    if (!finished) onwriteDrain(stream, state);
    state.pendingcb--;
    cb();
    finishMaybe(stream, state);
  }
  
  // Must force callback to be called on nextTick, so that we don't
  // emit 'drain' before the write() consumer gets the 'false' return
  // value, and has a chance to attach a 'drain' listener.
  function onwriteDrain(stream, state) {
    if (state.length === 0 && state.needDrain) {
      state.needDrain = false;
      stream.emit('drain');
    }
  }
  
  // if there's something in the buffer waiting, then process it
  function clearBuffer(stream, state) {
    state.bufferProcessing = true;
    var entry = state.bufferedRequest;
  
    if (stream._writev && entry && entry.next) {
      // Fast case, write everything using _writev()
      var l = state.bufferedRequestCount;
      var buffer = new Array(l);
      var holder = state.corkedRequestsFree;
      holder.entry = entry;
  
      var count = 0;
      var allBuffers = true;
      while (entry) {
        buffer[count] = entry;
        if (!entry.isBuf) allBuffers = false;
        entry = entry.next;
        count += 1;
      }
      buffer.allBuffers = allBuffers;
  
      doWrite(stream, state, true, state.length, buffer, '', holder.finish);
  
      // doWrite is almost always async, defer these to save a bit of time
      // as the hot path ends with doWrite
      state.pendingcb++;
      state.lastBufferedRequest = null;
      if (holder.next) {
        state.corkedRequestsFree = holder.next;
        holder.next = null;
      } else {
        state.corkedRequestsFree = new CorkedRequest(state);
      }
      state.bufferedRequestCount = 0;
    } else {
      // Slow case, write chunks one-by-one
      while (entry) {
        var chunk = entry.chunk;
        var encoding = entry.encoding;
        var cb = entry.callback;
        var len = state.objectMode ? 1 : chunk.length;
  
        doWrite(stream, state, false, len, chunk, encoding, cb);
        entry = entry.next;
        state.bufferedRequestCount--;
        // if we didn't call the onwrite immediately, then
        // it means that we need to wait until it does.
        // also, that means that the chunk and cb are currently
        // being processed, so move the buffer counter past them.
        if (state.writing) {
          break;
        }
      }
  
      if (entry === null) state.lastBufferedRequest = null;
    }
  
    state.bufferedRequest = entry;
    state.bufferProcessing = false;
  }
  
  Writable.prototype._write = function (chunk, encoding, cb) {
    cb(new Error('_write() is not implemented'));
  };
  
  Writable.prototype._writev = null;
  
  Writable.prototype.end = function (chunk, encoding, cb) {
    var state = this._writableState;
  
    if (typeof chunk === 'function') {
      cb = chunk;
      chunk = null;
      encoding = null;
    } else if (typeof encoding === 'function') {
      cb = encoding;
      encoding = null;
    }
  
    if (chunk !== null && chunk !== undefined) this.write(chunk, encoding);
  
    // .end() fully uncorks
    if (state.corked) {
      state.corked = 1;
      this.uncork();
    }
  
    // ignore unnecessary end() calls.
    if (!state.ending && !state.finished) endWritable(this, state, cb);
  };
  
  function needFinish(state) {
    return state.ending && state.length === 0 && state.bufferedRequest === null && !state.finished && !state.writing;
  }
  function callFinal(stream, state) {
    stream._final(function (err) {
      state.pendingcb--;
      if (err) {
        stream.emit('error', err);
      }
      state.prefinished = true;
      stream.emit('prefinish');
      finishMaybe(stream, state);
    });
  }
  function prefinish(stream, state) {
    if (!state.prefinished && !state.finalCalled) {
      if (typeof stream._final === 'function') {
        state.pendingcb++;
        state.finalCalled = true;
        pna.nextTick(callFinal, stream, state);
      } else {
        state.prefinished = true;
        stream.emit('prefinish');
      }
    }
  }
  
  function finishMaybe(stream, state) {
    var need = needFinish(state);
    if (need) {
      prefinish(stream, state);
      if (state.pendingcb === 0) {
        state.finished = true;
        stream.emit('finish');
      }
    }
    return need;
  }
  
  function endWritable(stream, state, cb) {
    state.ending = true;
    finishMaybe(stream, state);
    if (cb) {
      if (state.finished) pna.nextTick(cb);else stream.once('finish', cb);
    }
    state.ended = true;
    stream.writable = false;
  }
  
  function onCorkedFinish(corkReq, state, err) {
    var entry = corkReq.entry;
    corkReq.entry = null;
    while (entry) {
      var cb = entry.callback;
      state.pendingcb--;
      cb(err);
      entry = entry.next;
    }
    if (state.corkedRequestsFree) {
      state.corkedRequestsFree.next = corkReq;
    } else {
      state.corkedRequestsFree = corkReq;
    }
  }
  
  Object.defineProperty(Writable.prototype, 'destroyed', {
    get: function () {
      if (this._writableState === undefined) {
        return false;
      }
      return this._writableState.destroyed;
    },
    set: function (value) {
      // we ignore the value if the stream
      // has not been initialized yet
      if (!this._writableState) {
        return;
      }
  
      // backward compatibility, the user is explicitly
      // managing destroyed
      this._writableState.destroyed = value;
    }
  });
  
  Writable.prototype.destroy = destroyImpl.destroy;
  Writable.prototype._undestroy = destroyImpl.undestroy;
  Writable.prototype._destroy = function (err, cb) {
    this.end();
    cb(err);
  };
  }).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {},require("timers").setImmediate)
  
  },{"./_stream_duplex":129,"./internal/streams/destroy":135,"./internal/streams/stream":136,"_process":125,"core-util-is":63,"inherits":68,"process-nextick-args":124,"safe-buffer":138,"timers":146,"util-deprecate":150}],134:[function(require,module,exports){
  'use strict';
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  var Buffer = require('safe-buffer').Buffer;
  var util = require('util');
  
  function copyBuffer(src, target, offset) {
    src.copy(target, offset);
  }
  
  module.exports = function () {
    function BufferList() {
      _classCallCheck(this, BufferList);
  
      this.head = null;
      this.tail = null;
      this.length = 0;
    }
  
    BufferList.prototype.push = function push(v) {
      var entry = { data: v, next: null };
      if (this.length > 0) this.tail.next = entry;else this.head = entry;
      this.tail = entry;
      ++this.length;
    };
  
    BufferList.prototype.unshift = function unshift(v) {
      var entry = { data: v, next: this.head };
      if (this.length === 0) this.tail = entry;
      this.head = entry;
      ++this.length;
    };
  
    BufferList.prototype.shift = function shift() {
      if (this.length === 0) return;
      var ret = this.head.data;
      if (this.length === 1) this.head = this.tail = null;else this.head = this.head.next;
      --this.length;
      return ret;
    };
  
    BufferList.prototype.clear = function clear() {
      this.head = this.tail = null;
      this.length = 0;
    };
  
    BufferList.prototype.join = function join(s) {
      if (this.length === 0) return '';
      var p = this.head;
      var ret = '' + p.data;
      while (p = p.next) {
        ret += s + p.data;
      }return ret;
    };
  
    BufferList.prototype.concat = function concat(n) {
      if (this.length === 0) return Buffer.alloc(0);
      if (this.length === 1) return this.head.data;
      var ret = Buffer.allocUnsafe(n >>> 0);
      var p = this.head;
      var i = 0;
      while (p) {
        copyBuffer(p.data, ret, i);
        i += p.data.length;
        p = p.next;
      }
      return ret;
    };
  
    return BufferList;
  }();
  
  if (util && util.inspect && util.inspect.custom) {
    module.exports.prototype[util.inspect.custom] = function () {
      var obj = util.inspect({ length: this.length });
      return this.constructor.name + ' ' + obj;
    };
  }
  },{"safe-buffer":138,"util":7}],135:[function(require,module,exports){
  'use strict';
  
  /*<replacement>*/
  
  var pna = require('process-nextick-args');
  /*</replacement>*/
  
  // undocumented cb() API, needed for core, not for public API
  function destroy(err, cb) {
    var _this = this;
  
    var readableDestroyed = this._readableState && this._readableState.destroyed;
    var writableDestroyed = this._writableState && this._writableState.destroyed;
  
    if (readableDestroyed || writableDestroyed) {
      if (cb) {
        cb(err);
      } else if (err && (!this._writableState || !this._writableState.errorEmitted)) {
        pna.nextTick(emitErrorNT, this, err);
      }
      return this;
    }
  
    // we set destroyed to true before firing error callbacks in order
    // to make it re-entrance safe in case destroy() is called within callbacks
  
    if (this._readableState) {
      this._readableState.destroyed = true;
    }
  
    // if this is a duplex stream mark the writable part as destroyed as well
    if (this._writableState) {
      this._writableState.destroyed = true;
    }
  
    this._destroy(err || null, function (err) {
      if (!cb && err) {
        pna.nextTick(emitErrorNT, _this, err);
        if (_this._writableState) {
          _this._writableState.errorEmitted = true;
        }
      } else if (cb) {
        cb(err);
      }
    });
  
    return this;
  }
  
  function undestroy() {
    if (this._readableState) {
      this._readableState.destroyed = false;
      this._readableState.reading = false;
      this._readableState.ended = false;
      this._readableState.endEmitted = false;
    }
  
    if (this._writableState) {
      this._writableState.destroyed = false;
      this._writableState.ended = false;
      this._writableState.ending = false;
      this._writableState.finished = false;
      this._writableState.errorEmitted = false;
    }
  }
  
  function emitErrorNT(self, err) {
    self.emit('error', err);
  }
  
  module.exports = {
    destroy: destroy,
    undestroy: undestroy
  };
  },{"process-nextick-args":124}],136:[function(require,module,exports){
  module.exports = require('events').EventEmitter;
  
  },{"events":64}],137:[function(require,module,exports){
  exports = module.exports = require('./lib/_stream_readable.js');
  exports.Stream = exports;
  exports.Readable = exports;
  exports.Writable = require('./lib/_stream_writable.js');
  exports.Duplex = require('./lib/_stream_duplex.js');
  exports.Transform = require('./lib/_stream_transform.js');
  exports.PassThrough = require('./lib/_stream_passthrough.js');
  
  },{"./lib/_stream_duplex.js":129,"./lib/_stream_passthrough.js":130,"./lib/_stream_readable.js":131,"./lib/_stream_transform.js":132,"./lib/_stream_writable.js":133}],138:[function(require,module,exports){
  /* eslint-disable node/no-deprecated-api */
  var buffer = require('buffer')
  var Buffer = buffer.Buffer
  
  // alternative to using Object.keys for old browsers
  function copyProps (src, dst) {
    for (var key in src) {
      dst[key] = src[key]
    }
  }
  if (Buffer.from && Buffer.alloc && Buffer.allocUnsafe && Buffer.allocUnsafeSlow) {
    module.exports = buffer
  } else {
    // Copy properties from require('buffer')
    copyProps(buffer, exports)
    exports.Buffer = SafeBuffer
  }
  
  function SafeBuffer (arg, encodingOrOffset, length) {
    return Buffer(arg, encodingOrOffset, length)
  }
  
  // Copy static methods from Buffer
  copyProps(Buffer, SafeBuffer)
  
  SafeBuffer.from = function (arg, encodingOrOffset, length) {
    if (typeof arg === 'number') {
      throw new TypeError('Argument must not be a number')
    }
    return Buffer(arg, encodingOrOffset, length)
  }
  
  SafeBuffer.alloc = function (size, fill, encoding) {
    if (typeof size !== 'number') {
      throw new TypeError('Argument must be a number')
    }
    var buf = Buffer(size)
    if (fill !== undefined) {
      if (typeof encoding === 'string') {
        buf.fill(fill, encoding)
      } else {
        buf.fill(fill)
      }
    } else {
      buf.fill(0)
    }
    return buf
  }
  
  SafeBuffer.allocUnsafe = function (size) {
    if (typeof size !== 'number') {
      throw new TypeError('Argument must be a number')
    }
    return Buffer(size)
  }
  
  SafeBuffer.allocUnsafeSlow = function (size) {
    if (typeof size !== 'number') {
      throw new TypeError('Argument must be a number')
    }
    return buffer.SlowBuffer(size)
  }
  
  },{"buffer":9}],139:[function(require,module,exports){
  (function (global){
  var ClientRequest = require('./lib/request')
  var response = require('./lib/response')
  var extend = require('xtend')
  var statusCodes = require('builtin-status-codes')
  var url = require('url')
  
  var http = exports
  
  http.request = function (opts, cb) {
    if (typeof opts === 'string')
      opts = url.parse(opts)
    else
      opts = extend(opts)
  
    // Normally, the page is loaded from http or https, so not specifying a protocol
    // will result in a (valid) protocol-relative url. However, this won't work if
    // the protocol is something else, like 'file:'
    var defaultProtocol = global.location.protocol.search(/^https?:$/) === -1 ? 'http:' : ''
  
    var protocol = opts.protocol || defaultProtocol
    var host = opts.hostname || opts.host
    var port = opts.port
    var path = opts.path || '/'
  
    // Necessary for IPv6 addresses
    if (host && host.indexOf(':') !== -1)
      host = '[' + host + ']'
  
    // This may be a relative url. The browser should always be able to interpret it correctly.
    opts.url = (host ? (protocol + '//' + host) : '') + (port ? ':' + port : '') + path
    opts.method = (opts.method || 'GET').toUpperCase()
    opts.headers = opts.headers || {}
  
    // Also valid opts.auth, opts.mode
  
    var req = new ClientRequest(opts)
    if (cb)
      req.on('response', cb)
    return req
  }
  
  http.get = function get (opts, cb) {
    var req = http.request(opts, cb)
    req.end()
    return req
  }
  
  http.ClientRequest = ClientRequest
  http.IncomingMessage = response.IncomingMessage
  
  http.Agent = function () {}
  http.Agent.defaultMaxSockets = 4
  
  http.globalAgent = new http.Agent()
  
  http.STATUS_CODES = statusCodes
  
  http.METHODS = [
    'CHECKOUT',
    'CONNECT',
    'COPY',
    'DELETE',
    'GET',
    'HEAD',
    'LOCK',
    'M-SEARCH',
    'MERGE',
    'MKACTIVITY',
    'MKCOL',
    'MOVE',
    'NOTIFY',
    'OPTIONS',
    'PATCH',
    'POST',
    'PROPFIND',
    'PROPPATCH',
    'PURGE',
    'PUT',
    'REPORT',
    'SEARCH',
    'SUBSCRIBE',
    'TRACE',
    'UNLOCK',
    'UNSUBSCRIBE'
  ]
  }).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{"./lib/request":141,"./lib/response":142,"builtin-status-codes":10,"url":148,"xtend":231}],140:[function(require,module,exports){
  (function (global){
  exports.fetch = isFunction(global.fetch) && isFunction(global.ReadableStream)
  
  exports.writableStream = isFunction(global.WritableStream)
  
  exports.abortController = isFunction(global.AbortController)
  
  exports.blobConstructor = false
  try {
    new Blob([new ArrayBuffer(1)])
    exports.blobConstructor = true
  } catch (e) {}
  
  // The xhr request to example.com may violate some restrictive CSP configurations,
  // so if we're running in a browser that supports `fetch`, avoid calling getXHR()
  // and assume support for certain features below.
  var xhr
  function getXHR () {
    // Cache the xhr value
    if (xhr !== undefined) return xhr
  
    if (global.XMLHttpRequest) {
      xhr = new global.XMLHttpRequest()
      // If XDomainRequest is available (ie only, where xhr might not work
      // cross domain), use the page location. Otherwise use example.com
      // Note: this doesn't actually make an http request.
      try {
        xhr.open('GET', global.XDomainRequest ? '/' : 'https://example.com')
      } catch(e) {
        xhr = null
      }
    } else {
      // Service workers don't have XHR
      xhr = null
    }
    return xhr
  }
  
  function checkTypeSupport (type) {
    var xhr = getXHR()
    if (!xhr) return false
    try {
      xhr.responseType = type
      return xhr.responseType === type
    } catch (e) {}
    return false
  }
  
  // For some strange reason, Safari 7.0 reports typeof global.ArrayBuffer === 'object'.
  // Safari 7.1 appears to have fixed this bug.
  var haveArrayBuffer = typeof global.ArrayBuffer !== 'undefined'
  var haveSlice = haveArrayBuffer && isFunction(global.ArrayBuffer.prototype.slice)
  
  // If fetch is supported, then arraybuffer will be supported too. Skip calling
  // checkTypeSupport(), since that calls getXHR().
  exports.arraybuffer = exports.fetch || (haveArrayBuffer && checkTypeSupport('arraybuffer'))
  
  // These next two tests unavoidably show warnings in Chrome. Since fetch will always
  // be used if it's available, just return false for these to avoid the warnings.
  exports.msstream = !exports.fetch && haveSlice && checkTypeSupport('ms-stream')
  exports.mozchunkedarraybuffer = !exports.fetch && haveArrayBuffer &&
    checkTypeSupport('moz-chunked-arraybuffer')
  
  // If fetch is supported, then overrideMimeType will be supported too. Skip calling
  // getXHR().
  exports.overrideMimeType = exports.fetch || (getXHR() ? isFunction(getXHR().overrideMimeType) : false)
  
  exports.vbArray = isFunction(global.VBArray)
  
  function isFunction (value) {
    return typeof value === 'function'
  }
  
  xhr = null // Help gc
  
  }).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{}],141:[function(require,module,exports){
  (function (process,global,Buffer){
  var capability = require('./capability')
  var inherits = require('inherits')
  var response = require('./response')
  var stream = require('readable-stream')
  var toArrayBuffer = require('to-arraybuffer')
  
  var IncomingMessage = response.IncomingMessage
  var rStates = response.readyStates
  
  function decideMode (preferBinary, useFetch) {
    if (capability.fetch && useFetch) {
      return 'fetch'
    } else if (capability.mozchunkedarraybuffer) {
      return 'moz-chunked-arraybuffer'
    } else if (capability.msstream) {
      return 'ms-stream'
    } else if (capability.arraybuffer && preferBinary) {
      return 'arraybuffer'
    } else if (capability.vbArray && preferBinary) {
      return 'text:vbarray'
    } else {
      return 'text'
    }
  }
  
  var ClientRequest = module.exports = function (opts) {
    var self = this
    stream.Writable.call(self)
  
    self._opts = opts
    self._body = []
    self._headers = {}
    if (opts.auth)
      self.setHeader('Authorization', 'Basic ' + new Buffer(opts.auth).toString('base64'))
    Object.keys(opts.headers).forEach(function (name) {
      self.setHeader(name, opts.headers[name])
    })
  
    var preferBinary
    var useFetch = true
    if (opts.mode === 'disable-fetch' || ('requestTimeout' in opts && !capability.abortController)) {
      // If the use of XHR should be preferred. Not typically needed.
      useFetch = false
      preferBinary = true
    } else if (opts.mode === 'prefer-streaming') {
      // If streaming is a high priority but binary compatibility and
      // the accuracy of the 'content-type' header aren't
      preferBinary = false
    } else if (opts.mode === 'allow-wrong-content-type') {
      // If streaming is more important than preserving the 'content-type' header
      preferBinary = !capability.overrideMimeType
    } else if (!opts.mode || opts.mode === 'default' || opts.mode === 'prefer-fast') {
      // Use binary if text streaming may corrupt data or the content-type header, or for speed
      preferBinary = true
    } else {
      throw new Error('Invalid value for opts.mode')
    }
    self._mode = decideMode(preferBinary, useFetch)
    self._fetchTimer = null
  
    self.on('finish', function () {
      self._onFinish()
    })
  }
  
  inherits(ClientRequest, stream.Writable)
  
  ClientRequest.prototype.setHeader = function (name, value) {
    var self = this
    var lowerName = name.toLowerCase()
    // This check is not necessary, but it prevents warnings from browsers about setting unsafe
    // headers. To be honest I'm not entirely sure hiding these warnings is a good thing, but
    // http-browserify did it, so I will too.
    if (unsafeHeaders.indexOf(lowerName) !== -1)
      return
  
    self._headers[lowerName] = {
      name: name,
      value: value
    }
  }
  
  ClientRequest.prototype.getHeader = function (name) {
    var header = this._headers[name.toLowerCase()]
    if (header)
      return header.value
    return null
  }
  
  ClientRequest.prototype.removeHeader = function (name) {
    var self = this
    delete self._headers[name.toLowerCase()]
  }
  
  ClientRequest.prototype._onFinish = function () {
    var self = this
  
    if (self._destroyed)
      return
    var opts = self._opts
  
    var headersObj = self._headers
    var body = null
    if (opts.method !== 'GET' && opts.method !== 'HEAD') {
      if (capability.arraybuffer) {
        body = toArrayBuffer(Buffer.concat(self._body))
      } else if (capability.blobConstructor) {
        body = new global.Blob(self._body.map(function (buffer) {
          return toArrayBuffer(buffer)
        }), {
          type: (headersObj['content-type'] || {}).value || ''
        })
      } else {
        // get utf8 string
        body = Buffer.concat(self._body).toString()
      }
    }
  
    // create flattened list of headers
    var headersList = []
    Object.keys(headersObj).forEach(function (keyName) {
      var name = headersObj[keyName].name
      var value = headersObj[keyName].value
      if (Array.isArray(value)) {
        value.forEach(function (v) {
          headersList.push([name, v])
        })
      } else {
        headersList.push([name, value])
      }
    })
  
    if (self._mode === 'fetch') {
      var signal = null
      var fetchTimer = null
      if (capability.abortController) {
        var controller = new AbortController()
        signal = controller.signal
        self._fetchAbortController = controller
  
        if ('requestTimeout' in opts && opts.requestTimeout !== 0) {
          self._fetchTimer = global.setTimeout(function () {
            self.emit('requestTimeout')
            if (self._fetchAbortController)
              self._fetchAbortController.abort()
          }, opts.requestTimeout)
        }
      }
  
      global.fetch(self._opts.url, {
        method: self._opts.method,
        headers: headersList,
        body: body || undefined,
        mode: 'cors',
        credentials: opts.withCredentials ? 'include' : 'same-origin',
        signal: signal
      }).then(function (response) {
        self._fetchResponse = response
        self._connect()
      }, function (reason) {
        global.clearTimeout(self._fetchTimer)
        if (!self._destroyed)
          self.emit('error', reason)
      })
    } else {
      var xhr = self._xhr = new global.XMLHttpRequest()
      try {
        xhr.open(self._opts.method, self._opts.url, true)
      } catch (err) {
        process.nextTick(function () {
          self.emit('error', err)
        })
        return
      }
  
      // Can't set responseType on really old browsers
      if ('responseType' in xhr)
        xhr.responseType = self._mode.split(':')[0]
  
      if ('withCredentials' in xhr)
        xhr.withCredentials = !!opts.withCredentials
  
      if (self._mode === 'text' && 'overrideMimeType' in xhr)
        xhr.overrideMimeType('text/plain; charset=x-user-defined')
  
      if ('requestTimeout' in opts) {
        xhr.timeout = opts.requestTimeout
        xhr.ontimeout = function () {
          self.emit('requestTimeout')
        }
      }
  
      headersList.forEach(function (header) {
        xhr.setRequestHeader(header[0], header[1])
      })
  
      self._response = null
      xhr.onreadystatechange = function () {
        switch (xhr.readyState) {
          case rStates.LOADING:
          case rStates.DONE:
            self._onXHRProgress()
            break
        }
      }
      // Necessary for streaming in Firefox, since xhr.response is ONLY defined
      // in onprogress, not in onreadystatechange with xhr.readyState = 3
      if (self._mode === 'moz-chunked-arraybuffer') {
        xhr.onprogress = function () {
          self._onXHRProgress()
        }
      }
  
      xhr.onerror = function () {
        if (self._destroyed)
          return
        self.emit('error', new Error('XHR error'))
      }
  
      try {
        xhr.send(body)
      } catch (err) {
        process.nextTick(function () {
          self.emit('error', err)
        })
        return
      }
    }
  }
  
  /**
   * Checks if xhr.status is readable and non-zero, indicating no error.
   * Even though the spec says it should be available in readyState 3,
   * accessing it throws an exception in IE8
   */
  function statusValid (xhr) {
    try {
      var status = xhr.status
      return (status !== null && status !== 0)
    } catch (e) {
      return false
    }
  }
  
  ClientRequest.prototype._onXHRProgress = function () {
    var self = this
  
    if (!statusValid(self._xhr) || self._destroyed)
      return
  
    if (!self._response)
      self._connect()
  
    self._response._onXHRProgress()
  }
  
  ClientRequest.prototype._connect = function () {
    var self = this
  
    if (self._destroyed)
      return
  
    self._response = new IncomingMessage(self._xhr, self._fetchResponse, self._mode, self._fetchTimer)
    self._response.on('error', function(err) {
      self.emit('error', err)
    })
  
    self.emit('response', self._response)
  }
  
  ClientRequest.prototype._write = function (chunk, encoding, cb) {
    var self = this
  
    self._body.push(chunk)
    cb()
  }
  
  ClientRequest.prototype.abort = ClientRequest.prototype.destroy = function () {
    var self = this
    self._destroyed = true
    global.clearTimeout(self._fetchTimer)
    if (self._response)
      self._response._destroyed = true
    if (self._xhr)
      self._xhr.abort()
    else if (self._fetchAbortController)
      self._fetchAbortController.abort()
  }
  
  ClientRequest.prototype.end = function (data, encoding, cb) {
    var self = this
    if (typeof data === 'function') {
      cb = data
      data = undefined
    }
  
    stream.Writable.prototype.end.call(self, data, encoding, cb)
  }
  
  ClientRequest.prototype.flushHeaders = function () {}
  ClientRequest.prototype.setTimeout = function () {}
  ClientRequest.prototype.setNoDelay = function () {}
  ClientRequest.prototype.setSocketKeepAlive = function () {}
  
  // Taken from http://www.w3.org/TR/XMLHttpRequest/#the-setrequestheader%28%29-method
  var unsafeHeaders = [
    'accept-charset',
    'accept-encoding',
    'access-control-request-headers',
    'access-control-request-method',
    'connection',
    'content-length',
    'cookie',
    'cookie2',
    'date',
    'dnt',
    'expect',
    'host',
    'keep-alive',
    'origin',
    'referer',
    'te',
    'trailer',
    'transfer-encoding',
    'upgrade',
    'via'
  ]
  
  }).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {},require("buffer").Buffer)
  
  },{"./capability":140,"./response":142,"_process":125,"buffer":9,"inherits":68,"readable-stream":137,"to-arraybuffer":147}],142:[function(require,module,exports){
  (function (process,global,Buffer){
  var capability = require('./capability')
  var inherits = require('inherits')
  var stream = require('readable-stream')
  
  var rStates = exports.readyStates = {
    UNSENT: 0,
    OPENED: 1,
    HEADERS_RECEIVED: 2,
    LOADING: 3,
    DONE: 4
  }
  
  var IncomingMessage = exports.IncomingMessage = function (xhr, response, mode, fetchTimer) {
    var self = this
    stream.Readable.call(self)
  
    self._mode = mode
    self.headers = {}
    self.rawHeaders = []
    self.trailers = {}
    self.rawTrailers = []
  
    // Fake the 'close' event, but only once 'end' fires
    self.on('end', function () {
      // The nextTick is necessary to prevent the 'request' module from causing an infinite loop
      process.nextTick(function () {
        self.emit('close')
      })
    })
  
    if (mode === 'fetch') {
      self._fetchResponse = response
  
      self.url = response.url
      self.statusCode = response.status
      self.statusMessage = response.statusText
      
      response.headers.forEach(function (header, key){
        self.headers[key.toLowerCase()] = header
        self.rawHeaders.push(key, header)
      })
  
      if (capability.writableStream) {
        var writable = new WritableStream({
          write: function (chunk) {
            return new Promise(function (resolve, reject) {
              if (self._destroyed) {
                reject()
              } else if(self.push(new Buffer(chunk))) {
                resolve()
              } else {
                self._resumeFetch = resolve
              }
            })
          },
          close: function () {
            global.clearTimeout(fetchTimer)
            if (!self._destroyed)
              self.push(null)
          },
          abort: function (err) {
            if (!self._destroyed)
              self.emit('error', err)
          }
        })
  
        try {
          response.body.pipeTo(writable).catch(function (err) {
            global.clearTimeout(fetchTimer)
            if (!self._destroyed)
              self.emit('error', err)
          })
          return
        } catch (e) {} // pipeTo method isn't defined. Can't find a better way to feature test this
      }
      // fallback for when writableStream or pipeTo aren't available
      var reader = response.body.getReader()
      function read () {
        reader.read().then(function (result) {
          if (self._destroyed)
            return
          if (result.done) {
            global.clearTimeout(fetchTimer)
            self.push(null)
            return
          }
          self.push(new Buffer(result.value))
          read()
        }).catch(function (err) {
          global.clearTimeout(fetchTimer)
          if (!self._destroyed)
            self.emit('error', err)
        })
      }
      read()
    } else {
      self._xhr = xhr
      self._pos = 0
  
      self.url = xhr.responseURL
      self.statusCode = xhr.status
      self.statusMessage = xhr.statusText
      var headers = xhr.getAllResponseHeaders().split(/\r?\n/)
      headers.forEach(function (header) {
        var matches = header.match(/^([^:]+):\s*(.*)/)
        if (matches) {
          var key = matches[1].toLowerCase()
          if (key === 'set-cookie') {
            if (self.headers[key] === undefined) {
              self.headers[key] = []
            }
            self.headers[key].push(matches[2])
          } else if (self.headers[key] !== undefined) {
            self.headers[key] += ', ' + matches[2]
          } else {
            self.headers[key] = matches[2]
          }
          self.rawHeaders.push(matches[1], matches[2])
        }
      })
  
      self._charset = 'x-user-defined'
      if (!capability.overrideMimeType) {
        var mimeType = self.rawHeaders['mime-type']
        if (mimeType) {
          var charsetMatch = mimeType.match(/;\s*charset=([^;])(;|$)/)
          if (charsetMatch) {
            self._charset = charsetMatch[1].toLowerCase()
          }
        }
        if (!self._charset)
          self._charset = 'utf-8' // best guess
      }
    }
  }
  
  inherits(IncomingMessage, stream.Readable)
  
  IncomingMessage.prototype._read = function () {
    var self = this
  
    var resolve = self._resumeFetch
    if (resolve) {
      self._resumeFetch = null
      resolve()
    }
  }
  
  IncomingMessage.prototype._onXHRProgress = function () {
    var self = this
  
    var xhr = self._xhr
  
    var response = null
    switch (self._mode) {
      case 'text:vbarray': // For IE9
        if (xhr.readyState !== rStates.DONE)
          break
        try {
          // This fails in IE8
          response = new global.VBArray(xhr.responseBody).toArray()
        } catch (e) {}
        if (response !== null) {
          self.push(new Buffer(response))
          break
        }
        // Falls through in IE8	
      case 'text':
        try { // This will fail when readyState = 3 in IE9. Switch mode and wait for readyState = 4
          response = xhr.responseText
        } catch (e) {
          self._mode = 'text:vbarray'
          break
        }
        if (response.length > self._pos) {
          var newData = response.substr(self._pos)
          if (self._charset === 'x-user-defined') {
            var buffer = new Buffer(newData.length)
            for (var i = 0; i < newData.length; i++)
              buffer[i] = newData.charCodeAt(i) & 0xff
  
            self.push(buffer)
          } else {
            self.push(newData, self._charset)
          }
          self._pos = response.length
        }
        break
      case 'arraybuffer':
        if (xhr.readyState !== rStates.DONE || !xhr.response)
          break
        response = xhr.response
        self.push(new Buffer(new Uint8Array(response)))
        break
      case 'moz-chunked-arraybuffer': // take whole
        response = xhr.response
        if (xhr.readyState !== rStates.LOADING || !response)
          break
        self.push(new Buffer(new Uint8Array(response)))
        break
      case 'ms-stream':
        response = xhr.response
        if (xhr.readyState !== rStates.LOADING)
          break
        var reader = new global.MSStreamReader()
        reader.onprogress = function () {
          if (reader.result.byteLength > self._pos) {
            self.push(new Buffer(new Uint8Array(reader.result.slice(self._pos))))
            self._pos = reader.result.byteLength
          }
        }
        reader.onload = function () {
          self.push(null)
        }
        // reader.onerror = ??? // TODO: this
        reader.readAsArrayBuffer(response)
        break
    }
  
    // The ms-stream case handles end separately in reader.onload()
    if (self._xhr.readyState === rStates.DONE && self._mode !== 'ms-stream') {
      self.push(null)
    }
  }
  
  }).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {},require("buffer").Buffer)
  
  },{"./capability":140,"_process":125,"buffer":9,"inherits":68,"readable-stream":137}],143:[function(require,module,exports){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  'use strict';
  
  /*<replacement>*/
  
  var Buffer = require('safe-buffer').Buffer;
  /*</replacement>*/
  
  var isEncoding = Buffer.isEncoding || function (encoding) {
    encoding = '' + encoding;
    switch (encoding && encoding.toLowerCase()) {
      case 'hex':case 'utf8':case 'utf-8':case 'ascii':case 'binary':case 'base64':case 'ucs2':case 'ucs-2':case 'utf16le':case 'utf-16le':case 'raw':
        return true;
      default:
        return false;
    }
  };
  
  function _normalizeEncoding(enc) {
    if (!enc) return 'utf8';
    var retried;
    while (true) {
      switch (enc) {
        case 'utf8':
        case 'utf-8':
          return 'utf8';
        case 'ucs2':
        case 'ucs-2':
        case 'utf16le':
        case 'utf-16le':
          return 'utf16le';
        case 'latin1':
        case 'binary':
          return 'latin1';
        case 'base64':
        case 'ascii':
        case 'hex':
          return enc;
        default:
          if (retried) return; // undefined
          enc = ('' + enc).toLowerCase();
          retried = true;
      }
    }
  };
  
  // Do not cache `Buffer.isEncoding` when checking encoding names as some
  // modules monkey-patch it to support additional encodings
  function normalizeEncoding(enc) {
    var nenc = _normalizeEncoding(enc);
    if (typeof nenc !== 'string' && (Buffer.isEncoding === isEncoding || !isEncoding(enc))) throw new Error('Unknown encoding: ' + enc);
    return nenc || enc;
  }
  
  // StringDecoder provides an interface for efficiently splitting a series of
  // buffers into a series of JS strings without breaking apart multi-byte
  // characters.
  exports.StringDecoder = StringDecoder;
  function StringDecoder(encoding) {
    this.encoding = normalizeEncoding(encoding);
    var nb;
    switch (this.encoding) {
      case 'utf16le':
        this.text = utf16Text;
        this.end = utf16End;
        nb = 4;
        break;
      case 'utf8':
        this.fillLast = utf8FillLast;
        nb = 4;
        break;
      case 'base64':
        this.text = base64Text;
        this.end = base64End;
        nb = 3;
        break;
      default:
        this.write = simpleWrite;
        this.end = simpleEnd;
        return;
    }
    this.lastNeed = 0;
    this.lastTotal = 0;
    this.lastChar = Buffer.allocUnsafe(nb);
  }
  
  StringDecoder.prototype.write = function (buf) {
    if (buf.length === 0) return '';
    var r;
    var i;
    if (this.lastNeed) {
      r = this.fillLast(buf);
      if (r === undefined) return '';
      i = this.lastNeed;
      this.lastNeed = 0;
    } else {
      i = 0;
    }
    if (i < buf.length) return r ? r + this.text(buf, i) : this.text(buf, i);
    return r || '';
  };
  
  StringDecoder.prototype.end = utf8End;
  
  // Returns only complete characters in a Buffer
  StringDecoder.prototype.text = utf8Text;
  
  // Attempts to complete a partial non-UTF-8 character using bytes from a Buffer
  StringDecoder.prototype.fillLast = function (buf) {
    if (this.lastNeed <= buf.length) {
      buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed);
      return this.lastChar.toString(this.encoding, 0, this.lastTotal);
    }
    buf.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, buf.length);
    this.lastNeed -= buf.length;
  };
  
  // Checks the type of a UTF-8 byte, whether it's ASCII, a leading byte, or a
  // continuation byte. If an invalid byte is detected, -2 is returned.
  function utf8CheckByte(byte) {
    if (byte <= 0x7F) return 0;else if (byte >> 5 === 0x06) return 2;else if (byte >> 4 === 0x0E) return 3;else if (byte >> 3 === 0x1E) return 4;
    return byte >> 6 === 0x02 ? -1 : -2;
  }
  
  // Checks at most 3 bytes at the end of a Buffer in order to detect an
  // incomplete multi-byte UTF-8 character. The total number of bytes (2, 3, or 4)
  // needed to complete the UTF-8 character (if applicable) are returned.
  function utf8CheckIncomplete(self, buf, i) {
    var j = buf.length - 1;
    if (j < i) return 0;
    var nb = utf8CheckByte(buf[j]);
    if (nb >= 0) {
      if (nb > 0) self.lastNeed = nb - 1;
      return nb;
    }
    if (--j < i || nb === -2) return 0;
    nb = utf8CheckByte(buf[j]);
    if (nb >= 0) {
      if (nb > 0) self.lastNeed = nb - 2;
      return nb;
    }
    if (--j < i || nb === -2) return 0;
    nb = utf8CheckByte(buf[j]);
    if (nb >= 0) {
      if (nb > 0) {
        if (nb === 2) nb = 0;else self.lastNeed = nb - 3;
      }
      return nb;
    }
    return 0;
  }
  
  // Validates as many continuation bytes for a multi-byte UTF-8 character as
  // needed or are available. If we see a non-continuation byte where we expect
  // one, we "replace" the validated continuation bytes we've seen so far with
  // a single UTF-8 replacement character ('\ufffd'), to match v8's UTF-8 decoding
  // behavior. The continuation byte check is included three times in the case
  // where all of the continuation bytes for a character exist in the same buffer.
  // It is also done this way as a slight performance increase instead of using a
  // loop.
  function utf8CheckExtraBytes(self, buf, p) {
    if ((buf[0] & 0xC0) !== 0x80) {
      self.lastNeed = 0;
      return '\ufffd';
    }
    if (self.lastNeed > 1 && buf.length > 1) {
      if ((buf[1] & 0xC0) !== 0x80) {
        self.lastNeed = 1;
        return '\ufffd';
      }
      if (self.lastNeed > 2 && buf.length > 2) {
        if ((buf[2] & 0xC0) !== 0x80) {
          self.lastNeed = 2;
          return '\ufffd';
        }
      }
    }
  }
  
  // Attempts to complete a multi-byte UTF-8 character using bytes from a Buffer.
  function utf8FillLast(buf) {
    var p = this.lastTotal - this.lastNeed;
    var r = utf8CheckExtraBytes(this, buf, p);
    if (r !== undefined) return r;
    if (this.lastNeed <= buf.length) {
      buf.copy(this.lastChar, p, 0, this.lastNeed);
      return this.lastChar.toString(this.encoding, 0, this.lastTotal);
    }
    buf.copy(this.lastChar, p, 0, buf.length);
    this.lastNeed -= buf.length;
  }
  
  // Returns all complete UTF-8 characters in a Buffer. If the Buffer ended on a
  // partial character, the character's bytes are buffered until the required
  // number of bytes are available.
  function utf8Text(buf, i) {
    var total = utf8CheckIncomplete(this, buf, i);
    if (!this.lastNeed) return buf.toString('utf8', i);
    this.lastTotal = total;
    var end = buf.length - (total - this.lastNeed);
    buf.copy(this.lastChar, 0, end);
    return buf.toString('utf8', i, end);
  }
  
  // For UTF-8, a replacement character is added when ending on a partial
  // character.
  function utf8End(buf) {
    var r = buf && buf.length ? this.write(buf) : '';
    if (this.lastNeed) return r + '\ufffd';
    return r;
  }
  
  // UTF-16LE typically needs two bytes per character, but even if we have an even
  // number of bytes available, we need to check if we end on a leading/high
  // surrogate. In that case, we need to wait for the next two bytes in order to
  // decode the last character properly.
  function utf16Text(buf, i) {
    if ((buf.length - i) % 2 === 0) {
      var r = buf.toString('utf16le', i);
      if (r) {
        var c = r.charCodeAt(r.length - 1);
        if (c >= 0xD800 && c <= 0xDBFF) {
          this.lastNeed = 2;
          this.lastTotal = 4;
          this.lastChar[0] = buf[buf.length - 2];
          this.lastChar[1] = buf[buf.length - 1];
          return r.slice(0, -1);
        }
      }
      return r;
    }
    this.lastNeed = 1;
    this.lastTotal = 2;
    this.lastChar[0] = buf[buf.length - 1];
    return buf.toString('utf16le', i, buf.length - 1);
  }
  
  // For UTF-16LE we do not explicitly append special replacement characters if we
  // end on a partial character, we simply let v8 handle that.
  function utf16End(buf) {
    var r = buf && buf.length ? this.write(buf) : '';
    if (this.lastNeed) {
      var end = this.lastTotal - this.lastNeed;
      return r + this.lastChar.toString('utf16le', 0, end);
    }
    return r;
  }
  
  function base64Text(buf, i) {
    var n = (buf.length - i) % 3;
    if (n === 0) return buf.toString('base64', i);
    this.lastNeed = 3 - n;
    this.lastTotal = 3;
    if (n === 1) {
      this.lastChar[0] = buf[buf.length - 1];
    } else {
      this.lastChar[0] = buf[buf.length - 2];
      this.lastChar[1] = buf[buf.length - 1];
    }
    return buf.toString('base64', i, buf.length - n);
  }
  
  function base64End(buf) {
    var r = buf && buf.length ? this.write(buf) : '';
    if (this.lastNeed) return r + this.lastChar.toString('base64', 0, 3 - this.lastNeed);
    return r;
  }
  
  // Pass bytes on through for single-byte encodings (e.g. ascii, latin1, hex)
  function simpleWrite(buf) {
    return buf.toString(this.encoding);
  }
  
  function simpleEnd(buf) {
    return buf && buf.length ? this.write(buf) : '';
  }
  },{"safe-buffer":138}],144:[function(require,module,exports){
  "use strict";
  
  module.exports = [
    "get", "put", "post", "delete", "options", "head", "patch"
  ];
  
  },{}],145:[function(require,module,exports){
  module.exports={
    "title": "A JSON Schema for Swagger 2.0 API.",
    "id": "http://swagger.io/v2/schema.json#",
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "required": [
      "swagger",
      "info",
      "paths"
    ],
    "additionalProperties": false,
    "patternProperties": {
      "^x-": {
        "$ref": "#/definitions/vendorExtension"
      }
    },
    "properties": {
      "swagger": {
        "type": "string",
        "enum": [
          "2.0"
        ],
        "description": "The Swagger version of this document."
      },
      "info": {
        "$ref": "#/definitions/info"
      },
      "host": {
        "type": "string",
        "pattern": "^[^{}/ :\\\\]+(?::\\d+)?$",
        "description": "The host (name or ip) of the API. Example: 'swagger.io'"
      },
      "basePath": {
        "type": "string",
        "pattern": "^/",
        "description": "The base path to the API. Example: '/api'."
      },
      "schemes": {
        "$ref": "#/definitions/schemesList"
      },
      "consumes": {
        "description": "A list of MIME types accepted by the API.",
        "$ref": "#/definitions/mediaTypeList"
      },
      "produces": {
        "description": "A list of MIME types the API can produce.",
        "$ref": "#/definitions/mediaTypeList"
      },
      "paths": {
        "$ref": "#/definitions/paths"
      },
      "definitions": {
        "$ref": "#/definitions/definitions"
      },
      "parameters": {
        "$ref": "#/definitions/parameterDefinitions"
      },
      "responses": {
        "$ref": "#/definitions/responseDefinitions"
      },
      "security": {
        "$ref": "#/definitions/security"
      },
      "securityDefinitions": {
        "$ref": "#/definitions/securityDefinitions"
      },
      "tags": {
        "type": "array",
        "items": {
          "$ref": "#/definitions/tag"
        },
        "uniqueItems": true
      },
      "externalDocs": {
        "$ref": "#/definitions/externalDocs"
      }
    },
    "definitions": {
      "info": {
        "type": "object",
        "description": "General information about the API.",
        "required": [
          "version",
          "title"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "properties": {
          "title": {
            "type": "string",
            "description": "A unique and precise title of the API."
          },
          "version": {
            "type": "string",
            "description": "A semantic version number of the API."
          },
          "description": {
            "type": "string",
            "description": "A longer description of the API. Should be different from the title.  GitHub Flavored Markdown is allowed."
          },
          "termsOfService": {
            "type": "string",
            "description": "The terms of service for the API."
          },
          "contact": {
            "$ref": "#/definitions/contact"
          },
          "license": {
            "$ref": "#/definitions/license"
          }
        }
      },
      "contact": {
        "type": "object",
        "description": "Contact information for the owners of the API.",
        "additionalProperties": false,
        "properties": {
          "name": {
            "type": "string",
            "description": "The identifying name of the contact person/organization."
          },
          "url": {
            "type": "string",
            "description": "The URL pointing to the contact information.",
            "format": "uri"
          },
          "email": {
            "type": "string",
            "description": "The email address of the contact person/organization.",
            "format": "email"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "license": {
        "type": "object",
        "required": [
          "name"
        ],
        "additionalProperties": false,
        "properties": {
          "name": {
            "type": "string",
            "description": "The name of the license type. It's encouraged to use an OSI compatible license."
          },
          "url": {
            "type": "string",
            "description": "The URL pointing to the license.",
            "format": "uri"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "paths": {
        "type": "object",
        "description": "Relative paths to the individual endpoints. They must be relative to the 'basePath'.",
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          },
          "^/": {
            "$ref": "#/definitions/pathItem"
          }
        },
        "additionalProperties": false
      },
      "definitions": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/schema"
        },
        "description": "One or more JSON objects describing the schemas being consumed and produced by the API."
      },
      "parameterDefinitions": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/parameter"
        },
        "description": "One or more JSON representations for parameters"
      },
      "responseDefinitions": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/response"
        },
        "description": "One or more JSON representations for parameters"
      },
      "externalDocs": {
        "type": "object",
        "additionalProperties": false,
        "description": "information about external documentation",
        "required": [
          "url"
        ],
        "properties": {
          "description": {
            "type": "string"
          },
          "url": {
            "type": "string",
            "format": "uri"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "examples": {
        "type": "object",
        "additionalProperties": true
      },
      "mimeType": {
        "type": "string",
        "description": "The MIME type of the HTTP message."
      },
      "operation": {
        "type": "object",
        "required": [
          "responses"
        ],
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "properties": {
          "tags": {
            "type": "array",
            "items": {
              "type": "string"
            },
            "uniqueItems": true
          },
          "summary": {
            "type": "string",
            "description": "A brief summary of the operation."
          },
          "description": {
            "type": "string",
            "description": "A longer description of the operation, GitHub Flavored Markdown is allowed."
          },
          "externalDocs": {
            "$ref": "#/definitions/externalDocs"
          },
          "operationId": {
            "type": "string",
            "description": "A unique identifier of the operation."
          },
          "produces": {
            "description": "A list of MIME types the API can produce.",
            "$ref": "#/definitions/mediaTypeList"
          },
          "consumes": {
            "description": "A list of MIME types the API can consume.",
            "$ref": "#/definitions/mediaTypeList"
          },
          "parameters": {
            "$ref": "#/definitions/parametersList"
          },
          "responses": {
            "$ref": "#/definitions/responses"
          },
          "schemes": {
            "$ref": "#/definitions/schemesList"
          },
          "deprecated": {
            "type": "boolean",
            "default": false
          },
          "security": {
            "$ref": "#/definitions/security"
          }
        }
      },
      "pathItem": {
        "type": "object",
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "properties": {
          "$ref": {
            "type": "string"
          },
          "get": {
            "$ref": "#/definitions/operation"
          },
          "put": {
            "$ref": "#/definitions/operation"
          },
          "post": {
            "$ref": "#/definitions/operation"
          },
          "delete": {
            "$ref": "#/definitions/operation"
          },
          "options": {
            "$ref": "#/definitions/operation"
          },
          "head": {
            "$ref": "#/definitions/operation"
          },
          "patch": {
            "$ref": "#/definitions/operation"
          },
          "parameters": {
            "$ref": "#/definitions/parametersList"
          }
        }
      },
      "responses": {
        "type": "object",
        "description": "Response objects names can either be any valid HTTP status code or 'default'.",
        "minProperties": 1,
        "additionalProperties": false,
        "patternProperties": {
          "^([0-9]{3})$|^(default)$": {
            "$ref": "#/definitions/responseValue"
          },
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "not": {
          "type": "object",
          "additionalProperties": false,
          "patternProperties": {
            "^x-": {
              "$ref": "#/definitions/vendorExtension"
            }
          }
        }
      },
      "responseValue": {
        "oneOf": [
          {
            "$ref": "#/definitions/response"
          },
          {
            "$ref": "#/definitions/jsonReference"
          }
        ]
      },
      "response": {
        "type": "object",
        "required": [
          "description"
        ],
        "properties": {
          "description": {
            "type": "string"
          },
          "schema": {
            "oneOf": [
              {
                "$ref": "#/definitions/schema"
              },
              {
                "$ref": "#/definitions/fileSchema"
              }
            ]
          },
          "headers": {
            "$ref": "#/definitions/headers"
          },
          "examples": {
            "$ref": "#/definitions/examples"
          }
        },
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "headers": {
        "type": "object",
        "additionalProperties": {
          "$ref": "#/definitions/header"
        }
      },
      "header": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "type"
        ],
        "properties": {
          "type": {
            "type": "string",
            "enum": [
              "string",
              "number",
              "integer",
              "boolean",
              "array"
            ]
          },
          "format": {
            "type": "string"
          },
          "items": {
            "$ref": "#/definitions/primitivesItems"
          },
          "collectionFormat": {
            "$ref": "#/definitions/collectionFormat"
          },
          "default": {
            "$ref": "#/definitions/default"
          },
          "maximum": {
            "$ref": "#/definitions/maximum"
          },
          "exclusiveMaximum": {
            "$ref": "#/definitions/exclusiveMaximum"
          },
          "minimum": {
            "$ref": "#/definitions/minimum"
          },
          "exclusiveMinimum": {
            "$ref": "#/definitions/exclusiveMinimum"
          },
          "maxLength": {
            "$ref": "#/definitions/maxLength"
          },
          "minLength": {
            "$ref": "#/definitions/minLength"
          },
          "pattern": {
            "$ref": "#/definitions/pattern"
          },
          "maxItems": {
            "$ref": "#/definitions/maxItems"
          },
          "minItems": {
            "$ref": "#/definitions/minItems"
          },
          "uniqueItems": {
            "$ref": "#/definitions/uniqueItems"
          },
          "enum": {
            "$ref": "#/definitions/enum"
          },
          "multipleOf": {
            "$ref": "#/definitions/multipleOf"
          },
          "description": {
            "type": "string"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "vendorExtension": {
        "description": "Any property starting with x- is valid.",
        "additionalProperties": true,
        "additionalItems": true
      },
      "bodyParameter": {
        "type": "object",
        "required": [
          "name",
          "in",
          "schema"
        ],
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "properties": {
          "description": {
            "type": "string",
            "description": "A brief description of the parameter. This could contain examples of use.  GitHub Flavored Markdown is allowed."
          },
          "name": {
            "type": "string",
            "description": "The name of the parameter."
          },
          "in": {
            "type": "string",
            "description": "Determines the location of the parameter.",
            "enum": [
              "body"
            ]
          },
          "required": {
            "type": "boolean",
            "description": "Determines whether or not this parameter is required or optional.",
            "default": false
          },
          "schema": {
            "$ref": "#/definitions/schema"
          }
        },
        "additionalProperties": false
      },
      "headerParameterSubSchema": {
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "properties": {
          "required": {
            "type": "boolean",
            "description": "Determines whether or not this parameter is required or optional.",
            "default": false
          },
          "in": {
            "type": "string",
            "description": "Determines the location of the parameter.",
            "enum": [
              "header"
            ]
          },
          "description": {
            "type": "string",
            "description": "A brief description of the parameter. This could contain examples of use.  GitHub Flavored Markdown is allowed."
          },
          "name": {
            "type": "string",
            "description": "The name of the parameter."
          },
          "type": {
            "type": "string",
            "enum": [
              "string",
              "number",
              "boolean",
              "integer",
              "array"
            ]
          },
          "format": {
            "type": "string"
          },
          "items": {
            "$ref": "#/definitions/primitivesItems"
          },
          "collectionFormat": {
            "$ref": "#/definitions/collectionFormat"
          },
          "default": {
            "$ref": "#/definitions/default"
          },
          "maximum": {
            "$ref": "#/definitions/maximum"
          },
          "exclusiveMaximum": {
            "$ref": "#/definitions/exclusiveMaximum"
          },
          "minimum": {
            "$ref": "#/definitions/minimum"
          },
          "exclusiveMinimum": {
            "$ref": "#/definitions/exclusiveMinimum"
          },
          "maxLength": {
            "$ref": "#/definitions/maxLength"
          },
          "minLength": {
            "$ref": "#/definitions/minLength"
          },
          "pattern": {
            "$ref": "#/definitions/pattern"
          },
          "maxItems": {
            "$ref": "#/definitions/maxItems"
          },
          "minItems": {
            "$ref": "#/definitions/minItems"
          },
          "uniqueItems": {
            "$ref": "#/definitions/uniqueItems"
          },
          "enum": {
            "$ref": "#/definitions/enum"
          },
          "multipleOf": {
            "$ref": "#/definitions/multipleOf"
          }
        }
      },
      "queryParameterSubSchema": {
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "properties": {
          "required": {
            "type": "boolean",
            "description": "Determines whether or not this parameter is required or optional.",
            "default": false
          },
          "in": {
            "type": "string",
            "description": "Determines the location of the parameter.",
            "enum": [
              "query"
            ]
          },
          "description": {
            "type": "string",
            "description": "A brief description of the parameter. This could contain examples of use.  GitHub Flavored Markdown is allowed."
          },
          "name": {
            "type": "string",
            "description": "The name of the parameter."
          },
          "allowEmptyValue": {
            "type": "boolean",
            "default": false,
            "description": "allows sending a parameter by name only or with an empty value."
          },
          "type": {
            "type": "string",
            "enum": [
              "string",
              "number",
              "boolean",
              "integer",
              "array"
            ]
          },
          "format": {
            "type": "string"
          },
          "items": {
            "$ref": "#/definitions/primitivesItems"
          },
          "collectionFormat": {
            "$ref": "#/definitions/collectionFormatWithMulti"
          },
          "default": {
            "$ref": "#/definitions/default"
          },
          "maximum": {
            "$ref": "#/definitions/maximum"
          },
          "exclusiveMaximum": {
            "$ref": "#/definitions/exclusiveMaximum"
          },
          "minimum": {
            "$ref": "#/definitions/minimum"
          },
          "exclusiveMinimum": {
            "$ref": "#/definitions/exclusiveMinimum"
          },
          "maxLength": {
            "$ref": "#/definitions/maxLength"
          },
          "minLength": {
            "$ref": "#/definitions/minLength"
          },
          "pattern": {
            "$ref": "#/definitions/pattern"
          },
          "maxItems": {
            "$ref": "#/definitions/maxItems"
          },
          "minItems": {
            "$ref": "#/definitions/minItems"
          },
          "uniqueItems": {
            "$ref": "#/definitions/uniqueItems"
          },
          "enum": {
            "$ref": "#/definitions/enum"
          },
          "multipleOf": {
            "$ref": "#/definitions/multipleOf"
          }
        }
      },
      "formDataParameterSubSchema": {
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "properties": {
          "required": {
            "type": "boolean",
            "description": "Determines whether or not this parameter is required or optional.",
            "default": false
          },
          "in": {
            "type": "string",
            "description": "Determines the location of the parameter.",
            "enum": [
              "formData"
            ]
          },
          "description": {
            "type": "string",
            "description": "A brief description of the parameter. This could contain examples of use.  GitHub Flavored Markdown is allowed."
          },
          "name": {
            "type": "string",
            "description": "The name of the parameter."
          },
          "allowEmptyValue": {
            "type": "boolean",
            "default": false,
            "description": "allows sending a parameter by name only or with an empty value."
          },
          "type": {
            "type": "string",
            "enum": [
              "string",
              "number",
              "boolean",
              "integer",
              "array",
              "file"
            ]
          },
          "format": {
            "type": "string"
          },
          "items": {
            "$ref": "#/definitions/primitivesItems"
          },
          "collectionFormat": {
            "$ref": "#/definitions/collectionFormatWithMulti"
          },
          "default": {
            "$ref": "#/definitions/default"
          },
          "maximum": {
            "$ref": "#/definitions/maximum"
          },
          "exclusiveMaximum": {
            "$ref": "#/definitions/exclusiveMaximum"
          },
          "minimum": {
            "$ref": "#/definitions/minimum"
          },
          "exclusiveMinimum": {
            "$ref": "#/definitions/exclusiveMinimum"
          },
          "maxLength": {
            "$ref": "#/definitions/maxLength"
          },
          "minLength": {
            "$ref": "#/definitions/minLength"
          },
          "pattern": {
            "$ref": "#/definitions/pattern"
          },
          "maxItems": {
            "$ref": "#/definitions/maxItems"
          },
          "minItems": {
            "$ref": "#/definitions/minItems"
          },
          "uniqueItems": {
            "$ref": "#/definitions/uniqueItems"
          },
          "enum": {
            "$ref": "#/definitions/enum"
          },
          "multipleOf": {
            "$ref": "#/definitions/multipleOf"
          }
        }
      },
      "pathParameterSubSchema": {
        "additionalProperties": false,
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "required": [
          "required"
        ],
        "properties": {
          "required": {
            "type": "boolean",
            "enum": [
              true
            ],
            "description": "Determines whether or not this parameter is required or optional."
          },
          "in": {
            "type": "string",
            "description": "Determines the location of the parameter.",
            "enum": [
              "path"
            ]
          },
          "description": {
            "type": "string",
            "description": "A brief description of the parameter. This could contain examples of use.  GitHub Flavored Markdown is allowed."
          },
          "name": {
            "type": "string",
            "description": "The name of the parameter."
          },
          "type": {
            "type": "string",
            "enum": [
              "string",
              "number",
              "boolean",
              "integer",
              "array"
            ]
          },
          "format": {
            "type": "string"
          },
          "items": {
            "$ref": "#/definitions/primitivesItems"
          },
          "collectionFormat": {
            "$ref": "#/definitions/collectionFormat"
          },
          "default": {
            "$ref": "#/definitions/default"
          },
          "maximum": {
            "$ref": "#/definitions/maximum"
          },
          "exclusiveMaximum": {
            "$ref": "#/definitions/exclusiveMaximum"
          },
          "minimum": {
            "$ref": "#/definitions/minimum"
          },
          "exclusiveMinimum": {
            "$ref": "#/definitions/exclusiveMinimum"
          },
          "maxLength": {
            "$ref": "#/definitions/maxLength"
          },
          "minLength": {
            "$ref": "#/definitions/minLength"
          },
          "pattern": {
            "$ref": "#/definitions/pattern"
          },
          "maxItems": {
            "$ref": "#/definitions/maxItems"
          },
          "minItems": {
            "$ref": "#/definitions/minItems"
          },
          "uniqueItems": {
            "$ref": "#/definitions/uniqueItems"
          },
          "enum": {
            "$ref": "#/definitions/enum"
          },
          "multipleOf": {
            "$ref": "#/definitions/multipleOf"
          }
        }
      },
      "nonBodyParameter": {
        "type": "object",
        "required": [
          "name",
          "in",
          "type"
        ],
        "oneOf": [
          {
            "$ref": "#/definitions/headerParameterSubSchema"
          },
          {
            "$ref": "#/definitions/formDataParameterSubSchema"
          },
          {
            "$ref": "#/definitions/queryParameterSubSchema"
          },
          {
            "$ref": "#/definitions/pathParameterSubSchema"
          }
        ]
      },
      "parameter": {
        "oneOf": [
          {
            "$ref": "#/definitions/bodyParameter"
          },
          {
            "$ref": "#/definitions/nonBodyParameter"
          }
        ]
      },
      "schema": {
        "type": "object",
        "description": "A deterministic version of a JSON Schema object.",
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "properties": {
          "$ref": {
            "type": "string"
          },
          "format": {
            "type": "string"
          },
          "title": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/title"
          },
          "description": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/description"
          },
          "default": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/default"
          },
          "multipleOf": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/multipleOf"
          },
          "maximum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/maximum"
          },
          "exclusiveMaximum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/exclusiveMaximum"
          },
          "minimum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/minimum"
          },
          "exclusiveMinimum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/exclusiveMinimum"
          },
          "maxLength": {
            "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveInteger"
          },
          "minLength": {
            "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveIntegerDefault0"
          },
          "pattern": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/pattern"
          },
          "maxItems": {
            "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveInteger"
          },
          "minItems": {
            "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveIntegerDefault0"
          },
          "uniqueItems": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/uniqueItems"
          },
          "maxProperties": {
            "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveInteger"
          },
          "minProperties": {
            "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveIntegerDefault0"
          },
          "required": {
            "$ref": "http://json-schema.org/draft-04/schema#/definitions/stringArray"
          },
          "enum": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/enum"
          },
          "additionalProperties": {
            "anyOf": [
              {
                "$ref": "#/definitions/schema"
              },
              {
                "type": "boolean"
              }
            ],
            "default": {}
          },
          "type": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/type"
          },
          "items": {
            "anyOf": [
              {
                "$ref": "#/definitions/schema"
              },
              {
                "type": "array",
                "minItems": 1,
                "items": {
                  "$ref": "#/definitions/schema"
                }
              }
            ],
            "default": {}
          },
          "allOf": {
            "type": "array",
            "minItems": 1,
            "items": {
              "$ref": "#/definitions/schema"
            }
          },
          "properties": {
            "type": "object",
            "additionalProperties": {
              "$ref": "#/definitions/schema"
            },
            "default": {}
          },
          "discriminator": {
            "type": "string"
          },
          "readOnly": {
            "type": "boolean",
            "default": false
          },
          "xml": {
            "$ref": "#/definitions/xml"
          },
          "externalDocs": {
            "$ref": "#/definitions/externalDocs"
          },
          "example": {}
        },
        "additionalProperties": false
      },
      "fileSchema": {
        "type": "object",
        "description": "A deterministic version of a JSON Schema object.",
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        },
        "required": [
          "type"
        ],
        "properties": {
          "format": {
            "type": "string"
          },
          "title": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/title"
          },
          "description": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/description"
          },
          "default": {
            "$ref": "http://json-schema.org/draft-04/schema#/properties/default"
          },
          "required": {
            "$ref": "http://json-schema.org/draft-04/schema#/definitions/stringArray"
          },
          "type": {
            "type": "string",
            "enum": [
              "file"
            ]
          },
          "readOnly": {
            "type": "boolean",
            "default": false
          },
          "externalDocs": {
            "$ref": "#/definitions/externalDocs"
          },
          "example": {}
        },
        "additionalProperties": false
      },
      "primitivesItems": {
        "type": "object",
        "additionalProperties": false,
        "properties": {
          "type": {
            "type": "string",
            "enum": [
              "string",
              "number",
              "integer",
              "boolean",
              "array"
            ]
          },
          "format": {
            "type": "string"
          },
          "items": {
            "$ref": "#/definitions/primitivesItems"
          },
          "collectionFormat": {
            "$ref": "#/definitions/collectionFormat"
          },
          "default": {
            "$ref": "#/definitions/default"
          },
          "maximum": {
            "$ref": "#/definitions/maximum"
          },
          "exclusiveMaximum": {
            "$ref": "#/definitions/exclusiveMaximum"
          },
          "minimum": {
            "$ref": "#/definitions/minimum"
          },
          "exclusiveMinimum": {
            "$ref": "#/definitions/exclusiveMinimum"
          },
          "maxLength": {
            "$ref": "#/definitions/maxLength"
          },
          "minLength": {
            "$ref": "#/definitions/minLength"
          },
          "pattern": {
            "$ref": "#/definitions/pattern"
          },
          "maxItems": {
            "$ref": "#/definitions/maxItems"
          },
          "minItems": {
            "$ref": "#/definitions/minItems"
          },
          "uniqueItems": {
            "$ref": "#/definitions/uniqueItems"
          },
          "enum": {
            "$ref": "#/definitions/enum"
          },
          "multipleOf": {
            "$ref": "#/definitions/multipleOf"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "security": {
        "type": "array",
        "items": {
          "$ref": "#/definitions/securityRequirement"
        },
        "uniqueItems": true
      },
      "securityRequirement": {
        "type": "object",
        "additionalProperties": {
          "type": "array",
          "items": {
            "type": "string"
          },
          "uniqueItems": true
        }
      },
      "xml": {
        "type": "object",
        "additionalProperties": false,
        "properties": {
          "name": {
            "type": "string"
          },
          "namespace": {
            "type": "string"
          },
          "prefix": {
            "type": "string"
          },
          "attribute": {
            "type": "boolean",
            "default": false
          },
          "wrapped": {
            "type": "boolean",
            "default": false
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "tag": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "name"
        ],
        "properties": {
          "name": {
            "type": "string"
          },
          "description": {
            "type": "string"
          },
          "externalDocs": {
            "$ref": "#/definitions/externalDocs"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "securityDefinitions": {
        "type": "object",
        "additionalProperties": {
          "oneOf": [
            {
              "$ref": "#/definitions/basicAuthenticationSecurity"
            },
            {
              "$ref": "#/definitions/apiKeySecurity"
            },
            {
              "$ref": "#/definitions/oauth2ImplicitSecurity"
            },
            {
              "$ref": "#/definitions/oauth2PasswordSecurity"
            },
            {
              "$ref": "#/definitions/oauth2ApplicationSecurity"
            },
            {
              "$ref": "#/definitions/oauth2AccessCodeSecurity"
            }
          ]
        }
      },
      "basicAuthenticationSecurity": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "type"
        ],
        "properties": {
          "type": {
            "type": "string",
            "enum": [
              "basic"
            ]
          },
          "description": {
            "type": "string"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "apiKeySecurity": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "type",
          "name",
          "in"
        ],
        "properties": {
          "type": {
            "type": "string",
            "enum": [
              "apiKey"
            ]
          },
          "name": {
            "type": "string"
          },
          "in": {
            "type": "string",
            "enum": [
              "header",
              "query"
            ]
          },
          "description": {
            "type": "string"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "oauth2ImplicitSecurity": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "type",
          "flow",
          "authorizationUrl"
        ],
        "properties": {
          "type": {
            "type": "string",
            "enum": [
              "oauth2"
            ]
          },
          "flow": {
            "type": "string",
            "enum": [
              "implicit"
            ]
          },
          "scopes": {
            "$ref": "#/definitions/oauth2Scopes"
          },
          "authorizationUrl": {
            "type": "string",
            "format": "uri"
          },
          "description": {
            "type": "string"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "oauth2PasswordSecurity": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "type",
          "flow",
          "tokenUrl"
        ],
        "properties": {
          "type": {
            "type": "string",
            "enum": [
              "oauth2"
            ]
          },
          "flow": {
            "type": "string",
            "enum": [
              "password"
            ]
          },
          "scopes": {
            "$ref": "#/definitions/oauth2Scopes"
          },
          "tokenUrl": {
            "type": "string",
            "format": "uri"
          },
          "description": {
            "type": "string"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "oauth2ApplicationSecurity": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "type",
          "flow",
          "tokenUrl"
        ],
        "properties": {
          "type": {
            "type": "string",
            "enum": [
              "oauth2"
            ]
          },
          "flow": {
            "type": "string",
            "enum": [
              "application"
            ]
          },
          "scopes": {
            "$ref": "#/definitions/oauth2Scopes"
          },
          "tokenUrl": {
            "type": "string",
            "format": "uri"
          },
          "description": {
            "type": "string"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "oauth2AccessCodeSecurity": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "type",
          "flow",
          "authorizationUrl",
          "tokenUrl"
        ],
        "properties": {
          "type": {
            "type": "string",
            "enum": [
              "oauth2"
            ]
          },
          "flow": {
            "type": "string",
            "enum": [
              "accessCode"
            ]
          },
          "scopes": {
            "$ref": "#/definitions/oauth2Scopes"
          },
          "authorizationUrl": {
            "type": "string",
            "format": "uri"
          },
          "tokenUrl": {
            "type": "string",
            "format": "uri"
          },
          "description": {
            "type": "string"
          }
        },
        "patternProperties": {
          "^x-": {
            "$ref": "#/definitions/vendorExtension"
          }
        }
      },
      "oauth2Scopes": {
        "type": "object",
        "additionalProperties": {
          "type": "string"
        }
      },
      "mediaTypeList": {
        "type": "array",
        "items": {
          "$ref": "#/definitions/mimeType"
        },
        "uniqueItems": true
      },
      "parametersList": {
        "type": "array",
        "description": "The parameters needed to send a valid API call.",
        "additionalItems": false,
        "items": {
          "oneOf": [
            {
              "$ref": "#/definitions/parameter"
            },
            {
              "$ref": "#/definitions/jsonReference"
            }
          ]
        },
        "uniqueItems": true
      },
      "schemesList": {
        "type": "array",
        "description": "The transfer protocol of the API.",
        "items": {
          "type": "string",
          "enum": [
            "http",
            "https",
            "ws",
            "wss"
          ]
        },
        "uniqueItems": true
      },
      "collectionFormat": {
        "type": "string",
        "enum": [
          "csv",
          "ssv",
          "tsv",
          "pipes"
        ],
        "default": "csv"
      },
      "collectionFormatWithMulti": {
        "type": "string",
        "enum": [
          "csv",
          "ssv",
          "tsv",
          "pipes",
          "multi"
        ],
        "default": "csv"
      },
      "title": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/title"
      },
      "description": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/description"
      },
      "default": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/default"
      },
      "multipleOf": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/multipleOf"
      },
      "maximum": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/maximum"
      },
      "exclusiveMaximum": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/exclusiveMaximum"
      },
      "minimum": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/minimum"
      },
      "exclusiveMinimum": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/exclusiveMinimum"
      },
      "maxLength": {
        "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveInteger"
      },
      "minLength": {
        "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveIntegerDefault0"
      },
      "pattern": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/pattern"
      },
      "maxItems": {
        "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveInteger"
      },
      "minItems": {
        "$ref": "http://json-schema.org/draft-04/schema#/definitions/positiveIntegerDefault0"
      },
      "uniqueItems": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/uniqueItems"
      },
      "enum": {
        "$ref": "http://json-schema.org/draft-04/schema#/properties/enum"
      },
      "jsonReference": {
        "type": "object",
        "required": [
          "$ref"
        ],
        "additionalProperties": false,
        "properties": {
          "$ref": {
            "type": "string"
          }
        }
      }
    }
  }
  },{}],146:[function(require,module,exports){
  (function (setImmediate,clearImmediate){
  var nextTick = require('process/browser.js').nextTick;
  var apply = Function.prototype.apply;
  var slice = Array.prototype.slice;
  var immediateIds = {};
  var nextImmediateId = 0;
  
  // DOM APIs, for completeness
  
  exports.setTimeout = function() {
    return new Timeout(apply.call(setTimeout, window, arguments), clearTimeout);
  };
  exports.setInterval = function() {
    return new Timeout(apply.call(setInterval, window, arguments), clearInterval);
  };
  exports.clearTimeout =
  exports.clearInterval = function(timeout) { timeout.close(); };
  
  function Timeout(id, clearFn) {
    this._id = id;
    this._clearFn = clearFn;
  }
  Timeout.prototype.unref = Timeout.prototype.ref = function() {};
  Timeout.prototype.close = function() {
    this._clearFn.call(window, this._id);
  };
  
  // Does not start the time, just sets up the members needed.
  exports.enroll = function(item, msecs) {
    clearTimeout(item._idleTimeoutId);
    item._idleTimeout = msecs;
  };
  
  exports.unenroll = function(item) {
    clearTimeout(item._idleTimeoutId);
    item._idleTimeout = -1;
  };
  
  exports._unrefActive = exports.active = function(item) {
    clearTimeout(item._idleTimeoutId);
  
    var msecs = item._idleTimeout;
    if (msecs >= 0) {
      item._idleTimeoutId = setTimeout(function onTimeout() {
        if (item._onTimeout)
          item._onTimeout();
      }, msecs);
    }
  };
  
  // That's not how node.js implements it but the exposed api is the same.
  exports.setImmediate = typeof setImmediate === "function" ? setImmediate : function(fn) {
    var id = nextImmediateId++;
    var args = arguments.length < 2 ? false : slice.call(arguments, 1);
  
    immediateIds[id] = true;
  
    nextTick(function onNextTick() {
      if (immediateIds[id]) {
        // fn.call() is faster so we optimize for the common use-case
        // @see http://jsperf.com/call-apply-segu
        if (args) {
          fn.apply(null, args);
        } else {
          fn.call(null);
        }
        // Prevent ids from leaking
        exports.clearImmediate(id);
      }
    });
  
    return id;
  };
  
  exports.clearImmediate = typeof clearImmediate === "function" ? clearImmediate : function(id) {
    delete immediateIds[id];
  };
  }).call(this,require("timers").setImmediate,require("timers").clearImmediate)
  
  },{"process/browser.js":125,"timers":146}],147:[function(require,module,exports){
  var Buffer = require('buffer').Buffer
  
  module.exports = function (buf) {
    // If the buffer is backed by a Uint8Array, a faster version will work
    if (buf instanceof Uint8Array) {
      // If the buffer isn't a subarray, return the underlying ArrayBuffer
      if (buf.byteOffset === 0 && buf.byteLength === buf.buffer.byteLength) {
        return buf.buffer
      } else if (typeof buf.buffer.slice === 'function') {
        // Otherwise we need to get a proper copy
        return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength)
      }
    }
  
    if (Buffer.isBuffer(buf)) {
      // This is the slow version that will work with any Buffer
      // implementation (even in old browsers)
      var arrayCopy = new Uint8Array(buf.length)
      var len = buf.length
      for (var i = 0; i < len; i++) {
        arrayCopy[i] = buf[i]
      }
      return arrayCopy.buffer
    } else {
      throw new Error('Argument must be a Buffer')
    }
  }
  
  },{"buffer":9}],148:[function(require,module,exports){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  'use strict';
  
  var punycode = require('punycode');
  var util = require('./util');
  
  exports.parse = urlParse;
  exports.resolve = urlResolve;
  exports.resolveObject = urlResolveObject;
  exports.format = urlFormat;
  
  exports.Url = Url;
  
  function Url() {
    this.protocol = null;
    this.slashes = null;
    this.auth = null;
    this.host = null;
    this.port = null;
    this.hostname = null;
    this.hash = null;
    this.search = null;
    this.query = null;
    this.pathname = null;
    this.path = null;
    this.href = null;
  }
  
  // Reference: RFC 3986, RFC 1808, RFC 2396
  
  // define these here so at least they only have to be
  // compiled once on the first module load.
  var protocolPattern = /^([a-z0-9.+-]+:)/i,
      portPattern = /:[0-9]*$/,
  
      // Special case for a simple path URL
      simplePathPattern = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,
  
      // RFC 2396: characters reserved for delimiting URLs.
      // We actually just auto-escape these.
      delims = ['<', '>', '"', '`', ' ', '\r', '\n', '\t'],
  
      // RFC 2396: characters not allowed for various reasons.
      unwise = ['{', '}', '|', '\\', '^', '`'].concat(delims),
  
      // Allowed by RFCs, but cause of XSS attacks.  Always escape these.
      autoEscape = ['\''].concat(unwise),
      // Characters that are never ever allowed in a hostname.
      // Note that any invalid chars are also handled, but these
      // are the ones that are *expected* to be seen, so we fast-path
      // them.
      nonHostChars = ['%', '/', '?', ';', '#'].concat(autoEscape),
      hostEndingChars = ['/', '?', '#'],
      hostnameMaxLen = 255,
      hostnamePartPattern = /^[+a-z0-9A-Z_-]{0,63}$/,
      hostnamePartStart = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,
      // protocols that can allow "unsafe" and "unwise" chars.
      unsafeProtocol = {
        'javascript': true,
        'javascript:': true
      },
      // protocols that never have a hostname.
      hostlessProtocol = {
        'javascript': true,
        'javascript:': true
      },
      // protocols that always contain a // bit.
      slashedProtocol = {
        'http': true,
        'https': true,
        'ftp': true,
        'gopher': true,
        'file': true,
        'http:': true,
        'https:': true,
        'ftp:': true,
        'gopher:': true,
        'file:': true
      },
      querystring = require('querystring');
  
  function urlParse(url, parseQueryString, slashesDenoteHost) {
    if (url && util.isObject(url) && url instanceof Url) return url;
  
    var u = new Url;
    u.parse(url, parseQueryString, slashesDenoteHost);
    return u;
  }
  
  Url.prototype.parse = function(url, parseQueryString, slashesDenoteHost) {
    if (!util.isString(url)) {
      throw new TypeError("Parameter 'url' must be a string, not " + typeof url);
    }
  
    // Copy chrome, IE, opera backslash-handling behavior.
    // Back slashes before the query string get converted to forward slashes
    // See: https://code.google.com/p/chromium/issues/detail?id=25916
    var queryIndex = url.indexOf('?'),
        splitter =
            (queryIndex !== -1 && queryIndex < url.indexOf('#')) ? '?' : '#',
        uSplit = url.split(splitter),
        slashRegex = /\\/g;
    uSplit[0] = uSplit[0].replace(slashRegex, '/');
    url = uSplit.join(splitter);
  
    var rest = url;
  
    // trim before proceeding.
    // This is to support parse stuff like "  http://foo.com  \n"
    rest = rest.trim();
  
    if (!slashesDenoteHost && url.split('#').length === 1) {
      // Try fast path regexp
      var simplePath = simplePathPattern.exec(rest);
      if (simplePath) {
        this.path = rest;
        this.href = rest;
        this.pathname = simplePath[1];
        if (simplePath[2]) {
          this.search = simplePath[2];
          if (parseQueryString) {
            this.query = querystring.parse(this.search.substr(1));
          } else {
            this.query = this.search.substr(1);
          }
        } else if (parseQueryString) {
          this.search = '';
          this.query = {};
        }
        return this;
      }
    }
  
    var proto = protocolPattern.exec(rest);
    if (proto) {
      proto = proto[0];
      var lowerProto = proto.toLowerCase();
      this.protocol = lowerProto;
      rest = rest.substr(proto.length);
    }
  
    // figure out if it's got a host
    // user@server is *always* interpreted as a hostname, and url
    // resolution will treat //foo/bar as host=foo,path=bar because that's
    // how the browser resolves relative URLs.
    if (slashesDenoteHost || proto || rest.match(/^\/\/[^@\/]+@[^@\/]+/)) {
      var slashes = rest.substr(0, 2) === '//';
      if (slashes && !(proto && hostlessProtocol[proto])) {
        rest = rest.substr(2);
        this.slashes = true;
      }
    }
  
    if (!hostlessProtocol[proto] &&
        (slashes || (proto && !slashedProtocol[proto]))) {
  
      // there's a hostname.
      // the first instance of /, ?, ;, or # ends the host.
      //
      // If there is an @ in the hostname, then non-host chars *are* allowed
      // to the left of the last @ sign, unless some host-ending character
      // comes *before* the @-sign.
      // URLs are obnoxious.
      //
      // ex:
      // http://a@b@c/ => user:a@b host:c
      // http://a@b?@c => user:a host:c path:/?@c
  
      // v0.12 TODO(isaacs): This is not quite how Chrome does things.
      // Review our test case against browsers more comprehensively.
  
      // find the first instance of any hostEndingChars
      var hostEnd = -1;
      for (var i = 0; i < hostEndingChars.length; i++) {
        var hec = rest.indexOf(hostEndingChars[i]);
        if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
          hostEnd = hec;
      }
  
      // at this point, either we have an explicit point where the
      // auth portion cannot go past, or the last @ char is the decider.
      var auth, atSign;
      if (hostEnd === -1) {
        // atSign can be anywhere.
        atSign = rest.lastIndexOf('@');
      } else {
        // atSign must be in auth portion.
        // http://a@b/c@d => host:b auth:a path:/c@d
        atSign = rest.lastIndexOf('@', hostEnd);
      }
  
      // Now we have a portion which is definitely the auth.
      // Pull that off.
      if (atSign !== -1) {
        auth = rest.slice(0, atSign);
        rest = rest.slice(atSign + 1);
        this.auth = decodeURIComponent(auth);
      }
  
      // the host is the remaining to the left of the first non-host char
      hostEnd = -1;
      for (var i = 0; i < nonHostChars.length; i++) {
        var hec = rest.indexOf(nonHostChars[i]);
        if (hec !== -1 && (hostEnd === -1 || hec < hostEnd))
          hostEnd = hec;
      }
      // if we still have not hit it, then the entire thing is a host.
      if (hostEnd === -1)
        hostEnd = rest.length;
  
      this.host = rest.slice(0, hostEnd);
      rest = rest.slice(hostEnd);
  
      // pull out port.
      this.parseHost();
  
      // we've indicated that there is a hostname,
      // so even if it's empty, it has to be present.
      this.hostname = this.hostname || '';
  
      // if hostname begins with [ and ends with ]
      // assume that it's an IPv6 address.
      var ipv6Hostname = this.hostname[0] === '[' &&
          this.hostname[this.hostname.length - 1] === ']';
  
      // validate a little.
      if (!ipv6Hostname) {
        var hostparts = this.hostname.split(/\./);
        for (var i = 0, l = hostparts.length; i < l; i++) {
          var part = hostparts[i];
          if (!part) continue;
          if (!part.match(hostnamePartPattern)) {
            var newpart = '';
            for (var j = 0, k = part.length; j < k; j++) {
              if (part.charCodeAt(j) > 127) {
                // we replace non-ASCII char with a temporary placeholder
                // we need this to make sure size of hostname is not
                // broken by replacing non-ASCII by nothing
                newpart += 'x';
              } else {
                newpart += part[j];
              }
            }
            // we test again with ASCII char only
            if (!newpart.match(hostnamePartPattern)) {
              var validParts = hostparts.slice(0, i);
              var notHost = hostparts.slice(i + 1);
              var bit = part.match(hostnamePartStart);
              if (bit) {
                validParts.push(bit[1]);
                notHost.unshift(bit[2]);
              }
              if (notHost.length) {
                rest = '/' + notHost.join('.') + rest;
              }
              this.hostname = validParts.join('.');
              break;
            }
          }
        }
      }
  
      if (this.hostname.length > hostnameMaxLen) {
        this.hostname = '';
      } else {
        // hostnames are always lower case.
        this.hostname = this.hostname.toLowerCase();
      }
  
      if (!ipv6Hostname) {
        // IDNA Support: Returns a punycoded representation of "domain".
        // It only converts parts of the domain name that
        // have non-ASCII characters, i.e. it doesn't matter if
        // you call it with a domain that already is ASCII-only.
        this.hostname = punycode.toASCII(this.hostname);
      }
  
      var p = this.port ? ':' + this.port : '';
      var h = this.hostname || '';
      this.host = h + p;
      this.href += this.host;
  
      // strip [ and ] from the hostname
      // the host field still retains them, though
      if (ipv6Hostname) {
        this.hostname = this.hostname.substr(1, this.hostname.length - 2);
        if (rest[0] !== '/') {
          rest = '/' + rest;
        }
      }
    }
  
    // now rest is set to the post-host stuff.
    // chop off any delim chars.
    if (!unsafeProtocol[lowerProto]) {
  
      // First, make 100% sure that any "autoEscape" chars get
      // escaped, even if encodeURIComponent doesn't think they
      // need to be.
      for (var i = 0, l = autoEscape.length; i < l; i++) {
        var ae = autoEscape[i];
        if (rest.indexOf(ae) === -1)
          continue;
        var esc = encodeURIComponent(ae);
        if (esc === ae) {
          esc = escape(ae);
        }
        rest = rest.split(ae).join(esc);
      }
    }
  
  
    // chop off from the tail first.
    var hash = rest.indexOf('#');
    if (hash !== -1) {
      // got a fragment string.
      this.hash = rest.substr(hash);
      rest = rest.slice(0, hash);
    }
    var qm = rest.indexOf('?');
    if (qm !== -1) {
      this.search = rest.substr(qm);
      this.query = rest.substr(qm + 1);
      if (parseQueryString) {
        this.query = querystring.parse(this.query);
      }
      rest = rest.slice(0, qm);
    } else if (parseQueryString) {
      // no query string, but parseQueryString still requested
      this.search = '';
      this.query = {};
    }
    if (rest) this.pathname = rest;
    if (slashedProtocol[lowerProto] &&
        this.hostname && !this.pathname) {
      this.pathname = '/';
    }
  
    //to support http.request
    if (this.pathname || this.search) {
      var p = this.pathname || '';
      var s = this.search || '';
      this.path = p + s;
    }
  
    // finally, reconstruct the href based on what has been validated.
    this.href = this.format();
    return this;
  };
  
  // format a parsed object into a url string
  function urlFormat(obj) {
    // ensure it's an object, and not a string url.
    // If it's an obj, this is a no-op.
    // this way, you can call url_format() on strings
    // to clean up potentially wonky urls.
    if (util.isString(obj)) obj = urlParse(obj);
    if (!(obj instanceof Url)) return Url.prototype.format.call(obj);
    return obj.format();
  }
  
  Url.prototype.format = function() {
    var auth = this.auth || '';
    if (auth) {
      auth = encodeURIComponent(auth);
      auth = auth.replace(/%3A/i, ':');
      auth += '@';
    }
  
    var protocol = this.protocol || '',
        pathname = this.pathname || '',
        hash = this.hash || '',
        host = false,
        query = '';
  
    if (this.host) {
      host = auth + this.host;
    } else if (this.hostname) {
      host = auth + (this.hostname.indexOf(':') === -1 ?
          this.hostname :
          '[' + this.hostname + ']');
      if (this.port) {
        host += ':' + this.port;
      }
    }
  
    if (this.query &&
        util.isObject(this.query) &&
        Object.keys(this.query).length) {
      query = querystring.stringify(this.query);
    }
  
    var search = this.search || (query && ('?' + query)) || '';
  
    if (protocol && protocol.substr(-1) !== ':') protocol += ':';
  
    // only the slashedProtocols get the //.  Not mailto:, xmpp:, etc.
    // unless they had them to begin with.
    if (this.slashes ||
        (!protocol || slashedProtocol[protocol]) && host !== false) {
      host = '//' + (host || '');
      if (pathname && pathname.charAt(0) !== '/') pathname = '/' + pathname;
    } else if (!host) {
      host = '';
    }
  
    if (hash && hash.charAt(0) !== '#') hash = '#' + hash;
    if (search && search.charAt(0) !== '?') search = '?' + search;
  
    pathname = pathname.replace(/[?#]/g, function(match) {
      return encodeURIComponent(match);
    });
    search = search.replace('#', '%23');
  
    return protocol + host + pathname + search + hash;
  };
  
  function urlResolve(source, relative) {
    return urlParse(source, false, true).resolve(relative);
  }
  
  Url.prototype.resolve = function(relative) {
    return this.resolveObject(urlParse(relative, false, true)).format();
  };
  
  function urlResolveObject(source, relative) {
    if (!source) return relative;
    return urlParse(source, false, true).resolveObject(relative);
  }
  
  Url.prototype.resolveObject = function(relative) {
    if (util.isString(relative)) {
      var rel = new Url();
      rel.parse(relative, false, true);
      relative = rel;
    }
  
    var result = new Url();
    var tkeys = Object.keys(this);
    for (var tk = 0; tk < tkeys.length; tk++) {
      var tkey = tkeys[tk];
      result[tkey] = this[tkey];
    }
  
    // hash is always overridden, no matter what.
    // even href="" will remove it.
    result.hash = relative.hash;
  
    // if the relative url is empty, then there's nothing left to do here.
    if (relative.href === '') {
      result.href = result.format();
      return result;
    }
  
    // hrefs like //foo/bar always cut to the protocol.
    if (relative.slashes && !relative.protocol) {
      // take everything except the protocol from relative
      var rkeys = Object.keys(relative);
      for (var rk = 0; rk < rkeys.length; rk++) {
        var rkey = rkeys[rk];
        if (rkey !== 'protocol')
          result[rkey] = relative[rkey];
      }
  
      //urlParse appends trailing / to urls like http://www.example.com
      if (slashedProtocol[result.protocol] &&
          result.hostname && !result.pathname) {
        result.path = result.pathname = '/';
      }
  
      result.href = result.format();
      return result;
    }
  
    if (relative.protocol && relative.protocol !== result.protocol) {
      // if it's a known url protocol, then changing
      // the protocol does weird things
      // first, if it's not file:, then we MUST have a host,
      // and if there was a path
      // to begin with, then we MUST have a path.
      // if it is file:, then the host is dropped,
      // because that's known to be hostless.
      // anything else is assumed to be absolute.
      if (!slashedProtocol[relative.protocol]) {
        var keys = Object.keys(relative);
        for (var v = 0; v < keys.length; v++) {
          var k = keys[v];
          result[k] = relative[k];
        }
        result.href = result.format();
        return result;
      }
  
      result.protocol = relative.protocol;
      if (!relative.host && !hostlessProtocol[relative.protocol]) {
        var relPath = (relative.pathname || '').split('/');
        while (relPath.length && !(relative.host = relPath.shift()));
        if (!relative.host) relative.host = '';
        if (!relative.hostname) relative.hostname = '';
        if (relPath[0] !== '') relPath.unshift('');
        if (relPath.length < 2) relPath.unshift('');
        result.pathname = relPath.join('/');
      } else {
        result.pathname = relative.pathname;
      }
      result.search = relative.search;
      result.query = relative.query;
      result.host = relative.host || '';
      result.auth = relative.auth;
      result.hostname = relative.hostname || relative.host;
      result.port = relative.port;
      // to support http.request
      if (result.pathname || result.search) {
        var p = result.pathname || '';
        var s = result.search || '';
        result.path = p + s;
      }
      result.slashes = result.slashes || relative.slashes;
      result.href = result.format();
      return result;
    }
  
    var isSourceAbs = (result.pathname && result.pathname.charAt(0) === '/'),
        isRelAbs = (
            relative.host ||
            relative.pathname && relative.pathname.charAt(0) === '/'
        ),
        mustEndAbs = (isRelAbs || isSourceAbs ||
                      (result.host && relative.pathname)),
        removeAllDots = mustEndAbs,
        srcPath = result.pathname && result.pathname.split('/') || [],
        relPath = relative.pathname && relative.pathname.split('/') || [],
        psychotic = result.protocol && !slashedProtocol[result.protocol];
  
    // if the url is a non-slashed url, then relative
    // links like ../.. should be able
    // to crawl up to the hostname, as well.  This is strange.
    // result.protocol has already been set by now.
    // Later on, put the first path part into the host field.
    if (psychotic) {
      result.hostname = '';
      result.port = null;
      if (result.host) {
        if (srcPath[0] === '') srcPath[0] = result.host;
        else srcPath.unshift(result.host);
      }
      result.host = '';
      if (relative.protocol) {
        relative.hostname = null;
        relative.port = null;
        if (relative.host) {
          if (relPath[0] === '') relPath[0] = relative.host;
          else relPath.unshift(relative.host);
        }
        relative.host = null;
      }
      mustEndAbs = mustEndAbs && (relPath[0] === '' || srcPath[0] === '');
    }
  
    if (isRelAbs) {
      // it's absolute.
      result.host = (relative.host || relative.host === '') ?
                    relative.host : result.host;
      result.hostname = (relative.hostname || relative.hostname === '') ?
                        relative.hostname : result.hostname;
      result.search = relative.search;
      result.query = relative.query;
      srcPath = relPath;
      // fall through to the dot-handling below.
    } else if (relPath.length) {
      // it's relative
      // throw away the existing file, and take the new path instead.
      if (!srcPath) srcPath = [];
      srcPath.pop();
      srcPath = srcPath.concat(relPath);
      result.search = relative.search;
      result.query = relative.query;
    } else if (!util.isNullOrUndefined(relative.search)) {
      // just pull out the search.
      // like href='?foo'.
      // Put this after the other two cases because it simplifies the booleans
      if (psychotic) {
        result.hostname = result.host = srcPath.shift();
        //occationaly the auth can get stuck only in host
        //this especially happens in cases like
        //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
        var authInHost = result.host && result.host.indexOf('@') > 0 ?
                         result.host.split('@') : false;
        if (authInHost) {
          result.auth = authInHost.shift();
          result.host = result.hostname = authInHost.shift();
        }
      }
      result.search = relative.search;
      result.query = relative.query;
      //to support http.request
      if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
        result.path = (result.pathname ? result.pathname : '') +
                      (result.search ? result.search : '');
      }
      result.href = result.format();
      return result;
    }
  
    if (!srcPath.length) {
      // no path at all.  easy.
      // we've already handled the other stuff above.
      result.pathname = null;
      //to support http.request
      if (result.search) {
        result.path = '/' + result.search;
      } else {
        result.path = null;
      }
      result.href = result.format();
      return result;
    }
  
    // if a url ENDs in . or .., then it must get a trailing slash.
    // however, if it ends in anything else non-slashy,
    // then it must NOT get a trailing slash.
    var last = srcPath.slice(-1)[0];
    var hasTrailingSlash = (
        (result.host || relative.host || srcPath.length > 1) &&
        (last === '.' || last === '..') || last === '');
  
    // strip single dots, resolve double dots to parent dir
    // if the path tries to go above the root, `up` ends up > 0
    var up = 0;
    for (var i = srcPath.length; i >= 0; i--) {
      last = srcPath[i];
      if (last === '.') {
        srcPath.splice(i, 1);
      } else if (last === '..') {
        srcPath.splice(i, 1);
        up++;
      } else if (up) {
        srcPath.splice(i, 1);
        up--;
      }
    }
  
    // if the path is allowed to go above the root, restore leading ..s
    if (!mustEndAbs && !removeAllDots) {
      for (; up--; up) {
        srcPath.unshift('..');
      }
    }
  
    if (mustEndAbs && srcPath[0] !== '' &&
        (!srcPath[0] || srcPath[0].charAt(0) !== '/')) {
      srcPath.unshift('');
    }
  
    if (hasTrailingSlash && (srcPath.join('/').substr(-1) !== '/')) {
      srcPath.push('');
    }
  
    var isAbsolute = srcPath[0] === '' ||
        (srcPath[0] && srcPath[0].charAt(0) === '/');
  
    // put the host back
    if (psychotic) {
      result.hostname = result.host = isAbsolute ? '' :
                                      srcPath.length ? srcPath.shift() : '';
      //occationaly the auth can get stuck only in host
      //this especially happens in cases like
      //url.resolveObject('mailto:local1@domain1', 'local2@domain2')
      var authInHost = result.host && result.host.indexOf('@') > 0 ?
                       result.host.split('@') : false;
      if (authInHost) {
        result.auth = authInHost.shift();
        result.host = result.hostname = authInHost.shift();
      }
    }
  
    mustEndAbs = mustEndAbs || (result.host && srcPath.length);
  
    if (mustEndAbs && !isAbsolute) {
      srcPath.unshift('');
    }
  
    if (!srcPath.length) {
      result.pathname = null;
      result.path = null;
    } else {
      result.pathname = srcPath.join('/');
    }
  
    //to support request.http
    if (!util.isNull(result.pathname) || !util.isNull(result.search)) {
      result.path = (result.pathname ? result.pathname : '') +
                    (result.search ? result.search : '');
    }
    result.auth = relative.auth || result.auth;
    result.slashes = result.slashes || relative.slashes;
    result.href = result.format();
    return result;
  };
  
  Url.prototype.parseHost = function() {
    var host = this.host;
    var port = portPattern.exec(host);
    if (port) {
      port = port[0];
      if (port !== ':') {
        this.port = port.substr(1);
      }
      host = host.substr(0, host.length - port.length);
    }
    if (host) this.hostname = host;
  };
  
  },{"./util":149,"punycode":8,"querystring":128}],149:[function(require,module,exports){
  'use strict';
  
  module.exports = {
    isString: function(arg) {
      return typeof(arg) === 'string';
    },
    isObject: function(arg) {
      return typeof(arg) === 'object' && arg !== null;
    },
    isNull: function(arg) {
      return arg === null;
    },
    isNullOrUndefined: function(arg) {
      return arg == null;
    }
  };
  
  },{}],150:[function(require,module,exports){
  (function (global){
  
  /**
   * Module exports.
   */
  
  module.exports = deprecate;
  
  /**
   * Mark that a method should not be used.
   * Returns a modified function which warns once by default.
   *
   * If `localStorage.noDeprecation = true` is set, then it is a no-op.
   *
   * If `localStorage.throwDeprecation = true` is set, then deprecated functions
   * will throw an Error when invoked.
   *
   * If `localStorage.traceDeprecation = true` is set, then deprecated functions
   * will invoke `console.trace()` instead of `console.error()`.
   *
   * @param {Function} fn - the function to deprecate
   * @param {String} msg - the string to print to the console when `fn` is invoked
   * @returns {Function} a new "deprecated" version of `fn`
   * @api public
   */
  
  function deprecate (fn, msg) {
    if (config('noDeprecation')) {
      return fn;
    }
  
    var warned = false;
    function deprecated() {
      if (!warned) {
        if (config('throwDeprecation')) {
          throw new Error(msg);
        } else if (config('traceDeprecation')) {
          console.trace(msg);
        } else {
          console.warn(msg);
        }
        warned = true;
      }
      return fn.apply(this, arguments);
    }
  
    return deprecated;
  }
  
  /**
   * Checks `localStorage` for boolean values for the given `name`.
   *
   * @param {String} name
   * @returns {Boolean}
   * @api private
   */
  
  function config (name) {
    // accessing global.localStorage can trigger a DOMException in sandboxed iframes
    try {
      if (!global.localStorage) return false;
    } catch (_) {
      return false;
    }
    var val = global.localStorage[name];
    if (null == val) return false;
    return String(val).toLowerCase() === 'true';
  }
  
  }).call(this,typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{}],151:[function(require,module,exports){
  module.exports = function isBuffer(arg) {
    return arg && typeof arg === 'object'
      && typeof arg.copy === 'function'
      && typeof arg.fill === 'function'
      && typeof arg.readUInt8 === 'function';
  }
  },{}],152:[function(require,module,exports){
  (function (process,global){
  // Copyright Joyent, Inc. and other Node contributors.
  //
  // Permission is hereby granted, free of charge, to any person obtaining a
  // copy of this software and associated documentation files (the
  // "Software"), to deal in the Software without restriction, including
  // without limitation the rights to use, copy, modify, merge, publish,
  // distribute, sublicense, and/or sell copies of the Software, and to permit
  // persons to whom the Software is furnished to do so, subject to the
  // following conditions:
  //
  // The above copyright notice and this permission notice shall be included
  // in all copies or substantial portions of the Software.
  //
  // THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
  // OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
  // MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
  // NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  // DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  // OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
  // USE OR OTHER DEALINGS IN THE SOFTWARE.
  
  var formatRegExp = /%[sdj%]/g;
  exports.format = function(f) {
    if (!isString(f)) {
      var objects = [];
      for (var i = 0; i < arguments.length; i++) {
        objects.push(inspect(arguments[i]));
      }
      return objects.join(' ');
    }
  
    var i = 1;
    var args = arguments;
    var len = args.length;
    var str = String(f).replace(formatRegExp, function(x) {
      if (x === '%%') return '%';
      if (i >= len) return x;
      switch (x) {
        case '%s': return String(args[i++]);
        case '%d': return Number(args[i++]);
        case '%j':
          try {
            return JSON.stringify(args[i++]);
          } catch (_) {
            return '[Circular]';
          }
        default:
          return x;
      }
    });
    for (var x = args[i]; i < len; x = args[++i]) {
      if (isNull(x) || !isObject(x)) {
        str += ' ' + x;
      } else {
        str += ' ' + inspect(x);
      }
    }
    return str;
  };
  
  
  // Mark that a method should not be used.
  // Returns a modified function which warns once by default.
  // If --no-deprecation is set, then it is a no-op.
  exports.deprecate = function(fn, msg) {
    // Allow for deprecating things in the process of starting up.
    if (isUndefined(global.process)) {
      return function() {
        return exports.deprecate(fn, msg).apply(this, arguments);
      };
    }
  
    if (process.noDeprecation === true) {
      return fn;
    }
  
    var warned = false;
    function deprecated() {
      if (!warned) {
        if (process.throwDeprecation) {
          throw new Error(msg);
        } else if (process.traceDeprecation) {
          console.trace(msg);
        } else {
          console.error(msg);
        }
        warned = true;
      }
      return fn.apply(this, arguments);
    }
  
    return deprecated;
  };
  
  
  var debugs = {};
  var debugEnviron;
  exports.debuglog = function(set) {
    if (isUndefined(debugEnviron))
      debugEnviron = process.env.NODE_DEBUG || '';
    set = set.toUpperCase();
    if (!debugs[set]) {
      if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
        var pid = process.pid;
        debugs[set] = function() {
          var msg = exports.format.apply(exports, arguments);
          console.error('%s %d: %s', set, pid, msg);
        };
      } else {
        debugs[set] = function() {};
      }
    }
    return debugs[set];
  };
  
  
  /**
   * Echos the value of a value. Trys to print the value out
   * in the best way possible given the different types.
   *
   * @param {Object} obj The object to print out.
   * @param {Object} opts Optional options object that alters the output.
   */
  /* legacy: obj, showHidden, depth, colors*/
  function inspect(obj, opts) {
    // default options
    var ctx = {
      seen: [],
      stylize: stylizeNoColor
    };
    // legacy...
    if (arguments.length >= 3) ctx.depth = arguments[2];
    if (arguments.length >= 4) ctx.colors = arguments[3];
    if (isBoolean(opts)) {
      // legacy...
      ctx.showHidden = opts;
    } else if (opts) {
      // got an "options" object
      exports._extend(ctx, opts);
    }
    // set default options
    if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
    if (isUndefined(ctx.depth)) ctx.depth = 2;
    if (isUndefined(ctx.colors)) ctx.colors = false;
    if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
    if (ctx.colors) ctx.stylize = stylizeWithColor;
    return formatValue(ctx, obj, ctx.depth);
  }
  exports.inspect = inspect;
  
  
  // http://en.wikipedia.org/wiki/ANSI_escape_code#graphics
  inspect.colors = {
    'bold' : [1, 22],
    'italic' : [3, 23],
    'underline' : [4, 24],
    'inverse' : [7, 27],
    'white' : [37, 39],
    'grey' : [90, 39],
    'black' : [30, 39],
    'blue' : [34, 39],
    'cyan' : [36, 39],
    'green' : [32, 39],
    'magenta' : [35, 39],
    'red' : [31, 39],
    'yellow' : [33, 39]
  };
  
  // Don't use 'blue' not visible on cmd.exe
  inspect.styles = {
    'special': 'cyan',
    'number': 'yellow',
    'boolean': 'yellow',
    'undefined': 'grey',
    'null': 'bold',
    'string': 'green',
    'date': 'magenta',
    // "name": intentionally not styling
    'regexp': 'red'
  };
  
  
  function stylizeWithColor(str, styleType) {
    var style = inspect.styles[styleType];
  
    if (style) {
      return '\u001b[' + inspect.colors[style][0] + 'm' + str +
             '\u001b[' + inspect.colors[style][1] + 'm';
    } else {
      return str;
    }
  }
  
  
  function stylizeNoColor(str, styleType) {
    return str;
  }
  
  
  function arrayToHash(array) {
    var hash = {};
  
    array.forEach(function(val, idx) {
      hash[val] = true;
    });
  
    return hash;
  }
  
  
  function formatValue(ctx, value, recurseTimes) {
    // Provide a hook for user-specified inspect functions.
    // Check that value is an object with an inspect function on it
    if (ctx.customInspect &&
        value &&
        isFunction(value.inspect) &&
        // Filter out the util module, it's inspect function is special
        value.inspect !== exports.inspect &&
        // Also filter out any prototype objects using the circular check.
        !(value.constructor && value.constructor.prototype === value)) {
      var ret = value.inspect(recurseTimes, ctx);
      if (!isString(ret)) {
        ret = formatValue(ctx, ret, recurseTimes);
      }
      return ret;
    }
  
    // Primitive types cannot have properties
    var primitive = formatPrimitive(ctx, value);
    if (primitive) {
      return primitive;
    }
  
    // Look up the keys of the object.
    var keys = Object.keys(value);
    var visibleKeys = arrayToHash(keys);
  
    if (ctx.showHidden) {
      keys = Object.getOwnPropertyNames(value);
    }
  
    // IE doesn't make error fields non-enumerable
    // http://msdn.microsoft.com/en-us/library/ie/dww52sbt(v=vs.94).aspx
    if (isError(value)
        && (keys.indexOf('message') >= 0 || keys.indexOf('description') >= 0)) {
      return formatError(value);
    }
  
    // Some type of object without properties can be shortcutted.
    if (keys.length === 0) {
      if (isFunction(value)) {
        var name = value.name ? ': ' + value.name : '';
        return ctx.stylize('[Function' + name + ']', 'special');
      }
      if (isRegExp(value)) {
        return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
      }
      if (isDate(value)) {
        return ctx.stylize(Date.prototype.toString.call(value), 'date');
      }
      if (isError(value)) {
        return formatError(value);
      }
    }
  
    var base = '', array = false, braces = ['{', '}'];
  
    // Make Array say that they are Array
    if (isArray(value)) {
      array = true;
      braces = ['[', ']'];
    }
  
    // Make functions say that they are functions
    if (isFunction(value)) {
      var n = value.name ? ': ' + value.name : '';
      base = ' [Function' + n + ']';
    }
  
    // Make RegExps say that they are RegExps
    if (isRegExp(value)) {
      base = ' ' + RegExp.prototype.toString.call(value);
    }
  
    // Make dates with properties first say the date
    if (isDate(value)) {
      base = ' ' + Date.prototype.toUTCString.call(value);
    }
  
    // Make error with message first say the error
    if (isError(value)) {
      base = ' ' + formatError(value);
    }
  
    if (keys.length === 0 && (!array || value.length == 0)) {
      return braces[0] + base + braces[1];
    }
  
    if (recurseTimes < 0) {
      if (isRegExp(value)) {
        return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
      } else {
        return ctx.stylize('[Object]', 'special');
      }
    }
  
    ctx.seen.push(value);
  
    var output;
    if (array) {
      output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
    } else {
      output = keys.map(function(key) {
        return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
      });
    }
  
    ctx.seen.pop();
  
    return reduceToSingleString(output, base, braces);
  }
  
  
  function formatPrimitive(ctx, value) {
    if (isUndefined(value))
      return ctx.stylize('undefined', 'undefined');
    if (isString(value)) {
      var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '')
                                               .replace(/'/g, "\\'")
                                               .replace(/\\"/g, '"') + '\'';
      return ctx.stylize(simple, 'string');
    }
    if (isNumber(value))
      return ctx.stylize('' + value, 'number');
    if (isBoolean(value))
      return ctx.stylize('' + value, 'boolean');
    // For some reason typeof null is "object", so special case here.
    if (isNull(value))
      return ctx.stylize('null', 'null');
  }
  
  
  function formatError(value) {
    return '[' + Error.prototype.toString.call(value) + ']';
  }
  
  
  function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
    var output = [];
    for (var i = 0, l = value.length; i < l; ++i) {
      if (hasOwnProperty(value, String(i))) {
        output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
            String(i), true));
      } else {
        output.push('');
      }
    }
    keys.forEach(function(key) {
      if (!key.match(/^\d+$/)) {
        output.push(formatProperty(ctx, value, recurseTimes, visibleKeys,
            key, true));
      }
    });
    return output;
  }
  
  
  function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
    var name, str, desc;
    desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
    if (desc.get) {
      if (desc.set) {
        str = ctx.stylize('[Getter/Setter]', 'special');
      } else {
        str = ctx.stylize('[Getter]', 'special');
      }
    } else {
      if (desc.set) {
        str = ctx.stylize('[Setter]', 'special');
      }
    }
    if (!hasOwnProperty(visibleKeys, key)) {
      name = '[' + key + ']';
    }
    if (!str) {
      if (ctx.seen.indexOf(desc.value) < 0) {
        if (isNull(recurseTimes)) {
          str = formatValue(ctx, desc.value, null);
        } else {
          str = formatValue(ctx, desc.value, recurseTimes - 1);
        }
        if (str.indexOf('\n') > -1) {
          if (array) {
            str = str.split('\n').map(function(line) {
              return '  ' + line;
            }).join('\n').substr(2);
          } else {
            str = '\n' + str.split('\n').map(function(line) {
              return '   ' + line;
            }).join('\n');
          }
        }
      } else {
        str = ctx.stylize('[Circular]', 'special');
      }
    }
    if (isUndefined(name)) {
      if (array && key.match(/^\d+$/)) {
        return str;
      }
      name = JSON.stringify('' + key);
      if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
        name = name.substr(1, name.length - 2);
        name = ctx.stylize(name, 'name');
      } else {
        name = name.replace(/'/g, "\\'")
                   .replace(/\\"/g, '"')
                   .replace(/(^"|"$)/g, "'");
        name = ctx.stylize(name, 'string');
      }
    }
  
    return name + ': ' + str;
  }
  
  
  function reduceToSingleString(output, base, braces) {
    var numLinesEst = 0;
    var length = output.reduce(function(prev, cur) {
      numLinesEst++;
      if (cur.indexOf('\n') >= 0) numLinesEst++;
      return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
    }, 0);
  
    if (length > 60) {
      return braces[0] +
             (base === '' ? '' : base + '\n ') +
             ' ' +
             output.join(',\n  ') +
             ' ' +
             braces[1];
    }
  
    return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
  }
  
  
  // NOTE: These type checking functions intentionally don't use `instanceof`
  // because it is fragile and can be easily faked with `Object.create()`.
  function isArray(ar) {
    return Array.isArray(ar);
  }
  exports.isArray = isArray;
  
  function isBoolean(arg) {
    return typeof arg === 'boolean';
  }
  exports.isBoolean = isBoolean;
  
  function isNull(arg) {
    return arg === null;
  }
  exports.isNull = isNull;
  
  function isNullOrUndefined(arg) {
    return arg == null;
  }
  exports.isNullOrUndefined = isNullOrUndefined;
  
  function isNumber(arg) {
    return typeof arg === 'number';
  }
  exports.isNumber = isNumber;
  
  function isString(arg) {
    return typeof arg === 'string';
  }
  exports.isString = isString;
  
  function isSymbol(arg) {
    return typeof arg === 'symbol';
  }
  exports.isSymbol = isSymbol;
  
  function isUndefined(arg) {
    return arg === void 0;
  }
  exports.isUndefined = isUndefined;
  
  function isRegExp(re) {
    return isObject(re) && objectToString(re) === '[object RegExp]';
  }
  exports.isRegExp = isRegExp;
  
  function isObject(arg) {
    return typeof arg === 'object' && arg !== null;
  }
  exports.isObject = isObject;
  
  function isDate(d) {
    return isObject(d) && objectToString(d) === '[object Date]';
  }
  exports.isDate = isDate;
  
  function isError(e) {
    return isObject(e) &&
        (objectToString(e) === '[object Error]' || e instanceof Error);
  }
  exports.isError = isError;
  
  function isFunction(arg) {
    return typeof arg === 'function';
  }
  exports.isFunction = isFunction;
  
  function isPrimitive(arg) {
    return arg === null ||
           typeof arg === 'boolean' ||
           typeof arg === 'number' ||
           typeof arg === 'string' ||
           typeof arg === 'symbol' ||  // ES6 symbol
           typeof arg === 'undefined';
  }
  exports.isPrimitive = isPrimitive;
  
  exports.isBuffer = require('./support/isBuffer');
  
  function objectToString(o) {
    return Object.prototype.toString.call(o);
  }
  
  
  function pad(n) {
    return n < 10 ? '0' + n.toString(10) : n.toString(10);
  }
  
  
  var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep',
                'Oct', 'Nov', 'Dec'];
  
  // 26 Feb 16:19:34
  function timestamp() {
    var d = new Date();
    var time = [pad(d.getHours()),
                pad(d.getMinutes()),
                pad(d.getSeconds())].join(':');
    return [d.getDate(), months[d.getMonth()], time].join(' ');
  }
  
  
  // log is just a thin wrapper to console.log that prepends a timestamp
  exports.log = function() {
    console.log('%s - %s', timestamp(), exports.format.apply(exports, arguments));
  };
  
  
  /**
   * Inherit the prototype methods from one constructor into another.
   *
   * The Function.prototype.inherits from lang.js rewritten as a standalone
   * function (not on Function.prototype). NOTE: If this file is to be loaded
   * during bootstrapping this function needs to be rewritten using some native
   * functions as prototype setup using normal JavaScript does not work as
   * expected during bootstrapping (see mirror.js in r114903).
   *
   * @param {function} ctor Constructor function which needs to inherit the
   *     prototype.
   * @param {function} superCtor Constructor function to inherit prototype from.
   */
  exports.inherits = require('inherits');
  
  exports._extend = function(origin, add) {
    // Don't do anything if add isn't an object
    if (!add || !isObject(add)) return origin;
  
    var keys = Object.keys(add);
    var i = keys.length;
    while (i--) {
      origin[keys[i]] = add[keys[i]];
    }
    return origin;
  };
  
  function hasOwnProperty(obj, prop) {
    return Object.prototype.hasOwnProperty.call(obj, prop);
  }
  
  }).call(this,require('_process'),typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : {})
  
  },{"./support/isBuffer":151,"_process":125,"inherits":68}],153:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _toDate = _interopRequireDefault(require("./lib/toDate"));
  
  var _toFloat = _interopRequireDefault(require("./lib/toFloat"));
  
  var _toInt = _interopRequireDefault(require("./lib/toInt"));
  
  var _toBoolean = _interopRequireDefault(require("./lib/toBoolean"));
  
  var _equals = _interopRequireDefault(require("./lib/equals"));
  
  var _contains = _interopRequireDefault(require("./lib/contains"));
  
  var _matches = _interopRequireDefault(require("./lib/matches"));
  
  var _isEmail = _interopRequireDefault(require("./lib/isEmail"));
  
  var _isURL = _interopRequireDefault(require("./lib/isURL"));
  
  var _isMACAddress = _interopRequireDefault(require("./lib/isMACAddress"));
  
  var _isIP = _interopRequireDefault(require("./lib/isIP"));
  
  var _isIPRange = _interopRequireDefault(require("./lib/isIPRange"));
  
  var _isFQDN = _interopRequireDefault(require("./lib/isFQDN"));
  
  var _isBoolean = _interopRequireDefault(require("./lib/isBoolean"));
  
  var _isAlpha = _interopRequireWildcard(require("./lib/isAlpha"));
  
  var _isAlphanumeric = _interopRequireWildcard(require("./lib/isAlphanumeric"));
  
  var _isNumeric = _interopRequireDefault(require("./lib/isNumeric"));
  
  var _isPort = _interopRequireDefault(require("./lib/isPort"));
  
  var _isLowercase = _interopRequireDefault(require("./lib/isLowercase"));
  
  var _isUppercase = _interopRequireDefault(require("./lib/isUppercase"));
  
  var _isAscii = _interopRequireDefault(require("./lib/isAscii"));
  
  var _isFullWidth = _interopRequireDefault(require("./lib/isFullWidth"));
  
  var _isHalfWidth = _interopRequireDefault(require("./lib/isHalfWidth"));
  
  var _isVariableWidth = _interopRequireDefault(require("./lib/isVariableWidth"));
  
  var _isMultibyte = _interopRequireDefault(require("./lib/isMultibyte"));
  
  var _isSurrogatePair = _interopRequireDefault(require("./lib/isSurrogatePair"));
  
  var _isInt = _interopRequireDefault(require("./lib/isInt"));
  
  var _isFloat = _interopRequireWildcard(require("./lib/isFloat"));
  
  var _isDecimal = _interopRequireDefault(require("./lib/isDecimal"));
  
  var _isHexadecimal = _interopRequireDefault(require("./lib/isHexadecimal"));
  
  var _isDivisibleBy = _interopRequireDefault(require("./lib/isDivisibleBy"));
  
  var _isHexColor = _interopRequireDefault(require("./lib/isHexColor"));
  
  var _isISRC = _interopRequireDefault(require("./lib/isISRC"));
  
  var _isMD = _interopRequireDefault(require("./lib/isMD5"));
  
  var _isHash = _interopRequireDefault(require("./lib/isHash"));
  
  var _isJWT = _interopRequireDefault(require("./lib/isJWT"));
  
  var _isJSON = _interopRequireDefault(require("./lib/isJSON"));
  
  var _isEmpty = _interopRequireDefault(require("./lib/isEmpty"));
  
  var _isLength = _interopRequireDefault(require("./lib/isLength"));
  
  var _isByteLength = _interopRequireDefault(require("./lib/isByteLength"));
  
  var _isUUID = _interopRequireDefault(require("./lib/isUUID"));
  
  var _isMongoId = _interopRequireDefault(require("./lib/isMongoId"));
  
  var _isAfter = _interopRequireDefault(require("./lib/isAfter"));
  
  var _isBefore = _interopRequireDefault(require("./lib/isBefore"));
  
  var _isIn = _interopRequireDefault(require("./lib/isIn"));
  
  var _isCreditCard = _interopRequireDefault(require("./lib/isCreditCard"));
  
  var _isIdentityCard = _interopRequireDefault(require("./lib/isIdentityCard"));
  
  var _isISIN = _interopRequireDefault(require("./lib/isISIN"));
  
  var _isISBN = _interopRequireDefault(require("./lib/isISBN"));
  
  var _isISSN = _interopRequireDefault(require("./lib/isISSN"));
  
  var _isMobilePhone = _interopRequireWildcard(require("./lib/isMobilePhone"));
  
  var _isCurrency = _interopRequireDefault(require("./lib/isCurrency"));
  
  var _isISO = _interopRequireDefault(require("./lib/isISO8601"));
  
  var _isRFC = _interopRequireDefault(require("./lib/isRFC3339"));
  
  var _isISO31661Alpha = _interopRequireDefault(require("./lib/isISO31661Alpha2"));
  
  var _isISO31661Alpha2 = _interopRequireDefault(require("./lib/isISO31661Alpha3"));
  
  var _isBase = _interopRequireDefault(require("./lib/isBase64"));
  
  var _isDataURI = _interopRequireDefault(require("./lib/isDataURI"));
  
  var _isMagnetURI = _interopRequireDefault(require("./lib/isMagnetURI"));
  
  var _isMimeType = _interopRequireDefault(require("./lib/isMimeType"));
  
  var _isLatLong = _interopRequireDefault(require("./lib/isLatLong"));
  
  var _isPostalCode = _interopRequireWildcard(require("./lib/isPostalCode"));
  
  var _ltrim = _interopRequireDefault(require("./lib/ltrim"));
  
  var _rtrim = _interopRequireDefault(require("./lib/rtrim"));
  
  var _trim = _interopRequireDefault(require("./lib/trim"));
  
  var _escape = _interopRequireDefault(require("./lib/escape"));
  
  var _unescape = _interopRequireDefault(require("./lib/unescape"));
  
  var _stripLow = _interopRequireDefault(require("./lib/stripLow"));
  
  var _whitelist = _interopRequireDefault(require("./lib/whitelist"));
  
  var _blacklist = _interopRequireDefault(require("./lib/blacklist"));
  
  var _isWhitelisted = _interopRequireDefault(require("./lib/isWhitelisted"));
  
  var _normalizeEmail = _interopRequireDefault(require("./lib/normalizeEmail"));
  
  var _toString = _interopRequireDefault(require("./lib/util/toString"));
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = Object.defineProperty && Object.getOwnPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : {}; if (desc.get || desc.set) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var version = '10.10.0';
  var validator = {
    version: version,
    toDate: _toDate.default,
    toFloat: _toFloat.default,
    toInt: _toInt.default,
    toBoolean: _toBoolean.default,
    equals: _equals.default,
    contains: _contains.default,
    matches: _matches.default,
    isEmail: _isEmail.default,
    isURL: _isURL.default,
    isMACAddress: _isMACAddress.default,
    isIP: _isIP.default,
    isIPRange: _isIPRange.default,
    isFQDN: _isFQDN.default,
    isBoolean: _isBoolean.default,
    isAlpha: _isAlpha.default,
    isAlphaLocales: _isAlpha.locales,
    isAlphanumeric: _isAlphanumeric.default,
    isAlphanumericLocales: _isAlphanumeric.locales,
    isNumeric: _isNumeric.default,
    isPort: _isPort.default,
    isLowercase: _isLowercase.default,
    isUppercase: _isUppercase.default,
    isAscii: _isAscii.default,
    isFullWidth: _isFullWidth.default,
    isHalfWidth: _isHalfWidth.default,
    isVariableWidth: _isVariableWidth.default,
    isMultibyte: _isMultibyte.default,
    isSurrogatePair: _isSurrogatePair.default,
    isInt: _isInt.default,
    isFloat: _isFloat.default,
    isFloatLocales: _isFloat.locales,
    isDecimal: _isDecimal.default,
    isHexadecimal: _isHexadecimal.default,
    isDivisibleBy: _isDivisibleBy.default,
    isHexColor: _isHexColor.default,
    isISRC: _isISRC.default,
    isMD5: _isMD.default,
    isHash: _isHash.default,
    isJWT: _isJWT.default,
    isJSON: _isJSON.default,
    isEmpty: _isEmpty.default,
    isLength: _isLength.default,
    isByteLength: _isByteLength.default,
    isUUID: _isUUID.default,
    isMongoId: _isMongoId.default,
    isAfter: _isAfter.default,
    isBefore: _isBefore.default,
    isIn: _isIn.default,
    isCreditCard: _isCreditCard.default,
    isIdentityCard: _isIdentityCard.default,
    isISIN: _isISIN.default,
    isISBN: _isISBN.default,
    isISSN: _isISSN.default,
    isMobilePhone: _isMobilePhone.default,
    isMobilePhoneLocales: _isMobilePhone.locales,
    isPostalCode: _isPostalCode.default,
    isPostalCodeLocales: _isPostalCode.locales,
    isCurrency: _isCurrency.default,
    isISO8601: _isISO.default,
    isRFC3339: _isRFC.default,
    isISO31661Alpha2: _isISO31661Alpha.default,
    isISO31661Alpha3: _isISO31661Alpha2.default,
    isBase64: _isBase.default,
    isDataURI: _isDataURI.default,
    isMagnetURI: _isMagnetURI.default,
    isMimeType: _isMimeType.default,
    isLatLong: _isLatLong.default,
    ltrim: _ltrim.default,
    rtrim: _rtrim.default,
    trim: _trim.default,
    escape: _escape.default,
    unescape: _unescape.default,
    stripLow: _stripLow.default,
    whitelist: _whitelist.default,
    blacklist: _blacklist.default,
    isWhitelisted: _isWhitelisted.default,
    normalizeEmail: _normalizeEmail.default,
    toString: _toString.default
  };
  var _default = validator;
  exports.default = _default;
  module.exports = exports.default;
  },{"./lib/blacklist":155,"./lib/contains":156,"./lib/equals":157,"./lib/escape":158,"./lib/isAfter":159,"./lib/isAlpha":160,"./lib/isAlphanumeric":161,"./lib/isAscii":162,"./lib/isBase64":163,"./lib/isBefore":164,"./lib/isBoolean":165,"./lib/isByteLength":166,"./lib/isCreditCard":167,"./lib/isCurrency":168,"./lib/isDataURI":169,"./lib/isDecimal":170,"./lib/isDivisibleBy":171,"./lib/isEmail":172,"./lib/isEmpty":173,"./lib/isFQDN":174,"./lib/isFloat":175,"./lib/isFullWidth":176,"./lib/isHalfWidth":177,"./lib/isHash":178,"./lib/isHexColor":179,"./lib/isHexadecimal":180,"./lib/isIP":181,"./lib/isIPRange":182,"./lib/isISBN":183,"./lib/isISIN":184,"./lib/isISO31661Alpha2":185,"./lib/isISO31661Alpha3":186,"./lib/isISO8601":187,"./lib/isISRC":188,"./lib/isISSN":189,"./lib/isIdentityCard":190,"./lib/isIn":191,"./lib/isInt":192,"./lib/isJSON":193,"./lib/isJWT":194,"./lib/isLatLong":195,"./lib/isLength":196,"./lib/isLowercase":197,"./lib/isMACAddress":198,"./lib/isMD5":199,"./lib/isMagnetURI":200,"./lib/isMimeType":201,"./lib/isMobilePhone":202,"./lib/isMongoId":203,"./lib/isMultibyte":204,"./lib/isNumeric":205,"./lib/isPort":206,"./lib/isPostalCode":207,"./lib/isRFC3339":208,"./lib/isSurrogatePair":209,"./lib/isURL":210,"./lib/isUUID":211,"./lib/isUppercase":212,"./lib/isVariableWidth":213,"./lib/isWhitelisted":214,"./lib/ltrim":215,"./lib/matches":216,"./lib/normalizeEmail":217,"./lib/rtrim":218,"./lib/stripLow":219,"./lib/toBoolean":220,"./lib/toDate":221,"./lib/toFloat":222,"./lib/toInt":223,"./lib/trim":224,"./lib/unescape":225,"./lib/util/toString":229,"./lib/whitelist":230}],154:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.commaDecimal = exports.dotDecimal = exports.arabicLocales = exports.englishLocales = exports.decimal = exports.alphanumeric = exports.alpha = void 0;
  var alpha = {
    'en-US': /^[A-Z]+$/i,
    'bg-BG': /^[А-Я]+$/i,
    'cs-CZ': /^[A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ]+$/i,
    'da-DK': /^[A-ZÆØÅ]+$/i,
    'de-DE': /^[A-ZÄÖÜß]+$/i,
    'el-GR': /^[Α-ω]+$/i,
    'es-ES': /^[A-ZÁÉÍÑÓÚÜ]+$/i,
    'fr-FR': /^[A-ZÀÂÆÇÉÈÊËÏÎÔŒÙÛÜŸ]+$/i,
    'it-IT': /^[A-ZÀÉÈÌÎÓÒÙ]+$/i,
    'nb-NO': /^[A-ZÆØÅ]+$/i,
    'nl-NL': /^[A-ZÁÉËÏÓÖÜÚ]+$/i,
    'nn-NO': /^[A-ZÆØÅ]+$/i,
    'hu-HU': /^[A-ZÁÉÍÓÖŐÚÜŰ]+$/i,
    'pl-PL': /^[A-ZĄĆĘŚŁŃÓŻŹ]+$/i,
    'pt-PT': /^[A-ZÃÁÀÂÇÉÊÍÕÓÔÚÜ]+$/i,
    'ru-RU': /^[А-ЯЁ]+$/i,
    'sl-SI': /^[A-ZČĆĐŠŽ]+$/i,
    'sk-SK': /^[A-ZÁČĎÉÍŇÓŠŤÚÝŽĹŔĽÄÔ]+$/i,
    'sr-RS@latin': /^[A-ZČĆŽŠĐ]+$/i,
    'sr-RS': /^[А-ЯЂЈЉЊЋЏ]+$/i,
    'sv-SE': /^[A-ZÅÄÖ]+$/i,
    'tr-TR': /^[A-ZÇĞİıÖŞÜ]+$/i,
    'uk-UA': /^[А-ЩЬЮЯЄIЇҐі]+$/i,
    'ku-IQ': /^[ئابپتجچحخدرڕزژسشعغفڤقکگلڵمنوۆھەیێيطؤثآإأكضصةظذ]+$/i,
    ar: /^[ءآأؤإئابةتثجحخدذرزسشصضطظعغفقكلمنهوىيًٌٍَُِّْٰ]+$/
  };
  exports.alpha = alpha;
  var alphanumeric = {
    'en-US': /^[0-9A-Z]+$/i,
    'bg-BG': /^[0-9А-Я]+$/i,
    'cs-CZ': /^[0-9A-ZÁČĎÉĚÍŇÓŘŠŤÚŮÝŽ]+$/i,
    'da-DK': /^[0-9A-ZÆØÅ]+$/i,
    'de-DE': /^[0-9A-ZÄÖÜß]+$/i,
    'el-GR': /^[0-9Α-ω]+$/i,
    'es-ES': /^[0-9A-ZÁÉÍÑÓÚÜ]+$/i,
    'fr-FR': /^[0-9A-ZÀÂÆÇÉÈÊËÏÎÔŒÙÛÜŸ]+$/i,
    'it-IT': /^[0-9A-ZÀÉÈÌÎÓÒÙ]+$/i,
    'hu-HU': /^[0-9A-ZÁÉÍÓÖŐÚÜŰ]+$/i,
    'nb-NO': /^[0-9A-ZÆØÅ]+$/i,
    'nl-NL': /^[0-9A-ZÁÉËÏÓÖÜÚ]+$/i,
    'nn-NO': /^[0-9A-ZÆØÅ]+$/i,
    'pl-PL': /^[0-9A-ZĄĆĘŚŁŃÓŻŹ]+$/i,
    'pt-PT': /^[0-9A-ZÃÁÀÂÇÉÊÍÕÓÔÚÜ]+$/i,
    'ru-RU': /^[0-9А-ЯЁ]+$/i,
    'sl-SI': /^[0-9A-ZČĆĐŠŽ]+$/i,
    'sk-SK': /^[0-9A-ZÁČĎÉÍŇÓŠŤÚÝŽĹŔĽÄÔ]+$/i,
    'sr-RS@latin': /^[0-9A-ZČĆŽŠĐ]+$/i,
    'sr-RS': /^[0-9А-ЯЂЈЉЊЋЏ]+$/i,
    'sv-SE': /^[0-9A-ZÅÄÖ]+$/i,
    'tr-TR': /^[0-9A-ZÇĞİıÖŞÜ]+$/i,
    'uk-UA': /^[0-9А-ЩЬЮЯЄIЇҐі]+$/i,
    'ku-IQ': /^[٠١٢٣٤٥٦٧٨٩0-9ئابپتجچحخدرڕزژسشعغفڤقکگلڵمنوۆھەیێيطؤثآإأكضصةظذ]+$/i,
    ar: /^[٠١٢٣٤٥٦٧٨٩0-9ءآأؤإئابةتثجحخدذرزسشصضطظعغفقكلمنهوىيًٌٍَُِّْٰ]+$/
  };
  exports.alphanumeric = alphanumeric;
  var decimal = {
    'en-US': '.',
    ar: '٫'
  };
  exports.decimal = decimal;
  var englishLocales = ['AU', 'GB', 'HK', 'IN', 'NZ', 'ZA', 'ZM'];
  exports.englishLocales = englishLocales;
  
  for (var locale, i = 0; i < englishLocales.length; i++) {
    locale = "en-".concat(englishLocales[i]);
    alpha[locale] = alpha['en-US'];
    alphanumeric[locale] = alphanumeric['en-US'];
    decimal[locale] = decimal['en-US'];
  } // Source: http://www.localeplanet.com/java/
  
  
  var arabicLocales = ['AE', 'BH', 'DZ', 'EG', 'IQ', 'JO', 'KW', 'LB', 'LY', 'MA', 'QM', 'QA', 'SA', 'SD', 'SY', 'TN', 'YE'];
  exports.arabicLocales = arabicLocales;
  
  for (var _locale, _i = 0; _i < arabicLocales.length; _i++) {
    _locale = "ar-".concat(arabicLocales[_i]);
    alpha[_locale] = alpha.ar;
    alphanumeric[_locale] = alphanumeric.ar;
    decimal[_locale] = decimal.ar;
  } // Source: https://en.wikipedia.org/wiki/Decimal_mark
  
  
  var dotDecimal = [];
  exports.dotDecimal = dotDecimal;
  var commaDecimal = ['bg-BG', 'cs-CZ', 'da-DK', 'de-DE', 'el-GR', 'es-ES', 'fr-FR', 'it-IT', 'ku-IQ', 'hu-HU', 'nb-NO', 'nn-NO', 'nl-NL', 'pl-PL', 'pt-PT', 'ru-RU', 'sl-SI', 'sr-RS@latin', 'sr-RS', 'sv-SE', 'tr-TR', 'uk-UA'];
  exports.commaDecimal = commaDecimal;
  
  for (var _i2 = 0; _i2 < dotDecimal.length; _i2++) {
    decimal[dotDecimal[_i2]] = decimal['en-US'];
  }
  
  for (var _i3 = 0; _i3 < commaDecimal.length; _i3++) {
    decimal[commaDecimal[_i3]] = ',';
  }
  
  alpha['pt-BR'] = alpha['pt-PT'];
  alphanumeric['pt-BR'] = alphanumeric['pt-PT'];
  decimal['pt-BR'] = decimal['pt-PT']; // see #862
  
  alpha['pl-Pl'] = alpha['pl-PL'];
  alphanumeric['pl-Pl'] = alphanumeric['pl-PL'];
  decimal['pl-Pl'] = decimal['pl-PL'];
  },{}],155:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = blacklist;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function blacklist(str, chars) {
    (0, _assertString.default)(str);
    return str.replace(new RegExp("[".concat(chars, "]+"), 'g'), '');
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],156:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = contains;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _toString = _interopRequireDefault(require("./util/toString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function contains(str, elem) {
    (0, _assertString.default)(str);
    return str.indexOf((0, _toString.default)(elem)) >= 0;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226,"./util/toString":229}],157:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = equals;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function equals(str, comparison) {
    (0, _assertString.default)(str);
    return str === comparison;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],158:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = escape;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function escape(str) {
    (0, _assertString.default)(str);
    return str.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\//g, '&#x2F;').replace(/\\/g, '&#x5C;').replace(/`/g, '&#96;');
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],159:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isAfter;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _toDate = _interopRequireDefault(require("./toDate"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isAfter(str) {
    var date = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : String(new Date());
    (0, _assertString.default)(str);
    var comparison = (0, _toDate.default)(date);
    var original = (0, _toDate.default)(str);
    return !!(original && comparison && original > comparison);
  }
  
  module.exports = exports.default;
  },{"./toDate":221,"./util/assertString":226}],160:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isAlpha;
  exports.locales = void 0;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _alpha = require("./alpha");
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isAlpha(str) {
    var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
    (0, _assertString.default)(str);
  
    if (locale in _alpha.alpha) {
      return _alpha.alpha[locale].test(str);
    }
  
    throw new Error("Invalid locale '".concat(locale, "'"));
  }
  
  var locales = Object.keys(_alpha.alpha);
  exports.locales = locales;
  },{"./alpha":154,"./util/assertString":226}],161:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isAlphanumeric;
  exports.locales = void 0;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _alpha = require("./alpha");
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isAlphanumeric(str) {
    var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'en-US';
    (0, _assertString.default)(str);
  
    if (locale in _alpha.alphanumeric) {
      return _alpha.alphanumeric[locale].test(str);
    }
  
    throw new Error("Invalid locale '".concat(locale, "'"));
  }
  
  var locales = Object.keys(_alpha.alphanumeric);
  exports.locales = locales;
  },{"./alpha":154,"./util/assertString":226}],162:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isAscii;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  /* eslint-disable no-control-regex */
  var ascii = /^[\x00-\x7F]+$/;
  /* eslint-enable no-control-regex */
  
  function isAscii(str) {
    (0, _assertString.default)(str);
    return ascii.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],163:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isBase64;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var notBase64 = /[^A-Z0-9+\/=]/i;
  
  function isBase64(str) {
    (0, _assertString.default)(str);
    var len = str.length;
  
    if (!len || len % 4 !== 0 || notBase64.test(str)) {
      return false;
    }
  
    var firstPaddingChar = str.indexOf('=');
    return firstPaddingChar === -1 || firstPaddingChar === len - 1 || firstPaddingChar === len - 2 && str[len - 1] === '=';
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],164:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isBefore;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _toDate = _interopRequireDefault(require("./toDate"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isBefore(str) {
    var date = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : String(new Date());
    (0, _assertString.default)(str);
    var comparison = (0, _toDate.default)(date);
    var original = (0, _toDate.default)(str);
    return !!(original && comparison && original < comparison);
  }
  
  module.exports = exports.default;
  },{"./toDate":221,"./util/assertString":226}],165:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isBoolean;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isBoolean(str) {
    (0, _assertString.default)(str);
    return ['true', 'false', '1', '0'].indexOf(str) >= 0;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],166:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isByteLength;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }
  
  /* eslint-disable prefer-rest-params */
  function isByteLength(str, options) {
    (0, _assertString.default)(str);
    var min;
    var max;
  
    if (_typeof(options) === 'object') {
      min = options.min || 0;
      max = options.max;
    } else {
      // backwards compatibility: isByteLength(str, min [, max])
      min = arguments[1];
      max = arguments[2];
    }
  
    var len = encodeURI(str).split(/%..|./).length - 1;
    return len >= min && (typeof max === 'undefined' || len <= max);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],167:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isCreditCard;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  /* eslint-disable max-len */
  var creditCard = /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|(222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11}|6[27][0-9]{14})$/;
  /* eslint-enable max-len */
  
  function isCreditCard(str) {
    (0, _assertString.default)(str);
    var sanitized = str.replace(/[- ]+/g, '');
  
    if (!creditCard.test(sanitized)) {
      return false;
    }
  
    var sum = 0;
    var digit;
    var tmpNum;
    var shouldDouble;
  
    for (var i = sanitized.length - 1; i >= 0; i--) {
      digit = sanitized.substring(i, i + 1);
      tmpNum = parseInt(digit, 10);
  
      if (shouldDouble) {
        tmpNum *= 2;
  
        if (tmpNum >= 10) {
          sum += tmpNum % 10 + 1;
        } else {
          sum += tmpNum;
        }
      } else {
        sum += tmpNum;
      }
  
      shouldDouble = !shouldDouble;
    }
  
    return !!(sum % 10 === 0 ? sanitized : false);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],168:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isCurrency;
  
  var _merge = _interopRequireDefault(require("./util/merge"));
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function currencyRegex(options) {
    var decimal_digits = "\\d{".concat(options.digits_after_decimal[0], "}");
    options.digits_after_decimal.forEach(function (digit, index) {
      if (index !== 0) decimal_digits = "".concat(decimal_digits, "|\\d{").concat(digit, "}");
    });
    var symbol = "(\\".concat(options.symbol.replace(/\./g, '\\.'), ")").concat(options.require_symbol ? '' : '?'),
        negative = '-?',
        whole_dollar_amount_without_sep = '[1-9]\\d*',
        whole_dollar_amount_with_sep = "[1-9]\\d{0,2}(\\".concat(options.thousands_separator, "\\d{3})*"),
        valid_whole_dollar_amounts = ['0', whole_dollar_amount_without_sep, whole_dollar_amount_with_sep],
        whole_dollar_amount = "(".concat(valid_whole_dollar_amounts.join('|'), ")?"),
        decimal_amount = "(\\".concat(options.decimal_separator, "(").concat(decimal_digits, "))").concat(options.require_decimal ? '' : '?');
    var pattern = whole_dollar_amount + (options.allow_decimal || options.require_decimal ? decimal_amount : ''); // default is negative sign before symbol, but there are two other options (besides parens)
  
    if (options.allow_negatives && !options.parens_for_negatives) {
      if (options.negative_sign_after_digits) {
        pattern += negative;
      } else if (options.negative_sign_before_digits) {
        pattern = negative + pattern;
      }
    } // South African Rand, for example, uses R 123 (space) and R-123 (no space)
  
  
    if (options.allow_negative_sign_placeholder) {
      pattern = "( (?!\\-))?".concat(pattern);
    } else if (options.allow_space_after_symbol) {
      pattern = " ?".concat(pattern);
    } else if (options.allow_space_after_digits) {
      pattern += '( (?!$))?';
    }
  
    if (options.symbol_after_digits) {
      pattern += symbol;
    } else {
      pattern = symbol + pattern;
    }
  
    if (options.allow_negatives) {
      if (options.parens_for_negatives) {
        pattern = "(\\(".concat(pattern, "\\)|").concat(pattern, ")");
      } else if (!(options.negative_sign_before_digits || options.negative_sign_after_digits)) {
        pattern = negative + pattern;
      }
    } // ensure there's a dollar and/or decimal amount, and that
    // it doesn't start with a space or a negative sign followed by a space
  
  
    return new RegExp("^(?!-? )(?=.*\\d)".concat(pattern, "$"));
  }
  
  var default_currency_options = {
    symbol: '$',
    require_symbol: false,
    allow_space_after_symbol: false,
    symbol_after_digits: false,
    allow_negatives: true,
    parens_for_negatives: false,
    negative_sign_before_digits: false,
    negative_sign_after_digits: false,
    allow_negative_sign_placeholder: false,
    thousands_separator: ',',
    decimal_separator: '.',
    allow_decimal: true,
    require_decimal: false,
    digits_after_decimal: [2],
    allow_space_after_digits: false
  };
  
  function isCurrency(str, options) {
    (0, _assertString.default)(str);
    options = (0, _merge.default)(options, default_currency_options);
    return currencyRegex(options).test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226,"./util/merge":228}],169:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isDataURI;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var validMediaType = /^[a-z]+\/[a-z0-9\-\+]+$/i;
  var validAttribute = /^[a-z\-]+=[a-z0-9\-]+$/i;
  var validData = /^[a-z0-9!\$&'\(\)\*\+,;=\-\._~:@\/\?%\s]*$/i;
  
  function isDataURI(str) {
    (0, _assertString.default)(str);
    var data = str.split(',');
  
    if (data.length < 2) {
      return false;
    }
  
    var attributes = data.shift().trim().split(';');
    var schemeAndMediaType = attributes.shift();
  
    if (schemeAndMediaType.substr(0, 5) !== 'data:') {
      return false;
    }
  
    var mediaType = schemeAndMediaType.substr(5);
  
    if (mediaType !== '' && !validMediaType.test(mediaType)) {
      return false;
    }
  
    for (var i = 0; i < attributes.length; i++) {
      if (i === attributes.length - 1 && attributes[i].toLowerCase() === 'base64') {// ok
      } else if (!validAttribute.test(attributes[i])) {
        return false;
      }
    }
  
    for (var _i = 0; _i < data.length; _i++) {
      if (!validData.test(data[_i])) {
        return false;
      }
    }
  
    return true;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],170:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isDecimal;
  
  var _merge = _interopRequireDefault(require("./util/merge"));
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _includes = _interopRequireDefault(require("./util/includes"));
  
  var _alpha = require("./alpha");
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function decimalRegExp(options) {
    var regExp = new RegExp("^[-+]?([0-9]+)?(\\".concat(_alpha.decimal[options.locale], "[0-9]{").concat(options.decimal_digits, "})").concat(options.force_decimal ? '' : '?', "$"));
    return regExp;
  }
  
  var default_decimal_options = {
    force_decimal: false,
    decimal_digits: '1,',
    locale: 'en-US'
  };
  var blacklist = ['', '-', '+'];
  
  function isDecimal(str, options) {
    (0, _assertString.default)(str);
    options = (0, _merge.default)(options, default_decimal_options);
  
    if (options.locale in _alpha.decimal) {
      return !(0, _includes.default)(blacklist, str.replace(/ /g, '')) && decimalRegExp(options).test(str);
    }
  
    throw new Error("Invalid locale '".concat(options.locale, "'"));
  }
  
  module.exports = exports.default;
  },{"./alpha":154,"./util/assertString":226,"./util/includes":227,"./util/merge":228}],171:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isDivisibleBy;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _toFloat = _interopRequireDefault(require("./toFloat"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isDivisibleBy(str, num) {
    (0, _assertString.default)(str);
    return (0, _toFloat.default)(str) % parseInt(num, 10) === 0;
  }
  
  module.exports = exports.default;
  },{"./toFloat":222,"./util/assertString":226}],172:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isEmail;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _merge = _interopRequireDefault(require("./util/merge"));
  
  var _isByteLength = _interopRequireDefault(require("./isByteLength"));
  
  var _isFQDN = _interopRequireDefault(require("./isFQDN"));
  
  var _isIP = _interopRequireDefault(require("./isIP"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var default_email_options = {
    allow_display_name: false,
    require_display_name: false,
    allow_utf8_local_part: true,
    require_tld: true
  };
  /* eslint-disable max-len */
  
  /* eslint-disable no-control-regex */
  
  var displayName = /^[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~\.\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~\,\.\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF\s]*<(.+)>$/i;
  var emailUserPart = /^[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~]+$/i;
  var gmailUserPart = /^[a-z\d]+$/;
  var quotedEmailUser = /^([\s\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e]|(\\[\x01-\x09\x0b\x0c\x0d-\x7f]))*$/i;
  var emailUserUtf8Part = /^[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+$/i;
  var quotedEmailUserUtf8 = /^([\s\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|(\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*$/i;
  /* eslint-enable max-len */
  
  /* eslint-enable no-control-regex */
  
  function isEmail(str, options) {
    (0, _assertString.default)(str);
    options = (0, _merge.default)(options, default_email_options);
  
    if (options.require_display_name || options.allow_display_name) {
      var display_email = str.match(displayName);
  
      if (display_email) {
        str = display_email[1];
      } else if (options.require_display_name) {
        return false;
      }
    }
  
    var parts = str.split('@');
    var domain = parts.pop();
    var user = parts.join('@');
    var lower_domain = domain.toLowerCase();
  
    if (options.domain_specific_validation && (lower_domain === 'gmail.com' || lower_domain === 'googlemail.com')) {
      /*
        Previously we removed dots for gmail addresses before validating.
        This was removed because it allows `multiple..dots@gmail.com`
        to be reported as valid, but it is not.
        Gmail only normalizes single dots, removing them from here is pointless,
        should be done in normalizeEmail
      */
      user = user.toLowerCase(); // Removing sub-address from username before gmail validation
  
      var username = user.split('+')[0]; // Dots are not included in gmail length restriction
  
      if (!(0, _isByteLength.default)(username.replace('.', ''), {
        min: 6,
        max: 30
      })) {
        return false;
      }
  
      var _user_parts = username.split('.');
  
      for (var i = 0; i < _user_parts.length; i++) {
        if (!gmailUserPart.test(_user_parts[i])) {
          return false;
        }
      }
    }
  
    if (!(0, _isByteLength.default)(user, {
      max: 64
    }) || !(0, _isByteLength.default)(domain, {
      max: 254
    })) {
      return false;
    }
  
    if (!(0, _isFQDN.default)(domain, {
      require_tld: options.require_tld
    })) {
      if (!options.allow_ip_domain) {
        return false;
      }
  
      if (!(0, _isIP.default)(domain)) {
        if (!domain.startsWith('[') || !domain.endsWith(']')) {
          return false;
        }
  
        var noBracketdomain = domain.substr(1, domain.length - 2);
  
        if (noBracketdomain.length === 0 || !(0, _isIP.default)(noBracketdomain)) {
          return false;
        }
      }
    }
  
    if (user[0] === '"') {
      user = user.slice(1, user.length - 1);
      return options.allow_utf8_local_part ? quotedEmailUserUtf8.test(user) : quotedEmailUser.test(user);
    }
  
    var pattern = options.allow_utf8_local_part ? emailUserUtf8Part : emailUserPart;
    var user_parts = user.split('.');
  
    for (var _i = 0; _i < user_parts.length; _i++) {
      if (!pattern.test(user_parts[_i])) {
        return false;
      }
    }
  
    return true;
  }
  
  module.exports = exports.default;
  },{"./isByteLength":166,"./isFQDN":174,"./isIP":181,"./util/assertString":226,"./util/merge":228}],173:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isEmpty;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _merge = _interopRequireDefault(require("./util/merge"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var default_is_empty_options = {
    ignore_whitespace: false
  };
  
  function isEmpty(str, options) {
    (0, _assertString.default)(str);
    options = (0, _merge.default)(options, default_is_empty_options);
    return (options.ignore_whitespace ? str.trim().length : str.length) === 0;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226,"./util/merge":228}],174:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isFQDN;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _merge = _interopRequireDefault(require("./util/merge"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var default_fqdn_options = {
    require_tld: true,
    allow_underscores: false,
    allow_trailing_dot: false
  };
  
  function isFQDN(str, options) {
    (0, _assertString.default)(str);
    options = (0, _merge.default)(options, default_fqdn_options);
    /* Remove the optional trailing dot before checking validity */
  
    if (options.allow_trailing_dot && str[str.length - 1] === '.') {
      str = str.substring(0, str.length - 1);
    }
  
    var parts = str.split('.');
  
    for (var i = 0; i < parts.length; i++) {
      if (parts[i].length > 63) {
        return false;
      }
    }
  
    if (options.require_tld) {
      var tld = parts.pop();
  
      if (!parts.length || !/^([a-z\u00a1-\uffff]{2,}|xn[a-z0-9-]{2,})$/i.test(tld)) {
        return false;
      } // disallow spaces
  
  
      if (/[\s\u2002-\u200B\u202F\u205F\u3000\uFEFF\uDB40\uDC20]/.test(tld)) {
        return false;
      }
    }
  
    for (var part, _i = 0; _i < parts.length; _i++) {
      part = parts[_i];
  
      if (options.allow_underscores) {
        part = part.replace(/_/g, '');
      }
  
      if (!/^[a-z\u00a1-\uffff0-9-]+$/i.test(part)) {
        return false;
      } // disallow full-width chars
  
  
      if (/[\uff01-\uff5e]/.test(part)) {
        return false;
      }
  
      if (part[0] === '-' || part[part.length - 1] === '-') {
        return false;
      }
    }
  
    return true;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226,"./util/merge":228}],175:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isFloat;
  exports.locales = void 0;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _alpha = require("./alpha");
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isFloat(str, options) {
    (0, _assertString.default)(str);
    options = options || {};
    var float = new RegExp("^(?:[-+])?(?:[0-9]+)?(?:\\".concat(options.locale ? _alpha.decimal[options.locale] : '.', "[0-9]*)?(?:[eE][\\+\\-]?(?:[0-9]+))?$"));
  
    if (str === '' || str === '.' || str === '-' || str === '+') {
      return false;
    }
  
    var value = parseFloat(str.replace(',', '.'));
    return float.test(str) && (!options.hasOwnProperty('min') || value >= options.min) && (!options.hasOwnProperty('max') || value <= options.max) && (!options.hasOwnProperty('lt') || value < options.lt) && (!options.hasOwnProperty('gt') || value > options.gt);
  }
  
  var locales = Object.keys(_alpha.decimal);
  exports.locales = locales;
  },{"./alpha":154,"./util/assertString":226}],176:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isFullWidth;
  exports.fullWidth = void 0;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var fullWidth = /[^\u0020-\u007E\uFF61-\uFF9F\uFFA0-\uFFDC\uFFE8-\uFFEE0-9a-zA-Z]/;
  exports.fullWidth = fullWidth;
  
  function isFullWidth(str) {
    (0, _assertString.default)(str);
    return fullWidth.test(str);
  }
  },{"./util/assertString":226}],177:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isHalfWidth;
  exports.halfWidth = void 0;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var halfWidth = /[\u0020-\u007E\uFF61-\uFF9F\uFFA0-\uFFDC\uFFE8-\uFFEE0-9a-zA-Z]/;
  exports.halfWidth = halfWidth;
  
  function isHalfWidth(str) {
    (0, _assertString.default)(str);
    return halfWidth.test(str);
  }
  },{"./util/assertString":226}],178:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isHash;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var lengths = {
    md5: 32,
    md4: 32,
    sha1: 40,
    sha256: 64,
    sha384: 96,
    sha512: 128,
    ripemd128: 32,
    ripemd160: 40,
    tiger128: 32,
    tiger160: 40,
    tiger192: 48,
    crc32: 8,
    crc32b: 8
  };
  
  function isHash(str, algorithm) {
    (0, _assertString.default)(str);
    var hash = new RegExp("^[a-f0-9]{".concat(lengths[algorithm], "}$"));
    return hash.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],179:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isHexColor;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var hexcolor = /^#?([0-9A-F]{3}|[0-9A-F]{6})$/i;
  
  function isHexColor(str) {
    (0, _assertString.default)(str);
    return hexcolor.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],180:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isHexadecimal;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var hexadecimal = /^[0-9A-F]+$/i;
  
  function isHexadecimal(str) {
    (0, _assertString.default)(str);
    return hexadecimal.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],181:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isIP;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var ipv4Maybe = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
  var ipv6Block = /^[0-9A-F]{1,4}$/i;
  
  function isIP(str) {
    var version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    (0, _assertString.default)(str);
    version = String(version);
  
    if (!version) {
      return isIP(str, 4) || isIP(str, 6);
    } else if (version === '4') {
      if (!ipv4Maybe.test(str)) {
        return false;
      }
  
      var parts = str.split('.').sort(function (a, b) {
        return a - b;
      });
      return parts[3] <= 255;
    } else if (version === '6') {
      var blocks = str.split(':');
      var foundOmissionBlock = false; // marker to indicate ::
      // At least some OS accept the last 32 bits of an IPv6 address
      // (i.e. 2 of the blocks) in IPv4 notation, and RFC 3493 says
      // that '::ffff:a.b.c.d' is valid for IPv4-mapped IPv6 addresses,
      // and '::a.b.c.d' is deprecated, but also valid.
  
      var foundIPv4TransitionBlock = isIP(blocks[blocks.length - 1], 4);
      var expectedNumberOfBlocks = foundIPv4TransitionBlock ? 7 : 8;
  
      if (blocks.length > expectedNumberOfBlocks) {
        return false;
      } // initial or final ::
  
  
      if (str === '::') {
        return true;
      } else if (str.substr(0, 2) === '::') {
        blocks.shift();
        blocks.shift();
        foundOmissionBlock = true;
      } else if (str.substr(str.length - 2) === '::') {
        blocks.pop();
        blocks.pop();
        foundOmissionBlock = true;
      }
  
      for (var i = 0; i < blocks.length; ++i) {
        // test for a :: which can not be at the string start/end
        // since those cases have been handled above
        if (blocks[i] === '' && i > 0 && i < blocks.length - 1) {
          if (foundOmissionBlock) {
            return false; // multiple :: in address
          }
  
          foundOmissionBlock = true;
        } else if (foundIPv4TransitionBlock && i === blocks.length - 1) {// it has been checked before that the last
          // block is a valid IPv4 address
        } else if (!ipv6Block.test(blocks[i])) {
          return false;
        }
      }
  
      if (foundOmissionBlock) {
        return blocks.length >= 1;
      }
  
      return blocks.length === expectedNumberOfBlocks;
    }
  
    return false;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],182:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isIPRange;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _isIP = _interopRequireDefault(require("./isIP"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var subnetMaybe = /^\d{1,2}$/;
  
  function isIPRange(str) {
    (0, _assertString.default)(str);
    var parts = str.split('/'); // parts[0] -> ip, parts[1] -> subnet
  
    if (parts.length !== 2) {
      return false;
    }
  
    if (!subnetMaybe.test(parts[1])) {
      return false;
    } // Disallow preceding 0 i.e. 01, 02, ...
  
  
    if (parts[1].length > 1 && parts[1].startsWith('0')) {
      return false;
    }
  
    return (0, _isIP.default)(parts[0], 4) && parts[1] <= 32 && parts[1] >= 0;
  }
  
  module.exports = exports.default;
  },{"./isIP":181,"./util/assertString":226}],183:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isISBN;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var isbn10Maybe = /^(?:[0-9]{9}X|[0-9]{10})$/;
  var isbn13Maybe = /^(?:[0-9]{13})$/;
  var factor = [1, 3];
  
  function isISBN(str) {
    var version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    (0, _assertString.default)(str);
    version = String(version);
  
    if (!version) {
      return isISBN(str, 10) || isISBN(str, 13);
    }
  
    var sanitized = str.replace(/[\s-]+/g, '');
    var checksum = 0;
    var i;
  
    if (version === '10') {
      if (!isbn10Maybe.test(sanitized)) {
        return false;
      }
  
      for (i = 0; i < 9; i++) {
        checksum += (i + 1) * sanitized.charAt(i);
      }
  
      if (sanitized.charAt(9) === 'X') {
        checksum += 10 * 10;
      } else {
        checksum += 10 * sanitized.charAt(9);
      }
  
      if (checksum % 11 === 0) {
        return !!sanitized;
      }
    } else if (version === '13') {
      if (!isbn13Maybe.test(sanitized)) {
        return false;
      }
  
      for (i = 0; i < 12; i++) {
        checksum += factor[i % 2] * sanitized.charAt(i);
      }
  
      if (sanitized.charAt(12) - (10 - checksum % 10) % 10 === 0) {
        return !!sanitized;
      }
    }
  
    return false;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],184:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isISIN;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var isin = /^[A-Z]{2}[0-9A-Z]{9}[0-9]$/;
  
  function isISIN(str) {
    (0, _assertString.default)(str);
  
    if (!isin.test(str)) {
      return false;
    }
  
    var checksumStr = str.replace(/[A-Z]/g, function (character) {
      return parseInt(character, 36);
    });
    var sum = 0;
    var digit;
    var tmpNum;
    var shouldDouble = true;
  
    for (var i = checksumStr.length - 2; i >= 0; i--) {
      digit = checksumStr.substring(i, i + 1);
      tmpNum = parseInt(digit, 10);
  
      if (shouldDouble) {
        tmpNum *= 2;
  
        if (tmpNum >= 10) {
          sum += tmpNum + 1;
        } else {
          sum += tmpNum;
        }
      } else {
        sum += tmpNum;
      }
  
      shouldDouble = !shouldDouble;
    }
  
    return parseInt(str.substr(str.length - 1), 10) === (10000 - sum) % 10;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],185:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isISO31661Alpha2;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _includes = _interopRequireDefault(require("./util/includes"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  // from https://en.wikipedia.org/wiki/ISO_3166-1_alpha-2
  var validISO31661Alpha2CountriesCodes = ['AD', 'AE', 'AF', 'AG', 'AI', 'AL', 'AM', 'AO', 'AQ', 'AR', 'AS', 'AT', 'AU', 'AW', 'AX', 'AZ', 'BA', 'BB', 'BD', 'BE', 'BF', 'BG', 'BH', 'BI', 'BJ', 'BL', 'BM', 'BN', 'BO', 'BQ', 'BR', 'BS', 'BT', 'BV', 'BW', 'BY', 'BZ', 'CA', 'CC', 'CD', 'CF', 'CG', 'CH', 'CI', 'CK', 'CL', 'CM', 'CN', 'CO', 'CR', 'CU', 'CV', 'CW', 'CX', 'CY', 'CZ', 'DE', 'DJ', 'DK', 'DM', 'DO', 'DZ', 'EC', 'EE', 'EG', 'EH', 'ER', 'ES', 'ET', 'FI', 'FJ', 'FK', 'FM', 'FO', 'FR', 'GA', 'GB', 'GD', 'GE', 'GF', 'GG', 'GH', 'GI', 'GL', 'GM', 'GN', 'GP', 'GQ', 'GR', 'GS', 'GT', 'GU', 'GW', 'GY', 'HK', 'HM', 'HN', 'HR', 'HT', 'HU', 'ID', 'IE', 'IL', 'IM', 'IN', 'IO', 'IQ', 'IR', 'IS', 'IT', 'JE', 'JM', 'JO', 'JP', 'KE', 'KG', 'KH', 'KI', 'KM', 'KN', 'KP', 'KR', 'KW', 'KY', 'KZ', 'LA', 'LB', 'LC', 'LI', 'LK', 'LR', 'LS', 'LT', 'LU', 'LV', 'LY', 'MA', 'MC', 'MD', 'ME', 'MF', 'MG', 'MH', 'MK', 'ML', 'MM', 'MN', 'MO', 'MP', 'MQ', 'MR', 'MS', 'MT', 'MU', 'MV', 'MW', 'MX', 'MY', 'MZ', 'NA', 'NC', 'NE', 'NF', 'NG', 'NI', 'NL', 'NO', 'NP', 'NR', 'NU', 'NZ', 'OM', 'PA', 'PE', 'PF', 'PG', 'PH', 'PK', 'PL', 'PM', 'PN', 'PR', 'PS', 'PT', 'PW', 'PY', 'QA', 'RE', 'RO', 'RS', 'RU', 'RW', 'SA', 'SB', 'SC', 'SD', 'SE', 'SG', 'SH', 'SI', 'SJ', 'SK', 'SL', 'SM', 'SN', 'SO', 'SR', 'SS', 'ST', 'SV', 'SX', 'SY', 'SZ', 'TC', 'TD', 'TF', 'TG', 'TH', 'TJ', 'TK', 'TL', 'TM', 'TN', 'TO', 'TR', 'TT', 'TV', 'TW', 'TZ', 'UA', 'UG', 'UM', 'US', 'UY', 'UZ', 'VA', 'VC', 'VE', 'VG', 'VI', 'VN', 'VU', 'WF', 'WS', 'YE', 'YT', 'ZA', 'ZM', 'ZW'];
  
  function isISO31661Alpha2(str) {
    (0, _assertString.default)(str);
    return (0, _includes.default)(validISO31661Alpha2CountriesCodes, str.toUpperCase());
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226,"./util/includes":227}],186:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isISO31661Alpha3;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _includes = _interopRequireDefault(require("./util/includes"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  // from https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3
  var validISO31661Alpha3CountriesCodes = ['AFG', 'ALA', 'ALB', 'DZA', 'ASM', 'AND', 'AGO', 'AIA', 'ATA', 'ATG', 'ARG', 'ARM', 'ABW', 'AUS', 'AUT', 'AZE', 'BHS', 'BHR', 'BGD', 'BRB', 'BLR', 'BEL', 'BLZ', 'BEN', 'BMU', 'BTN', 'BOL', 'BES', 'BIH', 'BWA', 'BVT', 'BRA', 'IOT', 'BRN', 'BGR', 'BFA', 'BDI', 'KHM', 'CMR', 'CAN', 'CPV', 'CYM', 'CAF', 'TCD', 'CHL', 'CHN', 'CXR', 'CCK', 'COL', 'COM', 'COG', 'COD', 'COK', 'CRI', 'CIV', 'HRV', 'CUB', 'CUW', 'CYP', 'CZE', 'DNK', 'DJI', 'DMA', 'DOM', 'ECU', 'EGY', 'SLV', 'GNQ', 'ERI', 'EST', 'ETH', 'FLK', 'FRO', 'FJI', 'FIN', 'FRA', 'GUF', 'PYF', 'ATF', 'GAB', 'GMB', 'GEO', 'DEU', 'GHA', 'GIB', 'GRC', 'GRL', 'GRD', 'GLP', 'GUM', 'GTM', 'GGY', 'GIN', 'GNB', 'GUY', 'HTI', 'HMD', 'VAT', 'HND', 'HKG', 'HUN', 'ISL', 'IND', 'IDN', 'IRN', 'IRQ', 'IRL', 'IMN', 'ISR', 'ITA', 'JAM', 'JPN', 'JEY', 'JOR', 'KAZ', 'KEN', 'KIR', 'PRK', 'KOR', 'KWT', 'KGZ', 'LAO', 'LVA', 'LBN', 'LSO', 'LBR', 'LBY', 'LIE', 'LTU', 'LUX', 'MAC', 'MKD', 'MDG', 'MWI', 'MYS', 'MDV', 'MLI', 'MLT', 'MHL', 'MTQ', 'MRT', 'MUS', 'MYT', 'MEX', 'FSM', 'MDA', 'MCO', 'MNG', 'MNE', 'MSR', 'MAR', 'MOZ', 'MMR', 'NAM', 'NRU', 'NPL', 'NLD', 'NCL', 'NZL', 'NIC', 'NER', 'NGA', 'NIU', 'NFK', 'MNP', 'NOR', 'OMN', 'PAK', 'PLW', 'PSE', 'PAN', 'PNG', 'PRY', 'PER', 'PHL', 'PCN', 'POL', 'PRT', 'PRI', 'QAT', 'REU', 'ROU', 'RUS', 'RWA', 'BLM', 'SHN', 'KNA', 'LCA', 'MAF', 'SPM', 'VCT', 'WSM', 'SMR', 'STP', 'SAU', 'SEN', 'SRB', 'SYC', 'SLE', 'SGP', 'SXM', 'SVK', 'SVN', 'SLB', 'SOM', 'ZAF', 'SGS', 'SSD', 'ESP', 'LKA', 'SDN', 'SUR', 'SJM', 'SWZ', 'SWE', 'CHE', 'SYR', 'TWN', 'TJK', 'TZA', 'THA', 'TLS', 'TGO', 'TKL', 'TON', 'TTO', 'TUN', 'TUR', 'TKM', 'TCA', 'TUV', 'UGA', 'UKR', 'ARE', 'GBR', 'USA', 'UMI', 'URY', 'UZB', 'VUT', 'VEN', 'VNM', 'VGB', 'VIR', 'WLF', 'ESH', 'YEM', 'ZMB', 'ZWE'];
  
  function isISO31661Alpha3(str) {
    (0, _assertString.default)(str);
    return (0, _includes.default)(validISO31661Alpha3CountriesCodes, str.toUpperCase());
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226,"./util/includes":227}],187:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isISO8601;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  /* eslint-disable max-len */
  // from http://goo.gl/0ejHHW
  var iso8601 = /^([\+-]?\d{4}(?!\d{2}\b))((-?)((0[1-9]|1[0-2])(\3([12]\d|0[1-9]|3[01]))?|W([0-4]\d|5[0-3])(-?[1-7])?|(00[1-9]|0[1-9]\d|[12]\d{2}|3([0-5]\d|6[1-6])))([T\s]((([01]\d|2[0-3])((:?)[0-5]\d)?|24:?00)([\.,]\d+(?!:))?)?(\17[0-5]\d([\.,]\d+)?)?([zZ]|([\+-])([01]\d|2[0-3]):?([0-5]\d)?)?)?)?$/;
  /* eslint-enable max-len */
  
  var isValidDate = function isValidDate(str) {
    // str must have passed the ISO8601 check
    // this check is meant to catch invalid dates
    // like 2009-02-31
    // first check for ordinal dates
    var ordinalMatch = str.match(/^(\d{4})-?(\d{3})([ T]{1}\.*|$)/);
  
    if (ordinalMatch) {
      var oYear = Number(ordinalMatch[1]);
      var oDay = Number(ordinalMatch[2]); // if is leap year
  
      if (oYear % 4 === 0 && oYear % 100 !== 0) return oDay <= 366;
      return oDay <= 365;
    }
  
    var match = str.match(/(\d{4})-?(\d{0,2})-?(\d*)/).map(Number);
    var year = match[1];
    var month = match[2];
    var day = match[3];
    var monthString = month ? "0".concat(month).slice(-2) : month;
    var dayString = day ? "0".concat(day).slice(-2) : day; // create a date object and compare
  
    var d = new Date("".concat(year, "-").concat(monthString || '01', "-").concat(dayString || '01'));
    if (isNaN(d.getUTCFullYear())) return false;
  
    if (month && day) {
      return d.getUTCFullYear() === year && d.getUTCMonth() + 1 === month && d.getUTCDate() === day;
    }
  
    return true;
  };
  
  function isISO8601(str, options) {
    (0, _assertString.default)(str);
    var check = iso8601.test(str);
    if (!options) return check;
    if (check && options.strict) return isValidDate(str);
    return check;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],188:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isISRC;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  // see http://isrc.ifpi.org/en/isrc-standard/code-syntax
  var isrc = /^[A-Z]{2}[0-9A-Z]{3}\d{2}\d{5}$/;
  
  function isISRC(str) {
    (0, _assertString.default)(str);
    return isrc.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],189:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isISSN;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var issn = '^\\d{4}-?\\d{3}[\\dX]$';
  
  function isISSN(str) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    (0, _assertString.default)(str);
    var testIssn = issn;
    testIssn = options.require_hyphen ? testIssn.replace('?', '') : testIssn;
    testIssn = options.case_sensitive ? new RegExp(testIssn) : new RegExp(testIssn, 'i');
  
    if (!testIssn.test(str)) {
      return false;
    }
  
    var digits = str.replace('-', '').toUpperCase();
    var checksum = 0;
  
    for (var i = 0; i < digits.length; i++) {
      var digit = digits[i];
      checksum += (digit === 'X' ? 10 : +digit) * (8 - i);
    }
  
    return checksum % 11 === 0;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],190:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isIdentityCard;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var validators = {
    ES: function ES(str) {
      (0, _assertString.default)(str);
      var DNI = /^[0-9X-Z][0-9]{7}[TRWAGMYFPDXBNJZSQVHLCKE]$/;
      var charsValue = {
        X: 0,
        Y: 1,
        Z: 2
      };
      var controlDigits = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E']; // sanitize user input
  
      var sanitized = str.trim().toUpperCase(); // validate the data structure
  
      if (!DNI.test(sanitized)) {
        return false;
      } // validate the control digit
  
  
      var number = sanitized.slice(0, -1).replace(/[X,Y,Z]/g, function (char) {
        return charsValue[char];
      });
      return sanitized.endsWith(controlDigits[number % 23]);
    }
  };
  
  function isIdentityCard(str) {
    var locale = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'any';
    (0, _assertString.default)(str);
  
    if (locale in validators) {
      return validators[locale](str);
    } else if (locale === 'any') {
      for (var key in validators) {
        if (validators.hasOwnProperty(key)) {
          var validator = validators[key];
  
          if (validator(str)) {
            return true;
          }
        }
      }
  
      return false;
    }
  
    throw new Error("Invalid locale '".concat(locale, "'"));
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],191:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isIn;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _toString = _interopRequireDefault(require("./util/toString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }
  
  function isIn(str, options) {
    (0, _assertString.default)(str);
    var i;
  
    if (Object.prototype.toString.call(options) === '[object Array]') {
      var array = [];
  
      for (i in options) {
        if ({}.hasOwnProperty.call(options, i)) {
          array[i] = (0, _toString.default)(options[i]);
        }
      }
  
      return array.indexOf(str) >= 0;
    } else if (_typeof(options) === 'object') {
      return options.hasOwnProperty(str);
    } else if (options && typeof options.indexOf === 'function') {
      return options.indexOf(str) >= 0;
    }
  
    return false;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226,"./util/toString":229}],192:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isInt;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var int = /^(?:[-+]?(?:0|[1-9][0-9]*))$/;
  var intLeadingZeroes = /^[-+]?[0-9]+$/;
  
  function isInt(str, options) {
    (0, _assertString.default)(str);
    options = options || {}; // Get the regex to use for testing, based on whether
    // leading zeroes are allowed or not.
  
    var regex = options.hasOwnProperty('allow_leading_zeroes') && !options.allow_leading_zeroes ? int : intLeadingZeroes; // Check min/max/lt/gt
  
    var minCheckPassed = !options.hasOwnProperty('min') || str >= options.min;
    var maxCheckPassed = !options.hasOwnProperty('max') || str <= options.max;
    var ltCheckPassed = !options.hasOwnProperty('lt') || str < options.lt;
    var gtCheckPassed = !options.hasOwnProperty('gt') || str > options.gt;
    return regex.test(str) && minCheckPassed && maxCheckPassed && ltCheckPassed && gtCheckPassed;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],193:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isJSON;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }
  
  function isJSON(str) {
    (0, _assertString.default)(str);
  
    try {
      var obj = JSON.parse(str);
      return !!obj && _typeof(obj) === 'object';
    } catch (e) {
      /* ignore */
    }
  
    return false;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],194:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isJWT;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var jwt = /^([A-Za-z0-9\-_~+\/]+[=]{0,2})\.([A-Za-z0-9\-_~+\/]+[=]{0,2})(?:\.([A-Za-z0-9\-_~+\/]+[=]{0,2}))?$/;
  
  function isJWT(str) {
    (0, _assertString.default)(str);
    return jwt.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],195:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = _default;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var lat = /^\(?[+-]?(90(\.0+)?|[1-8]?\d(\.\d+)?)$/;
  var long = /^\s?[+-]?(180(\.0+)?|1[0-7]\d(\.\d+)?|\d{1,2}(\.\d+)?)\)?$/;
  
  function _default(str) {
    (0, _assertString.default)(str);
    if (!str.includes(',')) return false;
    var pair = str.split(',');
    return lat.test(pair[0]) && long.test(pair[1]);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],196:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isLength;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }
  
  /* eslint-disable prefer-rest-params */
  function isLength(str, options) {
    (0, _assertString.default)(str);
    var min;
    var max;
  
    if (_typeof(options) === 'object') {
      min = options.min || 0;
      max = options.max;
    } else {
      // backwards compatibility: isLength(str, min [, max])
      min = arguments[1];
      max = arguments[2];
    }
  
    var surrogatePairs = str.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g) || [];
    var len = str.length - surrogatePairs.length;
    return len >= min && (typeof max === 'undefined' || len <= max);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],197:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isLowercase;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isLowercase(str) {
    (0, _assertString.default)(str);
    return str === str.toLowerCase();
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],198:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isMACAddress;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var macAddress = /^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$/;
  var macAddressNoColons = /^([0-9a-fA-F]){12}$/;
  
  function isMACAddress(str, options) {
    (0, _assertString.default)(str);
  
    if (options && options.no_colons) {
      return macAddressNoColons.test(str);
    }
  
    return macAddress.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],199:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isMD5;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var md5 = /^[a-f0-9]{32}$/;
  
  function isMD5(str) {
    (0, _assertString.default)(str);
    return md5.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],200:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isMagnetURI;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var magnetURI = /^magnet:\?xt=urn:[a-z0-9]+:[a-z0-9]{32,40}&dn=.+&tr=.+$/i;
  
  function isMagnetURI(url) {
    (0, _assertString.default)(url);
    return magnetURI.test(url.trim());
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],201:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isMimeType;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  /*
    Checks if the provided string matches to a correct Media type format (MIME type)
  
    This function only checks is the string format follows the
    etablished rules by the according RFC specifications.
    This function supports 'charset' in textual media types
    (https://tools.ietf.org/html/rfc6657).
  
    This function does not check against all the media types listed
    by the IANA (https://www.iana.org/assignments/media-types/media-types.xhtml)
    because of lightness purposes : it would require to include
    all these MIME types in this librairy, which would weigh it
    significantly. This kind of effort maybe is not worth for the use that
    this function has in this entire librairy.
  
    More informations in the RFC specifications :
    - https://tools.ietf.org/html/rfc2045
    - https://tools.ietf.org/html/rfc2046
    - https://tools.ietf.org/html/rfc7231#section-3.1.1.1
    - https://tools.ietf.org/html/rfc7231#section-3.1.1.5
  */
  // Match simple MIME types
  // NB :
  //   Subtype length must not exceed 100 characters.
  //   This rule does not comply to the RFC specs (what is the max length ?).
  var mimeTypeSimple = /^(application|audio|font|image|message|model|multipart|text|video)\/[a-zA-Z0-9\.\-\+]{1,100}$/i; // eslint-disable-line max-len
  // Handle "charset" in "text/*"
  
  var mimeTypeText = /^text\/[a-zA-Z0-9\.\-\+]{1,100};\s?charset=("[a-zA-Z0-9\.\-\+\s]{0,70}"|[a-zA-Z0-9\.\-\+]{0,70})(\s?\([a-zA-Z0-9\.\-\+\s]{1,20}\))?$/i; // eslint-disable-line max-len
  // Handle "boundary" in "multipart/*"
  
  var mimeTypeMultipart = /^multipart\/[a-zA-Z0-9\.\-\+]{1,100}(;\s?(boundary|charset)=("[a-zA-Z0-9\.\-\+\s]{0,70}"|[a-zA-Z0-9\.\-\+]{0,70})(\s?\([a-zA-Z0-9\.\-\+\s]{1,20}\))?){0,2}$/i; // eslint-disable-line max-len
  
  function isMimeType(str) {
    (0, _assertString.default)(str);
    return mimeTypeSimple.test(str) || mimeTypeText.test(str) || mimeTypeMultipart.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],202:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isMobilePhone;
  exports.locales = void 0;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  /* eslint-disable max-len */
  var phones = {
    'ar-AE': /^((\+?971)|0)?5[024568]\d{7}$/,
    'ar-DZ': /^(\+?213|0)(5|6|7)\d{8}$/,
    'ar-EG': /^((\+?20)|0)?1[012]\d{8}$/,
    'ar-IQ': /^(\+?964|0)?7[0-9]\d{8}$/,
    'ar-JO': /^(\+?962|0)?7[789]\d{7}$/,
    'ar-KW': /^(\+?965)[569]\d{7}$/,
    'ar-SA': /^(!?(\+?966)|0)?5\d{8}$/,
    'ar-SY': /^(!?(\+?963)|0)?9\d{8}$/,
    'ar-TN': /^(\+?216)?[2459]\d{7}$/,
    'be-BY': /^(\+?375)?(24|25|29|33|44)\d{7}$/,
    'bg-BG': /^(\+?359|0)?8[789]\d{7}$/,
    'bn-BD': /\+?(88)?0?1[356789][0-9]{8}\b/,
    'cs-CZ': /^(\+?420)? ?[1-9][0-9]{2} ?[0-9]{3} ?[0-9]{3}$/,
    'da-DK': /^(\+?45)?\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{2}$/,
    'de-DE': /^(\+49)?0?1(5[0-25-9]\d|6([23]|0\d?)|7([0-57-9]|6\d))\d{7}$/,
    'el-GR': /^(\+?30|0)?(69\d{8})$/,
    'en-AU': /^(\+?61|0)4\d{8}$/,
    'en-GB': /^(\+?44|0)7\d{9}$/,
    'en-GH': /^(\+233|0)(20|50|24|54|27|57|26|56|23|28)\d{7}$/,
    'en-HK': /^(\+?852\-?)?[456789]\d{3}\-?\d{4}$/,
    'en-IN': /^(\+?91|0)?[6789]\d{9}$/,
    'en-KE': /^(\+?254|0)?[7]\d{8}$/,
    'en-MU': /^(\+?230|0)?\d{8}$/,
    'en-NG': /^(\+?234|0)?[789]\d{9}$/,
    'en-NZ': /^(\+?64|0)[28]\d{7,9}$/,
    'en-PK': /^((\+92)|(0092))-{0,1}\d{3}-{0,1}\d{7}$|^\d{11}$|^\d{4}-\d{7}$/,
    'en-RW': /^(\+?250|0)?[7]\d{8}$/,
    'en-SG': /^(\+65)?[89]\d{7}$/,
    'en-TZ': /^(\+?255|0)?[67]\d{8}$/,
    'en-UG': /^(\+?256|0)?[7]\d{8}$/,
    'en-US': /^((\+1|1)?( |-)?)?(\([2-9][0-9]{2}\)|[2-9][0-9]{2})( |-)?([2-9][0-9]{2}( |-)?[0-9]{4})$/,
    'en-ZA': /^(\+?27|0)\d{9}$/,
    'en-ZM': /^(\+?26)?09[567]\d{7}$/,
    'es-ES': /^(\+?34)?(6\d{1}|7[1234])\d{7}$/,
    'es-MX': /^(\+?52)?(1|01)?\d{10,11}$/,
    'es-UY': /^(\+598|0)9[1-9][\d]{6}$/,
    'et-EE': /^(\+?372)?\s?(5|8[1-4])\s?([0-9]\s?){6,7}$/,
    'fa-IR': /^(\+?98[\-\s]?|0)9[0-39]\d[\-\s]?\d{3}[\-\s]?\d{4}$/,
    'fi-FI': /^(\+?358|0)\s?(4(0|1|2|4|5|6)?|50)\s?(\d\s?){4,8}\d$/,
    'fo-FO': /^(\+?298)?\s?\d{2}\s?\d{2}\s?\d{2}$/,
    'fr-FR': /^(\+?33|0)[67]\d{8}$/,
    'he-IL': /^(\+972|0)([23489]|5[012345689]|77)[1-9]\d{6}$/,
    'hu-HU': /^(\+?36)(20|30|70)\d{7}$/,
    'id-ID': /^(\+?62|0)8(1[123456789]|2[1238]|3[1238]|5[12356789]|7[78]|9[56789]|8[123456789])([\s?|\d]{5,11})$/,
    'it-IT': /^(\+?39)?\s?3\d{2} ?\d{6,7}$/,
    'ja-JP': /^(\+?81|0)[789]0[ \-]?[1-9]\d{2}[ \-]?\d{5}$/,
    'kk-KZ': /^(\+?7|8)?7\d{9}$/,
    'kl-GL': /^(\+?299)?\s?\d{2}\s?\d{2}\s?\d{2}$/,
    'ko-KR': /^((\+?82)[ \-]?)?0?1([0|1|6|7|8|9]{1})[ \-]?\d{3,4}[ \-]?\d{4}$/,
    'lt-LT': /^(\+370|8)\d{8}$/,
    'ms-MY': /^(\+?6?01){1}(([0145]{1}(\-|\s)?\d{7,8})|([236789]{1}(\s|\-)?\d{7}))$/,
    'nb-NO': /^(\+?47)?[49]\d{7}$/,
    'nl-BE': /^(\+?32|0)4?\d{8}$/,
    'nn-NO': /^(\+?47)?[49]\d{7}$/,
    'pl-PL': /^(\+?48)? ?[5-8]\d ?\d{3} ?\d{2} ?\d{2}$/,
    'pt-BR': /(?=^(\+?5{2}\-?|0)[1-9]{2}\-?\d{4}\-?\d{4}$)(^(\+?5{2}\-?|0)[1-9]{2}\-?[6-9]{1}\d{3}\-?\d{4}$)|(^(\+?5{2}\-?|0)[1-9]{2}\-?9[6-9]{1}\d{3}\-?\d{4}$)/,
    'pt-PT': /^(\+?351)?9[1236]\d{7}$/,
    'ro-RO': /^(\+?4?0)\s?7\d{2}(\/|\s|\.|\-)?\d{3}(\s|\.|\-)?\d{3}$/,
    'ru-RU': /^(\+?7|8)?9\d{9}$/,
    'sl-SI': /^(\+386\s?|0)(\d{1}\s?\d{3}\s?\d{2}\s?\d{2}|\d{2}\s?\d{3}\s?\d{3})$/,
    'sk-SK': /^(\+?421)? ?[1-9][0-9]{2} ?[0-9]{3} ?[0-9]{3}$/,
    'sr-RS': /^(\+3816|06)[- \d]{5,9}$/,
    'sv-SE': /^(\+?46|0)[\s\-]?7[\s\-]?[02369]([\s\-]?\d){7}$/,
    'th-TH': /^(\+66|66|0)\d{9}$/,
    'tr-TR': /^(\+?90|0)?5\d{9}$/,
    'uk-UA': /^(\+?38|8)?0\d{9}$/,
    'vi-VN': /^(\+?84|0)((3([2-9]))|(5([689]))|(7([0|6-9]))|(8([1-5]))|(9([0-9])))([0-9]{7})$/,
    'zh-CN': /^((\+|00)86)?1([358][0-9]|4[579]|66|7[0135678]|9[89])[0-9]{8}$/,
    'zh-TW': /^(\+?886\-?|0)?9\d{8}$/
  };
  /* eslint-enable max-len */
  // aliases
  
  phones['en-CA'] = phones['en-US'];
  phones['fr-BE'] = phones['nl-BE'];
  phones['zh-HK'] = phones['en-HK'];
  
  function isMobilePhone(str, locale, options) {
    (0, _assertString.default)(str);
  
    if (options && options.strictMode && !str.startsWith('+')) {
      return false;
    }
  
    if (Array.isArray(locale)) {
      return locale.some(function (key) {
        if (phones.hasOwnProperty(key)) {
          var phone = phones[key];
  
          if (phone.test(str)) {
            return true;
          }
        }
  
        return false;
      });
    } else if (locale in phones) {
      return phones[locale].test(str); // alias falsey locale as 'any'
    } else if (!locale || locale === 'any') {
      for (var key in phones) {
        if (phones.hasOwnProperty(key)) {
          var phone = phones[key];
  
          if (phone.test(str)) {
            return true;
          }
        }
      }
  
      return false;
    }
  
    throw new Error("Invalid locale '".concat(locale, "'"));
  }
  
  var locales = Object.keys(phones);
  exports.locales = locales;
  },{"./util/assertString":226}],203:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isMongoId;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _isHexadecimal = _interopRequireDefault(require("./isHexadecimal"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isMongoId(str) {
    (0, _assertString.default)(str);
    return (0, _isHexadecimal.default)(str) && str.length === 24;
  }
  
  module.exports = exports.default;
  },{"./isHexadecimal":180,"./util/assertString":226}],204:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isMultibyte;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  /* eslint-disable no-control-regex */
  var multibyte = /[^\x00-\x7F]/;
  /* eslint-enable no-control-regex */
  
  function isMultibyte(str) {
    (0, _assertString.default)(str);
    return multibyte.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],205:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isNumeric;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var numeric = /^[+-]?([0-9]*[.])?[0-9]+$/;
  var numericNoSymbols = /^[0-9]+$/;
  
  function isNumeric(str, options) {
    (0, _assertString.default)(str);
  
    if (options && options.no_symbols) {
      return numericNoSymbols.test(str);
    }
  
    return numeric.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],206:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isPort;
  
  var _isInt = _interopRequireDefault(require("./isInt"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isPort(str) {
    return (0, _isInt.default)(str, {
      min: 0,
      max: 65535
    });
  }
  
  module.exports = exports.default;
  },{"./isInt":192}],207:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = _default;
  exports.locales = void 0;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  // common patterns
  var threeDigit = /^\d{3}$/;
  var fourDigit = /^\d{4}$/;
  var fiveDigit = /^\d{5}$/;
  var sixDigit = /^\d{6}$/;
  var patterns = {
    AD: /^AD\d{3}$/,
    AT: fourDigit,
    AU: fourDigit,
    BE: fourDigit,
    BG: fourDigit,
    CA: /^[ABCEGHJKLMNPRSTVXY]\d[ABCEGHJ-NPRSTV-Z][\s\-]?\d[ABCEGHJ-NPRSTV-Z]\d$/i,
    CH: fourDigit,
    CZ: /^\d{3}\s?\d{2}$/,
    DE: fiveDigit,
    DK: fourDigit,
    DZ: fiveDigit,
    EE: fiveDigit,
    ES: fiveDigit,
    FI: fiveDigit,
    FR: /^\d{2}\s?\d{3}$/,
    GB: /^(gir\s?0aa|[a-z]{1,2}\d[\da-z]?\s?(\d[a-z]{2})?)$/i,
    GR: /^\d{3}\s?\d{2}$/,
    HR: /^([1-5]\d{4}$)/,
    HU: fourDigit,
    IL: fiveDigit,
    IN: sixDigit,
    IS: threeDigit,
    IT: fiveDigit,
    JP: /^\d{3}\-\d{4}$/,
    KE: fiveDigit,
    LI: /^(948[5-9]|949[0-7])$/,
    LT: /^LT\-\d{5}$/,
    LU: fourDigit,
    LV: /^LV\-\d{4}$/,
    MX: fiveDigit,
    NL: /^\d{4}\s?[a-z]{2}$/i,
    NO: fourDigit,
    PL: /^\d{2}\-\d{3}$/,
    PT: /^\d{4}\-\d{3}?$/,
    RO: sixDigit,
    RU: sixDigit,
    SA: fiveDigit,
    SE: /^\d{3}\s?\d{2}$/,
    SI: fourDigit,
    SK: /^\d{3}\s?\d{2}$/,
    TN: fourDigit,
    TW: /^\d{3}(\d{2})?$/,
    UA: fiveDigit,
    US: /^\d{5}(-\d{4})?$/,
    ZA: fourDigit,
    ZM: fiveDigit
  };
  var locales = Object.keys(patterns);
  exports.locales = locales;
  
  function _default(str, locale) {
    (0, _assertString.default)(str);
  
    if (locale in patterns) {
      return patterns[locale].test(str);
    } else if (locale === 'any') {
      for (var key in patterns) {
        if (patterns.hasOwnProperty(key)) {
          var pattern = patterns[key];
  
          if (pattern.test(str)) {
            return true;
          }
        }
      }
  
      return false;
    }
  
    throw new Error("Invalid locale '".concat(locale, "'"));
  }
  },{"./util/assertString":226}],208:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isRFC3339;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  /* Based on https://tools.ietf.org/html/rfc3339#section-5.6 */
  var dateFullYear = /[0-9]{4}/;
  var dateMonth = /(0[1-9]|1[0-2])/;
  var dateMDay = /([12]\d|0[1-9]|3[01])/;
  var timeHour = /([01][0-9]|2[0-3])/;
  var timeMinute = /[0-5][0-9]/;
  var timeSecond = /([0-5][0-9]|60)/;
  var timeSecFrac = /(\.[0-9]+)?/;
  var timeNumOffset = new RegExp("[-+]".concat(timeHour.source, ":").concat(timeMinute.source));
  var timeOffset = new RegExp("([zZ]|".concat(timeNumOffset.source, ")"));
  var partialTime = new RegExp("".concat(timeHour.source, ":").concat(timeMinute.source, ":").concat(timeSecond.source).concat(timeSecFrac.source));
  var fullDate = new RegExp("".concat(dateFullYear.source, "-").concat(dateMonth.source, "-").concat(dateMDay.source));
  var fullTime = new RegExp("".concat(partialTime.source).concat(timeOffset.source));
  var rfc3339 = new RegExp("".concat(fullDate.source, "[ tT]").concat(fullTime.source));
  
  function isRFC3339(str) {
    (0, _assertString.default)(str);
    return rfc3339.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],209:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isSurrogatePair;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var surrogatePair = /[\uD800-\uDBFF][\uDC00-\uDFFF]/;
  
  function isSurrogatePair(str) {
    (0, _assertString.default)(str);
    return surrogatePair.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],210:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isURL;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _isFQDN = _interopRequireDefault(require("./isFQDN"));
  
  var _isIP = _interopRequireDefault(require("./isIP"));
  
  var _merge = _interopRequireDefault(require("./util/merge"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var default_url_options = {
    protocols: ['http', 'https', 'ftp'],
    require_tld: true,
    require_protocol: false,
    require_host: true,
    require_valid_protocol: true,
    allow_underscores: false,
    allow_trailing_dot: false,
    allow_protocol_relative_urls: false
  };
  var wrapped_ipv6 = /^\[([^\]]+)\](?::([0-9]+))?$/;
  
  function isRegExp(obj) {
    return Object.prototype.toString.call(obj) === '[object RegExp]';
  }
  
  function checkHost(host, matches) {
    for (var i = 0; i < matches.length; i++) {
      var match = matches[i];
  
      if (host === match || isRegExp(match) && match.test(host)) {
        return true;
      }
    }
  
    return false;
  }
  
  function isURL(url, options) {
    (0, _assertString.default)(url);
  
    if (!url || url.length >= 2083 || /[\s<>]/.test(url)) {
      return false;
    }
  
    if (url.indexOf('mailto:') === 0) {
      return false;
    }
  
    options = (0, _merge.default)(options, default_url_options);
    var protocol, auth, host, hostname, port, port_str, split, ipv6;
    split = url.split('#');
    url = split.shift();
    split = url.split('?');
    url = split.shift();
    split = url.split('://');
  
    if (split.length > 1) {
      protocol = split.shift().toLowerCase();
  
      if (options.require_valid_protocol && options.protocols.indexOf(protocol) === -1) {
        return false;
      }
    } else if (options.require_protocol) {
      return false;
    } else if (url.substr(0, 2) === '//') {
      if (!options.allow_protocol_relative_urls) {
        return false;
      }
  
      split[0] = url.substr(2);
    }
  
    url = split.join('://');
  
    if (url === '') {
      return false;
    }
  
    split = url.split('/');
    url = split.shift();
  
    if (url === '' && !options.require_host) {
      return true;
    }
  
    split = url.split('@');
  
    if (split.length > 1) {
      if (options.disallow_auth) {
        return false;
      }
  
      auth = split.shift();
  
      if (auth.indexOf(':') >= 0 && auth.split(':').length > 2) {
        return false;
      }
    }
  
    hostname = split.join('@');
    port_str = null;
    ipv6 = null;
    var ipv6_match = hostname.match(wrapped_ipv6);
  
    if (ipv6_match) {
      host = '';
      ipv6 = ipv6_match[1];
      port_str = ipv6_match[2] || null;
    } else {
      split = hostname.split(':');
      host = split.shift();
  
      if (split.length) {
        port_str = split.join(':');
      }
    }
  
    if (port_str !== null) {
      port = parseInt(port_str, 10);
  
      if (!/^[0-9]+$/.test(port_str) || port <= 0 || port > 65535) {
        return false;
      }
    }
  
    if (!(0, _isIP.default)(host) && !(0, _isFQDN.default)(host, options) && (!ipv6 || !(0, _isIP.default)(ipv6, 6))) {
      return false;
    }
  
    host = host || ipv6;
  
    if (options.host_whitelist && !checkHost(host, options.host_whitelist)) {
      return false;
    }
  
    if (options.host_blacklist && checkHost(host, options.host_blacklist)) {
      return false;
    }
  
    return true;
  }
  
  module.exports = exports.default;
  },{"./isFQDN":174,"./isIP":181,"./util/assertString":226,"./util/merge":228}],211:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isUUID;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var uuid = {
    3: /^[0-9A-F]{8}-[0-9A-F]{4}-3[0-9A-F]{3}-[0-9A-F]{4}-[0-9A-F]{12}$/i,
    4: /^[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$/i,
    5: /^[0-9A-F]{8}-[0-9A-F]{4}-5[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$/i,
    all: /^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/i
  };
  
  function isUUID(str) {
    var version = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'all';
    (0, _assertString.default)(str);
    var pattern = uuid[version];
    return pattern && pattern.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],212:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isUppercase;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isUppercase(str) {
    (0, _assertString.default)(str);
    return str === str.toUpperCase();
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],213:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isVariableWidth;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _isFullWidth = require("./isFullWidth");
  
  var _isHalfWidth = require("./isHalfWidth");
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isVariableWidth(str) {
    (0, _assertString.default)(str);
    return _isFullWidth.fullWidth.test(str) && _isHalfWidth.halfWidth.test(str);
  }
  
  module.exports = exports.default;
  },{"./isFullWidth":176,"./isHalfWidth":177,"./util/assertString":226}],214:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = isWhitelisted;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function isWhitelisted(str, chars) {
    (0, _assertString.default)(str);
  
    for (var i = str.length - 1; i >= 0; i--) {
      if (chars.indexOf(str[i]) === -1) {
        return false;
      }
    }
  
    return true;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],215:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = ltrim;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function ltrim(str, chars) {
    (0, _assertString.default)(str);
    var pattern = chars ? new RegExp("^[".concat(chars, "]+"), 'g') : /^\s+/g;
    return str.replace(pattern, '');
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],216:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = matches;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function matches(str, pattern, modifiers) {
    (0, _assertString.default)(str);
  
    if (Object.prototype.toString.call(pattern) !== '[object RegExp]') {
      pattern = new RegExp(pattern, modifiers);
    }
  
    return pattern.test(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],217:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = normalizeEmail;
  
  var _merge = _interopRequireDefault(require("./util/merge"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var default_normalize_email_options = {
    // The following options apply to all email addresses
    // Lowercases the local part of the email address.
    // Please note this may violate RFC 5321 as per http://stackoverflow.com/a/9808332/192024).
    // The domain is always lowercased, as per RFC 1035
    all_lowercase: true,
    // The following conversions are specific to GMail
    // Lowercases the local part of the GMail address (known to be case-insensitive)
    gmail_lowercase: true,
    // Removes dots from the local part of the email address, as that's ignored by GMail
    gmail_remove_dots: true,
    // Removes the subaddress (e.g. "+foo") from the email address
    gmail_remove_subaddress: true,
    // Conversts the googlemail.com domain to gmail.com
    gmail_convert_googlemaildotcom: true,
    // The following conversions are specific to Outlook.com / Windows Live / Hotmail
    // Lowercases the local part of the Outlook.com address (known to be case-insensitive)
    outlookdotcom_lowercase: true,
    // Removes the subaddress (e.g. "+foo") from the email address
    outlookdotcom_remove_subaddress: true,
    // The following conversions are specific to Yahoo
    // Lowercases the local part of the Yahoo address (known to be case-insensitive)
    yahoo_lowercase: true,
    // Removes the subaddress (e.g. "-foo") from the email address
    yahoo_remove_subaddress: true,
    // The following conversions are specific to Yandex
    // Lowercases the local part of the Yandex address (known to be case-insensitive)
    yandex_lowercase: true,
    // The following conversions are specific to iCloud
    // Lowercases the local part of the iCloud address (known to be case-insensitive)
    icloud_lowercase: true,
    // Removes the subaddress (e.g. "+foo") from the email address
    icloud_remove_subaddress: true
  }; // List of domains used by iCloud
  
  var icloud_domains = ['icloud.com', 'me.com']; // List of domains used by Outlook.com and its predecessors
  // This list is likely incomplete.
  // Partial reference:
  // https://blogs.office.com/2013/04/17/outlook-com-gets-two-step-verification-sign-in-by-alias-and-new-international-domains/
  
  var outlookdotcom_domains = ['hotmail.at', 'hotmail.be', 'hotmail.ca', 'hotmail.cl', 'hotmail.co.il', 'hotmail.co.nz', 'hotmail.co.th', 'hotmail.co.uk', 'hotmail.com', 'hotmail.com.ar', 'hotmail.com.au', 'hotmail.com.br', 'hotmail.com.gr', 'hotmail.com.mx', 'hotmail.com.pe', 'hotmail.com.tr', 'hotmail.com.vn', 'hotmail.cz', 'hotmail.de', 'hotmail.dk', 'hotmail.es', 'hotmail.fr', 'hotmail.hu', 'hotmail.id', 'hotmail.ie', 'hotmail.in', 'hotmail.it', 'hotmail.jp', 'hotmail.kr', 'hotmail.lv', 'hotmail.my', 'hotmail.ph', 'hotmail.pt', 'hotmail.sa', 'hotmail.sg', 'hotmail.sk', 'live.be', 'live.co.uk', 'live.com', 'live.com.ar', 'live.com.mx', 'live.de', 'live.es', 'live.eu', 'live.fr', 'live.it', 'live.nl', 'msn.com', 'outlook.at', 'outlook.be', 'outlook.cl', 'outlook.co.il', 'outlook.co.nz', 'outlook.co.th', 'outlook.com', 'outlook.com.ar', 'outlook.com.au', 'outlook.com.br', 'outlook.com.gr', 'outlook.com.pe', 'outlook.com.tr', 'outlook.com.vn', 'outlook.cz', 'outlook.de', 'outlook.dk', 'outlook.es', 'outlook.fr', 'outlook.hu', 'outlook.id', 'outlook.ie', 'outlook.in', 'outlook.it', 'outlook.jp', 'outlook.kr', 'outlook.lv', 'outlook.my', 'outlook.ph', 'outlook.pt', 'outlook.sa', 'outlook.sg', 'outlook.sk', 'passport.com']; // List of domains used by Yahoo Mail
  // This list is likely incomplete
  
  var yahoo_domains = ['rocketmail.com', 'yahoo.ca', 'yahoo.co.uk', 'yahoo.com', 'yahoo.de', 'yahoo.fr', 'yahoo.in', 'yahoo.it', 'ymail.com']; // List of domains used by yandex.ru
  
  var yandex_domains = ['yandex.ru', 'yandex.ua', 'yandex.kz', 'yandex.com', 'yandex.by', 'ya.ru']; // replace single dots, but not multiple consecutive dots
  
  function dotsReplacer(match) {
    if (match.length > 1) {
      return match;
    }
  
    return '';
  }
  
  function normalizeEmail(email, options) {
    options = (0, _merge.default)(options, default_normalize_email_options);
    var raw_parts = email.split('@');
    var domain = raw_parts.pop();
    var user = raw_parts.join('@');
    var parts = [user, domain]; // The domain is always lowercased, as it's case-insensitive per RFC 1035
  
    parts[1] = parts[1].toLowerCase();
  
    if (parts[1] === 'gmail.com' || parts[1] === 'googlemail.com') {
      // Address is GMail
      if (options.gmail_remove_subaddress) {
        parts[0] = parts[0].split('+')[0];
      }
  
      if (options.gmail_remove_dots) {
        // this does not replace consecutive dots like example..email@gmail.com
        parts[0] = parts[0].replace(/\.+/g, dotsReplacer);
      }
  
      if (!parts[0].length) {
        return false;
      }
  
      if (options.all_lowercase || options.gmail_lowercase) {
        parts[0] = parts[0].toLowerCase();
      }
  
      parts[1] = options.gmail_convert_googlemaildotcom ? 'gmail.com' : parts[1];
    } else if (icloud_domains.indexOf(parts[1]) >= 0) {
      // Address is iCloud
      if (options.icloud_remove_subaddress) {
        parts[0] = parts[0].split('+')[0];
      }
  
      if (!parts[0].length) {
        return false;
      }
  
      if (options.all_lowercase || options.icloud_lowercase) {
        parts[0] = parts[0].toLowerCase();
      }
    } else if (outlookdotcom_domains.indexOf(parts[1]) >= 0) {
      // Address is Outlook.com
      if (options.outlookdotcom_remove_subaddress) {
        parts[0] = parts[0].split('+')[0];
      }
  
      if (!parts[0].length) {
        return false;
      }
  
      if (options.all_lowercase || options.outlookdotcom_lowercase) {
        parts[0] = parts[0].toLowerCase();
      }
    } else if (yahoo_domains.indexOf(parts[1]) >= 0) {
      // Address is Yahoo
      if (options.yahoo_remove_subaddress) {
        var components = parts[0].split('-');
        parts[0] = components.length > 1 ? components.slice(0, -1).join('-') : components[0];
      }
  
      if (!parts[0].length) {
        return false;
      }
  
      if (options.all_lowercase || options.yahoo_lowercase) {
        parts[0] = parts[0].toLowerCase();
      }
    } else if (yandex_domains.indexOf(parts[1]) >= 0) {
      if (options.all_lowercase || options.yandex_lowercase) {
        parts[0] = parts[0].toLowerCase();
      }
  
      parts[1] = 'yandex.ru'; // all yandex domains are equal, 1st preffered
    } else if (options.all_lowercase) {
      // Any other address
      parts[0] = parts[0].toLowerCase();
    }
  
    return parts.join('@');
  }
  
  module.exports = exports.default;
  },{"./util/merge":228}],218:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = rtrim;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function rtrim(str, chars) {
    (0, _assertString.default)(str);
    var pattern = chars ? new RegExp("[".concat(chars, "]")) : /\s/;
    var idx = str.length - 1;
  
    for (; idx >= 0 && pattern.test(str[idx]); idx--) {
      ;
    }
  
    return idx < str.length ? str.substr(0, idx + 1) : str;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],219:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = stripLow;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  var _blacklist = _interopRequireDefault(require("./blacklist"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function stripLow(str, keep_new_lines) {
    (0, _assertString.default)(str);
    var chars = keep_new_lines ? '\\x00-\\x09\\x0B\\x0C\\x0E-\\x1F\\x7F' : '\\x00-\\x1F\\x7F';
    return (0, _blacklist.default)(str, chars);
  }
  
  module.exports = exports.default;
  },{"./blacklist":155,"./util/assertString":226}],220:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = toBoolean;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function toBoolean(str, strict) {
    (0, _assertString.default)(str);
  
    if (strict) {
      return str === '1' || str === 'true';
    }
  
    return str !== '0' && str !== 'false' && str !== '';
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],221:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = toDate;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function toDate(date) {
    (0, _assertString.default)(date);
    date = Date.parse(date);
    return !isNaN(date) ? new Date(date) : null;
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],222:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = toFloat;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function toFloat(str) {
    (0, _assertString.default)(str);
    return parseFloat(str);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],223:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = toInt;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function toInt(str, radix) {
    (0, _assertString.default)(str);
    return parseInt(str, radix || 10);
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],224:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = trim;
  
  var _rtrim = _interopRequireDefault(require("./rtrim"));
  
  var _ltrim = _interopRequireDefault(require("./ltrim"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function trim(str, chars) {
    return (0, _rtrim.default)((0, _ltrim.default)(str, chars), chars);
  }
  
  module.exports = exports.default;
  },{"./ltrim":215,"./rtrim":218}],225:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = unescape;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function unescape(str) {
    (0, _assertString.default)(str);
    return str.replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#x27;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#x2F;/g, '/').replace(/&#x5C;/g, '\\').replace(/&#96;/g, '`');
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],226:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = assertString;
  
  function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }
  
  function assertString(input) {
    var isString = typeof input === 'string' || input instanceof String;
  
    if (!isString) {
      var invalidType;
  
      if (input === null) {
        invalidType = 'null';
      } else {
        invalidType = _typeof(input);
  
        if (invalidType === 'object' && input.constructor && input.constructor.hasOwnProperty('name')) {
          invalidType = input.constructor.name;
        } else {
          invalidType = "a ".concat(invalidType);
        }
      }
  
      throw new TypeError("Expected string but received ".concat(invalidType, "."));
    }
  }
  
  module.exports = exports.default;
  },{}],227:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var includes = function includes(arr, val) {
    return arr.some(function (arrVal) {
      return val === arrVal;
    });
  };
  
  var _default = includes;
  exports.default = _default;
  module.exports = exports.default;
  },{}],228:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = merge;
  
  function merge() {
    var obj = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var defaults = arguments.length > 1 ? arguments[1] : undefined;
  
    for (var key in defaults) {
      if (typeof obj[key] === 'undefined') {
        obj[key] = defaults[key];
      }
    }
  
    return obj;
  }
  
  module.exports = exports.default;
  },{}],229:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = toString;
  
  function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }
  
  function toString(input) {
    if (_typeof(input) === 'object' && input !== null) {
      if (typeof input.toString === 'function') {
        input = input.toString();
      } else {
        input = '[object Object]';
      }
    } else if (input === null || typeof input === 'undefined' || isNaN(input) && !input.length) {
      input = '';
    }
  
    return String(input);
  }
  
  module.exports = exports.default;
  },{}],230:[function(require,module,exports){
  "use strict";
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = whitelist;
  
  var _assertString = _interopRequireDefault(require("./util/assertString"));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function whitelist(str, chars) {
    (0, _assertString.default)(str);
    return str.replace(new RegExp("[^".concat(chars, "]+"), 'g'), '');
  }
  
  module.exports = exports.default;
  },{"./util/assertString":226}],231:[function(require,module,exports){
  module.exports = extend
  
  var hasOwnProperty = Object.prototype.hasOwnProperty;
  
  function extend() {
      var target = {}
  
      for (var i = 0; i < arguments.length; i++) {
          var source = arguments[i]
  
          for (var key in source) {
              if (hasOwnProperty.call(source, key)) {
                  target[key] = source[key]
              }
          }
      }
  
      return target
  }
  
  },{}],232:[function(require,module,exports){
  "use strict";
  
  module.exports = {
  
      INVALID_TYPE:                           "Expected type {0} but found type {1}",
      INVALID_FORMAT:                         "Object didn't pass validation for format {0}: {1}",
      ENUM_MISMATCH:                          "No enum match for: {0}",
      ENUM_CASE_MISMATCH:                     "Enum does not match case for: {0}",
      ANY_OF_MISSING:                         "Data does not match any schemas from 'anyOf'",
      ONE_OF_MISSING:                         "Data does not match any schemas from 'oneOf'",
      ONE_OF_MULTIPLE:                        "Data is valid against more than one schema from 'oneOf'",
      NOT_PASSED:                             "Data matches schema from 'not'",
  
      // Array errors
      ARRAY_LENGTH_SHORT:                     "Array is too short ({0}), minimum {1}",
      ARRAY_LENGTH_LONG:                      "Array is too long ({0}), maximum {1}",
      ARRAY_UNIQUE:                           "Array items are not unique (indexes {0} and {1})",
      ARRAY_ADDITIONAL_ITEMS:                 "Additional items not allowed",
  
      // Numeric errors
      MULTIPLE_OF:                            "Value {0} is not a multiple of {1}",
      MINIMUM:                                "Value {0} is less than minimum {1}",
      MINIMUM_EXCLUSIVE:                      "Value {0} is equal or less than exclusive minimum {1}",
      MAXIMUM:                                "Value {0} is greater than maximum {1}",
      MAXIMUM_EXCLUSIVE:                      "Value {0} is equal or greater than exclusive maximum {1}",
  
      // Object errors
      OBJECT_PROPERTIES_MINIMUM:              "Too few properties defined ({0}), minimum {1}",
      OBJECT_PROPERTIES_MAXIMUM:              "Too many properties defined ({0}), maximum {1}",
      OBJECT_MISSING_REQUIRED_PROPERTY:       "Missing required property: {0}",
      OBJECT_ADDITIONAL_PROPERTIES:           "Additional properties not allowed: {0}",
      OBJECT_DEPENDENCY_KEY:                  "Dependency failed - key must exist: {0} (due to key: {1})",
  
      // String errors
      MIN_LENGTH:                             "String is too short ({0} chars), minimum {1}",
      MAX_LENGTH:                             "String is too long ({0} chars), maximum {1}",
      PATTERN:                                "String does not match pattern {0}: {1}",
  
      // Schema validation errors
      KEYWORD_TYPE_EXPECTED:                  "Keyword '{0}' is expected to be of type '{1}'",
      KEYWORD_UNDEFINED_STRICT:               "Keyword '{0}' must be defined in strict mode",
      KEYWORD_UNEXPECTED:                     "Keyword '{0}' is not expected to appear in the schema",
      KEYWORD_MUST_BE:                        "Keyword '{0}' must be {1}",
      KEYWORD_DEPENDENCY:                     "Keyword '{0}' requires keyword '{1}'",
      KEYWORD_PATTERN:                        "Keyword '{0}' is not a valid RegExp pattern: {1}",
      KEYWORD_VALUE_TYPE:                     "Each element of keyword '{0}' array must be a '{1}'",
      UNKNOWN_FORMAT:                         "There is no validation function for format '{0}'",
      CUSTOM_MODE_FORCE_PROPERTIES:           "{0} must define at least one property if present",
  
      // Remote errors
      REF_UNRESOLVED:                         "Reference has not been resolved during compilation: {0}",
      UNRESOLVABLE_REFERENCE:                 "Reference could not be resolved: {0}",
      SCHEMA_NOT_REACHABLE:                   "Validator was not able to read schema with uri: {0}",
      SCHEMA_TYPE_EXPECTED:                   "Schema is expected to be of type 'object'",
      SCHEMA_NOT_AN_OBJECT:                   "Schema is not an object: {0}",
      ASYNC_TIMEOUT:                          "{0} asynchronous task(s) have timed out after {1} ms",
      PARENT_SCHEMA_VALIDATION_FAILED:        "Schema failed to validate against its parent schema, see inner errors for details.",
      REMOTE_NOT_VALID:                       "Remote reference didn't compile successfully: {0}"
  
  };
  
  },{}],233:[function(require,module,exports){
  /*jshint maxlen: false*/
  
  var validator = require("validator");
  
  var FormatValidators = {
      "date": function (date) {
          if (typeof date !== "string") {
              return true;
          }
          // full-date from http://tools.ietf.org/html/rfc3339#section-5.6
          var matches = /^([0-9]{4})-([0-9]{2})-([0-9]{2})$/.exec(date);
          if (matches === null) {
              return false;
          }
          // var year = matches[1];
          // var month = matches[2];
          // var day = matches[3];
          if (matches[2] < "01" || matches[2] > "12" || matches[3] < "01" || matches[3] > "31") {
              return false;
          }
          return true;
      },
      "date-time": function (dateTime) {
          if (typeof dateTime !== "string") {
              return true;
          }
          // date-time from http://tools.ietf.org/html/rfc3339#section-5.6
          var s = dateTime.toLowerCase().split("t");
          if (!FormatValidators.date(s[0])) {
              return false;
          }
          var matches = /^([0-9]{2}):([0-9]{2}):([0-9]{2})(.[0-9]+)?(z|([+-][0-9]{2}:[0-9]{2}))$/.exec(s[1]);
          if (matches === null) {
              return false;
          }
          // var hour = matches[1];
          // var minute = matches[2];
          // var second = matches[3];
          // var fraction = matches[4];
          // var timezone = matches[5];
          if (matches[1] > "23" || matches[2] > "59" || matches[3] > "59") {
              return false;
          }
          return true;
      },
      "email": function (email) {
          if (typeof email !== "string") {
              return true;
          }
          return validator.isEmail(email, { "require_tld": true });
      },
      "hostname": function (hostname) {
          if (typeof hostname !== "string") {
              return true;
          }
          /*
              http://json-schema.org/latest/json-schema-validation.html#anchor114
              A string instance is valid against this attribute if it is a valid
              representation for an Internet host name, as defined by RFC 1034, section 3.1 [RFC1034].
  
              http://tools.ietf.org/html/rfc1034#section-3.5
  
              <digit> ::= any one of the ten digits 0 through 9
              var digit = /[0-9]/;
  
              <letter> ::= any one of the 52 alphabetic characters A through Z in upper case and a through z in lower case
              var letter = /[a-zA-Z]/;
  
              <let-dig> ::= <letter> | <digit>
              var letDig = /[0-9a-zA-Z]/;
  
              <let-dig-hyp> ::= <let-dig> | "-"
              var letDigHyp = /[-0-9a-zA-Z]/;
  
              <ldh-str> ::= <let-dig-hyp> | <let-dig-hyp> <ldh-str>
              var ldhStr = /[-0-9a-zA-Z]+/;
  
              <label> ::= <letter> [ [ <ldh-str> ] <let-dig> ]
              var label = /[a-zA-Z](([-0-9a-zA-Z]+)?[0-9a-zA-Z])?/;
  
              <subdomain> ::= <label> | <subdomain> "." <label>
              var subdomain = /^[a-zA-Z](([-0-9a-zA-Z]+)?[0-9a-zA-Z])?(\.[a-zA-Z](([-0-9a-zA-Z]+)?[0-9a-zA-Z])?)*$/;
  
              <domain> ::= <subdomain> | " "
              var domain = null;
          */
          var valid = /^[a-zA-Z](([-0-9a-zA-Z]+)?[0-9a-zA-Z])?(\.[a-zA-Z](([-0-9a-zA-Z]+)?[0-9a-zA-Z])?)*$/.test(hostname);
          if (valid) {
              // the sum of all label octets and label lengths is limited to 255.
              if (hostname.length > 255) { return false; }
              // Each node has a label, which is zero to 63 octets in length
              var labels = hostname.split(".");
              for (var i = 0; i < labels.length; i++) { if (labels[i].length > 63) { return false; } }
          }
          return valid;
      },
      "host-name": function (hostname) {
          return FormatValidators.hostname.call(this, hostname);
      },
      "ipv4": function (ipv4) {
          if (typeof ipv4 !== "string") { return true; }
          return validator.isIP(ipv4, 4);
      },
      "ipv6": function (ipv6) {
          if (typeof ipv6 !== "string") { return true; }
          return validator.isIP(ipv6, 6);
      },
      "regex": function (str) {
          try {
              RegExp(str);
              return true;
          } catch (e) {
              return false;
          }
      },
      "uri": function (uri) {
          if (this.options.strictUris) {
              return FormatValidators["strict-uri"].apply(this, arguments);
          }
          // https://github.com/zaggino/z-schema/issues/18
          // RegExp from http://tools.ietf.org/html/rfc3986#appendix-B
          return typeof uri !== "string" || RegExp("^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\\?([^#]*))?(#(.*))?").test(uri);
      },
      "strict-uri": function (uri) {
          return typeof uri !== "string" || validator.isURL(uri);
      }
  };
  
  module.exports = FormatValidators;
  
  },{"validator":153}],234:[function(require,module,exports){
  "use strict";
  
  var FormatValidators = require("./FormatValidators"),
      Report           = require("./Report"),
      Utils            = require("./Utils");
  
  var JsonValidators = {
      multipleOf: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.1.1.2
          if (typeof json !== "number") {
              return;
          }
          if (Utils.whatIs(json / schema.multipleOf) !== "integer") {
              report.addError("MULTIPLE_OF", [json, schema.multipleOf], null, schema);
          }
      },
      maximum: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.1.2.2
          if (typeof json !== "number") {
              return;
          }
          if (schema.exclusiveMaximum !== true) {
              if (json > schema.maximum) {
                  report.addError("MAXIMUM", [json, schema.maximum], null, schema);
              }
          } else {
              if (json >= schema.maximum) {
                  report.addError("MAXIMUM_EXCLUSIVE", [json, schema.maximum], null, schema);
              }
          }
      },
      exclusiveMaximum: function () {
          // covered in maximum
      },
      minimum: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.1.3.2
          if (typeof json !== "number") {
              return;
          }
          if (schema.exclusiveMinimum !== true) {
              if (json < schema.minimum) {
                  report.addError("MINIMUM", [json, schema.minimum], null, schema);
              }
          } else {
              if (json <= schema.minimum) {
                  report.addError("MINIMUM_EXCLUSIVE", [json, schema.minimum], null, schema);
              }
          }
      },
      exclusiveMinimum: function () {
          // covered in minimum
      },
      maxLength: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.2.1.2
          if (typeof json !== "string") {
              return;
          }
          if (Utils.ucs2decode(json).length > schema.maxLength) {
              report.addError("MAX_LENGTH", [json.length, schema.maxLength], null, schema);
          }
      },
      minLength: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.2.2.2
          if (typeof json !== "string") {
              return;
          }
          if (Utils.ucs2decode(json).length < schema.minLength) {
              report.addError("MIN_LENGTH", [json.length, schema.minLength], null, schema);
          }
      },
      pattern: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.2.3.2
          if (typeof json !== "string") {
              return;
          }
          if (RegExp(schema.pattern).test(json) === false) {
              report.addError("PATTERN", [schema.pattern, json], null, schema);
          }
      },
      additionalItems: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.1.2
          if (!Array.isArray(json)) {
              return;
          }
          // if the value of "additionalItems" is boolean value false and the value of "items" is an array,
          // the json is valid if its size is less than, or equal to, the size of "items".
          if (schema.additionalItems === false && Array.isArray(schema.items)) {
              if (json.length > schema.items.length) {
                  report.addError("ARRAY_ADDITIONAL_ITEMS", null, null, schema);
              }
          }
      },
      items: function () { /*report, schema, json*/
          // covered in additionalItems
      },
      maxItems: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.2.2
          if (!Array.isArray(json)) {
              return;
          }
          if (json.length > schema.maxItems) {
              report.addError("ARRAY_LENGTH_LONG", [json.length, schema.maxItems], null, schema);
          }
      },
      minItems: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.3.2
          if (!Array.isArray(json)) {
              return;
          }
          if (json.length < schema.minItems) {
              report.addError("ARRAY_LENGTH_SHORT", [json.length, schema.minItems], null, schema);
          }
      },
      uniqueItems: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.4.2
          if (!Array.isArray(json)) {
              return;
          }
          if (schema.uniqueItems === true) {
              var matches = [];
              if (Utils.isUniqueArray(json, matches) === false) {
                  report.addError("ARRAY_UNIQUE", matches, null, schema);
              }
          }
      },
      maxProperties: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.1.2
          if (Utils.whatIs(json) !== "object") {
              return;
          }
          var keysCount = Object.keys(json).length;
          if (keysCount > schema.maxProperties) {
              report.addError("OBJECT_PROPERTIES_MAXIMUM", [keysCount, schema.maxProperties], null, schema);
          }
      },
      minProperties: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.2.2
          if (Utils.whatIs(json) !== "object") {
              return;
          }
          var keysCount = Object.keys(json).length;
          if (keysCount < schema.minProperties) {
              report.addError("OBJECT_PROPERTIES_MINIMUM", [keysCount, schema.minProperties], null, schema);
          }
      },
      required: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.3.2
          if (Utils.whatIs(json) !== "object") {
              return;
          }
          var idx = schema.required.length;
          while (idx--) {
              var requiredPropertyName = schema.required[idx];
              if (json[requiredPropertyName] === undefined) {
                  report.addError("OBJECT_MISSING_REQUIRED_PROPERTY", [requiredPropertyName], null, schema);
              }
          }
      },
      additionalProperties: function (report, schema, json) {
          // covered in properties and patternProperties
          if (schema.properties === undefined && schema.patternProperties === undefined) {
              return JsonValidators.properties.call(this, report, schema, json);
          }
      },
      patternProperties: function (report, schema, json) {
          // covered in properties
          if (schema.properties === undefined) {
              return JsonValidators.properties.call(this, report, schema, json);
          }
      },
      properties: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.4.2
          if (Utils.whatIs(json) !== "object") {
              return;
          }
          var properties = schema.properties !== undefined ? schema.properties : {};
          var patternProperties = schema.patternProperties !== undefined ? schema.patternProperties : {};
          if (schema.additionalProperties === false) {
              // The property set of the json to validate.
              var s = Object.keys(json);
              // The property set from "properties".
              var p = Object.keys(properties);
              // The property set from "patternProperties".
              var pp = Object.keys(patternProperties);
              // remove from "s" all elements of "p", if any;
              s = Utils.difference(s, p);
              // for each regex in "pp", remove all elements of "s" which this regex matches.
              var idx = pp.length;
              while (idx--) {
                  var regExp = RegExp(pp[idx]),
                      idx2 = s.length;
                  while (idx2--) {
                      if (regExp.test(s[idx2]) === true) {
                          s.splice(idx2, 1);
                      }
                  }
              }
              // Validation of the json succeeds if, after these two steps, set "s" is empty.
              if (s.length > 0) {
                  // assumeAdditional can be an array of allowed properties
                  var idx3 = this.options.assumeAdditional.length;
                  if (idx3) {
                      while (idx3--) {
                          var io = s.indexOf(this.options.assumeAdditional[idx3]);
                          if (io !== -1) {
                              s.splice(io, 1);
                          }
                      }
                  }
                  if (s.length > 0) {
                      report.addError("OBJECT_ADDITIONAL_PROPERTIES", [s], null, schema);
                  }
              }
          }
      },
      dependencies: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.5.2
          if (Utils.whatIs(json) !== "object") {
              return;
          }
  
          var keys = Object.keys(schema.dependencies),
              idx = keys.length;
  
          while (idx--) {
              // iterate all dependencies
              var dependencyName = keys[idx];
              if (json[dependencyName]) {
                  var dependencyDefinition = schema.dependencies[dependencyName];
                  if (Utils.whatIs(dependencyDefinition) === "object") {
                      // if dependency is a schema, validate against this schema
                      exports.validate.call(this, report, dependencyDefinition, json);
                  } else { // Array
                      // if dependency is an array, object needs to have all properties in this array
                      var idx2 = dependencyDefinition.length;
                      while (idx2--) {
                          var requiredPropertyName = dependencyDefinition[idx2];
                          if (json[requiredPropertyName] === undefined) {
                              report.addError("OBJECT_DEPENDENCY_KEY", [requiredPropertyName, dependencyName], null, schema);
                          }
                      }
                  }
              }
          }
      },
      enum: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.1.2
          var match = false,
              caseInsensitiveMatch = false,
              idx = schema.enum.length;
          while (idx--) {
              if (Utils.areEqual(json, schema.enum[idx])) {
                  match = true;
                  break;
              } else if (Utils.areEqual(json, schema.enum[idx]), { caseInsensitiveComparison: true }) {
                  caseInsensitiveMatch = true;
              }
          }
  
          if (match === false) {
              var error = caseInsensitiveMatch && this.options.enumCaseInsensitiveComparison ? "ENUM_CASE_MISMATCH" : "ENUM_MISMATCH";
              report.addError(error, [json], null, schema);
          }
      },
      type: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.2.2
          var jsonType = Utils.whatIs(json);
          if (typeof schema.type === "string") {
              if (jsonType !== schema.type && (jsonType !== "integer" || schema.type !== "number")) {
                  report.addError("INVALID_TYPE", [schema.type, jsonType], null, schema);
              }
          } else {
              if (schema.type.indexOf(jsonType) === -1 && (jsonType !== "integer" || schema.type.indexOf("number") === -1)) {
                  report.addError("INVALID_TYPE", [schema.type, jsonType], null, schema);
              }
          }
      },
      allOf: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.3.2
          var idx = schema.allOf.length;
          while (idx--) {
              var validateResult = exports.validate.call(this, report, schema.allOf[idx], json);
              if (this.options.breakOnFirstError && validateResult === false) {
                  break;
              }
          }
      },
      anyOf: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.4.2
          var subReports = [],
              passed = false,
              idx = schema.anyOf.length;
  
          while (idx-- && passed === false) {
              var subReport = new Report(report);
              subReports.push(subReport);
              passed = exports.validate.call(this, subReport, schema.anyOf[idx], json);
          }
  
          if (passed === false) {
              report.addError("ANY_OF_MISSING", undefined, subReports, schema);
          }
      },
      oneOf: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.5.2
          var passes = 0,
              subReports = [],
              idx = schema.oneOf.length;
  
          while (idx--) {
              var subReport = new Report(report, { maxErrors: 1 });
              subReports.push(subReport);
              if (exports.validate.call(this, subReport, schema.oneOf[idx], json) === true) {
                  passes++;
              }
          }
  
          if (passes === 0) {
              report.addError("ONE_OF_MISSING", undefined, subReports, schema);
          } else if (passes > 1) {
              report.addError("ONE_OF_MULTIPLE", null, null, schema);
          }
      },
      not: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.6.2
          var subReport = new Report(report);
          if (exports.validate.call(this, subReport, schema.not, json) === true) {
              report.addError("NOT_PASSED", null, null, schema);
          }
      },
      definitions: function () { /*report, schema, json*/
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.7.2
          // nothing to do here
      },
      format: function (report, schema, json) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.7.2
          var formatValidatorFn = FormatValidators[schema.format];
          if (typeof formatValidatorFn === "function") {
              if (formatValidatorFn.length === 2) {
                  // async
                  report.addAsyncTask(formatValidatorFn, [json], function (result) {
                      if (result !== true) {
                          report.addError("INVALID_FORMAT", [schema.format, json], null, schema);
                      }
                  });
              } else {
                  // sync
                  if (formatValidatorFn.call(this, json) !== true) {
                      report.addError("INVALID_FORMAT", [schema.format, json], null, schema);
                  }
              }
          } else if (this.options.ignoreUnknownFormats !== true) {
              report.addError("UNKNOWN_FORMAT", [schema.format], null, schema);
          }
      }
  };
  
  var recurseArray = function (report, schema, json) {
      // http://json-schema.org/latest/json-schema-validation.html#rfc.section.8.2
  
      var idx = json.length;
  
      // If "items" is an array, this situation, the schema depends on the index:
      // if the index is less than, or equal to, the size of "items",
      // the child instance must be valid against the corresponding schema in the "items" array;
      // otherwise, it must be valid against the schema defined by "additionalItems".
      if (Array.isArray(schema.items)) {
  
          while (idx--) {
              // equal to doesn't make sense here
              if (idx < schema.items.length) {
                  report.path.push(idx.toString());
                  exports.validate.call(this, report, schema.items[idx], json[idx]);
                  report.path.pop();
              } else {
                  // might be boolean, so check that it's an object
                  if (typeof schema.additionalItems === "object") {
                      report.path.push(idx.toString());
                      exports.validate.call(this, report, schema.additionalItems, json[idx]);
                      report.path.pop();
                  }
              }
          }
  
      } else if (typeof schema.items === "object") {
  
          // If items is a schema, then the child instance must be valid against this schema,
          // regardless of its index, and regardless of the value of "additionalItems".
          while (idx--) {
              report.path.push(idx.toString());
              exports.validate.call(this, report, schema.items, json[idx]);
              report.path.pop();
          }
  
      }
  };
  
  var recurseObject = function (report, schema, json) {
      // http://json-schema.org/latest/json-schema-validation.html#rfc.section.8.3
  
      // If "additionalProperties" is absent, it is considered present with an empty schema as a value.
      // In addition, boolean value true is considered equivalent to an empty schema.
      var additionalProperties = schema.additionalProperties;
      if (additionalProperties === true || additionalProperties === undefined) {
          additionalProperties = {};
      }
  
      // p - The property set from "properties".
      var p = schema.properties ? Object.keys(schema.properties) : [];
  
      // pp - The property set from "patternProperties". Elements of this set will be called regexes for convenience.
      var pp = schema.patternProperties ? Object.keys(schema.patternProperties) : [];
  
      // m - The property name of the child.
      var keys = Object.keys(json),
          idx = keys.length;
  
      while (idx--) {
          var m = keys[idx],
              propertyValue = json[m];
  
          // s - The set of schemas for the child instance.
          var s = [];
  
          // 1. If set "p" contains value "m", then the corresponding schema in "properties" is added to "s".
          if (p.indexOf(m) !== -1) {
              s.push(schema.properties[m]);
          }
  
          // 2. For each regex in "pp", if it matches "m" successfully, the corresponding schema in "patternProperties" is added to "s".
          var idx2 = pp.length;
          while (idx2--) {
              var regexString = pp[idx2];
              if (RegExp(regexString).test(m) === true) {
                  s.push(schema.patternProperties[regexString]);
              }
          }
  
          // 3. The schema defined by "additionalProperties" is added to "s" if and only if, at this stage, "s" is empty.
          if (s.length === 0 && additionalProperties !== false) {
              s.push(additionalProperties);
          }
  
          // we are passing tests even without this assert because this is covered by properties check
          // if s is empty in this stage, no additionalProperties are allowed
          // report.expect(s.length !== 0, 'E001', m);
  
          // Instance property value must pass all schemas from s
          idx2 = s.length;
          while (idx2--) {
              report.path.push(m);
              exports.validate.call(this, report, s[idx2], propertyValue);
              report.path.pop();
          }
      }
  };
  
  exports.JsonValidators = JsonValidators;
  
  /**
   *
   * @param {Report} report
   * @param {*} schema
   * @param {*} json
   */
  exports.validate = function (report, schema, json) {
  
      report.commonErrorMessage = "JSON_OBJECT_VALIDATION_FAILED";
  
      // check if schema is an object
      var to = Utils.whatIs(schema);
      if (to !== "object") {
          report.addError("SCHEMA_NOT_AN_OBJECT", [to], null, schema);
          return false;
      }
  
      // check if schema is empty, everything is valid against empty schema
      var keys = Object.keys(schema);
      if (keys.length === 0) {
          return true;
      }
  
      // this method can be called recursively, so we need to remember our root
      var isRoot = false;
      if (!report.rootSchema) {
          report.rootSchema = schema;
          isRoot = true;
      }
  
      // follow schema.$ref keys
      if (schema.$ref !== undefined) {
          // avoid infinite loop with maxRefs
          var maxRefs = 99;
          while (schema.$ref && maxRefs > 0) {
              if (!schema.__$refResolved) {
                  report.addError("REF_UNRESOLVED", [schema.$ref], null, schema);
                  break;
              } else if (schema.__$refResolved === schema) {
                  break;
              } else {
                  schema = schema.__$refResolved;
                  keys = Object.keys(schema);
              }
              maxRefs--;
          }
          if (maxRefs === 0) {
              throw new Error("Circular dependency by $ref references!");
          }
      }
  
      // type checking first
      var jsonType = Utils.whatIs(json);
      if (schema.type) {
          keys.splice(keys.indexOf("type"), 1);
          JsonValidators.type.call(this, report, schema, json);
          if (report.errors.length && this.options.breakOnFirstError) {
              return false;
          }
      }
  
      // now iterate all the keys in schema and execute validation methods
      var idx = keys.length;
      while (idx--) {
          if (JsonValidators[keys[idx]]) {
              JsonValidators[keys[idx]].call(this, report, schema, json);
              if (report.errors.length && this.options.breakOnFirstError) { break; }
          }
      }
  
      if (report.errors.length === 0 || this.options.breakOnFirstError === false) {
          if (jsonType === "array") {
              recurseArray.call(this, report, schema, json);
          } else if (jsonType === "object") {
              recurseObject.call(this, report, schema, json);
          }
      }
  
      if (typeof this.options.customValidator === "function") {
          this.options.customValidator(report, schema, json);
      }
  
      // we don't need the root pointer anymore
      if (isRoot) {
          report.rootSchema = undefined;
      }
  
      // return valid just to be able to break at some code points
      return report.errors.length === 0;
  
  };
  
  },{"./FormatValidators":233,"./Report":236,"./Utils":240}],235:[function(require,module,exports){
  // Number.isFinite polyfill
  // http://people.mozilla.org/~jorendorff/es6-draft.html#sec-number.isfinite
  if (typeof Number.isFinite !== "function") {
      Number.isFinite = function isFinite(value) {
          // 1. If Type(number) is not Number, return false.
          if (typeof value !== "number") {
              return false;
          }
          // 2. If number is NaN, +∞, or −∞, return false.
          if (value !== value || value === Infinity || value === -Infinity) {
              return false;
          }
          // 3. Otherwise, return true.
          return true;
      };
  }
  
  },{}],236:[function(require,module,exports){
  (function (process){
  "use strict";
  
  var get    = require("lodash.get");
  var Errors = require("./Errors");
  var Utils  = require("./Utils");
  
  /**
   * @class
   *
   * @param {Report|object} parentOrOptions
   * @param {object} [reportOptions]
   */
  function Report(parentOrOptions, reportOptions) {
      this.parentReport = parentOrOptions instanceof Report ?
                              parentOrOptions :
                              undefined;
  
      this.options = parentOrOptions instanceof Report ?
                         parentOrOptions.options :
                         parentOrOptions || {};
  
      this.reportOptions = reportOptions || {};
  
      this.errors = [];
      /**
       * @type {string[]}
       */
      this.path = [];
      this.asyncTasks = [];
  
      this.rootSchema = undefined;
      this.commonErrorMessage = undefined;
      this.json = undefined;
  }
  
  /**
   * @returns {boolean}
   */
  Report.prototype.isValid = function () {
      if (this.asyncTasks.length > 0) {
          throw new Error("Async tasks pending, can't answer isValid");
      }
      return this.errors.length === 0;
  };
  
  /**
   *
   * @param {*} fn
   * @param {*} args
   * @param {*} asyncTaskResultProcessFn
   */
  Report.prototype.addAsyncTask = function (fn, args, asyncTaskResultProcessFn) {
      this.asyncTasks.push([fn, args, asyncTaskResultProcessFn]);
  };
  
  /**
   *
   * @param {*} timeout
   * @param {function(*, *)} callback
   *
   * @returns {void}
   */
  Report.prototype.processAsyncTasks = function (timeout, callback) {
  
      var validationTimeout = timeout || 2000,
          tasksCount        = this.asyncTasks.length,
          idx               = tasksCount,
          timedOut          = false,
          self              = this;
  
      function finish() {
          process.nextTick(function () {
              var valid = self.errors.length === 0,
                  err = valid ? undefined : self.errors;
              callback(err, valid);
          });
      }
  
      function respond(asyncTaskResultProcessFn) {
          return function (asyncTaskResult) {
              if (timedOut) { return; }
              asyncTaskResultProcessFn(asyncTaskResult);
              if (--tasksCount === 0) {
                  finish();
              }
          };
      }
  
      // finish if tasks are completed or there are any errors and breaking on first error was requested
      if (tasksCount === 0 || (this.errors.length > 0 && this.options.breakOnFirstError)) {
          finish();
          return;
      }
  
      while (idx--) {
          var task = this.asyncTasks[idx];
          task[0].apply(null, task[1].concat(respond(task[2])));
      }
  
      setTimeout(function () {
          if (tasksCount > 0) {
              timedOut = true;
              self.addError("ASYNC_TIMEOUT", [tasksCount, validationTimeout]);
              callback(self.errors, false);
          }
      }, validationTimeout);
  
  };
  
  /**
   *
   * @param {*} returnPathAsString
   *
   * @return {string[]|string}
   */
  Report.prototype.getPath = function (returnPathAsString) {
      /**
       * @type {string[]|string}
       */
      var path = [];
      if (this.parentReport) {
          path = path.concat(this.parentReport.path);
      }
      path = path.concat(this.path);
  
      if (returnPathAsString !== true) {
          // Sanitize the path segments (http://tools.ietf.org/html/rfc6901#section-4)
          path = "#/" + path.map(function (segment) {
  
              if (Utils.isAbsoluteUri(segment)) {
                  return "uri(" + segment + ")";
              }
  
              return segment.replace(/\~/g, "~0").replace(/\//g, "~1");
          }).join("/");
      }
      return path;
  };
  
  Report.prototype.getSchemaId = function () {
  
      if (!this.rootSchema) {
          return null;
      }
  
      // get the error path as an array
      var path = [];
      if (this.parentReport) {
          path = path.concat(this.parentReport.path);
      }
      path = path.concat(this.path);
  
      // try to find id in the error path
      while (path.length > 0) {
          var obj = get(this.rootSchema, path);
          if (obj && obj.id) { return obj.id; }
          path.pop();
      }
  
      // return id of the root
      return this.rootSchema.id;
  };
  
  /**
   *
   * @param {*} errorCode
   * @param {*} params
   *
   * @return {boolean}
   */
  Report.prototype.hasError = function (errorCode, params) {
      var idx = this.errors.length;
      while (idx--) {
          if (this.errors[idx].code === errorCode) {
              // assume match
              var match = true;
  
              // check the params too
              var idx2 = this.errors[idx].params.length;
              while (idx2--) {
                  if (this.errors[idx].params[idx2] !== params[idx2]) {
                      match = false;
                  }
              }
  
              // if match, return true
              if (match) { return match; }
          }
      }
      return false;
  };
  
  /**
   *
   * @param {*} errorCode
   * @param {*} params
   * @param {Report[]|Report} [subReports]
   * @param {*} [schema]
   *
   * @return {void}
   */
  Report.prototype.addError = function (errorCode, params, subReports, schema) {
      if (!errorCode) { throw new Error("No errorCode passed into addError()"); }
  
      this.addCustomError(errorCode, Errors[errorCode], params, subReports, schema);
  };
  
  Report.prototype.getJson = function () {
      var self = this;
      while (self.json === undefined) {
          self = self.parentReport;
          if (self === undefined) {
              return undefined;
          }
      }
      return self.json;
  };
  
  /**
   *
   * @param {*} errorCode
   * @param {*} errorMessage
   * @param {*[]} params
   * @param {Report[]|Report} subReports
   * @param {*} schema
   *
   * @returns {void}
   */
  Report.prototype.addCustomError = function (errorCode, errorMessage, params, subReports, schema) {
      if (this.errors.length >= this.reportOptions.maxErrors) {
          return;
      }
  
      if (!errorMessage) { throw new Error("No errorMessage known for code " + errorCode); }
  
      params = params || [];
  
      var idx = params.length;
      while (idx--) {
          var whatIs = Utils.whatIs(params[idx]);
          var param = (whatIs === "object" || whatIs === "null") ? JSON.stringify(params[idx]) : params[idx];
          errorMessage = errorMessage.replace("{" + idx + "}", param);
      }
  
      var err = {
          code: errorCode,
          params: params,
          message: errorMessage,
          path: this.getPath(this.options.reportPathAsArray),
          schemaId: this.getSchemaId()
      };
  
      err[Utils.schemaSymbol] = schema;
      err[Utils.jsonSymbol] = this.getJson();
  
      if (schema && typeof schema === "string") {
          err.description = schema;
      } else if (schema && typeof schema === "object") {
          if (schema.title) {
              err.title = schema.title;
          }
          if (schema.description) {
              err.description = schema.description;
          }
      }
  
      if (subReports != null) {
          if (!Array.isArray(subReports)) {
              subReports = [subReports];
          }
          err.inner = [];
          idx = subReports.length;
          while (idx--) {
              var subReport = subReports[idx],
                  idx2 = subReport.errors.length;
              while (idx2--) {
                  err.inner.push(subReport.errors[idx2]);
              }
          }
          if (err.inner.length === 0) {
              err.inner = undefined;
          }
      }
  
      this.errors.push(err);
  };
  
  module.exports = Report;
  
  }).call(this,require('_process'))
  
  },{"./Errors":232,"./Utils":240,"_process":125,"lodash.get":120}],237:[function(require,module,exports){
  "use strict";
  
  var isequal             = require("lodash.isequal");
  var Report              = require("./Report");
  var SchemaCompilation   = require("./SchemaCompilation");
  var SchemaValidation    = require("./SchemaValidation");
  var Utils               = require("./Utils");
  
  function decodeJSONPointer(str) {
      // http://tools.ietf.org/html/draft-ietf-appsawg-json-pointer-07#section-3
      return decodeURIComponent(str).replace(/~[0-1]/g, function (x) {
          return x === "~1" ? "/" : "~";
      });
  }
  
  function getRemotePath(uri) {
      var io = uri.indexOf("#");
      return io === -1 ? uri : uri.slice(0, io);
  }
  
  function getQueryPath(uri) {
      var io = uri.indexOf("#");
      var res = io === -1 ? undefined : uri.slice(io + 1);
      // WARN: do not slice slash, #/ means take root and go down from it
      // if (res && res[0] === "/") { res = res.slice(1); }
      return res;
  }
  
  function findId(schema, id) {
      // process only arrays and objects
      if (typeof schema !== "object" || schema === null) {
          return;
      }
  
      // no id means root so return itself
      if (!id) {
          return schema;
      }
  
      if (schema.id) {
          if (schema.id === id || schema.id[0] === "#" && schema.id.substring(1) === id) {
              return schema;
          }
      }
  
      var idx, result;
      if (Array.isArray(schema)) {
          idx = schema.length;
          while (idx--) {
              result = findId(schema[idx], id);
              if (result) { return result; }
          }
      } else {
          var keys = Object.keys(schema);
          idx = keys.length;
          while (idx--) {
              var k = keys[idx];
              if (k.indexOf("__$") === 0) {
                  continue;
              }
              result = findId(schema[k], id);
              if (result) { return result; }
          }
      }
  }
  
  /**
   *
   * @param {*} uri
   * @param {*} schema
   *
   * @returns {void}
   */
  exports.cacheSchemaByUri = function (uri, schema) {
      var remotePath = getRemotePath(uri);
      if (remotePath) {
          this.cache[remotePath] = schema;
      }
  };
  
  /**
   *
   * @param {*} uri
   *
   * @returns {void}
   */
  exports.removeFromCacheByUri = function (uri) {
      var remotePath = getRemotePath(uri);
      if (remotePath) {
          delete this.cache[remotePath];
      }
  };
  
  /**
   *
   * @param {*} uri
   *
   * @returns {boolean}
   */
  exports.checkCacheForUri = function (uri) {
      var remotePath = getRemotePath(uri);
      return remotePath ? this.cache[remotePath] != null : false;
  };
  
  exports.getSchema = function (report, schema) {
      if (typeof schema === "object") {
          schema = exports.getSchemaByReference.call(this, report, schema);
      }
      if (typeof schema === "string") {
          schema = exports.getSchemaByUri.call(this, report, schema);
      }
      return schema;
  };
  
  exports.getSchemaByReference = function (report, key) {
      var i = this.referenceCache.length;
      while (i--) {
          if (isequal(this.referenceCache[i][0], key)) {
              return this.referenceCache[i][1];
          }
      }
      // not found
      var schema = Utils.cloneDeep(key);
      this.referenceCache.push([key, schema]);
      return schema;
  };
  
  exports.getSchemaByUri = function (report, uri, root) {
      var remotePath = getRemotePath(uri),
          queryPath = getQueryPath(uri),
          result = remotePath ? this.cache[remotePath] : root;
  
      if (result && remotePath) {
          // we need to avoid compiling schemas in a recursive loop
          var compileRemote = result !== root;
          // now we need to compile and validate resolved schema (in case it's not already)
          if (compileRemote) {
  
              report.path.push(remotePath);
  
              var remoteReport = new Report(report);
              if (SchemaCompilation.compileSchema.call(this, remoteReport, result)) {
                  var savedOptions = this.options;
                  try {
                      // If custom validationOptions were provided to setRemoteReference(),
                      // use them instead of the default options
                      this.options = result.__$validationOptions || this.options;
                      SchemaValidation.validateSchema.call(this, remoteReport, result);
                  } finally {
                      this.options = savedOptions;
                  }
              }
              var remoteReportIsValid = remoteReport.isValid();
              if (!remoteReportIsValid) {
                  report.addError("REMOTE_NOT_VALID", [uri], remoteReport);
              }
  
              report.path.pop();
  
              if (!remoteReportIsValid) {
                  return undefined;
              }
          }
      }
  
      if (result && queryPath) {
          var parts = queryPath.split("/");
          for (var idx = 0, lim = parts.length; result && idx < lim; idx++) {
              var key = decodeJSONPointer(parts[idx]);
              if (idx === 0) { // it's an id
                  result = findId(result, key);
              } else { // it's a path behind id
                  result = result[key];
              }
          }
      }
  
      return result;
  };
  
  exports.getRemotePath = getRemotePath;
  
  },{"./Report":236,"./SchemaCompilation":238,"./SchemaValidation":239,"./Utils":240,"lodash.isequal":121}],238:[function(require,module,exports){
  "use strict";
  
  var Report      = require("./Report");
  var SchemaCache = require("./SchemaCache");
  var Utils       = require("./Utils");
  
  function mergeReference(scope, ref) {
      if (Utils.isAbsoluteUri(ref)) {
          return ref;
      }
  
      var joinedScope = scope.join(""),
          isScopeAbsolute = Utils.isAbsoluteUri(joinedScope),
          isScopeRelative = Utils.isRelativeUri(joinedScope),
          isRefRelative = Utils.isRelativeUri(ref),
          toRemove;
  
      if (isScopeAbsolute && isRefRelative) {
          toRemove = joinedScope.match(/\/[^\/]*$/);
          if (toRemove) {
              joinedScope = joinedScope.slice(0, toRemove.index + 1);
          }
      } else if (isScopeRelative && isRefRelative) {
          joinedScope = "";
      } else {
          toRemove = joinedScope.match(/[^#/]+$/);
          if (toRemove) {
              joinedScope = joinedScope.slice(0, toRemove.index);
          }
      }
  
      var res = joinedScope + ref;
      res = res.replace(/##/, "#");
      return res;
  }
  
  function collectReferences(obj, results, scope, path) {
      results = results || [];
      scope = scope || [];
      path = path || [];
  
      if (typeof obj !== "object" || obj === null) {
          return results;
      }
  
      if (typeof obj.id === "string") {
          scope.push(obj.id);
      }
  
      if (typeof obj.$ref === "string" && typeof obj.__$refResolved === "undefined") {
          results.push({
              ref: mergeReference(scope, obj.$ref),
              key: "$ref",
              obj: obj,
              path: path.slice(0)
          });
      }
      if (typeof obj.$schema === "string" && typeof obj.__$schemaResolved === "undefined") {
          results.push({
              ref: mergeReference(scope, obj.$schema),
              key: "$schema",
              obj: obj,
              path: path.slice(0)
          });
      }
  
      var idx;
      if (Array.isArray(obj)) {
          idx = obj.length;
          while (idx--) {
              path.push(idx.toString());
              collectReferences(obj[idx], results, scope, path);
              path.pop();
          }
      } else {
          var keys = Object.keys(obj);
          idx = keys.length;
          while (idx--) {
              // do not recurse through resolved references and other z-schema props
              if (keys[idx].indexOf("__$") === 0) { continue; }
              path.push(keys[idx]);
              collectReferences(obj[keys[idx]], results, scope, path);
              path.pop();
          }
      }
  
      if (typeof obj.id === "string") {
          scope.pop();
      }
  
      return results;
  }
  
  var compileArrayOfSchemasLoop = function (mainReport, arr) {
      var idx = arr.length,
          compiledCount = 0;
  
      while (idx--) {
  
          // try to compile each schema separately
          var report = new Report(mainReport);
          var isValid = exports.compileSchema.call(this, report, arr[idx]);
          if (isValid) { compiledCount++; }
  
          // copy errors to report
          mainReport.errors = mainReport.errors.concat(report.errors);
  
      }
  
      return compiledCount;
  };
  
  function findId(arr, id) {
      var idx = arr.length;
      while (idx--) {
          if (arr[idx].id === id) {
              return arr[idx];
          }
      }
      return null;
  }
  
  var compileArrayOfSchemas = function (report, arr) {
  
      var compiled = 0,
          lastLoopCompiled;
  
      do {
  
          // remove all UNRESOLVABLE_REFERENCE errors before compiling array again
          var idx = report.errors.length;
          while (idx--) {
              if (report.errors[idx].code === "UNRESOLVABLE_REFERENCE") {
                  report.errors.splice(idx, 1);
              }
          }
  
          // remember how many were compiled in the last loop
          lastLoopCompiled = compiled;
  
          // count how many are compiled now
          compiled = compileArrayOfSchemasLoop.call(this, report, arr);
  
          // fix __$missingReferences if possible
          idx = arr.length;
          while (idx--) {
              var sch = arr[idx];
              if (sch.__$missingReferences) {
                  var idx2 = sch.__$missingReferences.length;
                  while (idx2--) {
                      var refObj = sch.__$missingReferences[idx2];
                      var response = findId(arr, refObj.ref);
                      if (response) {
                          // this might create circular references
                          refObj.obj["__" + refObj.key + "Resolved"] = response;
                          // it's resolved now so delete it
                          sch.__$missingReferences.splice(idx2, 1);
                      }
                  }
                  if (sch.__$missingReferences.length === 0) {
                      delete sch.__$missingReferences;
                  }
              }
          }
  
          // keep repeating if not all compiled and at least one more was compiled in the last loop
      } while (compiled !== arr.length && compiled !== lastLoopCompiled);
  
      return report.isValid();
  
  };
  
  exports.compileSchema = function (report, schema) {
  
      report.commonErrorMessage = "SCHEMA_COMPILATION_FAILED";
  
      // if schema is a string, assume it's a uri
      if (typeof schema === "string") {
          var loadedSchema = SchemaCache.getSchemaByUri.call(this, report, schema);
          if (!loadedSchema) {
              report.addError("SCHEMA_NOT_REACHABLE", [schema]);
              return false;
          }
          schema = loadedSchema;
      }
  
      // if schema is an array, assume it's an array of schemas
      if (Array.isArray(schema)) {
          return compileArrayOfSchemas.call(this, report, schema);
      }
  
      // if we have an id than it should be cached already (if this instance has compiled it)
      if (schema.__$compiled && schema.id && SchemaCache.checkCacheForUri.call(this, schema.id) === false) {
          schema.__$compiled = undefined;
      }
  
      // do not re-compile schemas
      if (schema.__$compiled) {
          return true;
      }
  
      if (schema.id && typeof schema.id === "string") {
          // add this to our schemaCache (before compilation in case we have references including id)
          SchemaCache.cacheSchemaByUri.call(this, schema.id, schema);
      }
  
      // this method can be called recursively, so we need to remember our root
      var isRoot = false;
      if (!report.rootSchema) {
          report.rootSchema = schema;
          isRoot = true;
      }
  
      // delete all __$missingReferences from previous compilation attempts
      var isValidExceptReferences = report.isValid();
      delete schema.__$missingReferences;
  
      // collect all references that need to be resolved - $ref and $schema
      var refs = collectReferences.call(this, schema),
          idx = refs.length;
      while (idx--) {
          // resolve all the collected references into __xxxResolved pointer
          var refObj = refs[idx];
          var response = SchemaCache.getSchemaByUri.call(this, report, refObj.ref, schema);
  
          // we can try to use custom schemaReader if available
          if (!response) {
              var schemaReader = this.getSchemaReader();
              if (schemaReader) {
                  // it's supposed to return a valid schema
                  var s = schemaReader(refObj.ref);
                  if (s) {
                      // it needs to have the id
                      s.id = refObj.ref;
                      // try to compile the schema
                      var subreport = new Report(report);
                      if (!exports.compileSchema.call(this, subreport, s)) {
                          // copy errors to report
                          report.errors = report.errors.concat(subreport.errors);
                      } else {
                          response = SchemaCache.getSchemaByUri.call(this, report, refObj.ref, schema);
                      }
                  }
              }
          }
  
          if (!response) {
  
              var hasNotValid = report.hasError("REMOTE_NOT_VALID", [refObj.ref]);
              var isAbsolute = Utils.isAbsoluteUri(refObj.ref);
              var isDownloaded = false;
              var ignoreUnresolvableRemotes = this.options.ignoreUnresolvableReferences === true;
  
              if (isAbsolute) {
                  // we shouldn't add UNRESOLVABLE_REFERENCE for schemas we already have downloaded
                  // and set through setRemoteReference method
                  isDownloaded = SchemaCache.checkCacheForUri.call(this, refObj.ref);
              }
  
              if (hasNotValid) {
                  // already has REMOTE_NOT_VALID error for this one
              } else if (ignoreUnresolvableRemotes && isAbsolute) {
                  // ignoreUnresolvableRemotes is on and remote isAbsolute
              } else if (isDownloaded) {
                  // remote is downloaded, so no UNRESOLVABLE_REFERENCE
              } else {
                  Array.prototype.push.apply(report.path, refObj.path);
                  report.addError("UNRESOLVABLE_REFERENCE", [refObj.ref]);
                  report.path = report.path.slice(0, -refObj.path.length);
  
                  // pusblish unresolved references out
                  if (isValidExceptReferences) {
                      schema.__$missingReferences = schema.__$missingReferences || [];
                      schema.__$missingReferences.push(refObj);
                  }
              }
          }
          // this might create circular references
          refObj.obj["__" + refObj.key + "Resolved"] = response;
      }
  
      var isValid = report.isValid();
      if (isValid) {
          schema.__$compiled = true;
      } else {
          if (schema.id && typeof schema.id === "string") {
              // remove this schema from schemaCache because it failed to compile
              SchemaCache.removeFromCacheByUri.call(this, schema.id);
          }
      }
  
      // we don't need the root pointer anymore
      if (isRoot) {
          report.rootSchema = undefined;
      }
  
      return isValid;
  
  };
  
  },{"./Report":236,"./SchemaCache":237,"./Utils":240}],239:[function(require,module,exports){
  "use strict";
  
  var FormatValidators = require("./FormatValidators"),
      JsonValidation   = require("./JsonValidation"),
      Report           = require("./Report"),
      Utils            = require("./Utils");
  
  var SchemaValidators = {
      $ref: function (report, schema) {
          // http://tools.ietf.org/html/draft-ietf-appsawg-json-pointer-07
          // http://tools.ietf.org/html/draft-pbryan-zyp-json-ref-03
          if (typeof schema.$ref !== "string") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["$ref", "string"]);
          }
      },
      $schema: function (report, schema) {
          // http://json-schema.org/latest/json-schema-core.html#rfc.section.6
          if (typeof schema.$schema !== "string") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["$schema", "string"]);
          }
      },
      multipleOf: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.1.1.1
          if (typeof schema.multipleOf !== "number") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["multipleOf", "number"]);
          } else if (schema.multipleOf <= 0) {
              report.addError("KEYWORD_MUST_BE", ["multipleOf", "strictly greater than 0"]);
          }
      },
      maximum: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.1.2.1
          if (typeof schema.maximum !== "number") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["maximum", "number"]);
          }
      },
      exclusiveMaximum: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.1.2.1
          if (typeof schema.exclusiveMaximum !== "boolean") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["exclusiveMaximum", "boolean"]);
          } else if (schema.maximum === undefined) {
              report.addError("KEYWORD_DEPENDENCY", ["exclusiveMaximum", "maximum"]);
          }
      },
      minimum: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.1.3.1
          if (typeof schema.minimum !== "number") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["minimum", "number"]);
          }
      },
      exclusiveMinimum: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.1.3.1
          if (typeof schema.exclusiveMinimum !== "boolean") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["exclusiveMinimum", "boolean"]);
          } else if (schema.minimum === undefined) {
              report.addError("KEYWORD_DEPENDENCY", ["exclusiveMinimum", "minimum"]);
          }
      },
      maxLength: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.2.1.1
          if (Utils.whatIs(schema.maxLength) !== "integer") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["maxLength", "integer"]);
          } else if (schema.maxLength < 0) {
              report.addError("KEYWORD_MUST_BE", ["maxLength", "greater than, or equal to 0"]);
          }
      },
      minLength: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.2.2.1
          if (Utils.whatIs(schema.minLength) !== "integer") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["minLength", "integer"]);
          } else if (schema.minLength < 0) {
              report.addError("KEYWORD_MUST_BE", ["minLength", "greater than, or equal to 0"]);
          }
      },
      pattern: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.2.3.1
          if (typeof schema.pattern !== "string") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["pattern", "string"]);
          } else {
              try {
                  RegExp(schema.pattern);
              } catch (e) {
                  report.addError("KEYWORD_PATTERN", ["pattern", schema.pattern]);
              }
          }
      },
      additionalItems: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.1.1
          var type = Utils.whatIs(schema.additionalItems);
          if (type !== "boolean" && type !== "object") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["additionalItems", ["boolean", "object"]]);
          } else if (type === "object") {
              report.path.push("additionalItems");
              exports.validateSchema.call(this, report, schema.additionalItems);
              report.path.pop();
          }
      },
      items: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.1.1
          var type = Utils.whatIs(schema.items);
  
          if (type === "object") {
              report.path.push("items");
              exports.validateSchema.call(this, report, schema.items);
              report.path.pop();
          } else if (type === "array") {
              var idx = schema.items.length;
              while (idx--) {
                  report.path.push("items");
                  report.path.push(idx.toString());
                  exports.validateSchema.call(this, report, schema.items[idx]);
                  report.path.pop();
                  report.path.pop();
              }
          } else {
              report.addError("KEYWORD_TYPE_EXPECTED", ["items", ["array", "object"]]);
          }
  
          // custom - strict mode
          if (this.options.forceAdditional === true && schema.additionalItems === undefined && Array.isArray(schema.items)) {
              report.addError("KEYWORD_UNDEFINED_STRICT", ["additionalItems"]);
          }
          // custome - assume defined false mode
          if (this.options.assumeAdditional && schema.additionalItems === undefined && Array.isArray(schema.items)) {
              schema.additionalItems = false;
          }
      },
      maxItems: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.2.1
          if (typeof schema.maxItems !== "number") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["maxItems", "integer"]);
          } else if (schema.maxItems < 0) {
              report.addError("KEYWORD_MUST_BE", ["maxItems", "greater than, or equal to 0"]);
          }
      },
      minItems: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.3.1
          if (Utils.whatIs(schema.minItems) !== "integer") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["minItems", "integer"]);
          } else if (schema.minItems < 0) {
              report.addError("KEYWORD_MUST_BE", ["minItems", "greater than, or equal to 0"]);
          }
      },
      uniqueItems: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.3.4.1
          if (typeof schema.uniqueItems !== "boolean") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["uniqueItems", "boolean"]);
          }
      },
      maxProperties: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.1.1
          if (Utils.whatIs(schema.maxProperties) !== "integer") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["maxProperties", "integer"]);
          } else if (schema.maxProperties < 0) {
              report.addError("KEYWORD_MUST_BE", ["maxProperties", "greater than, or equal to 0"]);
          }
      },
      minProperties: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.2.1
          if (Utils.whatIs(schema.minProperties) !== "integer") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["minProperties", "integer"]);
          } else if (schema.minProperties < 0) {
              report.addError("KEYWORD_MUST_BE", ["minProperties", "greater than, or equal to 0"]);
          }
      },
      required: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.3.1
          if (Utils.whatIs(schema.required) !== "array") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["required", "array"]);
          } else if (schema.required.length === 0) {
              report.addError("KEYWORD_MUST_BE", ["required", "an array with at least one element"]);
          } else {
              var idx = schema.required.length;
              while (idx--) {
                  if (typeof schema.required[idx] !== "string") {
                      report.addError("KEYWORD_VALUE_TYPE", ["required", "string"]);
                  }
              }
              if (Utils.isUniqueArray(schema.required) === false) {
                  report.addError("KEYWORD_MUST_BE", ["required", "an array with unique items"]);
              }
          }
      },
      additionalProperties: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.4.1
          var type = Utils.whatIs(schema.additionalProperties);
          if (type !== "boolean" && type !== "object") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["additionalProperties", ["boolean", "object"]]);
          } else if (type === "object") {
              report.path.push("additionalProperties");
              exports.validateSchema.call(this, report, schema.additionalProperties);
              report.path.pop();
          }
      },
      properties: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.4.1
          if (Utils.whatIs(schema.properties) !== "object") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["properties", "object"]);
              return;
          }
  
          var keys = Object.keys(schema.properties),
              idx = keys.length;
          while (idx--) {
              var key = keys[idx],
                  val = schema.properties[key];
              report.path.push("properties");
              report.path.push(key);
              exports.validateSchema.call(this, report, val);
              report.path.pop();
              report.path.pop();
          }
  
          // custom - strict mode
          if (this.options.forceAdditional === true && schema.additionalProperties === undefined) {
              report.addError("KEYWORD_UNDEFINED_STRICT", ["additionalProperties"]);
          }
          // custome - assume defined false mode
          if (this.options.assumeAdditional && schema.additionalProperties === undefined) {
              schema.additionalProperties = false;
          }
          // custom - forceProperties
          if (this.options.forceProperties === true && keys.length === 0) {
              report.addError("CUSTOM_MODE_FORCE_PROPERTIES", ["properties"]);
          }
      },
      patternProperties: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.4.1
          if (Utils.whatIs(schema.patternProperties) !== "object") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["patternProperties", "object"]);
              return;
          }
  
          var keys = Object.keys(schema.patternProperties),
              idx = keys.length;
          while (idx--) {
              var key = keys[idx],
                  val = schema.patternProperties[key];
              try {
                  RegExp(key);
              } catch (e) {
                  report.addError("KEYWORD_PATTERN", ["patternProperties", key]);
              }
              report.path.push("patternProperties");
              report.path.push(key.toString());
              exports.validateSchema.call(this, report, val);
              report.path.pop();
              report.path.pop();
          }
  
          // custom - forceProperties
          if (this.options.forceProperties === true && keys.length === 0) {
              report.addError("CUSTOM_MODE_FORCE_PROPERTIES", ["patternProperties"]);
          }
      },
      dependencies: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.4.5.1
          if (Utils.whatIs(schema.dependencies) !== "object") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["dependencies", "object"]);
          } else {
              var keys = Object.keys(schema.dependencies),
                  idx = keys.length;
              while (idx--) {
                  var schemaKey = keys[idx],
                      schemaDependency = schema.dependencies[schemaKey],
                      type = Utils.whatIs(schemaDependency);
  
                  if (type === "object") {
                      report.path.push("dependencies");
                      report.path.push(schemaKey);
                      exports.validateSchema.call(this, report, schemaDependency);
                      report.path.pop();
                      report.path.pop();
                  } else if (type === "array") {
                      var idx2 = schemaDependency.length;
                      if (idx2 === 0) {
                          report.addError("KEYWORD_MUST_BE", ["dependencies", "not empty array"]);
                      }
                      while (idx2--) {
                          if (typeof schemaDependency[idx2] !== "string") {
                              report.addError("KEYWORD_VALUE_TYPE", ["dependensices", "string"]);
                          }
                      }
                      if (Utils.isUniqueArray(schemaDependency) === false) {
                          report.addError("KEYWORD_MUST_BE", ["dependencies", "an array with unique items"]);
                      }
                  } else {
                      report.addError("KEYWORD_VALUE_TYPE", ["dependencies", "object or array"]);
                  }
              }
          }
      },
      enum: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.1.1
          if (Array.isArray(schema.enum) === false) {
              report.addError("KEYWORD_TYPE_EXPECTED", ["enum", "array"]);
          } else if (schema.enum.length === 0) {
              report.addError("KEYWORD_MUST_BE", ["enum", "an array with at least one element"]);
          } else if (Utils.isUniqueArray(schema.enum) === false) {
              report.addError("KEYWORD_MUST_BE", ["enum", "an array with unique elements"]);
          }
      },
      type: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.2.1
          var primitiveTypes = ["array", "boolean", "integer", "number", "null", "object", "string"],
              primitiveTypeStr = primitiveTypes.join(","),
              isArray = Array.isArray(schema.type);
  
          if (isArray) {
              var idx = schema.type.length;
              while (idx--) {
                  if (primitiveTypes.indexOf(schema.type[idx]) === -1) {
                      report.addError("KEYWORD_TYPE_EXPECTED", ["type", primitiveTypeStr]);
                  }
              }
              if (Utils.isUniqueArray(schema.type) === false) {
                  report.addError("KEYWORD_MUST_BE", ["type", "an object with unique properties"]);
              }
          } else if (typeof schema.type === "string") {
              if (primitiveTypes.indexOf(schema.type) === -1) {
                  report.addError("KEYWORD_TYPE_EXPECTED", ["type", primitiveTypeStr]);
              }
          } else {
              report.addError("KEYWORD_TYPE_EXPECTED", ["type", ["string", "array"]]);
          }
  
          if (this.options.noEmptyStrings === true) {
              if (schema.type === "string" || isArray && schema.type.indexOf("string") !== -1) {
                  if (schema.minLength === undefined &&
                      schema.enum === undefined &&
                      schema.format === undefined) {
  
                      schema.minLength = 1;
                  }
              }
          }
          if (this.options.noEmptyArrays === true) {
              if (schema.type === "array" || isArray && schema.type.indexOf("array") !== -1) {
                  if (schema.minItems === undefined) {
                      schema.minItems = 1;
                  }
              }
          }
          if (this.options.forceProperties === true) {
              if (schema.type === "object" || isArray && schema.type.indexOf("object") !== -1) {
                  if (schema.properties === undefined && schema.patternProperties === undefined) {
                      report.addError("KEYWORD_UNDEFINED_STRICT", ["properties"]);
                  }
              }
          }
          if (this.options.forceItems === true) {
              if (schema.type === "array" || isArray && schema.type.indexOf("array") !== -1) {
                  if (schema.items === undefined) {
                      report.addError("KEYWORD_UNDEFINED_STRICT", ["items"]);
                  }
              }
          }
          if (this.options.forceMinItems === true) {
              if (schema.type === "array" || isArray && schema.type.indexOf("array") !== -1) {
                  if (schema.minItems === undefined) {
                      report.addError("KEYWORD_UNDEFINED_STRICT", ["minItems"]);
                  }
              }
          }
          if (this.options.forceMaxItems === true) {
              if (schema.type === "array" || isArray && schema.type.indexOf("array") !== -1) {
                  if (schema.maxItems === undefined) {
                      report.addError("KEYWORD_UNDEFINED_STRICT", ["maxItems"]);
                  }
              }
          }
          if (this.options.forceMinLength === true) {
              if (schema.type === "string" || isArray && schema.type.indexOf("string") !== -1) {
                  if (schema.minLength === undefined &&
                      schema.format === undefined &&
                      schema.enum === undefined &&
                      schema.pattern === undefined) {
                      report.addError("KEYWORD_UNDEFINED_STRICT", ["minLength"]);
                  }
              }
          }
          if (this.options.forceMaxLength === true) {
              if (schema.type === "string" || isArray && schema.type.indexOf("string") !== -1) {
                  if (schema.maxLength === undefined &&
                      schema.format === undefined &&
                      schema.enum === undefined &&
                      schema.pattern === undefined) {
                      report.addError("KEYWORD_UNDEFINED_STRICT", ["maxLength"]);
                  }
              }
          }
      },
      allOf: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.3.1
          if (Array.isArray(schema.allOf) === false) {
              report.addError("KEYWORD_TYPE_EXPECTED", ["allOf", "array"]);
          } else if (schema.allOf.length === 0) {
              report.addError("KEYWORD_MUST_BE", ["allOf", "an array with at least one element"]);
          } else {
              var idx = schema.allOf.length;
              while (idx--) {
                  report.path.push("allOf");
                  report.path.push(idx.toString());
                  exports.validateSchema.call(this, report, schema.allOf[idx]);
                  report.path.pop();
                  report.path.pop();
              }
          }
      },
      anyOf: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.4.1
          if (Array.isArray(schema.anyOf) === false) {
              report.addError("KEYWORD_TYPE_EXPECTED", ["anyOf", "array"]);
          } else if (schema.anyOf.length === 0) {
              report.addError("KEYWORD_MUST_BE", ["anyOf", "an array with at least one element"]);
          } else {
              var idx = schema.anyOf.length;
              while (idx--) {
                  report.path.push("anyOf");
                  report.path.push(idx.toString());
                  exports.validateSchema.call(this, report, schema.anyOf[idx]);
                  report.path.pop();
                  report.path.pop();
              }
          }
      },
      oneOf: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.5.1
          if (Array.isArray(schema.oneOf) === false) {
              report.addError("KEYWORD_TYPE_EXPECTED", ["oneOf", "array"]);
          } else if (schema.oneOf.length === 0) {
              report.addError("KEYWORD_MUST_BE", ["oneOf", "an array with at least one element"]);
          } else {
              var idx = schema.oneOf.length;
              while (idx--) {
                  report.path.push("oneOf");
                  report.path.push(idx.toString());
                  exports.validateSchema.call(this, report, schema.oneOf[idx]);
                  report.path.pop();
                  report.path.pop();
              }
          }
      },
      not: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.6.1
          if (Utils.whatIs(schema.not) !== "object") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["not", "object"]);
          } else {
              report.path.push("not");
              exports.validateSchema.call(this, report, schema.not);
              report.path.pop();
          }
      },
      definitions: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.5.5.7.1
          if (Utils.whatIs(schema.definitions) !== "object") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["definitions", "object"]);
          } else {
              var keys = Object.keys(schema.definitions),
                  idx = keys.length;
              while (idx--) {
                  var key = keys[idx],
                      val = schema.definitions[key];
                  report.path.push("definitions");
                  report.path.push(key);
                  exports.validateSchema.call(this, report, val);
                  report.path.pop();
                  report.path.pop();
              }
          }
      },
      format: function (report, schema) {
          if (typeof schema.format !== "string") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["format", "string"]);
          } else {
              if (FormatValidators[schema.format] === undefined && this.options.ignoreUnknownFormats !== true) {
                  report.addError("UNKNOWN_FORMAT", [schema.format]);
              }
          }
      },
      id: function (report, schema) {
          // http://json-schema.org/latest/json-schema-core.html#rfc.section.7.2
          if (typeof schema.id !== "string") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["id", "string"]);
          }
      },
      title: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.6.1
          if (typeof schema.title !== "string") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["title", "string"]);
          }
      },
      description: function (report, schema) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.6.1
          if (typeof schema.description !== "string") {
              report.addError("KEYWORD_TYPE_EXPECTED", ["description", "string"]);
          }
      },
      "default": function (/* report, schema */) {
          // http://json-schema.org/latest/json-schema-validation.html#rfc.section.6.2
          // There are no restrictions placed on the value of this keyword.
      }
  };
  
  /**
   *
   * @param {Report} report
   * @param {*[]} arr
   *
   * @returns {boolean}
   */
  var validateArrayOfSchemas = function (report, arr) {
      var idx = arr.length;
      while (idx--) {
          exports.validateSchema.call(this, report, arr[idx]);
      }
      return report.isValid();
  };
  
  /**
   *
   * @param {Report} report
   * @param {*} schema
   */
  exports.validateSchema = function (report, schema) {
  
      report.commonErrorMessage = "SCHEMA_VALIDATION_FAILED";
  
      // if schema is an array, assume it's an array of schemas
      if (Array.isArray(schema)) {
          return validateArrayOfSchemas.call(this, report, schema);
      }
  
      // do not revalidate schema that has already been validated once
      if (schema.__$validated) {
          return true;
      }
  
      // if $schema is present, this schema should validate against that $schema
      var hasParentSchema = schema.$schema && schema.id !== schema.$schema;
      if (hasParentSchema) {
          if (schema.__$schemaResolved && schema.__$schemaResolved !== schema) {
              var subReport = new Report(report);
              var valid = JsonValidation.validate.call(this, subReport, schema.__$schemaResolved, schema);
              if (valid === false) {
                  report.addError("PARENT_SCHEMA_VALIDATION_FAILED", null, subReport);
              }
          } else {
              if (this.options.ignoreUnresolvableReferences !== true) {
                  report.addError("REF_UNRESOLVED", [schema.$schema]);
              }
          }
      }
  
      if (this.options.noTypeless === true) {
          // issue #36 - inherit type to anyOf, oneOf, allOf if noTypeless is defined
          if (schema.type !== undefined) {
              var schemas = [];
              if (Array.isArray(schema.anyOf)) { schemas = schemas.concat(schema.anyOf); }
              if (Array.isArray(schema.oneOf)) { schemas = schemas.concat(schema.oneOf); }
              if (Array.isArray(schema.allOf)) { schemas = schemas.concat(schema.allOf); }
              schemas.forEach(function (sch) {
                  if (!sch.type) { sch.type = schema.type; }
              });
          }
          // end issue #36
          if (schema.enum === undefined &&
              schema.type === undefined &&
              schema.anyOf === undefined &&
              schema.oneOf === undefined &&
              schema.not === undefined &&
              schema.$ref === undefined) {
              report.addError("KEYWORD_UNDEFINED_STRICT", ["type"]);
          }
      }
  
      var keys = Object.keys(schema),
          idx = keys.length;
      while (idx--) {
          var key = keys[idx];
          if (key.indexOf("__") === 0) { continue; }
          if (SchemaValidators[key] !== undefined) {
              SchemaValidators[key].call(this, report, schema);
          } else if (!hasParentSchema) {
              if (this.options.noExtraKeywords === true) {
                  report.addError("KEYWORD_UNEXPECTED", [key]);
              }
          }
      }
  
      if (this.options.pedanticCheck === true) {
          if (schema.enum) {
              // break recursion
              var tmpSchema = Utils.clone(schema);
              delete tmpSchema.enum;
              delete tmpSchema.default;
  
              report.path.push("enum");
              idx = schema.enum.length;
              while (idx--) {
                  report.path.push(idx.toString());
                  JsonValidation.validate.call(this, report, tmpSchema, schema.enum[idx]);
                  report.path.pop();
              }
              report.path.pop();
          }
  
          if (schema.default) {
              report.path.push("default");
              JsonValidation.validate.call(this, report, schema, schema.default);
              report.path.pop();
          }
      }
  
      var isValid = report.isValid();
      if (isValid) {
          schema.__$validated = true;
      }
      return isValid;
  };
  
  },{"./FormatValidators":233,"./JsonValidation":234,"./Report":236,"./Utils":240}],240:[function(require,module,exports){
  "use strict";
  
  require("core-js/es6/symbol");
  
  exports.jsonSymbol = Symbol.for("z-schema/json");
  
  exports.schemaSymbol = Symbol.for("z-schema/schema");
  
  /**
   * @param {object} obj
   *
   * @returns {string[]}
   */
  var sortedKeys = exports.sortedKeys = function (obj) {
      return Object.keys(obj).sort();
  };
  
  /**
   *
   * @param {string} uri
   *
   * @returns {boolean}
   */
  exports.isAbsoluteUri = function (uri) {
      return /^https?:\/\//.test(uri);
  };
  
  /**
   *
   * @param {string} uri
   *
   * @returns {boolean}
   */
  exports.isRelativeUri = function (uri) {
      // relative URIs that end with a hash sign, issue #56
      return /.+#/.test(uri);
  };
  
  exports.whatIs = function (what) {
  
      var to = typeof what;
  
      if (to === "object") {
          if (what === null) {
              return "null";
          }
          if (Array.isArray(what)) {
              return "array";
          }
          return "object"; // typeof what === 'object' && what === Object(what) && !Array.isArray(what);
      }
  
      if (to === "number") {
          if (Number.isFinite(what)) {
              if (what % 1 === 0) {
                  return "integer";
              } else {
                  return "number";
              }
          }
          if (Number.isNaN(what)) {
              return "not-a-number";
          }
          return "unknown-number";
      }
  
      return to; // undefined, boolean, string, function
  
  };
  
  /**
   *
   * @param {*} json1
   * @param {*} json2
   * @param {*} [options]
   *
   * @returns {boolean}
   */
  exports.areEqual = function areEqual(json1, json2, options) {
  
      options = options || {};
      var caseInsensitiveComparison = options.caseInsensitiveComparison || false;
  
      // http://json-schema.org/latest/json-schema-core.html#rfc.section.3.6
  
      // Two JSON values are said to be equal if and only if:
      // both are nulls; or
      // both are booleans, and have the same value; or
      // both are strings, and have the same value; or
      // both are numbers, and have the same mathematical value; or
      if (json1 === json2) {
          return true;
      }
      if (
        caseInsensitiveComparison === true &&
        typeof json1 === "string" && typeof json2 === "string" &&
        json1.toUpperCase() === json2.toUpperCase()) {
          return true;
      }
  
      var i, len;
  
      // both are arrays, and:
      if (Array.isArray(json1) && Array.isArray(json2)) {
          // have the same number of items; and
          if (json1.length !== json2.length) {
              return false;
          }
          // items at the same index are equal according to this definition; or
          len = json1.length;
          for (i = 0; i < len; i++) {
              if (!areEqual(json1[i], json2[i], { caseInsensitiveComparison: caseInsensitiveComparison })) {
                  return false;
              }
          }
          return true;
      }
  
      // both are objects, and:
      if (exports.whatIs(json1) === "object" && exports.whatIs(json2) === "object") {
          // have the same set of property names; and
          var keys1 = sortedKeys(json1);
          var keys2 = sortedKeys(json2);
          if (!areEqual(keys1, keys2, { caseInsensitiveComparison: caseInsensitiveComparison })) {
              return false;
          }
          // values for a same property name are equal according to this definition.
          len = keys1.length;
          for (i = 0; i < len; i++) {
              if (!areEqual(json1[keys1[i]], json2[keys1[i]], { caseInsensitiveComparison: caseInsensitiveComparison })) {
                  return false;
              }
          }
          return true;
      }
  
      return false;
  };
  
  /**
   *
   * @param {*[]} arr
   * @param {number[]} [indexes]
   *
   * @returns {boolean}
   */
  exports.isUniqueArray = function (arr, indexes) {
      var i, j, l = arr.length;
      for (i = 0; i < l; i++) {
          for (j = i + 1; j < l; j++) {
              if (exports.areEqual(arr[i], arr[j])) {
                  if (indexes) { indexes.push(i, j); }
                  return false;
              }
          }
      }
      return true;
  };
  
  /**
   *
   * @param {*} bigSet
   * @param {*} subSet
   *
   * @returns {*[]}
   */
  exports.difference = function (bigSet, subSet) {
      var arr = [],
          idx = bigSet.length;
      while (idx--) {
          if (subSet.indexOf(bigSet[idx]) === -1) {
              arr.push(bigSet[idx]);
          }
      }
      return arr;
  };
  
  // NOT a deep version of clone
  exports.clone = function (src) {
      if (typeof src === "undefined") { return void 0; }
      if (typeof src !== "object" || src === null) { return src; }
      var res, idx;
      if (Array.isArray(src)) {
          res = [];
          idx = src.length;
          while (idx--) {
              res[idx] = src[idx];
          }
      } else {
          res = {};
          var keys = Object.keys(src);
          idx = keys.length;
          while (idx--) {
              var key = keys[idx];
              res[key] = src[key];
          }
      }
      return res;
  };
  
  exports.cloneDeep = function (src) {
      var visited = [], cloned = [];
      function cloneDeep(src) {
          if (typeof src !== "object" || src === null) { return src; }
          var res, idx, cidx;
  
          cidx = visited.indexOf(src);
          if (cidx !== -1) { return cloned[cidx]; }
  
          visited.push(src);
          if (Array.isArray(src)) {
              res = [];
              cloned.push(res);
              idx = src.length;
              while (idx--) {
                  res[idx] = cloneDeep(src[idx]);
              }
          } else {
              res = {};
              cloned.push(res);
              var keys = Object.keys(src);
              idx = keys.length;
              while (idx--) {
                  var key = keys[idx];
                  res[key] = cloneDeep(src[key]);
              }
          }
          return res;
      }
      return cloneDeep(src);
  };
  
  /*
    following function comes from punycode.js library
    see: https://github.com/bestiejs/punycode.js
  */
  /*jshint -W016*/
  /**
   * Creates an array containing the numeric code points of each Unicode
   * character in the string. While JavaScript uses UCS-2 internally,
   * this function will convert a pair of surrogate halves (each of which
   * UCS-2 exposes as separate characters) into a single code point,
   * matching UTF-16.
   * @see `punycode.ucs2.encode`
   * @see <https://mathiasbynens.be/notes/javascript-encoding>
   * @memberOf punycode.ucs2
   * @name decode
   * @param {String} string The Unicode input string (UCS-2).
   * @returns {Array} The new array of code points.
   */
  exports.ucs2decode = function (string) {
      var output = [],
          counter = 0,
          length = string.length,
          value,
          extra;
      while (counter < length) {
          value = string.charCodeAt(counter++);
          if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
              // high surrogate, and there is a next character
              extra = string.charCodeAt(counter++);
              if ((extra & 0xFC00) == 0xDC00) { // low surrogate
                  output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
              } else {
                  // unmatched surrogate; only append this code unit, in case the next
                  // code unit is the high surrogate of a surrogate pair
                  output.push(value);
                  counter--;
              }
          } else {
              output.push(value);
          }
      }
      return output;
  };
  /*jshint +W016*/
  
  },{"core-js/es6/symbol":12}],241:[function(require,module,exports){
  (function (process){
  "use strict";
  
  require("./Polyfills");
  var get               = require("lodash.get");
  var Report            = require("./Report");
  var FormatValidators  = require("./FormatValidators");
  var JsonValidation    = require("./JsonValidation");
  var SchemaCache       = require("./SchemaCache");
  var SchemaCompilation = require("./SchemaCompilation");
  var SchemaValidation  = require("./SchemaValidation");
  var Utils             = require("./Utils");
  var Draft4Schema      = require("./schemas/schema.json");
  var Draft4HyperSchema = require("./schemas/hyper-schema.json");
  
  /**
   * default options
   */
  var defaultOptions = {
      // default timeout for all async tasks
      asyncTimeout: 2000,
      // force additionalProperties and additionalItems to be defined on "object" and "array" types
      forceAdditional: false,
      // assume additionalProperties and additionalItems are defined as "false" where appropriate
      assumeAdditional: false,
      // do case insensitive comparison for enums
      enumCaseInsensitiveComparison: false,
      // force items to be defined on "array" types
      forceItems: false,
      // force minItems to be defined on "array" types
      forceMinItems: false,
      // force maxItems to be defined on "array" types
      forceMaxItems: false,
      // force minLength to be defined on "string" types
      forceMinLength: false,
      // force maxLength to be defined on "string" types
      forceMaxLength: false,
      // force properties or patternProperties to be defined on "object" types
      forceProperties: false,
      // ignore references that cannot be resolved (remote schemas) // TODO: make sure this is only for remote schemas, not local ones
      ignoreUnresolvableReferences: false,
      // disallow usage of keywords that this validator can't handle
      noExtraKeywords: false,
      // disallow usage of schema's without "type" defined
      noTypeless: false,
      // disallow zero length strings in validated objects
      noEmptyStrings: false,
      // disallow zero length arrays in validated objects
      noEmptyArrays: false,
      // forces "uri" format to be in fully rfc3986 compliant
      strictUris: false,
      // turn on some of the above
      strictMode: false,
      // report error paths as an array of path segments to get to the offending node
      reportPathAsArray: false,
      // stops validation as soon as an error is found, true by default but can be turned off
      breakOnFirstError: true,
      // check if schema follow best practices and common sence
      pedanticCheck: false,
      // ignore unknown formats (do not report them as an error)
      ignoreUnknownFormats: false,
      // function to be called on every schema
      customValidator: null
  };
  
  function normalizeOptions(options) {
      var normalized;
  
      // options
      if (typeof options === "object") {
          var keys = Object.keys(options),
              idx = keys.length,
              key;
  
          // check that the options are correctly configured
          while (idx--) {
              key = keys[idx];
              if (defaultOptions[key] === undefined) {
                  throw new Error("Unexpected option passed to constructor: " + key);
              }
          }
  
          // copy the default options into passed options
          keys = Object.keys(defaultOptions);
          idx = keys.length;
          while (idx--) {
              key = keys[idx];
              if (options[key] === undefined) {
                  options[key] = Utils.clone(defaultOptions[key]);
              }
          }
  
          normalized = options;
      } else {
          normalized = Utils.clone(defaultOptions);
      }
  
      if (normalized.strictMode === true) {
          normalized.forceAdditional  = true;
          normalized.forceItems       = true;
          normalized.forceMaxLength   = true;
          normalized.forceProperties  = true;
          normalized.noExtraKeywords  = true;
          normalized.noTypeless       = true;
          normalized.noEmptyStrings   = true;
          normalized.noEmptyArrays    = true;
      }
  
      return normalized;
  }
  
  /**
   * @class
   *
   * @param {*} [options]
   */
  function ZSchema(options) {
      this.cache = {};
      this.referenceCache = [];
      this.validateOptions = {};
  
      this.options = normalizeOptions(options);
  
      // Disable strict validation for the built-in schemas
      var metaschemaOptions = normalizeOptions({ });
  
      this.setRemoteReference("http://json-schema.org/draft-04/schema", Draft4Schema, metaschemaOptions);
      this.setRemoteReference("http://json-schema.org/draft-04/hyper-schema", Draft4HyperSchema, metaschemaOptions);
  }
  
  /**
   * instance methods
   *
   * @param {*} schema
   *
   * @returns {boolean}
   */
  ZSchema.prototype.compileSchema = function (schema) {
      var report = new Report(this.options);
  
      schema = SchemaCache.getSchema.call(this, report, schema);
  
      SchemaCompilation.compileSchema.call(this, report, schema);
  
      this.lastReport = report;
      return report.isValid();
  };
  
  /**
   *
   * @param {*} schema
   *
   * @returns {boolean}
   */
  ZSchema.prototype.validateSchema = function (schema) {
      if (Array.isArray(schema) && schema.length === 0) {
          throw new Error(".validateSchema was called with an empty array");
      }
  
      var report = new Report(this.options);
  
      schema = SchemaCache.getSchema.call(this, report, schema);
  
      var compiled = SchemaCompilation.compileSchema.call(this, report, schema);
      if (compiled) { SchemaValidation.validateSchema.call(this, report, schema); }
  
      this.lastReport = report;
      return report.isValid();
  };
  
  /**
   *
   * @param {*} json
   * @param {*} schema
   * @param {*} [options]
   * @param {function(*, *)} [callback]
   *
   * @returns {boolean}
   */
  ZSchema.prototype.validate = function (json, schema, options, callback) {
  
      if (Utils.whatIs(options) === "function") {
          callback = options;
          options = {};
      }
      if (!options) { options = {}; }
  
      this.validateOptions = options;
  
      var whatIs = Utils.whatIs(schema);
      if (whatIs !== "string" && whatIs !== "object") {
          var e = new Error("Invalid .validate call - schema must be an string or object but " + whatIs + " was passed!");
          if (callback) {
              process.nextTick(function () {
                  callback(e, false);
              });
              return;
          }
          throw e;
      }
  
      var foundError = false;
      var report = new Report(this.options);
      report.json = json;
  
      if (typeof schema === "string") {
          var schemaName = schema;
          schema = SchemaCache.getSchema.call(this, report, schemaName);
          if (!schema) {
              throw new Error("Schema with id '" + schemaName + "' wasn't found in the validator cache!");
          }
      } else {
          schema = SchemaCache.getSchema.call(this, report, schema);
      }
  
      var compiled = false;
      if (!foundError) {
          compiled = SchemaCompilation.compileSchema.call(this, report, schema);
      }
      if (!compiled) {
          this.lastReport = report;
          foundError = true;
      }
  
      var validated = false;
      if (!foundError) {
          validated = SchemaValidation.validateSchema.call(this, report, schema);
      }
      if (!validated) {
          this.lastReport = report;
          foundError = true;
      }
  
      if (options.schemaPath) {
          report.rootSchema = schema;
          schema = get(schema, options.schemaPath);
          if (!schema) {
              throw new Error("Schema path '" + options.schemaPath + "' wasn't found in the schema!");
          }
      }
  
      if (!foundError) {
          JsonValidation.validate.call(this, report, schema, json);
      }
  
      if (callback) {
          report.processAsyncTasks(this.options.asyncTimeout, callback);
          return;
      } else if (report.asyncTasks.length > 0) {
          throw new Error("This validation has async tasks and cannot be done in sync mode, please provide callback argument.");
      }
  
      // assign lastReport so errors are retrievable in sync mode
      this.lastReport = report;
      return report.isValid();
  };
  ZSchema.prototype.getLastError = function () {
      if (this.lastReport.errors.length === 0) {
          return null;
      }
      var e = new Error();
      e.name = "z-schema validation error";
      e.message = this.lastReport.commonErrorMessage;
      e.details = this.lastReport.errors;
      return e;
  };
  ZSchema.prototype.getLastErrors = function () {
      return this.lastReport && this.lastReport.errors.length > 0 ? this.lastReport.errors : undefined;
  };
  ZSchema.prototype.getMissingReferences = function (arr) {
      arr = arr || this.lastReport.errors;
      var res = [],
          idx = arr.length;
      while (idx--) {
          var error = arr[idx];
          if (error.code === "UNRESOLVABLE_REFERENCE") {
              var reference = error.params[0];
              if (res.indexOf(reference) === -1) {
                  res.push(reference);
              }
          }
          if (error.inner) {
              res = res.concat(this.getMissingReferences(error.inner));
          }
      }
      return res;
  };
  ZSchema.prototype.getMissingRemoteReferences = function () {
      var missingReferences = this.getMissingReferences(),
          missingRemoteReferences = [],
          idx = missingReferences.length;
      while (idx--) {
          var remoteReference = SchemaCache.getRemotePath(missingReferences[idx]);
          if (remoteReference && missingRemoteReferences.indexOf(remoteReference) === -1) {
              missingRemoteReferences.push(remoteReference);
          }
      }
      return missingRemoteReferences;
  };
  ZSchema.prototype.setRemoteReference = function (uri, schema, validationOptions) {
      if (typeof schema === "string") {
          schema = JSON.parse(schema);
      } else {
          schema = Utils.cloneDeep(schema);
      }
  
      if (validationOptions) {
          schema.__$validationOptions = normalizeOptions(validationOptions);
      }
  
      SchemaCache.cacheSchemaByUri.call(this, uri, schema);
  };
  ZSchema.prototype.getResolvedSchema = function (schema) {
      var report = new Report(this.options);
      schema = SchemaCache.getSchema.call(this, report, schema);
  
      // clone before making any modifications
      schema = Utils.cloneDeep(schema);
  
      var visited = [];
  
      // clean-up the schema and resolve references
      var cleanup = function (schema) {
          var key,
              typeOf = Utils.whatIs(schema);
          if (typeOf !== "object" && typeOf !== "array") {
              return;
          }
  
          if (schema.___$visited) {
              return;
          }
  
          schema.___$visited = true;
          visited.push(schema);
  
          if (schema.$ref && schema.__$refResolved) {
              var from = schema.__$refResolved;
              var to = schema;
              delete schema.$ref;
              delete schema.__$refResolved;
              for (key in from) {
                  if (from.hasOwnProperty(key)) {
                      to[key] = from[key];
                  }
              }
          }
          for (key in schema) {
              if (schema.hasOwnProperty(key)) {
                  if (key.indexOf("__$") === 0) {
                      delete schema[key];
                  } else {
                      cleanup(schema[key]);
                  }
              }
          }
      };
  
      cleanup(schema);
      visited.forEach(function (s) {
          delete s.___$visited;
      });
  
      this.lastReport = report;
      if (report.isValid()) {
          return schema;
      } else {
          throw this.getLastError();
      }
  };
  
  /**
   *
   * @param {*} schemaReader
   *
   * @returns {void}
   */
  ZSchema.prototype.setSchemaReader = function (schemaReader) {
      return ZSchema.setSchemaReader(schemaReader);
  };
  
  ZSchema.prototype.getSchemaReader = function () {
      return ZSchema.schemaReader;
  };
  
  ZSchema.schemaReader = undefined;
  /*
      static methods
  */
  ZSchema.setSchemaReader = function (schemaReader) {
      ZSchema.schemaReader = schemaReader;
  };
  ZSchema.registerFormat = function (formatName, validatorFunction) {
      FormatValidators[formatName] = validatorFunction;
  };
  ZSchema.unregisterFormat = function (formatName) {
      delete FormatValidators[formatName];
  };
  ZSchema.getRegisteredFormats = function () {
      return Object.keys(FormatValidators);
  };
  ZSchema.getDefaultOptions = function () {
      return Utils.cloneDeep(defaultOptions);
  };
  
  ZSchema.schemaSymbol = Utils.schemaSymbol;
  
  ZSchema.jsonSymbol = Utils.jsonSymbol;
  
  module.exports = ZSchema;
  
  }).call(this,require('_process'))
  
  },{"./FormatValidators":233,"./JsonValidation":234,"./Polyfills":235,"./Report":236,"./SchemaCache":237,"./SchemaCompilation":238,"./SchemaValidation":239,"./Utils":240,"./schemas/hyper-schema.json":242,"./schemas/schema.json":243,"_process":125,"lodash.get":120}],242:[function(require,module,exports){
  module.exports={
      "$schema": "http://json-schema.org/draft-04/hyper-schema#",
      "id": "http://json-schema.org/draft-04/hyper-schema#",
      "title": "JSON Hyper-Schema",
      "allOf": [
          {
              "$ref": "http://json-schema.org/draft-04/schema#"
          }
      ],
      "properties": {
          "additionalItems": {
              "anyOf": [
                  {
                      "type": "boolean"
                  },
                  {
                      "$ref": "#"
                  }
              ]
          },
          "additionalProperties": {
              "anyOf": [
                  {
                      "type": "boolean"
                  },
                  {
                      "$ref": "#"
                  }
              ]
          },
          "dependencies": {
              "additionalProperties": {
                  "anyOf": [
                      {
                          "$ref": "#"
                      },
                      {
                          "type": "array"
                      }
                  ]
              }
          },
          "items": {
              "anyOf": [
                  {
                      "$ref": "#"
                  },
                  {
                      "$ref": "#/definitions/schemaArray"
                  }
              ]
          },
          "definitions": {
              "additionalProperties": {
                  "$ref": "#"
              }
          },
          "patternProperties": {
              "additionalProperties": {
                  "$ref": "#"
              }
          },
          "properties": {
              "additionalProperties": {
                  "$ref": "#"
              }
          },
          "allOf": {
              "$ref": "#/definitions/schemaArray"
          },
          "anyOf": {
              "$ref": "#/definitions/schemaArray"
          },
          "oneOf": {
              "$ref": "#/definitions/schemaArray"
          },
          "not": {
              "$ref": "#"
          },
  
          "links": {
              "type": "array",
              "items": {
                  "$ref": "#/definitions/linkDescription"
              }
          },
          "fragmentResolution": {
              "type": "string"
          },
          "media": {
              "type": "object",
              "properties": {
                  "type": {
                      "description": "A media type, as described in RFC 2046",
                      "type": "string"
                  },
                  "binaryEncoding": {
                      "description": "A content encoding scheme, as described in RFC 2045",
                      "type": "string"
                  }
              }
          },
          "pathStart": {
              "description": "Instances' URIs must start with this value for this schema to apply to them",
              "type": "string",
              "format": "uri"
          }
      },
      "definitions": {
          "schemaArray": {
              "type": "array",
              "items": {
                  "$ref": "#"
              }
          },
          "linkDescription": {
              "title": "Link Description Object",
              "type": "object",
              "required": [ "href", "rel" ],
              "properties": {
                  "href": {
                      "description": "a URI template, as defined by RFC 6570, with the addition of the $, ( and ) characters for pre-processing",
                      "type": "string"
                  },
                  "rel": {
                      "description": "relation to the target resource of the link",
                      "type": "string"
                  },
                  "title": {
                      "description": "a title for the link",
                      "type": "string"
                  },
                  "targetSchema": {
                      "description": "JSON Schema describing the link target",
                      "$ref": "#"
                  },
                  "mediaType": {
                      "description": "media type (as defined by RFC 2046) describing the link target",
                      "type": "string"
                  },
                  "method": {
                      "description": "method for requesting the target of the link (e.g. for HTTP this might be \"GET\" or \"DELETE\")",
                      "type": "string"
                  },
                  "encType": {
                      "description": "The media type in which to submit data along with the request",
                      "type": "string",
                      "default": "application/json"
                  },
                  "schema": {
                      "description": "Schema describing the data to submit along with the request",
                      "$ref": "#"
                  }
              }
          }
      }
  }
  
  
  },{}],243:[function(require,module,exports){
  module.exports={
      "id": "http://json-schema.org/draft-04/schema#",
      "$schema": "http://json-schema.org/draft-04/schema#",
      "description": "Core schema meta-schema",
      "definitions": {
          "schemaArray": {
              "type": "array",
              "minItems": 1,
              "items": { "$ref": "#" }
          },
          "positiveInteger": {
              "type": "integer",
              "minimum": 0
          },
          "positiveIntegerDefault0": {
              "allOf": [ { "$ref": "#/definitions/positiveInteger" }, { "default": 0 } ]
          },
          "simpleTypes": {
              "enum": [ "array", "boolean", "integer", "null", "number", "object", "string" ]
          },
          "stringArray": {
              "type": "array",
              "items": { "type": "string" },
              "minItems": 1,
              "uniqueItems": true
          }
      },
      "type": "object",
      "properties": {
          "id": {
              "type": "string",
              "format": "uri"
          },
          "$schema": {
              "type": "string",
              "format": "uri"
          },
          "title": {
              "type": "string"
          },
          "description": {
              "type": "string"
          },
          "default": {},
          "multipleOf": {
              "type": "number",
              "minimum": 0,
              "exclusiveMinimum": true
          },
          "maximum": {
              "type": "number"
          },
          "exclusiveMaximum": {
              "type": "boolean",
              "default": false
          },
          "minimum": {
              "type": "number"
          },
          "exclusiveMinimum": {
              "type": "boolean",
              "default": false
          },
          "maxLength": { "$ref": "#/definitions/positiveInteger" },
          "minLength": { "$ref": "#/definitions/positiveIntegerDefault0" },
          "pattern": {
              "type": "string",
              "format": "regex"
          },
          "additionalItems": {
              "anyOf": [
                  { "type": "boolean" },
                  { "$ref": "#" }
              ],
              "default": {}
          },
          "items": {
              "anyOf": [
                  { "$ref": "#" },
                  { "$ref": "#/definitions/schemaArray" }
              ],
              "default": {}
          },
          "maxItems": { "$ref": "#/definitions/positiveInteger" },
          "minItems": { "$ref": "#/definitions/positiveIntegerDefault0" },
          "uniqueItems": {
              "type": "boolean",
              "default": false
          },
          "maxProperties": { "$ref": "#/definitions/positiveInteger" },
          "minProperties": { "$ref": "#/definitions/positiveIntegerDefault0" },
          "required": { "$ref": "#/definitions/stringArray" },
          "additionalProperties": {
              "anyOf": [
                  { "type": "boolean" },
                  { "$ref": "#" }
              ],
              "default": {}
          },
          "definitions": {
              "type": "object",
              "additionalProperties": { "$ref": "#" },
              "default": {}
          },
          "properties": {
              "type": "object",
              "additionalProperties": { "$ref": "#" },
              "default": {}
          },
          "patternProperties": {
              "type": "object",
              "additionalProperties": { "$ref": "#" },
              "default": {}
          },
          "dependencies": {
              "type": "object",
              "additionalProperties": {
                  "anyOf": [
                      { "$ref": "#" },
                      { "$ref": "#/definitions/stringArray" }
                  ]
              }
          },
          "enum": {
              "type": "array",
              "minItems": 1,
              "uniqueItems": true
          },
          "type": {
              "anyOf": [
                  { "$ref": "#/definitions/simpleTypes" },
                  {
                      "type": "array",
                      "items": { "$ref": "#/definitions/simpleTypes" },
                      "minItems": 1,
                      "uniqueItems": true
                  }
              ]
          },
          "format": { "type": "string" },
          "allOf": { "$ref": "#/definitions/schemaArray" },
          "anyOf": { "$ref": "#/definitions/schemaArray" },
          "oneOf": { "$ref": "#/definitions/schemaArray" },
          "not": { "$ref": "#" }
      },
      "dependencies": {
          "exclusiveMaximum": [ "maximum" ],
          "exclusiveMinimum": [ "minimum" ]
      },
      "default": {}
  }
  
  },{}]},{},[1])(1)
  });
  //# sourceMappingURL=swagger-parser.js.map
  